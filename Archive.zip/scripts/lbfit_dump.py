"""Dump logits of every leaderboard-scored checkpoint on fixed forget-set views, so gold hypotheses can be tested
against the leaderboard offline (scripts/lbfit.py). CPU or GPU.

Views (fixed, deterministic): clean forget images (subset --n), one 'mild' augmented copy (common.augment, CPU generator).
Writes output/lbfit/<key>.pt = {"clean": [n,100] fp16, "mild": [n,100] fp16}; idx subset in output/lbfit/idx.pt.
Usage: python scripts/lbfit_dump.py [--n 1200 --threads 48]
"""
import argparse, csv, sys, time
from pathlib import Path
import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=1200)
ap.add_argument("--threads", type=int, default=48)
ap.add_argument("--extra", default="", help="comma list of extra ckpt paths to dump (e.g. not-yet-submitted)")
a = ap.parse_args()
torch.set_num_threads(a.threads)
dev = "cuda" if torch.cuda.is_available() else "cpu"
OUT = C.ROOT / "output" / "lbfit"
OUT.mkdir(exist_ok=True)

imgs = torch.from_numpy(np.load(C.ROOT / "forget_images.npz")["images"])
g = torch.Generator().manual_seed(0)
idx = torch.randperm(len(imgs), generator=g)[:a.n].sort().values
torch.save(idx, OUT / "idx.pt")
x_clean = C.norm(C.u8_to01(imgs[idx]))
g2 = torch.Generator().manual_seed(1)
x_mild = torch.cat([C.norm(C.augment(C.u8_to01(imgs[idx[i:i + 200]]), g2, scale=(0.6, 1.0), rot_deg=10,
                                      bright=0.2, contrast=0.2, noise=0.05)) for i in range(0, len(idx), 200)])

import glob as _glob
def _last1000(pat):
    files = sorted(f for f in _glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
    return torch.from_numpy(np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in files])[-1000:])
DRIFT = {"tw875": C.norm(C.u8_to01(_last1000("output/twins/s0.875_sh*.npz"))),
         "tw625": C.norm(C.u8_to01(_last1000("output/twins/s0.625b_sh*.npz"))),
         "out": C.norm(C.u8_to01(torch.from_numpy(np.load(C.ROOT / "output/outside_task1/images_224.npz")["images"])))}
ckpts = {"orig": C.ROOT / "model.pt"}
with open(C.ROOT / "output" / "submissions.csv") as f:
    for r in csv.DictReader(f):
        if r["score"]:
            p = C.ROOT / r["file"]
            if p.exists():
                ckpts[r["file"].replace("output/", "").replace("/", "__").replace(".pt", "")] = p
for e in filter(None, a.extra.split(",")):
    ckpts[e.replace("output/", "").replace("/", "__").replace(".pt", "")] = C.ROOT / e

model = C.tt.build_model().to(dev).eval()
for k, p in ckpts.items():
    o = OUT / f"{k}.pt"
    od = OUT / "drift" / f"{k}.pt"
    od.parent.mkdir(exist_ok=True)
    if o.exists() and od.exists():
        continue
    t0 = time.time()
    model.load_state_dict(torch.load(p, map_location="cpu", weights_only=True), strict=True)
    res = {}
    views = [] if o.exists() else [("clean", x_clean), ("mild", x_mild)]
    views += list(DRIFT.items())
    with torch.no_grad():
        for name, x in views:
            outs = []
            for i in range(0, len(x), 100):
                xb = x[i:i + 100].to(dev)
                if dev == "cuda":
                    with torch.autocast("cuda", dtype=torch.float16):
                        outs.append(model(xb).float().cpu())
                else:
                    outs.append(model(xb).float())
            res[name] = torch.cat(outs).half()
    if not o.exists():
        torch.save({k2: res[k2] for k2 in ("clean", "mild")}, o)
    torch.save({k2: res[k2] for k2 in DRIFT}, od)
    print(f"{k}: {time.time() - t0:.0f}s", flush=True)
