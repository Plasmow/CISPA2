"""Check float residual == embed() up to rounding, then AUC of residual-based maps vs GT (40 train imgs/method)."""
import sys, time
import numpy as np, torch
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT, auc
from residual import residual_float, feature_maps

ds = load_split("train"); rng = np.random.RandomState(0)
for meth in ("pixelseal", "trustmark", "stegastamp"):
    wm = load_watermark(meth, KIT / "models", "cuda")
    it = ds[[i for i, m in enumerate(ds.meta) if m["method"] == meth][0]]
    r = residual_float(wm, it["image"], it["message"]).cpu().numpy().transpose(1, 2, 0)
    ref = wm.embed(it["image"], it["message"]).astype(np.float32) - it["image"]
    rec = np.clip(it["image"] + r, 0, 255)
    print(f"{meth}: |r| mean={np.abs(r).mean():.3f} std={r.std():.3f} | max|round-trip - embed()|="
          f"{np.abs(np.trunc(rec) - it['image'] - ref).max():.1f}, frac mismatch={(np.abs(np.trunc(rec) - it['image'] - ref) > 0.5).mean():.4f}", flush=True)
    idx_t = [i for i, m in enumerate(ds.meta) if m["method"] == meth and m["full_watermark"]]
    idx_f = [i for i, m in enumerate(ds.meta) if m["method"] == meth and not m["full_watermark"]]
    M, G, Fl = {}, [], []; t = time.time()
    for i in list(rng.permutation(idx_t)[:20]) + list(rng.permutation(idx_f)[:20]):
        it = ds[i]; maps, _ = feature_maps(wm, it["image"], it["message"])
        for k, v in maps.items(): M.setdefault(k, []).append(v)
        G.append(it["mask128"]); Fl.append(it["full_watermark"])
    G = np.stack(G).astype(bool); Fl = np.array(Fl)
    print(f"  {meth} {time.time()-t:.1f}s for 40 imgs")
    for k, v in M.items():
        v = np.stack(v)
        print(f"  {k:12s} AUC all={auc(v, G):.3f}  full=T={auc(v[Fl], G[Fl]):.3f}  full=F={auc(v[~Fl], G[~Fl]):.3f} | "
              f"mean in GT={v[G].mean():.3f} out={v[~G].mean():.3f}", flush=True)
