#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:30:00
#SBATCH --job-name=wm_wmunetT
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/runs/wmunetT/slurm_%j.out
# Agent B: wm-U-Net specialised for type T (stack/wm_unet_T.py). Maps only: no fusion, no submission, nothing uploaded.
# dc-gpu-devel: nodes OUTSIDE the cispahack reservation. Submit from the team folder, then check
#   scontrol show job <id> | grep Reservation      (must be empty)
# Each GPU runs a chain; the first run of each chain is the priority, the second one is a bonus (seed / init variant).
# One run = T-oriented synthetic phase + 5-fold fine-tuning (same folds as every source), variants
#   <tag> (T weighted x3) and <tag>o (T images only); synthetic-only map <tag>0. ~15-20 min per run (previous jobs: 8-13 min).
#   GPU0: PixelSeal  wmunetT  (4000 T-synth steps from scratch)        -> PixelSeal  wmunetT2 (2nd seed)
#   GPU1: TrustMark  wmunetT                                         -> TrustMark  wmunetT2 (2nd seed)
#   GPU2: PixelSeal  wmunetTi (init wmunet checkpoint + 1500 T-synth) -> TrustMark  wmunetTi
#   GPU3: StegaStamp wmunetT                                         -> StegaStamp wmunetTi (init wmunetH checkpoint)
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }
INIT="--steps 1500 --freeze_steps 0 --lr 1e-4"

( CUDA_VISIBLE_DEVICES=0 $PY wm_unet_T.py --method pixelseal  --tag wmunetT  --seed 0
  CUDA_VISIBLE_DEVICES=0 $PY wm_unet_T.py --method pixelseal  --tag wmunetT2 --seed 1 ) 2>&1 | tagged gpu0 &
( CUDA_VISIBLE_DEVICES=1 $PY wm_unet_T.py --method trustmark  --tag wmunetT  --seed 0
  CUDA_VISIBLE_DEVICES=1 $PY wm_unet_T.py --method trustmark  --tag wmunetT2 --seed 1 ) 2>&1 | tagged gpu1 &
( CUDA_VISIBLE_DEVICES=2 $PY wm_unet_T.py --method pixelseal  --tag wmunetTi --init wmunet  $INIT
  CUDA_VISIBLE_DEVICES=2 $PY wm_unet_T.py --method trustmark  --tag wmunetTi --init wmunet  $INIT ) 2>&1 | tagged gpu2 &
( CUDA_VISIBLE_DEVICES=3 $PY wm_unet_T.py --method stegastamp --tag wmunetT  --seed 0
  CUDA_VISIBLE_DEVICES=3 $PY wm_unet_T.py --method stegastamp --tag wmunetTi --init wmunetH $INIT ) 2>&1 | tagged gpu3 &
wait
ls -la --time-style=+%H:%M maps/wmunetT*
echo done
