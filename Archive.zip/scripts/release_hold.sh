#!/bin/bash
# When the worker job (15905119) is RUNNING, move staged items from output/queue/hold to pending.
cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
until [ "$(squeue -j 15905119 -h -o %T 2>/dev/null)" = "RUNNING" ]; do sleep 20; done
sleep 30
mv output/queue/hold/*.sh output/queue/pending/ 2>/dev/null
echo "$(date +%T) released $(ls output/queue/pending | wc -l) items"
