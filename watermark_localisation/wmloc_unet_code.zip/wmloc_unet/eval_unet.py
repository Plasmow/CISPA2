"""Evaluate the U-Net runs from their out-of-fold (OOF) predictions with the official per-image mIoU.

For every variant found in runs/ (all 5 folds present) and for the mean of all variants ("ensemble"):
  - mIoU at fixed threshold 0.5, per method and per regime
  - mIoU with a per-method threshold learned by 5-fold CV on the OOF maps (rule "single")
  - mIoU with the regime "switch" rule (whole-image score decides the regime, one threshold per regime), CV
Also writes runs/<variant>/oof_all.npz (train, aligned with metadata order) and test_mean.npz (mean over folds),
which are the maps to reuse later in the fusion.
"""
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TASK = Path(os.environ.get("WMLOC_TASK", "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task"))   # data root (release/, starter_kit/, loc/)
sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(TASK / "starter_kit"))
from wmloc.data import LocalisationDataset  # noqa: E402
from wmloc.utils import miou_image  # noqa: E402
from evalkit import cv_eval  # noqa: E402

METHODS = ("pixelseal", "trustmark", "stegastamp")


def collect(variant):
    d = HERE / "runs" / variant
    fs = sorted(d.glob("fold*/oof.npz"))
    if len(fs) < 5:
        return None
    oof = {}
    for f in fs:
        z = np.load(f); oof.update(zip(z["names"].tolist(), z["prob"].astype(np.float32)))
    tz = [np.load(f.parent / "test.npz") for f in fs]
    test_names = tz[0]["names"]; assert all((t["names"] == test_names).all() for t in tz)
    test = np.mean([t["prob"].astype(np.float32) for t in tz], 0)
    return oof, test_names, test


def main():
    ds = LocalisationDataset(TASK / "release", "train")
    names = [m["image_name"] for m in ds.meta]; meth = np.array([m["method"] for m in ds.meta])
    full = np.array([m["full_watermark"] for m in ds.meta]); gt = np.stack([ds.m128[n] for n in names]).astype(bool)
    gl = np.load(TASK / "loc" / "cache" / "global_train.npy", allow_pickle=True).item()
    lut = {n: l for mm in METHODS for n, l in zip(gl[mm]["names"], gl[mm]["logits"])}
    g = np.array([(lut[n] * (np.array([int(c) for c in m["message"]]) * 2 - 1)).mean() for n, m in zip(names, ds.meta)])

    maps = {}
    for v in sorted(p.name for p in (HERE / "runs").iterdir() if p.is_dir()):
        r = collect(v)
        if r is None:
            print(f"skip {v} (incomplete)"); continue
        oof, tn, test = r
        maps[v] = (np.stack([oof[n] for n in names]), tn, test)
        np.savez(HERE / "runs" / v / "oof_all.npz", names=np.array(names), prob=maps[v][0].astype(np.float16))
        np.savez(HERE / "runs" / v / "test_mean.npz", names=tn, prob=test.astype(np.float16))
    if len(maps) > 1:
        maps["ensemble"] = (np.mean([m[0] for m in maps.values()], 0), maps[next(iter(maps))][1],
                            np.mean([m[2] for m in maps.values()], 0))

    lines = ["Baselines (CV): whole-image score threshold = 0.4512 | regime oracle = 0.4547", "",
             "| variant | mIoU@0.5 | pixelseal | trustmark | stegastamp | full=T | full=F | CV thr/method | CV switch/method |",
             "|---|---|---|---|---|---|---|---|---|"]
    for v, (prob, _, _) in maps.items():
        s05 = np.array([miou_image(p > 0.5, t) for p, t in zip(prob, gt)])
        cv_single, cv_switch = [], []
        for m in METHODS:
            i = meth == m
            cv_single.append(cv_eval(prob[i], gt[i], g[i], "single").mean())
            cv_switch.append(cv_eval(prob[i], gt[i], g[i], "switch").mean())
        per = " | ".join(f"{s05[meth == m].mean():.4f}" for m in METHODS)
        lines.append(f"| {v} | **{s05.mean():.4f}** | {per} | {s05[full].mean():.4f} | {s05[~full].mean():.4f} | "
                     f"{np.mean(cv_single):.4f} | {np.mean(cv_switch):.4f} |")
    txt = "\n".join(lines); print(txt)
    (HERE / "results_unet.md").write_text(txt + "\n")


if __name__ == "__main__":
    main()
