"""Guided rectangle search (CPU): seeds from the v3 fused maps instead of a blind grid, then local refinement with
the decoder, down to 1 px (StegaStamp needs +-2 px).

Images: whole-image bit acc < --gacc (probable type F), same selection as the teammate's blind search ('lowacc').
Seeds: bounding boxes of the predicted region of the fused map (maps/fused_<split>_<method>.npz) at several
thresholds (whole region + 2 largest components), plus the teammate's blind-search box when it exists (read-only,
loc/cache/rect_*). Score of a box = bit acc (+ 1e-3 x signed confidence) of its crop resized to the decoder input
(same crop/resize as loc/rect_search.py). Refinement: coordinate ascent over the 4 edges and joint shifts, steps
16, 8, 4, 2, 1 px, on the 3 best seeds.
Output: maps/rect_<method>_<split>_guided.npz (names, boxes y0 y1 x0 x1, acc, conf, seed_acc). Read by v3.py --rect.

    python guided_rect.py stegastamp test --nproc 12
"""
import argparse
import glob
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc"))
from common import load_split, load_watermark, KIT, CACHE  # noqa: E402

RES = {"pixelseal": 256, "trustmark": 245, "stegastamp": 400}
MODE = {"pixelseal": "bilinear", "trustmark": "bilinear", "stegastamp": "bicubic"}
MAXAR = {"pixelseal": 16.0, "trustmark": 2.0, "stegastamp": 16.0}
MINSIDE = 24
G = {}   # per-process globals


def valid(b, meth):
    y0, y1, x0, x1 = b; h, w = y1 - y0, x1 - x0
    return 0 <= y0 and y1 <= 512 and 0 <= x0 and x1 <= 512 and h >= MINSIDE and w >= MINSIDE and max(h, w) / min(h, w) <= MAXAR[meth]


def fix(b, meth):
    """Clip to the image and to the aspect-ratio limit (shrink the long side around its centre)."""
    y0, y1, x0, x1 = [int(v) for v in b]
    y0, x0 = max(0, y0), max(0, x0); y1, x1 = min(512, y1), min(512, x1)
    h, w = y1 - y0, x1 - x0
    if h < MINSIDE or w < MINSIDE:
        return None
    if h / w > MAXAR[meth]:
        c = (y0 + y1) / 2; h = int(w * MAXAR[meth]); y0, y1 = int(c - h / 2), int(c - h / 2) + h
    elif w / h > MAXAR[meth]:
        c = (x0 + x1) / 2; w = int(h * MAXAR[meth]); x0, x1 = int(c - w / 2), int(c - w / 2) + w
    b = (y0, y1, x0, x1)
    return b if valid(b, meth) else None


def init(meth, split, threads):
    torch.set_num_threads(threads)
    G["meth"] = meth; G["wm"] = load_watermark(meth, KIT / "models", "cpu"); G["ds"] = load_split(split, [meth])
    if meth == "stegastamp":                           # the wrapper builds its ONNX session with 4 threads
        pass


@torch.no_grad()
def score(x, boxes, sgn):
    meth = G["meth"]; R = RES[meth]
    batch = torch.stack([F.interpolate(x[None, :, y0:y1, x0:x1], size=(R, R), mode=MODE[meth], align_corners=False,
                                       antialias=True)[0] for (y0, y1, x0, x1) in boxes]).clamp_(0, 1)
    L = G["wm"].logits(batch).float().cpu(); s = L * sgn
    return (s > 0).float().mean(1).numpy(), s.mean(1).numpy()


def refine(x, sgn, seed, key):
    meth = G["meth"]; best, bk = seed, key
    for step in (16, 8, 4, 2, 1):
        while True:
            cands = []
            for e in range(4):
                for d in (-step, step):
                    b = list(best); b[e] += d; cands.append(tuple(b))
            for d in (-step, step):                    # joint shifts (keep the size)
                cands.append((best[0] + d, best[1] + d, best[2], best[3])); cands.append((best[0], best[1], best[2] + d, best[3] + d))
            cands = [c for c in cands if valid(c, meth)]
            if not cands:
                break
            acc, conf = score(x, cands, sgn); keys = acc + 1e-3 * conf; j = int(keys.argmax())
            if keys[j] > bk + 1e-6:
                best, bk = cands[j], float(keys[j])
            else:
                break
    return best, bk


def work(args):
    i, seeds = args; meth = G["meth"]; it = G["ds"][i]
    x = torch.from_numpy(np.array(it["image"])).permute(2, 0, 1).float().div(255)
    sgn = torch.as_tensor(it["message"].astype(np.float32) * 2 - 1)
    seeds = [s for s in (fix(b, meth) for b in seeds) if s is not None]
    seeds = list(dict.fromkeys(seeds))
    if not seeds:
        return it["image_name"], (0, 512, 0, 512), 0.0, 0.0, 0.0
    acc, conf = score(x, seeds, sgn); keys = acc + 1e-3 * conf; order = np.argsort(-keys)
    best, bk = None, -1.0
    for j in order[:3]:
        b, k = refine(x, sgn, seeds[j], float(keys[j]))
        if k > bk:
            best, bk = b, k
    fa, fc = score(x, [best], sgn)
    return it["image_name"], best, float(fa[0]), float(fc[0]), float(acc.max())


def seeds_from_map(P):
    """Bounding boxes (512 px) of the predicted region at several thresholds: whole region + 2 largest components."""
    out = []
    for thr in (0.3, 0.5, 0.7):
        m = P > thr
        if m.sum() < 4:
            continue
        ys, xs = np.nonzero(m); out.append((ys.min() * 4, (ys.max() + 1) * 4, xs.min() * 4, (xs.max() + 1) * 4))
        lab, n = ndi.label(m)
        if n > 1:
            sizes = ndi.sum(m, lab, range(1, n + 1))
            for k in np.argsort(-sizes)[:2]:
                ys, xs = np.nonzero(lab == k + 1); out.append((ys.min() * 4, (ys.max() + 1) * 4, xs.min() * 4, (xs.max() + 1) * 4))
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("method"); ap.add_argument("split")
    ap.add_argument("--gacc", type=float, default=0.8); ap.add_argument("--nproc", type=int, default=12)
    ap.add_argument("--threads", type=int, default=4); ap.add_argument("--nmax", type=int, default=10 ** 9)
    a = ap.parse_args(); meth, split = a.method, a.split
    ds = load_split(split, [meth]); names = [m["image_name"] for m in ds.meta]
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item()[meth]; lut = dict(zip(gl["names"], gl["logits"]))
    gacc = np.array([((lut[n] > 0) == np.array([int(c) for c in m["message"]])).mean() for n, m in zip(names, ds.meta)])
    fz = np.load(HERE / "maps" / f"fused_{split}_{meth}.npz"); fmap = dict(zip(fz["names"].tolist(), fz["logit128"].astype(np.float32)))
    blind = {}
    for f in glob.glob(str(CACHE / f"rect_{meth}_{split}_*.npz")):    # teammate's blind-search boxes, as extra seeds
        d = np.load(f); blind.update({str(n): tuple(int(v) for v in b) for n, b in zip(d["names"], d["boxes"])})
    idx = [i for i in range(len(names)) if gacc[i] < a.gacc][:a.nmax]
    tasks = [(i, seeds_from_map(1 / (1 + np.exp(-fmap[names[i]]))) + ([blind[names[i]]] if names[i] in blind else [])) for i in idx]
    print(f"{meth} {split}: {len(tasks)} images (whole-image bit acc < {a.gacc}), {sum(names[i] in blind for i in idx)} with a blind box", flush=True)
    t = time.time(); res = []
    with Pool(a.nproc, initializer=init, initargs=(meth, split, a.threads)) as pool:
        for k, r in enumerate(pool.imap_unordered(work, tasks)):
            res.append(r)
            if (k + 1) % 20 == 0 or k + 1 == len(tasks):
                accs = np.array([x[2] for x in res])
                print(f"  {k + 1}/{len(tasks)} {(time.time() - t) / (k + 1):.1f}s/img | acc>=0.85: {np.mean(accs >= 0.85):.0%} | "
                      f"seed acc -> refined acc (median): {np.median([x[4] for x in res]):.3f} -> {np.median(accs):.3f}", flush=True)
    np.savez(HERE / "maps" / f"rect_{meth}_{split}_guided.npz", names=np.array([r[0] for r in res]),
             boxes=np.array([r[1] for r in res]), acc=np.array([r[2] for r in res]), conf=np.array([r[3] for r in res]),
             seed_acc=np.array([r[4] for r in res]))


if __name__ == "__main__":
    main()
