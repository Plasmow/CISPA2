#!/bin/bash
# Start from SCRUB C@240 (best leaderboard ckpt, 0.1152) and distill briefly toward twin-based targets:
# keep SCRUB's forgetting level, fix WHICH wrong class it picks. Checkpoints every 27 steps (half an epoch).
INIT=output/scrubB_C_lr3e-5_T4/ckpt_00240.pt
T=output/targets
COMMON="--init $INIT --epochs 3 --lr 3e-5 --clean_frac 0.5 --eval_every 27 --warmup 10"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON "$@" > output/$name.log 2>&1 & }
run 0 si_tw0.625      --target $T/tw0.625.pt
run 1 si_tw0.625_geo  --target $T/tw0.625.pt --agg geo
run 2 si_hy625_m2_s3  --target $T/a1_m2_s3_T1.5_w1_tw625.pt
run 3 si_hy_m2_s3     --target $T/a1_m2_s3_T1.5_w1_tw.pt
wait
