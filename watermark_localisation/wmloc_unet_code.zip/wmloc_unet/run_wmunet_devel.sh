#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:00:00
#SBATCH --job-name=wm_wmunet_dev
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/wmunet_dev_%j.out
# dc-gpu-devel: 12 nodes OUTSIDE the cispahack reservation (no node in common), account training2666 allowed,
# QoS part_dc_gpu_devel (2 h max). Allowed by the organisers: non-reservation jobs do not count toward the team's node.
# Submit from the team folder; after start check:  scontrol show job <id> | grep Reservation   (must be empty)
#
# U-Net whose encoder is the watermark decoder (stack/wm_unet.py): synthetic pre-training, then 5-fold fine-tuning.
# GPU0/1: PixelSeal / TrustMark, encoder frozen 2000 steps then lr 1e-5   (tag wmunet)
# GPU2/3: PixelSeal / TrustMark, encoder always frozen                    (tag wmunetF)
# Then the v3 fusion with the new sources (candidate file only, NOT uploaded).
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }

CUDA_VISIBLE_DEVICES=0 $PY wm_unet.py --method pixelseal --steps 6000 --freeze_steps 2000 --tag wmunet  2>&1 | tagged gpu0 &
CUDA_VISIBLE_DEVICES=1 $PY wm_unet.py --method trustmark --steps 6000 --freeze_steps 2000 --tag wmunet  2>&1 | tagged gpu1 &
CUDA_VISIBLE_DEVICES=2 $PY wm_unet.py --method pixelseal --steps 6000 --freeze_steps -1   --tag wmunetF 2>&1 | tagged gpu2 &
CUDA_VISIBLE_DEVICES=3 $PY wm_unet.py --method trustmark --steps 6000 --freeze_steps -1   --tag wmunetF 2>&1 | tagged gpu3 &
wait

CUDA_VISIBLE_DEVICES="" $PY v3.py --rect --extras headmulti remark headsyn headsyn2 wmunet wmunet0 wmunetF wmunetF0 \
  --out ../submissions/submission_v4_wmunet.pt --baseline_cv 9 2>&1 | grep -v -i warn
echo done
