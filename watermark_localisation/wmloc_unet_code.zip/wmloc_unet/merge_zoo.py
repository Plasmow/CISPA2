"""Merge fold outputs of the given runs into runs/<v>/oof_all.npz + test_mean.npz (same logic as eval_unet.collect),
only for the listed variants (eval_unet.py would rewrite every run). Prints the switch CV per method.
    python merge_zoo.py zeffb4_hp_glob_stack zhrw18_hp_glob_stack ..."""
import sys
from pathlib import Path
import numpy as np
HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "starter_kit")); sys.path.insert(0, str(TASK / "loc"))
from wmloc.data import LocalisationDataset  # noqa: E402
from eval_unet import collect  # noqa: E402

ds = LocalisationDataset(TASK / "release", "train")
names = [m["image_name"] for m in ds.meta]
for v in sys.argv[1:]:
    r = collect(v)
    if r is None:
        print(f"{v}: INCOMPLETE ({len(list((HERE / 'runs' / v).glob('fold*/oof.npz')))} folds)"); continue
    oof, tn, test = r
    np.savez(HERE / "runs" / v / "oof_all.npz", names=np.array(names), prob=np.stack([oof[n] for n in names]).astype(np.float16))
    np.savez(HERE / "runs" / v / "test_mean.npz", names=tn, prob=test.astype(np.float16))
    print(f"{v}: merged")
