"""Decode every SAM segment with the official decoder, to rank the segments of regime-F images (CPU pilot / GPU full pass).

For each eligible image (regime F: whole-image bit acc < 0.8, no decoder rectangle above the version's thresholds, SAM
candidates in loc/cache/sam_cands, read-only) and each candidate segment c (128 grid -> 512 nearest neighbour):
    x_c = image where c = 1, FILL elsewhere ; decoded at 512 by the official wrapper preprocessing (no crop, no rescale
    beyond the wrapper's own resize; StegaStamp: PyTorch port of the ONNX graph incl. the STN, 400 bicubic antialias).
FILLS: gray (0.5), blur (Gaussian sigma 8 of the image), mean (mean colour of the image).
Scores per candidate and fill:
    conf   mean over bits of logits * (2 msg - 1)                       (a)
    acc    bit accuracy                                                  (b)
    ppin   PixelSeal / TrustMark: per-position signed confidence averaged over the positions covered by c   (c)
    ppdiff ppin - the same average over the positions NOT covered by c
    *0     the same minus the value for the fully filled image ("nothing") (d) -- identical ranking within an image
plus the area of c.
Pilot (--pilot N): N F-seg train images per method; reports, per method and fill, the within-image AUC (good segment =
IoU with the truth > 0.7 vs the others), the median rank of the truly best segment, and the mIoU of the top-1 segment vs
snap_sam's choice (soft IoU x contrast on the v9 OOF map) and vs the v9 OOF mask.

    OMP_NUM_THREADS=8 python seg_decode.py --pilot 20 --dev cpu          # pilot, writes maps/segdec_pilot_train_<m>.npz
    python seg_decode.py --split test --methods pixelseal --dev cuda      # full pass, writes maps/segdec_<split>_<m>.npz
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

sys_argv = sys.argv; sys.argv = sys.argv[:1]
import sam_rank as SR                                            # noqa: E402  (global_acc, load_cands, feats)
sys.argv = sys_argv
from v3 import HERE, ROOT, METHODS, load_rect, load_split  # noqa: E402
from common import load_watermark, KIT  # noqa: E402
from evalkit import miou_batch  # noqa: E402

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
FILLS = ("gray", "blur", "mean")


def auc_within(s, good):
    """AUC of score s separating good (True) from bad candidates of ONE image (ties averaged); nan if one class is empty."""
    if good.all() or not good.any():
        return np.nan
    from scipy.stats import rankdata
    r = rankdata(s); n1 = good.sum(); n0 = (~good).sum()
    return (r[good].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)


class Dec:
    def __init__(self, meth, dev):
        self.meth, self.dev = meth, dev
        if meth == "stegastamp":
            from stega_torch import StegaDecoder
            self.net = StegaDecoder().to(dev).eval()
        else:
            self.wm = load_watermark(meth, KIT / "models", dev)

    @torch.no_grad()
    def __call__(self, x, sgn):
        """x [B,3,512,512] in [0,1] -> conf [B], acc [B], per-position signed confidence [B,h,w] (None for StegaStamp)."""
        if self.meth == "stegastamp":
            x4 = F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
            s = self.net(x4).float() * sgn
            return s.mean(1).cpu().numpy(), (s > 0).float().mean(1).cpu().numpy(), None
        pp = self.wm.features(x)["per_position_logits"].float()                    # [B, nbits, h, w]
        s = pp.mean((2, 3)) * sgn                                                     # global logits = mean of per-position
        ppc = (pp * sgn[:, :, None, None]).mean(1)                                    # [B, h, w]
        return s.mean(1).cpu().numpy(), (s > 0).float().mean(1).cpu().numpy(), ppc.cpu().numpy()


def fills_of(img):
    """img [3,512,512] float -> dict fill -> [3,512,512]."""
    blur = np.stack([ndi.gaussian_filter(c, 8) for c in img])
    return {"gray": np.full_like(img, 0.5), "blur": blur, "mean": np.broadcast_to(img.mean((1, 2))[:, None, None], img.shape).copy()}


def score_image(dec, img, msg, C128, bs):
    """-> dict of arrays [K] (per fill) + area."""
    sgn = torch.as_tensor(msg.astype(np.float32) * 2 - 1, device=dec.dev)[None]
    K = len(C128); out = {"area": C128.reshape(K, -1).mean(1)}
    Fl = fills_of(img); x_img = torch.from_numpy(img).float()
    for fname, fill in Fl.items():
        fill_t = torch.from_numpy(fill).float()
        c0, a0, p0 = dec(fill_t[None].to(dec.dev), sgn)                              # fully filled image: the "nothing" reference
        conf, acc, ppin, ppdiff = np.zeros(K), np.zeros(K), np.zeros(K), np.zeros(K)
        for b in range(0, K, bs):
            seg = torch.from_numpy(C128[b:b + bs]).float()                            # [b,128,128]
            m512 = seg.repeat_interleave(4, 1).repeat_interleave(4, 2)[:, None]       # nearest neighbour 128 -> 512
            x = (m512 * x_img[None] + (1 - m512) * fill_t[None]).to(dec.dev)
            cf, ac, pp = dec(x, sgn.expand(len(x), -1))
            conf[b:b + bs], acc[b:b + bs] = cf, ac
            if pp is not None:
                h, w = pp.shape[1:]
                cov = F.adaptive_avg_pool2d(seg[:, None], (h, w))[:, 0].numpy()        # fraction of each position covered by c
                ppin[b:b + bs] = (pp * cov).sum((1, 2)) / np.maximum(cov.sum((1, 2)), 1e-6)
                ppdiff[b:b + bs] = ppin[b:b + bs] - (pp * (1 - cov)).sum((1, 2)) / np.maximum((1 - cov).sum((1, 2)), 1e-6)
        out[f"conf_{fname}"] = conf; out[f"acc_{fname}"] = acc; out[f"conf0_{fname}"] = conf - c0[0]
        if dec.meth != "stegastamp":
            out[f"ppin_{fname}"] = ppin; out[f"ppdiff_{fname}"] = ppdiff
            out[f"ppin0_{fname}"] = ppin - float(p0[0].mean())
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot", type=int, default=0, help="N F-seg train images per method (pilot mode)")
    ap.add_argument("--split", default="train"); ap.add_argument("--methods", nargs="+", default=list(METHODS))
    ap.add_argument("--dev", default="cpu"); ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--version", default="submission_v9"); a = ap.parse_args()
    split = "train" if a.pilot else a.split
    cfg = json.loads((ROOT / "submissions" / f"{a.version}.json").read_text())
    thr = {m: float(cfg[m]["rect"].split(">=")[1]) if cfg[m].get("rect", "none") != "none" else 9.0 for m in METHODS}
    rects = {n for m in METHODS for n, (_, acc) in load_rect(m, split).items() if acc >= thr[m]}
    gacc, meth_of = SR.global_acc(split); cands = SR.load_cands(split)
    typo = {r["name"]: r for r in json.loads((TASK / "loc" / "cache" / "typo_stats.json").read_text())} if split == "train" else {}
    sd = ROOT / "sam" / a.version
    if a.pilot:
        d = torch.load(sd / "probs_train_oof.pt", weights_only=True); probs = {n: np.asarray(x, np.float32).ravel() for n, x in zip(d["image_names"], d["probs"].numpy())}
        d = torch.load(sd / "masks_train_oof.pt", weights_only=True); base = {n: np.asarray(x).ravel().astype(bool) for n, x in zip(d["image_names"], d["masks"].numpy())}
    lines = []
    for meth in a.methods:
        ds = load_split(split, [meth]); dec = Dec(meth, a.dev)
        idx = [i for i, m in enumerate(ds.meta) if gacc[m["image_name"]] < 0.8 and m["image_name"] not in rects
               and m["image_name"] in cands and len(cands[m["image_name"]])]
        if a.pilot:
            idx = [i for i in idx if not typo[ds.meta[i]["image_name"]]["full"] and typo[ds.meta[i]["image_name"]]["fill_bbox"] < 0.99]
            idx = idx[:: max(1, len(idx) // a.pilot)][:a.pilot]
        rec = {"names": []}; t0 = time.time(); ev = []
        for k, i in enumerate(idx):
            it = ds[i]; n = it["image_name"]; img = np.asarray(it["image"], np.float32).transpose(2, 0, 1) / 255
            C = cands[n].reshape(-1, 128, 128)
            sc = score_image(dec, img, it["message"], C, a.bs)
            rec["names"].append(n)
            for key, v in sc.items():
                rec.setdefault(key, []).append(v.astype(np.float32))
            if a.pilot:
                gt = ds.m128[n].astype(bool)
                miou = miou_batch(C, np.broadcast_to(gt, C.shape))
                inter = (C & gt).reshape(len(C), -1).sum(1); union = (C | gt).reshape(len(C), -1).sum(1); iou = inter / np.maximum(union, 1)
                X, M = SR.feats(probs[n], base[n], cands[n], gacc[n], meth)
                j_rule = int(np.argmax(X[1:, 7])); v9 = miou_batch(base[n].reshape(1, 128, 128), gt[None])[0]
                ev.append(dict(sc=sc, miou=miou, good=iou > 0.7, rule=miou[j_rule], v9=v9))
            print(f"[{meth}] {k + 1}/{len(idx)} {n} K={len(C)} {(time.time() - t0) / (k + 1):.1f}s/img", flush=True)
        name = f"segdec_pilot_train_{meth}.npz" if a.pilot else f"segdec_{split}_{meth}.npz"
        np.savez(HERE / "maps" / name, **{k: np.array(v, dtype=object) if k != "names" else np.array(v) for k, v in rec.items()})
        if a.pilot and ev:
            keys = [k for k in ev[0]["sc"] if k != "area"] + ["area"]
            n_good = sum(e["good"].any() for e in ev)
            lines.append(f"\n**{meth}** : {len(ev)} images F-seg, dont {n_good} avec au moins un bon segment (IoU > 0.7). "
                         f"Règle actuelle (top-1) : {np.mean([e['rule'] for e in ev]):.4f} ; masque v9 OOF : {np.mean([e['v9'] for e in ev]):.4f} ; "
                         f"oracle segment : {np.mean([e['miou'].max() for e in ev]):.4f}\n")
            lines.append("| score | AUC intra-image | rang médian du meilleur segment | mIoU du top-1 |\n|---|---|---|---|")
            for key in keys:
                aucs = [auc_within(e["sc"][key], e["good"]) for e in ev]
                ranks = [int((e["sc"][key] > e["sc"][key][int(np.argmax(e["miou"]))]).sum()) + 1 for e in ev]
                top1 = [e["miou"][int(np.argmax(e["sc"][key]))] for e in ev]
                lines.append(f"| {key} | {np.nanmean(aucs):.3f} | {int(np.median(ranks))} / {int(np.median([len(e['miou']) for e in ev]))} | {np.mean(top1):.4f} |")
            print("\n".join(lines[-len(keys) - 2:]), flush=True)
    if a.pilot:
        (ROOT / "results_segdec_pilot.md").write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
