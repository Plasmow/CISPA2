"""Time score_windows on 10 train images per method (login GPU)."""
import sys, time
import numpy as np, torch
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT
from heatmap import score_windows, positions, SIZES
ds = load_split("train")
print("windows/img:", {w: len(positions(w)) ** 2 for w in SIZES}, "total", sum(len(positions(w)) ** 2 for w in SIZES))
for meth in ("pixelseal", "trustmark", "stegastamp"):
    wm = load_watermark(meth, KIT / "models", "cuda")
    idx = [i for i, m in enumerate(ds.meta) if m["method"] == meth][:11]
    it = ds[idx[0]]; score_windows(wm, it["image"], it["message"], meth)   # warm-up
    torch.cuda.synchronize(); t = time.time()
    for i in idx[1:]:
        it = ds[i]; score_windows(wm, it["image"], it["message"], meth)
    torch.cuda.synchronize(); dt = (time.time() - t) / 10
    n = 170 + 340
    print(f"{meth:10s} {dt:.2f} s/img -> {n} imgs (train+test) = {dt*n/60:.1f} min on this GPU", flush=True)
