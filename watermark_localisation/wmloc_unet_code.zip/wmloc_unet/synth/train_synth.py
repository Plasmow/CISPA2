"""Go / no-go test: train a U-Net ONLY on synthetic edits, evaluate zero-shot on the 510 real train images.

Synthetic samples come from generator.SynthGenerator (bank of COCO photos watermarked by the 3 methods, edits made on
the fly), produced by DataLoader workers. Model: UNet128 (ResNet34 by default) with high-pass input channels and the
method one-hot as the global vector (no detector score: the point is to see whether the network learns the
watermark from pixels). Loss BCE + soft mIoU, as for the real U-Net.

Zero-shot evaluation on real train images (never used for training): official mIoU at threshold 0.5, and with the
regime 'switch' rule (thresholds fitted by 5-fold CV on the real images, using the real whole-image score).
Outputs runs_synth/<name>/{model.pt, real_train_probs.npz, real_test_probs.npz, log.json}.

    python train_synth.py --name r34_hp --steps 3000
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, IterableDataset, get_worker_info

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(TASK / "starter_kit"))
from generator import SynthGenerator, METHODS  # noqa: E402
from unet import UNet128, miou_loss  # noqa: E402
from wmloc.data import LocalisationDataset  # noqa: E402
from evalkit import cv_eval, miou_batch  # noqa: E402


class SynthStream(IterableDataset):
    def __init__(self, seed, realistic=False):
        self.seed, self.realistic = seed, realistic

    def __iter__(self):
        wi = get_worker_info(); g = SynthGenerator(seed=self.seed + (wi.id if wi else 0), realistic=self.realistic)
        while True:
            s = g.sample()
            yield (torch.from_numpy(s["image"]).permute(2, 0, 1), torch.from_numpy(s["mask128"].astype(np.float32)),
                   METHODS.index(s["method"]), int(s["full_watermark"]))


def load_real(split):
    ds = LocalisationDataset(TASK / "release", split)
    imgs = torch.from_numpy(np.stack([np.asarray(ds[i]["image"]) for i in range(len(ds))])).permute(0, 3, 1, 2).contiguous()
    meth = np.array([METHODS.index(m["method"]) for m in ds.meta]); names = [m["image_name"] for m in ds.meta]
    gl = np.load(TASK / "loc" / "cache" / f"global_{split}.npy", allow_pickle=True).item()
    lut = {n: l for mm in METHODS for n, l in zip(gl[mm]["names"], gl[mm]["logits"])}
    g = np.array([(lut[n] * (np.array([int(c) for c in m["message"]]) * 2. - 1)).mean() for n, m in zip(names, ds.meta)])
    out = dict(imgs=imgs, meth=meth, names=names, g=g)
    if ds.train:
        out["gt"] = np.stack([ds.m128[n] for n in names]).astype(bool); out["full"] = np.array([m["full_watermark"] for m in ds.meta])
    return out


@torch.no_grad()
def predict(model, d, dev, amp, bs=16):
    model.eval(); out = []
    for b in range(0, len(d["imgs"]), bs):
        x = d["imgs"][b:b + bs].to(dev).float() / 255
        glob = F.one_hot(torch.from_numpy(d["meth"][b:b + bs]), 3).float().to(dev)
        with torch.autocast("cuda", dtype=amp):
            out.append(torch.sigmoid(model(x, glob).float()).cpu())
    model.train(); return torch.cat(out).numpy()


def report(p, d, with_cv=False):
    s05 = miou_batch(p > 0.5, d["gt"]); full = d["full"]; res = {"mIoU@0.5": round(float(s05.mean()), 4)}
    for j, m in enumerate(METHODS):
        i = d["meth"] == j; res[m] = round(float(s05[i].mean()), 4)
        if with_cv:
            s = cv_eval(p[i], d["gt"][i], d["g"][i], "switch")
            res[f"{m}_cv_switch"] = round(float(s.mean()), 4)
            res[f"{m}_cv_T/F"] = (round(float(s[full[i]].mean()), 4), round(float(s[~full[i]].mean()), 4))
    if with_cv:
        res["cv_switch_mean"] = round(float(np.mean([res[f"{m}_cv_switch"] for m in METHODS])), 4)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", default="r34_hp"); ap.add_argument("--encoder", default="resnet34.a1_in1k")
    ap.add_argument("--steps", type=int, default=3000); ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--lr_enc", type=float, default=1e-4)
    ap.add_argument("--realistic", action="store_true", help="feathered edges, rescaled transplants, colour shift, noise")
    ap.add_argument("--workers", type=int, default=8); ap.add_argument("--eval_every", type=int, default=1000)
    a = ap.parse_args()
    dev = "cuda"; torch.backends.cudnn.benchmark = True
    amp = torch.bfloat16 if torch.cuda.get_device_capability()[0] >= 8 else torch.float16   # Turing (RTX 8000): no native bf16
    scaler = torch.amp.GradScaler("cuda", enabled=(amp == torch.float16))
    real = load_real("train"); print(f"real train loaded {tuple(real['imgs'].shape)}, amp={amp}", flush=True)
    model = UNet128(encoder=a.encoder, highpass=True, glob_dim=3).to(dev).to(memory_format=torch.channels_last)
    enc_p = list(model.enc.parameters()); ids = {id(p) for p in enc_p}
    opt = torch.optim.AdamW([{"params": enc_p, "lr": a.lr_enc}, {"params": [p for p in model.parameters() if id(p) not in ids], "lr": a.lr}],
                            weight_decay=1e-4)
    warm = 200
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / warm) * 0.5 * (1 + np.cos(np.pi * min(1, s / a.steps))))
    dl = DataLoader(SynthStream(seed=1234, realistic=a.realistic), batch_size=a.bs, num_workers=a.workers, pin_memory=True, persistent_workers=True)
    out = HERE / "runs_synth" / a.name; out.mkdir(parents=True, exist_ok=True); log = []; t0 = time.time(); run = 0
    for step, (x, y, meth, full) in enumerate(dl, 1):
        x = x.to(dev, non_blocking=True).float() / 255; y = y.to(dev); glob = F.one_hot(meth, 3).float().to(dev)
        k = np.random.randint(8); x = torch.rot90(x, k % 4, (-2, -1)); y = torch.rot90(y, k % 4, (-2, -1))
        if k >= 4:
            x, y = x.flip(-1), y.flip(-1)
        with torch.autocast("cuda", dtype=amp):
            lg = model(x.contiguous(memory_format=torch.channels_last), glob)
        loss = F.binary_cross_entropy_with_logits(lg.float(), y) + miou_loss(lg, y)
        opt.zero_grad(set_to_none=True); scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
        run = 0.98 * run + 0.02 * loss.item() if step > 1 else loss.item()
        if step % 100 == 0:
            print(f"[{a.name}] step {step} loss {run:.4f} {(time.time() - t0) / step:.2f}s/step", flush=True)
        if step % a.eval_every == 0 or step == a.steps:
            last = step == a.steps
            r = dict(step=step, t=round(time.time() - t0), **report(predict(model, real, dev, amp), real, with_cv=last))
            log.append(r); print(f"[{a.name}] ZERO-SHOT on real train: " + json.dumps(r), flush=True)
        if step == a.steps:
            break
    p_tr = predict(model, real, dev, amp); te = load_real("test"); p_te = predict(model, te, dev, amp)
    np.savez(out / "real_train_probs.npz", names=np.array(real["names"]), prob=p_tr.astype(np.float16))
    np.savez(out / "real_test_probs.npz", names=np.array(te["names"]), prob=p_te.astype(np.float16))
    torch.save({k: v.half() for k, v in model.state_dict().items()}, out / "model.pt")
    (out / "log.json").write_text(json.dumps(dict(args=vars(a), log=log), indent=1))
    print("done", out, flush=True)


if __name__ == "__main__":
    main()
