"""Multi-layer ('hypercolumn') heads for PixelSeal and TrustMark, CPU only.

The single-layer head reads one intermediate layer of the frozen decoder (PixelSeal ConvNeXt stage 2 at 16x16,
TrustMark ResNet layer2 at 31x31). Deeper layers alone were worse (too coarse), shallower ones too (too little
context). Here several layers are brought to one grid (finer layers average-pooled, deeper ones bilinearly
upsampled) and concatenated with the per-position confidence, the whole-image score g and the position; a
logistic regression per position is trained in 5-fold CV. Best config per method -> stack/maps/headmulti_*.npz
(train: out-of-fold logits; test: mean of the 5 fold heads), used as an extra source by the fusion.
"""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

LOC = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
sys.path.insert(0, str(LOC))
from common import load_split, CACHE, folds  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels, pos_feats, fit_logreg, predict_logreg  # noqa: E402

HERE = Path(__file__).resolve().parent
torch.set_num_threads(32)


def to_grid(x, hw):
    x = torch.as_tensor(np.asarray(x, np.float32))
    if x.shape[-1] > hw:
        return F.adaptive_avg_pool2d(x, hw).numpy()
    if x.shape[-1] < hw:
        return F.interpolate(x, size=(hw, hw), mode="bilinear", align_corners=False).numpy()
    return x.numpy()


def layers(meth, split, names, msg):
    d = np.load(CACHE / f"perpos_{meth}_{split}.npz"); dm = np.load(CACHE / f"mid_{meth}_{split}.npz")
    assert d["names"].tolist() == names and dm["names"].tolist() == names
    conf = (d["pp"].astype(np.float32) * msg[:, :, None, None]).mean(1, keepdims=True)
    if meth == "pixelseal":   # stage1 32x32 (192), stage2 16x16 (384), last stage 8x8 (768)
        return {"s1": dm["a"], "s2": dm["b"], "s3": d["feat"], "conf": conf}
    return {"l2": dm["a"], "l3": d["feat_l3"], "l4": d["feat"], "conf": conf}   # TrustMark: 31, 16, 8


CONFIGS = {
    "pixelseal": [("g16 s2 (single, reference)", 16, ["s2", "conf"]),
                  ("g16 s1+s2", 16, ["s1", "s2", "conf"]),
                  ("g16 s1+s2+s3", 16, ["s1", "s2", "s3", "conf"]),
                  ("g16 s2+s3", 16, ["s2", "s3", "conf"]),
                  ("g32 s1+s2+s3", 32, ["s1", "s2", "s3", "conf"])],
    "trustmark": [("g31 l2 (single, reference)", 31, ["l2"]),
                  ("g31 l2+l3", 31, ["l2", "l3", "conf"]),
                  ("g31 l2+l3+l4", 31, ["l2", "l3", "l4", "conf"]),
                  ("g16 l2+l3+l4", 16, ["l2", "l3", "l4", "conf"])],
}


def build(L, keys, hw, g):
    N = len(g); parts = [to_grid(L[k].astype(np.float32), hw) for k in keys]
    parts += [np.broadcast_to(g[:, None, None, None], (N, 1, hw, hw)).astype(np.float32), pos_feats(N, hw, hw)]
    X = np.concatenate(parts, 1)
    return X.transpose(0, 2, 3, 1).reshape(N, hw * hw, -1)


def info(meth, split):
    ds = load_split(split, [meth]); names = [m["image_name"] for m in ds.meta]
    msg = np.array([[int(c) for c in m["message"]] for m in ds.meta], np.float32) * 2 - 1
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item(); lut = dict(zip(gl[meth]["names"], gl[meth]["logits"]))
    return ds, names, msg, np.array([(lut[n] * msg[i]).mean() for i, n in enumerate(names)])


def main():
    (HERE / "maps").mkdir(exist_ok=True); lines = []
    for meth, cfgs in CONFIGS.items():
        ds, names, msg, g = info(meth, "train"); _, tnames, tmsg, tg = info(meth, "test")
        L, Lt = layers(meth, "train", names, msg), layers(meth, "test", tnames, tmsg)
        gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([m["full_watermark"] for m in ds.meta]); N = len(names)
        best = None
        for name, hw, keys in cfgs:
            X = build(L, keys, hw, g); Y = soft_labels(gt, (hw, hw)).reshape(N, -1); D = X.shape[-1]
            for wd in (1e-3, 1e-2, 1e-1):
                oof = np.zeros((N, hw * hw), np.float32); models = []
                for f in folds(N, 5, 0):
                    tr = np.setdiff1d(np.arange(N), f)
                    m = fit_logreg(X[tr].reshape(-1, D), Y[tr].reshape(-1), wd, iters=200, dev="cpu"); models.append(m)
                    oof[f] = predict_logreg(m, X[f].reshape(-1, D), dev="cpu").reshape(len(f), -1)
                o128 = to128(oof.reshape(N, hw, hw)); s = cv_eval(o128, gt, g, "switch", seed=1)
                lines.append(f"| {meth} | {name} | {D} | {wd:g} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
                print(lines[-1], flush=True)
                if best is None or s.mean() > best[0]:
                    best = (s.mean(), name, hw, keys, wd, o128, models)
        sc, name, hw, keys, wd, o128, models = best
        Xt = build(Lt, keys, hw, tg); D = Xt.shape[-1]
        t = np.mean([predict_logreg(m, Xt.reshape(-1, D), dev="cpu").reshape(len(tnames), hw, hw) for m in models], 0)
        np.savez(HERE / "maps" / f"headmulti_train_{meth}.npz", names=np.array(names), logit128=o128.astype(np.float16))
        np.savez(HERE / "maps" / f"headmulti_test_{meth}.npz", names=np.array(tnames), logit128=to128(t).astype(np.float16))
        lines.append(f"| {meth} | **best: {name}, wd={wd:g}** | | | **{sc:.4f}** | | |"); print(lines[-1], flush=True)
    hdr = ["| method | layers | dims | L2 | mIoU (CV switch) | type T | type F |", "|---|---|---|---|---|---|---|"]
    (HERE.parent / "results_head_multi.md").write_text("\n".join(hdr + lines) + "\n")


if __name__ == "__main__":
    main()
