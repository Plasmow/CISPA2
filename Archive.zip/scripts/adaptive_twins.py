"""Offline emulation of ADAPTIVE twin strength (per-image noise level) as a gold hypothesis, scored with the lbfit
leaderboard model (same score formula / grids as lbfit.py). CPU only, no submission.

Twin ladder (effective noise level; sd-turbo img2img runs int(steps*s) steps, so s0.5@4 == s0.7@4):
  0.3  : s0.3            (steps 4 -> 1 step,  k=4)
  0.5  : s0.5 + s0.7     (steps 4 -> 2 steps, k=8)
  0.625: s0.625 + 0.625b (steps 8 -> 5 steps, k=12)
  0.875: s0.875          (steps 8 -> 7 steps, k=4)
(+ any new ladder rungs in output/twins/l<level>_sh*.npz, see gen_twins --tag).
Intermediate levels are emulated by mixing the two neighbouring rungs' mean T=2 distributions.

Rules compared (each gives a per-image gold distribution g_i at T=2):
  fixed s           : same level for every image (baseline; fixed 0.625 = lbfit's best twin hypothesis)
  conf<c (maxp/pt)  : user's rule -- per image, smallest s whose twin-mean maxp (or p_true) <= c
  dino gate tau     : per image, largest rung whose twins are still 'the same object' (median DINO cos to the source
                      >= tau); classifier-independent
  dino pool tau     : average over ALL twins with level >= 0.5 and DINO cos >= tau (farthest twins that keep the object)
Usage: .venv/bin/python scripts/adaptive_twins.py [--save NAME:RULE]
"""
import argparse, glob, sys
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, str(Path(__file__).resolve().parent))
from lbfit_lib import *  # noqa

ap = argparse.ArgumentParser()
ap.add_argument("--save", default="", help="comma list of hypothesis names to save as output/targets/g_<name>.pt")
ap.add_argument("--top", type=int, default=60)
a = ap.parse_args()

import time; T0 = time.time()
torch.set_num_threads(16)
subs = load_subs()
orig = torch.load(LB / "orig.pt"); y = orig["clean"].float().argmax(1); N = len(y); ar = torch.arange(N)
Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
score = np.array([s["score"] for s in subs]); PK = np.array([s["pkl"] for s in subs])
VIEWS = ("clean", "mild")
lq = lambda z: F.log_softmax(z.float() / T, -1)
LQ = {k: {v: lq(Z[k][v]) for v in VIEWS} for k in Z}; LQo = {v: lq(orig[v]) for v in VIEWS}
LS = {k: {v: loss_stats_from_logits(Z[k][v], y) for v in VIEWS} for k in Z}
LSo = {v: loss_stats_from_logits(orig[v], y) for v in VIEWS}
MUS = np.arange(1, 12.01, 0.5); SDS = np.arange(1, 14.01, 0.5); CS = [0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5]
LDS = {(mu, sd): np.array([np.mean([lds(*LS[s["key"]][v], *LSo[v], mu, sd) for v in VIEWS]) for s in subs])
       for mu in MUS for sd in SDS}
ibest = int(np.argmax(score)); print(f"setup {time.time()-T0:.0f}s", flush=True)


def ps_vec(g):
    return np.array([np.mean([1 - np.clip(kl_mean(g, LQ[s["key"]][v]) / kl_mean(g, LQo[v]), 0, 1) for v in VIEWS])
                     for s in subs])


def fit(g):
    ps = ps_vec(g); best = None
    for (mu, sd), l in LDS.items():
        for c in CS:
            pred = l * ps / (1 + c * PK); sse = ((pred - score) ** 2).sum()
            if best is None or sse < best[0]:
                best = (sse, mu, sd, c, pred)
    sse, mu, sd, c, pred = best
    rho = np.corrcoef(np.argsort(np.argsort(pred)), np.argsort(np.argsort(score)))[0, 1]
    return dict(rmse=float(np.sqrt(sse / len(score))), mu=mu, sd=sd, c=c, rho=float(rho), ps=ps)


# ------------------------------------------------------------------ twin ladder
def load_tag(tag):
    fs = sorted(f for f in glob.glob(str(ROOT / f"output/twins/{tag}_sh*.npz")) if ".tmp" not in f)
    if not fs:
        return None
    idx, lg = [], []
    for f in fs:
        with np.load(f) as d:
            idx.append(d["idx"]); lg.append(d["logits"])
    idx = np.concatenate(idx)
    if len(idx) != N:
        return None
    return torch.from_numpy(np.concatenate(lg)).float()[np.argsort(idx)]


RUNGS = {0.3: ["s0.3"], 0.5: ["s0.5", "s0.7"], 0.625: ["s0.625", "s0.625b"], 0.875: ["s0.875"]}
for f in glob.glob(str(ROOT / "output/twins/l*_sh0.npz")):           # new ladder rungs: l<level><tag>_sh*.npz
    tag = Path(f).name.split("_sh")[0]
    lev = float(tag[1:].rstrip("abcdefgh"))
    RUNGS.setdefault(lev, []).append(tag)
TW, TAGOF = {}, {}
for lev, tags in sorted(RUNGS.items()):
    parts = [(t, load_tag(t)) for t in tags]
    parts = [(t, p) for t, p in parts if p is not None]
    if parts:
        TW[lev] = torch.cat([p for _, p in parts], 1)
        TAGOF[lev] = [(t, p.shape[1]) for t, p in parts]
LEV = sorted(TW); print(f"twins loaded {time.time()-T0:.0f}s", flush=True)
print("ladder:", {l: tuple(TW[l].shape[1:2]) for l in LEV})
G = {l: F.softmax(TW[l] / T, -1).mean(1) for l in LEV}                  # T=2 mean distribution per rung
P1 = {l: F.softmax(TW[l], -1).mean(1) for l in LEV}                     # T=1 mean (for the confidence rules)
for l in LEV:
    keep = (TW[l].argmax(-1) == y[:, None]).float().mean().item()
    print(f"  rung {l:<6} k={TW[l].shape[1]:2d} keep-label {keep:.3f}  maxp1 {P1[l].max(1).values.mean():.3f} "
          f"p_true1 {P1[l][ar, y].mean():.3f}  p_true2 {G[l][ar, y].mean():.3f}")

GRID = np.round(np.arange(LEV[0], LEV[-1] + 1e-9, 0.025), 4)


def at_level(s, M):
    """mix neighbouring rungs of M (dict level->[N,C]) at scalar s"""
    if s <= LEV[0]:
        return M[LEV[0]]
    for lo, hi in zip(LEV[:-1], LEV[1:]):
        if s <= hi:
            w = (s - lo) / (hi - lo)
            return (1 - w) * M[lo] + w * M[hi]
    return M[LEV[-1]]


GS = torch.stack([at_level(s, G) for s in GRID])          # [S,N,C]
P1S = torch.stack([at_level(s, P1) for s in GRID])


def per_image(sel):  # sel: [N] long index into GRID
    return GS[sel, ar]


H = {}
for j, s in enumerate(GRID):
    if abs(s * 40 - round(s * 40)) < 1e-6 and (round(s * 1000) % 50 == 0 or s in LEV):
        H[f"fixed s{s:g}"] = GS[j]
# user's confidence-band rule: smallest s with twin-mean confidence <= c
for crit in ("maxp", "pt"):
    C1 = P1S.max(2).values if crit == "maxp" else P1S[:, ar, y]     # [S,N]
    for c in (0.3, 0.4, 0.5, 0.525, 0.55, 0.575, 0.6, 0.625, 0.65, 0.675, 0.7, 0.8, 0.9):
        ok = C1 <= c
        sel = torch.where(ok.any(0), ok.float().argmax(0), torch.full((N,), len(GRID) - 1))
        H[f"conf {crit}<={c}"] = per_image(sel)
        H[f"conf {crit}<={c}"].sel = GRID[sel.numpy()]

# DINO semantic gate (classifier independent)
dpath = ROOT / "output/twins/dino.pt"
COS = None
if dpath.exists():
    D = torch.load(dpath)
    src = D["src"].float()
    COS = {}
    for l in LEV:
        if all(t in D for t, _ in TAGOF[l]):
            e = torch.cat([D[t].float() for t, _ in TAGOF[l]], 1)          # [N,k,D]
            COS[l] = (e * src[:, None]).sum(-1)                           # [N,k]
    print("DINO cos to source, median per rung:", {l: round(COS[l].median().item(), 3) for l in COS})
    print("  per-image median cos quantiles (5/25/50/75/95%):")
    for l in COS:
        q = COS[l].median(1).values.quantile(torch.tensor([.05, .25, .5, .75, .95]))
        print(f"   {l}: {[round(v, 3) for v in q.tolist()]}")
    # within-rung: does the classifier flip correlate with semantic drift?
    for l in COS:
        flip = (TW[l].argmax(-1) != y[:, None]).float()
        lo = COS[l] < COS[l].median()
        print(f"   rung {l}: flip rate | low-cos half {flip[lo].mean():.3f}  high-cos half {flip[~lo].mean():.3f}")
    L_ = [l for l in LEV if l in COS]
    allc = torch.cat([COS[l].flatten() for l in L_])
    for qtau in (0.1, 0.25, 0.4, 0.5, 0.6):
        tau = allc.quantile(qtau).item()
        # gate: per image the largest rung with median cos >= tau (fallback lowest rung)
        med = torch.stack([COS[l].median(1).values for l in L_])          # [R,N]
        okr = med >= tau
        last = torch.where(okr.any(0), len(L_) - 1 - okr.flip(0).float().argmax(0), torch.zeros(N, dtype=torch.long))
        g = torch.stack([G[l] for l in L_])[last, ar]
        H[f"dino gate q{qtau}"] = g
        H[f"dino gate q{qtau}"].sel = np.array(L_)[last.numpy()]
        # pool: all twins at level >= 0.5 with cos >= tau
        num = torch.zeros(N, 100); den = torch.zeros(N)
        for l in L_:
            if l < 0.5:
                continue
            w = (COS[l] >= tau).float()                                   # [N,k]
            num += (F.softmax(TW[l] / T, -1) * w[..., None]).sum(1); den += w.sum(1)
        fb = G[0.625] if 0.625 in G else G[L_[-1]]
        g = torch.where(den[:, None] > 0, num / den.clamp_min(1)[:, None], fb)
        H[f"dino pool q{qtau}"] = g
        # soft: weight by exp((cos - tau)/0.02) over levels >= 0.5 (smooth version of the pool)
        num = torch.zeros(N, 100); den = torch.zeros(N)
        for l in L_:
            if l < 0.5:
                continue
            w = torch.sigmoid((COS[l] - tau) / 0.02)
            num += (F.softmax(TW[l] / T, -1) * w[..., None]).sum(1); den += w.sum(1)
        H[f"dino soft q{qtau}"] = num / den.clamp_min(1e-6)[:, None]
else:
    print("(no output/twins/dino.pt yet: DINO rules skipped)")

# reference: lbfit's blend (tw12 + orig tail P0.3)
zt = orig["clean"].float().clone(); zt[ar, y] = -1e4
tail = F.softmax(zt / T, -1) * 0.7 + F.one_hot(y, 100).float() * 0.3
if 0.625 in G:
    H["ref blend(0.625,tailP.3)"] = 0.5 * G[0.625] + 0.5 * tail
    for k in [k for k in list(H) if k.startswith(("dino", "conf"))]:
        H[f"{k} +tail"] = 0.5 * H[k] + 0.5 * tail

rows = []
for name, g in H.items():
    r = fit(g)
    pt = g[ar, y]
    ent = -(g * g.clamp_min(1e-12).log()).sum(1).mean().item()
    sel = getattr(g, "sel", None)
    rows.append((r["rmse"], name, r, pt.mean().item(), pt.std().item(), ent,
                 None if sel is None else (float(np.mean(sel)), float(np.std(sel)))))
rows.sort(key=lambda t: t[0])
print(f"\n{'hypothesis':30s} rmse    rho   mu   sd   c    | p_true2 mean±std  ent2 | PS(best sub) | sel s mean±std")
for rmse, name, r, ptm, pts, ent, sel in rows[:a.top]:
    ss = "" if sel is None else f"{sel[0]:.3f}±{sel[1]:.3f}"
    print(f"{name:30s} {rmse:.4f} {r['rho']:.3f} {r['mu']:4.1f} {r['sd']:4.1f} {r['c']:.2f} | {ptm:.3f}±{pts:.3f}  {ent:.2f} | "
          f"{r['ps'][ibest]:.3f} | {ss}")

for name in [s for s in a.save.split(",") if s]:
    torch.save({"g": H[name], "labels": y, "name": name}, ROOT / "output/targets" / f"g_{name.replace(' ', '_')}.pt")
    print("saved", name)

# ------------------------------------------------------------------ robustness: LOO refit + dz predictions
if "--cv" in sys.argv or True:
    keys = [s["key"] for s in subs]
    dzi = [i for i, k in enumerate(keys) if k.startswith("dz")]
    print(f"\nLOO (refit mu,sd,c without each sub) for the top {min(25, len(rows))}; dz subs: "
          + ", ".join(f"{keys[i].split('__')[0]}={score[i]:.4f}" for i in dzi))
    Lmat = np.stack(list(LDS.values())); MS = list(LDS.keys())
    for rmse, name, r, *_ in [t for t in rows if t[1].startswith(("conf maxp", "dino gate q0.25", "ref", "fixed s0.625"))][:40]:
        ps = r["ps"]; errs = []
        P = Lmat[:, None, :] * ps[None, None, :] / (1 + np.array(CS)[None, :, None] * PK[None, None, :])  # [G,C,n]
        SE = (P - score) ** 2
        tot = SE.sum(2)
        for i in range(len(score)):
            g_, c_ = np.unravel_index(np.argmin(tot - SE[:, :, i]), tot.shape)
            errs.append(P[g_, c_, i] - score[i])
        errs = np.array(errs)
        g_, c_ = np.unravel_index(np.argmin(tot), tot.shape)
        print(f"  {name:30s} fit {rmse:.4f}  LOO {np.sqrt((errs ** 2).mean()):.4f}  | dz LOO pred "
              + " ".join(f"{score[i]:.3f}->{score[i] + errs[i]:.3f}" for i in dzi)
              + f" | ridge mu{MS[g_][0]}+sd{MS[g_][1]}")
