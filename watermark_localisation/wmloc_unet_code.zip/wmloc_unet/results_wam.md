# WAM-ft et blocs MELB (22/11, 10:45–11:05) : pas de gain au niveau des cartes

Papiers : `Hackathon_Watermark_Localisation_Task/paper/` (WAM, Sander et al. 2025 ; MELB, Bulychev et al. 2025).
Code : `W/stack/wam_ft.py` (job `W/run_wam_devel.sh`, n° 15906072, dc-gpu-devel, hors réservation, 6 min)
et `W/stack/melb_blocks.py` (CPU). Journal : `W/logs/wam_15906072.out` ; JSON : `W/logs/wam{,2}_<méthode>.json`.

## Idée
- **WAM** : tête 1×1 `dhead` (32 → n_bits) sur les features finales du wm-U-Net. Perte de décodage = BCE des bits
  sur les cases tatouées seulement (éq. 5 de WAM, λ = 10). On lit une **carte d'accord au message connu**
  a = moyenne_k (2m_k − 1)·dec_k.
- Variante « nul » : μ = 1 × BCE vers 0.5 sur les cases propres. C'est l'équivalent de la phase 2 de WAM, pour que
  le décodage ne déborde pas dans les trous.
- **MELB** : statistique par bloc. L'accord, ou une carte existante, est moyenné sur des blocs de 4×4 ou 8×8 cases,
  puis ajouté comme source à la fusion par case.

## Résultats des cartes seules (cv_switch sur 5 plis ; même recette, mêmes plis et mêmes graines que le témoin `c`)

| Méthode (init) | témoin `wamc` | WAM `wamd` | WAM + nul `wamn` | accord `wamda` | accord `wamna` |
|---|---|---|---|---|---|
| PixelSeal (`wmunet`) | 0.6075 | 0.6069 | 0.6079 | 0.4637 | 0.4567 |
| PixelSeal (`wmunet2`, suffixe 2) | — | 0.6083 | 0.6065 | 0.4564 | 0.4486 |
| TrustMark (`wmunet`) | 0.6044 | 0.6020 | 0.6050 | 0.4437 | 0.4434 |
| StegaStamp (`wmunetH`) | 0.6048 | 0.6022 | 0.6001 | 0.4530 | 0.4574 |

- **La tête de décodage n'apprend rien.** Sa BCE reste à 0.70, soit ln 2 = 0.693, sur tous les plis et pour les 3 méthodes.
  - Les cartes d'accord restent au niveau du simple choix de régime (≈ 0.45) : aucun signal.
  - Cause probable : 32 canaux par case ne peuvent pas porter 100 à 256 bits indépendants par une couche linéaire.
  - Et WAM apprend son décodage par pixel en 300 époques sur 118 000 images ; ici, 15 époques sur 136 images par pli.
- **Carte de détection** : WAM ou WAM + nul restent à ±0.003 du témoin apparié, dans le bruit.
  La perte auxiliaire ne nuit pas, mais n'aide pas non plus.
- **MELB sur les cartes existantes** (PixelSeal, `W/logs/melb_existing_pixelseal.md`) : la fusion v12a passe de 0.6176
  à 0.6182 avec `wmunet_b8` + `wmunet2_b8`, et à 0.6171 avec les 4 cartes de blocs. C'est du bruit, comme le lissage gaussien déjà testé.

## Fusion complète v3 (même commande que v12a + tags ; avant SAM, référence v12a = 0.6966)

| Version | PixelSeal | TrustMark | StegaStamp | Moyenne | Écart |
|---|---|---|---|---|---|
| v12a | 0.6525 | 0.6778 | 0.7594 | 0.6966 | — |
| v18_wam (+ `wamn wamd wamn2 wamd2`) | 0.6536 | 0.6687 | 0.7605 | 0.6943 | −0.0023 |
| v18_wamc (+ `wamc`, témoin) | 0.6531 | 0.6758 | 0.7586 | 0.6958 | −0.0008 |

- TrustMark −0.009 : les nouvelles cartes, quasi identiques à `wmunet`, évincent `wmunet0` et `wmunetF0` du top 3.
  v3 retient alors `wmunet` seul. C'est un artefact de sélection, pas une information nouvelle.
- Meilleur cas, en prenant PixelSeal et StegaStamp de v18_wam et TrustMark de v12a : 0.6973, soit +0.0007 avant SAM,
  loin du seuil de +0.003. SAM n'a pas été lancé.
- **Décision : rejeté. v12a_sam (0.7192 public) reste la soumission finale.** Les fichiers v18_wam et v18_wamc
  (`W/submissions/`) n'ont pas été envoyés.

## À ne pas refaire
- Une tête de bits sur les features finales du U-Net : il faudrait des features riches en information de bits
  et un entraînement long, comme dans WAM (synthétique massif), ce qui dépasse le budget.
- Les blocs MELB sur des cartes de logits : équivalent à un lissage, sans gain.
