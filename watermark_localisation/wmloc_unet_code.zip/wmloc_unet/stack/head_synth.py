"""Heads trained on SYNTHETIC data, on top of the frozen decoder (PixelSeal, TrustMark), CPU only.

Same inputs as the best real multi-layer heads (head_multi.py):
  PixelSeal : 16x16 grid  [ConvNeXt stage1 (pooled), stage2, per-position confidence, g, position]
  TrustMark : 31x31 grid  [ResNet layer2, layer3 (upsampled), per-position confidence, g, position]
computed on realistic synthetic edits (synth/generator.py) instead of the 170 real images. Two heads:
  - logistic regression per position (as the real head)
  - small conv head: 1x1 (D->64) -> 3x3 (64->64) -> 1x1 (64->1)
Evaluated on the real train images (never used for training, so their maps are legitimate out-of-fold maps).
The best one per method -> stack/maps/headsyn_{train,test}_<method>.npz, an extra source for the fusion.
"""
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]; HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(ROOT / "synth")); sys.path.insert(0, str(TASK / "loc"))
from common import load_watermark, KIT, auc  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels, fit_logreg, predict_logreg  # noqa: E402
from head_multi import layers, build, info  # noqa: E402

torch.set_num_threads(32)
CFG = {"pixelseal": (16, ["s1", "s2", "conf"], 3000, 1e-3), "trustmark": (31, ["l2", "l3", "conf"], 2000, 1e-2)}


def _gen(args):
    meth, seed, n = args
    from generator import SynthGenerator
    g = SynthGenerator(methods=(meth,), seed=seed, realistic=True); out = []
    for _ in range(n):
        s = g.sample(); out.append((s["image"].astype(np.uint8), s["mask128"].astype(bool), s["message"].astype(np.float32)))
    return out


@torch.no_grad()
def decoder_layers(wm, meth, imgs, msgs, bs=32):
    """Same layers as the cached real features (step1b_extract*.py), fp16."""
    keep = {k: [] for k in (("s1", "s2") if meth == "pixelseal" else ("l2", "l3"))}; conf = []
    for b in range(0, len(imgs), bs):
        x = torch.from_numpy(imgs[b:b + bs]).permute(0, 3, 1, 2).float() / 255
        sgn = torch.from_numpy(msgs[b:b + bs] * 2 - 1)
        if meth == "pixelseal":
            cn = wm.det.convnext; h = wm.det.preprocess(wm._resize(x)); outs = []
            for i in range(4):
                h = cn.stages[i](cn.downsample_layers[i](h)); outs.append(h)
            emb = wm.det.pixel_decoder.output_upscaling(outs[3]); lin = wm.det.pixel_decoder.linear
            pp = (torch.einsum("bchw,oc->bohw", emb, lin.weight) + lin.bias[None, :, None, None])[:, 1:]
            keep["s1"].append(outs[1].half()); keep["s2"].append(outs[2].half())
        else:
            f = wm.features(x); pp = f["per_position_logits"]
            keep["l2"].append(f["layer2"].half()); keep["l3"].append(f["layer3"].half())
        conf.append((pp.float() * sgn[:, :, None, None]).mean(1, keepdim=True))
    L = {k: torch.cat(v).numpy() for k, v in keep.items()}; L["conf"] = torch.cat(conf).numpy()
    return L, L["conf"].mean((1, 2, 3))                                   # g = mean of the per-position confidence


class ConvHead(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.net = nn.Sequential(nn.Conv2d(d, 64, 1), nn.ReLU(), nn.Conv2d(64, 64, 3, padding=1), nn.ReLU(), nn.Conv2d(64, 1, 1))

    def forward(self, x):
        return self.net(x)[:, 0]


def train_conv(X, Y, hw, epochs=6, bs=32):
    """X [N, hw*hw, D] (already standardised), Y [N, hw*hw] soft labels."""
    N, _, D = X.shape; Xt = torch.from_numpy(X).view(N, hw, hw, D).permute(0, 3, 1, 2); Yt = torch.from_numpy(Y).view(N, hw, hw)
    torch.manual_seed(0); m = ConvHead(D); opt = torch.optim.Adam(m.parameters(), 1e-3, weight_decay=1e-4)
    for ep in range(epochs):
        perm = torch.randperm(N); tot = 0
        for b in range(0, N, bs):
            i = perm[b:b + bs]; loss = F.binary_cross_entropy_with_logits(m(Xt[i]), Yt[i])
            opt.zero_grad(); loss.backward(); opt.step(); tot += loss.item() * len(i)
        print(f"    conv head epoch {ep + 1}: loss {tot / N:.4f}", flush=True)
    return m


@torch.no_grad()
def predict_conv(m, X, hw):
    N, _, D = X.shape; out = []
    for b in range(0, N, 64):
        out.append(m(torch.from_numpy(X[b:b + 64]).view(-1, hw, hw, D).permute(0, 3, 1, 2)).numpy())
    return np.concatenate(out)


def main():
    lines = []
    for meth, (hw, keys, n_syn, wd) in CFG.items():
        t = time.time()
        with Pool(24) as pool:
            chunks = pool.map(_gen, [(meth, 1000 + k, n_syn // 24 + 1) for k in range(24)])
        S = [s for c in chunks for s in c][:n_syn]
        imgs = np.stack([s[0] for s in S]); gts = np.stack([s[1] for s in S]); msgs = np.stack([s[2] for s in S])
        print(f"{meth}: {len(S)} synthetic samples in {time.time() - t:.0f}s", flush=True); t = time.time()
        wm = load_watermark(meth, KIT / "models", "cpu"); Ls, gs = decoder_layers(wm, meth, imgs, msgs); del imgs
        print(f"{meth}: decoder layers in {time.time() - t:.0f}s", flush=True)
        Xs = build(Ls, keys, hw, gs); del Ls; Ys = soft_labels(gts, (hw, hw)).reshape(len(gts), -1)
        # real train / test inputs, built exactly like the real multi-layer head
        ds, names, msg, g = info(meth, "train"); _, tnames, tmsg, tg = info(meth, "test")
        Xr, Xt = build(layers(meth, "train", names, msg), keys, hw, g), build(layers(meth, "test", tnames, tmsg), keys, hw, tg)
        gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([m["full_watermark"] for m in ds.meta])
        D = Xs.shape[-1]; results = {}
        # (a) logistic regression per position, fitted on synthetic only (positions subsampled for speed)
        sub = Xs.reshape(len(Xs), hw, hw, D)[:, ::2, ::2].reshape(-1, D); ysub = Ys.reshape(len(Ys), hw, hw)[:, ::2, ::2].reshape(-1)
        lr = fit_logreg(sub, ysub, wd, iters=200, dev="cpu"); del sub
        results["logistic"] = (predict_logreg(lr, Xr.reshape(-1, D), "cpu").reshape(-1, hw, hw),
                               predict_logreg(lr, Xt.reshape(-1, D), "cpu").reshape(-1, hw, hw))
        # (b) small conv head, standardised with the synthetic statistics
        mu = Xs.reshape(-1, D).mean(0); sd = Xs.reshape(-1, D).std(0) + 1e-4
        st = lambda X: ((X - mu) / sd).astype(np.float32)  # noqa: E731
        conv = train_conv(st(Xs), Ys.astype(np.float32), hw); del Xs
        results["conv"] = (predict_conv(conv, st(Xr), hw), predict_conv(conv, st(Xt), hw))
        best = None
        for k, (r_tr, r_te) in results.items():
            o = to128(r_tr); s = cv_eval(o, gt, g, "switch", seed=1)
            lines.append(f"| {meth} | synthetic {k} | {auc(o[full], gt[full]):.3f} | {auc(o[~full], gt[~full]):.3f} | "
                         f"{s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |"); print(lines[-1], flush=True)
            if best is None or s.mean() > best[0]:
                best = (s.mean(), k, o, to128(r_te))
        np.savez(HERE / "maps" / f"headsyn_train_{meth}.npz", names=np.array(names), logit128=best[2].astype(np.float16))
        np.savez(HERE / "maps" / f"headsyn_test_{meth}.npz", names=np.array(tnames), logit128=best[3].astype(np.float16))
        lines.append(f"| {meth} | **kept: {best[1]}** | | | **{best[0]:.4f}** | | |")
    hdr = ["| method | head | AUC type T | AUC type F | mIoU (CV switch) | type T | type F |", "|---|---|---|---|---|---|---|"]
    (ROOT / "results_head_synth.md").write_text("\n".join(hdr + lines) + "\n")


if __name__ == "__main__":
    main()
