"""Pseudo-labelled fine-tuning of the wm-U-Net on the TEST images (Agent B, task 3).

1) CPU, once:  python wm_unet_T_pl.py --build_labels [--base submission_v8]
   Near-exact test labels, per method -> maps/plwmunetT_labels_test_<m>.npz (names, label u8, weight u8, kind):
     rect : decoder box with bit acc >= --rect_acc (0.9), v3.load_rect (loc/cache rect_* incl. the local StegaStamp
            search, + maps/rect2_*)                                                 -> label = box, all cells weighted
     sam  : <base>_sam.pt replaced the mask by a SAM segment AND the snap score >= s_hi, s_hi = smallest score whose
            snapped train images reach a mean mIoU >= --sam_miou (0.9)            -> label = segment, all cells weighted
     T    : other images predicted T (g > tg): label = P > 0.5 on the fused test map, weight only where P < 0.1 or P > 0.9
     (other F images: unused)
2) GPU:  python wm_unet_T_pl.py --method pixelseal --init_ckpt maps/wmunetT_pixelseal_synthetic.pt
   5-fold fine-tuning, SAME folds as every source (folds(N, 5, 0)), T images weighted x--wT, from the given synthetic
   checkpoint, two variants with identical settings:  plwmunetT (train folds + all pseudo-labelled test images)
   and plwmunetTn (no pseudo-labels, control). Outputs maps/<tag>_{train,test}_<m>.npz (never overwritten).
   CAVEAT: the pseudo-labels come from models fitted on the WHOLE train split, so the OOF CV of plwmunetT is slightly
   optimistic: keep it only if it beats plwmunetTn by more than +0.005.
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from wm_unet_T import (HERE, ROOT, TASK, CH, WMUNet, StegaUNet, load_real, predict, set_encoder_trainable, load_watermark, KIT,
                       folds, miou_batch, scores, load_ref, RUNS)

MAPS = HERE / "maps"


def wloss(lg, y, w, eps=1.0):
    """Per-image BCE + (1 - soft 2-class mIoU), both restricted to the weighted cells."""
    bce = torch.nn.functional.binary_cross_entropy_with_logits(lg, y, reduction="none")
    ws = w.sum((1, 2)).clamp_min(1.0); bce = (bce * w).sum((1, 2)) / ws
    p = torch.sigmoid(lg.float()) * w; yy = y * w
    i1 = (p * y).sum((1, 2)); u1 = (p + yy - p * y).sum((1, 2))
    q = (1 - torch.sigmoid(lg.float())) * w; z = (1 - y) * w
    i0 = (q * (1 - y)).sum((1, 2)); u0 = (q + z - q * (1 - y)).sum((1, 2))
    return bce + 1 - ((i1 + eps) / (u1 + eps) + (i0 + eps) / (u0 + eps)) / 2


# ------------------------------------------------------------------------------------------------ 1. labels (CPU)
def build_labels(a):
    import glob
    from scipy import ndimage
    from v3 import METHODS, load_split, load_rect, g_of
    from common import CACHE
    from evalkit import fit_switch
    N = 128 * 128
    Pt = torch.load(ROOT / "sam" / a.base / "probs_test.pt", weights_only=True); pt = dict(zip(Pt["image_names"], Pt["probs"].numpy()))
    Pr = torch.load(ROOT / "sam" / a.base / "probs_train_oof.pt", weights_only=True); pr = dict(zip(Pr["image_names"], Pr["probs"].numpy()))
    b = torch.load(ROOT / "submissions" / f"{a.base}.pt", weights_only=True); s = torch.load(ROOT / "submissions" / f"{a.base}_sam.pt", weights_only=True)
    assert b["image_names"] == s["image_names"]; snapped = {n for n, x, y in zip(b["image_names"], b["masks"].numpy(), s["masks"].numpy()) if (x != y).any()}
    sam_mask = dict(zip(s["image_names"], s["masks"].numpy().astype(bool)))
    cands = {}
    for f in glob.glob(str(CACHE / "sam_cands" / "sam_*.npz")):
        d = np.load(f, allow_pickle=True)
        for n, c in zip(d["names"], d["cands"]):
            cands[str(n)] = np.unpackbits(c, axis=1)[:, :N].astype(bool) if len(c) else np.zeros((0, N), bool)

    def snap(p, Cs):                                     # = snap_sam_local.snap
        if len(Cs) == 0:
            return None, -1.0
        Cf = Cs.astype(np.float32); area = Cf.sum(1); inside = (Cf @ p) / (area + 1e-6)
        R = np.stack([ndimage.binary_dilation(c.reshape(128, 128), iterations=4).ravel() & ~c for c in Cs]).astype(np.float32)
        ring = (R @ p) / (R.sum(1) + 1e-6); pn = (p - p.min()) / (p.max() - p.min() + 1e-6)
        inter = Cf @ pn; soft = inter / (area + pn.sum() - inter + 1e-6)
        sc = soft * np.clip((inside - ring) / (p.std() + 1e-6), 0, None); j = sc.argmax()
        return Cs[j], float(sc[j])

    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}; meta_te = {m["image_name"]: m for m in te_all.meta}
    # s_hi from the train split: snap score above which the chosen segment is near-exact (mean mIoU >= --sam_miou)
    conf, ss = [], []
    for n in pr:
        if n in cands and not meta_tr[n]["full_watermark"]:
            c, sc = snap(pr[n].ravel().astype(np.float32), cands[n])
            if c is not None:
                conf.append(sc); ss.append(miou_batch(c.reshape(1, 128, 128), tr_all.m128[n][None].astype(bool))[0])
    conf, ss = np.array(conf), np.array(ss); o = np.argsort(-conf); run = np.cumsum(ss[o]) / np.arange(1, len(o) + 1)
    ok = np.where(run >= a.sam_miou)[0]; s_hi = float(conf[o][ok.max()]) if len(ok) else np.inf
    print(f"s_hi = {s_hi:.3f}: {len(ok) and ok.max() + 1} train F images above it, their segment mIoU {run[ok.max()] if len(ok) else float('nan'):.3f}")
    report = {"base": a.base, "s_hi": s_hi, "rect_acc": a.rect_acc}
    for meth in METHODS:
        n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
        g_tr, g_te = g_of("train", n_tr, meta_tr), g_of("test", n_te, meta_te)
        Ltr = np.log(np.clip(np.stack([pr[n] for n in n_tr]), 1e-4, 1 - 1e-4) / (1 - np.clip(np.stack([pr[n] for n in n_tr]), 1e-4, 1 - 1e-4)))
        tg = fit_switch(Ltr, np.stack([tr_all.m128[n] for n in n_tr]).astype(bool), g_tr, np.arange(len(n_tr)))["tg"]
        R = load_rect(meth, "test"); lab = np.zeros((len(n_te), 128, 128), np.uint8); wt = np.zeros_like(lab); kind = []
        for i, n in enumerate(n_te):
            p = pt[n]
            if n in R and R[n][1] >= a.rect_acc:
                lab[i] = R[n][0]; wt[i] = 1; kind.append("rect")
            elif n in snapped and n in cands and snap(p.ravel().astype(np.float32), cands[n])[1] >= s_hi:
                lab[i] = sam_mask[n]; wt[i] = 1; kind.append("sam")
            elif g_te[i] > tg:
                lab[i] = p > 0.5; wt[i] = (p < 0.1) | (p > 0.9); kind.append("T")
            else:
                kind.append("none")
        kind = np.array(kind); out = MAPS / f"plwmunetT_labels_test_{meth}.npz"
        if out.exists():
            raise SystemExit(f"refusing to overwrite {out}")
        np.savez_compressed(out, names=np.array(n_te), label=lab, weight=wt, kind=kind)
        report[meth] = {k: int((kind == k).sum()) for k in ("rect", "sam", "T", "none")}
        report[meth]["T_weighted_cell_frac"] = round(float(wt[kind == "T"].mean()), 3) if (kind == "T").any() else None
        print(meth, report[meth], "->", out, flush=True)
    RUNS.mkdir(parents=True, exist_ok=True); (RUNS / f"plwmunetT_labels_{a.base}.json").write_text(json.dumps(report, indent=1))


# ------------------------------------------------------------------------------------------------ 2. fine-tuning (GPU)
def train(a):
    meth, dev = a.method, a.dev; t0 = time.time(); torch.manual_seed(a.seed)
    names_out = [MAPS / f"{t}_{s}_{meth}.npz" for t in (a.tag, a.tag + "n") for s in ("train", "test")] + [RUNS / f"{a.tag}_{meth}.json"]
    clash = [str(p) for p in names_out if p.exists()]
    if clash:
        raise SystemExit(f"refusing to overwrite existing files: {clash}")
    torch.backends.cuda.matmul.allow_tf32 = False; torch.backends.cudnn.allow_tf32 = False
    if meth == "stegastamp":
        model = StegaUNet().to(dev)
    else:
        wm = load_watermark(meth, KIT / "models", dev); model = WMUNet(meth, wm).to(dev); del wm
    sd = torch.load(a.init_ckpt, map_location=dev, weights_only=True); pre_state = {k: v.float() for k, v in sd.items()}
    real = load_real(meth, "train", a.max_real); test = load_real(meth, "test", a.max_real); M = len(test["names"])
    z = np.load(MAPS / f"plwmunetT_labels_test_{meth}.npz"); assert z["names"].tolist()[:M] == test["names"]
    use = np.where(z["kind"][:M] != "none")[0]; PLy = torch.from_numpy(z["label"][use].astype(np.float32)); PLw = torch.from_numpy(z["weight"][use].astype(np.float32))
    refs = {t: R for t in ("wmunet", "wmunetT") if (R := load_ref(meth, real["names"], t)) is not None}
    log = {"args": vars(a), "n_pseudo": int(len(use)), "ref": {t: scores(R, real) for t, R in refs.items()}, "evals": []}
    print(f"[{meth}] {len(use)} pseudo-labelled test images; refs {json.dumps(log['ref'])}", flush=True)
    N = len(real["names"]); full = real["full"]
    for variant, tag in (("pl", a.tag), ("nopl", a.tag + "n")):
        oof = np.zeros((N, 128, 128), np.float32); tmean = np.zeros((len(test["names"]), 128, 128), np.float32); per_fold = []
        for k, f in enumerate(folds(N, 5, 0)):
            model.load_state_dict(pre_state); tr = np.setdiff1d(np.arange(N), f); set_encoder_trainable(model, True)
            opt = torch.optim.AdamW([{"params": [p for n, p in model.named_parameters() if not n.startswith("enc.")], "lr": a.ft_lr},
                                     {"params": list(model.enc.parameters()), "lr": a.enc_lr / 2}], weight_decay=1e-4)
            rng = np.random.RandomState(k + 100 * a.seed)
            items = [("r", i) for i in tr] + ([("p", j) for j in range(len(use))] if variant == "pl" else [])
            for ep in range(a.ft_epochs):
                perm = [items[t] for t in rng.permutation(len(items))]
                for b in range(0, len(perm), 8):
                    bt = perm[b:b + 8]; xs, ys, ws, iw = [], [], [], []
                    for src, i in bt:
                        if src == "r":
                            xs.append(real["imgs"][i]); ys.append(torch.from_numpy(real["gt"][i].astype(np.float32)))
                            ws.append(torch.ones(128, 128)); iw.append(a.wT if full[i] else 1.0); mg = real["msgs"][i]
                        else:
                            xs.append(test["imgs"][use[i]]); ys.append(PLy[i]); ws.append(PLw[i]); iw.append(a.pl_weight)
                    msgs = torch.stack([real["msgs"][i] if s_ == "r" else test["msgs"][use[i]] for s_, i in bt])
                    x = torch.stack(xs).to(dev).float() / 255; y = torch.stack(ys).to(dev); w = torch.stack(ws).to(dev); iwt = torch.tensor(iw, device=dev)
                    li = wloss(model(x, msgs.to(dev) * 2 - 1), y, w); loss = (li * iwt).sum() / iwt.sum()
                    opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
            oof[f] = predict(model, real, f, dev); tmean += predict(model, test, np.arange(len(test["names"])), dev) / 5
            Tf = f[full[f]]; row = dict(fold=k, new_T_miou0=round(float(miou_batch(oof[Tf] > 0, real["gt"][Tf]).mean()), 4))
            for rt, Rm in refs.items():
                row[f"{rt}_T_miou0"] = round(float(miou_batch(Rm[Tf] > 0, real["gt"][Tf]).mean()), 4)
            per_fold.append(row); print(f"[{meth}:{variant}] fold {k}: {json.dumps(row)} ({time.time() - t0:.0f}s)", flush=True)
        np.savez(MAPS / f"{tag}_train_{meth}.npz", names=np.array(real["names"]), logit128=oof.astype(np.float16))
        np.savez(MAPS / f"{tag}_test_{meth}.npz", names=np.array(test["names"]), logit128=tmean.astype(np.float16))
        r = dict(tag=tag, **scores(oof, real), per_fold=per_fold); log["evals"].append(r)
        print(f"[{meth}] {tag}: {json.dumps({k: v for k, v in r.items() if k != 'per_fold'})}", flush=True)
    (RUNS / f"{a.tag}_{meth}.json").write_text(json.dumps(log, indent=1)); print(f"[{meth}] done in {time.time() - t0:.0f}s", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--build_labels", action="store_true"); ap.add_argument("--base", default="submission_v8")
    ap.add_argument("--rect_acc", type=float, default=0.9); ap.add_argument("--sam_miou", type=float, default=0.9)
    ap.add_argument("--method", choices=list(CH)); ap.add_argument("--init_ckpt"); ap.add_argument("--tag", default="plwmunetT")
    ap.add_argument("--ft_epochs", type=int, default=15); ap.add_argument("--ft_lr", type=float, default=1e-4); ap.add_argument("--enc_lr", type=float, default=1e-5)
    ap.add_argument("--wT", type=float, default=3.0); ap.add_argument("--pl_weight", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--dev", default="cuda"); ap.add_argument("--max_real", type=int, default=None)
    a = ap.parse_args()
    build_labels(a) if a.build_labels else train(a)


if __name__ == "__main__":
    main()
