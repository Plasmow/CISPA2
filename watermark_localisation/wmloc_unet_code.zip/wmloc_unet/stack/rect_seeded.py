"""Map-seeded rectangle search: the fused heatmap proposes rectangles, the watermark decoder adjusts them.

Why: about half of the type-F masks are plain rectangles, and the crop of the true rectangle (resized to the decoder
input) decodes the known message (StegaStamp: 31/40 missed train rectangles reach bit acc >= 0.85 with a 2 px margin).
The blind search (loc/rect_search.py: 32 px grid + greedy refinement) misses most of them because the decoder only
answers when the box edges are within a few pixels, so its coarse seeds are wrong.

Seeds per image:
  map    : maximum-sum rectangles of (fused logit - b), b in {-1,0,1,2}; bounding boxes of the 3 largest components of
           the map at P > 0.3 and P > 0.5 (the 128 grid is mapped to pixels x4)
  coarse : top-K diverse boxes of a coarse grid (edges every G px), ranked by the decoder confidence
Every seed is refined by greedy edge moves (steps 16, 8, 4, 2, 1 px) on the decoder confidence (mean logit signed by the
known message), all seeds in parallel on the GPU. The best refined box (bit acc, then confidence) is kept.

    python rect_seeded.py stegastamp train 0 4 [--dev cuda] [--nmax N] [--coarse 32]
Writes maps/rect2_<method>_<split>_<shard>.npz (names, boxes, acc, conf, src, best_map_acc, best_coarse_acc).
"""
import argparse
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

HERE = Path(__file__).resolve().parent
LOC = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
sys.path.insert(0, str(LOC)); sys.path.insert(0, str(HERE))
from common import load_split, load_watermark, KIT  # noqa: E402
from shapes2 import max_rect  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("method"); ap.add_argument("split"); ap.add_argument("shard", type=int); ap.add_argument("nshards", type=int)
ap.add_argument("--dev", default="cuda"); ap.add_argument("--nmax", type=int, default=10 ** 9)
ap.add_argument("--coarse", type=int, default=32, help="coarse grid step in px (0 = map seeds only)")
ap.add_argument("--topk", type=int, default=8); ap.add_argument("--minside", type=int, default=8)
ap.add_argument("--gmargin", type=float, default=0.1, help="search images with g <= tg + margin (predicted type F)")
ap.add_argument("--names", default=None, help="comma-separated image names (debug)")
a = ap.parse_args()
dev = a.dev
if dev == "cuda":
    torch.backends.cuda.matmul.allow_tf32 = True; torch.backends.cudnn.allow_tf32 = True
RES_ = {"pixelseal": 256, "trustmark": 245, "stegastamp": 400}[a.method]
MODE = "bicubic" if a.method == "stegastamp" else "bilinear"
MAXAR = 2.0 if a.method == "trustmark" else 16.0
BS = {"pixelseal": 256, "trustmark": 512, "stegastamp": 192}[a.method]

ds = load_split(a.split, [a.method])
if a.method == "stegastamp":
    from stega_torch import StegaDecoder
    _dec = StegaDecoder().to(dev).eval()
    def logits_fn(x):
        return _dec(x)
else:
    _wm = load_watermark(a.method, KIT / "models", dev)
    def logits_fn(x):
        return _wm.logits(x).float().to(dev)


def crops_resized(x, boxes):
    out = torch.empty(len(boxes), 3, RES_, RES_, device=dev)
    for i, (y0, y1, x0, x1) in enumerate(boxes):
        out[i] = F.interpolate(x[None, :, y0:y1, x0:x1], size=(RES_, RES_), mode=MODE, align_corners=False, antialias=True)[0]
    return out.clamp_(0, 1)


@torch.no_grad()
def score(x, boxes, sgn):
    accs, confs = [], []
    for b in range(0, len(boxes), BS):
        s = logits_fn(crops_resized(x, boxes[b:b + BS])) * sgn
        accs.append((s > 0).float().mean(1).cpu()); confs.append(s.mean(1).cpu())
    return torch.cat(accs).numpy(), torch.cat(confs).numpy()


def valid(b):
    y0, y1, x0, x1 = b; h, w = y1 - y0, x1 - x0
    return 0 <= y0 and y1 <= 512 and 0 <= x0 and x1 <= 512 and h >= a.minside and w >= a.minside and max(h, w) / min(h, w) <= MAXAR


def coarse_boxes(G):
    v = list(range(0, 513, G))
    if v[-1] != 512:
        v.append(512)
    pairs = [(p, q) for i, p in enumerate(v) for q in v[i + 1:]]
    return [(y0, y1, x0, x1) for (y0, y1) in pairs for (x0, x1) in pairs if valid((y0, y1, x0, x1)) and min(y1 - y0, x1 - x0) >= 24]


def box_iou(p, q):
    ih = max(0, min(p[1], q[1]) - max(p[0], q[0])); iw = max(0, min(p[3], q[3]) - max(p[2], q[2])); inter = ih * iw
    return inter / ((p[1] - p[0]) * (p[3] - p[2]) + (q[1] - q[0]) * (q[3] - q[2]) - inter)


def clip_box(b):
    y0, y1, x0, x1 = [int(v) for v in b]
    y0, x0 = max(0, y0), max(0, x0); y1, x1 = min(512, max(y1, y0 + a.minside)), min(512, max(x1, x0 + a.minside))
    return (y0, y1, x0, x1)


def map_seeds(L):
    out = []
    for b in (-1.0, 0.0, 1.0, 2.0):
        v, y0, y1, x0, x1 = max_rect(L.astype(np.float64) - b)
        if v > 0:
            out.append(clip_box((4 * y0, 4 * y1, 4 * x0, 4 * x1)))
    for t in (0.3, 0.5):
        lab, k = ndi.label(L > np.log(t / (1 - t)))
        if k:
            sz = ndi.sum(np.ones_like(lab), lab, range(1, k + 1))
            for c in np.argsort(-sz)[:3]:
                ys, xs = np.where(lab == c + 1); out.append(clip_box((4 * ys.min(), 4 * ys.max() + 4, 4 * xs.min(), 4 * xs.max() + 4)))
    uniq = []
    for b in out:
        if valid(b) and all(box_iou(b, u) < 0.9 for u in uniq):
            uniq.append(b)
    return uniq


def refine_all(x, sgn, seeds):
    """Greedy edge refinement of all seeds in parallel; key = confidence. -> list of (box, acc, conf)."""
    cur = [tuple(s) for s in seeds]
    acc0, conf0 = score(x, cur, sgn); key = list(conf0); acc = list(acc0)
    for step in (16, 8, 4, 2, 1):
        active = list(range(len(cur)))
        while active:
            cands, owner = [], []
            for si in active:
                for e in range(4):
                    for d in (-step, step):
                        b = list(cur[si]); b[e] += d; b = tuple(b)
                        if valid(b):
                            cands.append(b); owner.append(si)
            if not cands:
                break
            ca, cc = score(x, cands, sgn); owner = np.array(owner); nxt = []
            for si in active:
                js = np.where(owner == si)[0]
                if len(js) == 0:
                    continue
                j = js[np.argmax(cc[js])]
                if cc[j] > key[si] + 1e-6:
                    cur[si], key[si], acc[si] = cands[j], cc[j], ca[j]; nxt.append(si)
            active = nxt
    return [(cur[i], float(acc[i]), float(key[i])) for i in range(len(cur))]


# ---- images to search: predicted type F from the fused map's g (threshold fitted on train)
zt = np.load(HERE / "maps" / f"fused_{a.split}_{a.method}.npz"); fnames = zt["names"].tolist(); FL = zt["logit128"].astype(np.float32); FG = zt["g"]
ztr = np.load(HERE / "maps" / f"fused_train_{a.method}.npz")
from evalkit import fit_switch  # noqa: E402
tr_ds = load_split("train", [a.method]) if a.split != "train" else ds
gt_tr = np.stack([tr_ds.m128[n] for n in ztr["names"].tolist()]).astype(bool)
tg = fit_switch(ztr["logit128"].astype(np.float32), gt_tr, ztr["g"], np.arange(len(gt_tr)))["tg"]
pos = {n: i for i, n in enumerate(fnames)}
if a.names:
    want = set(a.names.split(","))
    idx = [i for i, m in enumerate(ds.meta) if m["image_name"] in want]
else:
    idx = [i for i, m in enumerate(ds.meta) if FG[pos[m["image_name"]]] <= tg + a.gmargin]
idx = idx[:a.nmax][a.shard::a.nshards]
COARSE = coarse_boxes(a.coarse) if a.coarse else []
print(f"{a.method} {a.split} shard {a.shard}: {len(idx)} images, tg={tg:.3f}, coarse boxes/img {len(COARSE)}", flush=True)

rec = {k: [] for k in ("names", "boxes", "acc", "conf", "src", "best_map_acc", "best_coarse_acc")}
t0 = time.time()
for k, i in enumerate(idx):
    it = ds[i]; n = it["image_name"]
    x = torch.from_numpy(np.array(it["image"])).permute(2, 0, 1).float().div(255).to(dev)
    sgn = torch.as_tensor(it["message"].astype(np.float32) * 2 - 1, device=dev)
    ms = map_seeds(FL[pos[n]]); cs = []
    if COARSE:
        _, conf = score(x, COARSE, sgn); taken = []
        for j in np.argsort(-conf):
            b = COARSE[j]
            if all(box_iou(b, t) < 0.5 for t in taken):
                taken.append(b)
            if len(taken) >= a.topk:
                break
        cs = taken
    if not ms and not cs:
        ms = [(128, 384, 128, 384)]                                   # nothing proposed: a central box as the only seed
    res = refine_all(x, sgn, ms + cs)
    src = ["map"] * len(ms) + ["coarse"] * len(cs)
    best = max(range(len(res)), key=lambda j: (res[j][1], res[j][2]))
    bm = max([r[1] for r, s in zip(res, src) if s == "map"], default=-1.0); bc = max([r[1] for r, s in zip(res, src) if s == "coarse"], default=-1.0)
    for key_, v in (("names", n), ("boxes", res[best][0]), ("acc", res[best][1]), ("conf", res[best][2]), ("src", src[best]),
                    ("best_map_acc", bm), ("best_coarse_acc", bc)):
        rec[key_].append(v)
    print(f"[{a.method} {a.split} {a.shard}] {k + 1}/{len(idx)} {n} box={res[best][0]} acc={res[best][1]:.3f} src={src[best]} "
          f"map={bm:.3f} coarse={bc:.3f} {(time.time() - t0) / (k + 1):.1f}s/img", flush=True)
    if (k + 1) % 10 == 0 or k + 1 == len(idx):
        np.savez(HERE / "maps" / f"rect2_{a.method}_{a.split}_{a.shard}.npz", **{kk: np.array(vv) for kk, vv in rec.items()})
print("done", flush=True)
