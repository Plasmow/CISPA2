"""Context-preserving localisation maps.

occlusion_scores(): whole image kept, only the window is replaced (gray or the window's mean colour);
                    score = conf(full image) - conf(occluded)  (> 0 where the window carried the watermark).
grad_maps():        gradient of the signed confidence conf = mean_bits(logit * (2m-1)) w.r.t. the 512 input
                    (PixelSeal / TrustMark, PyTorch). Maps: grad . hp(x) (signed contribution of the fine details),
                    grad . x, |grad|; each smoothed (gaussian sigma) and pooled to 128x128.
"""
import sys

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from windows import decode_logits  # noqa: E402
sys.path.insert(0, "/p/project1/training2666/debbah2/wmloc_unet")
from unet import gaussian_blur  # noqa: E402
from heatmap import positions  # noqa: E402


@torch.no_grad()
def occlusion_scores(wm, img_uint8, msg, sizes=(64, 96, 128), stride=32, fill="gray", dev="cuda"):
    x = torch.from_numpy(np.asarray(img_uint8)).permute(2, 0, 1).float().div(255).to(dev)
    sgn = torch.as_tensor(np.asarray(msg, np.float32) * 2 - 1)
    base = (decode_logits(wm, x[None])[0] * sgn).mean().item(); out = {}
    for w in sizes:
        ps = positions(w, stride); boxes = [(y, xx) for y in ps for xx in ps]; L = []
        for b in range(0, len(boxes), 64):
            batch = x[None].repeat(len(boxes[b:b + 64]), 1, 1, 1)
            for i, (y, xx) in enumerate(boxes[b:b + 64]):
                v = 0.5 if fill == "gray" else batch[i, :, y:y + w, xx:xx + w].mean((1, 2), keepdim=True)
                batch[i, :, y:y + w, xx:xx + w] = v
            L.append(decode_logits(wm, batch))
        out[w] = (base - (torch.cat(L) * sgn).mean(1)).reshape(len(ps), len(ps)).numpy()
    return out, base


def _conf_fn(wm):
    if wm.name == "pixelseal":
        return lambda x: wm.det(wm._resize(x))[:, 1:]
    if wm.name == "trustmark":
        return lambda x: wm.net(wm._prep(x))
    raise ValueError("gradients only for PyTorch decoders")


def grad_maps(wm, img_uint8, msg, sigmas=(4, 8, 16), dev="cuda"):
    f = _conf_fn(wm)
    x = torch.from_numpy(np.asarray(img_uint8)).permute(2, 0, 1)[None].float().div(255).to(dev).requires_grad_(True)
    sgn = torch.as_tensor(np.asarray(msg, np.float32) * 2 - 1, device=dev)
    with torch.enable_grad():
        conf = (f(x).float() * sgn).mean()
        (gx,) = torch.autograd.grad(conf, x)
    x = x.detach(); hx = x - gaussian_blur(x, 2.0)
    raw = {"g_hp": (gx * hx).sum(1, keepdim=True), "g_x": (gx * x).sum(1, keepdim=True),
           "g_abs": gx.abs().sum(1, keepdim=True)}
    out = {}
    for k, m in raw.items():
        for s in sigmas:
            out[f"{k}_s{s}"] = F.avg_pool2d(gaussian_blur(m, s), 4)[0, 0].cpu().numpy()
    return out, conf.item()
