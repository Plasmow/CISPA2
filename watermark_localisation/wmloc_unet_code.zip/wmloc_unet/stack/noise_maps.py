"""Local noise-level maps (noise-inconsistency forensics). Not learned -> trivially out-of-fold on the train.

Y = luminance (float, 512x512).
  n1 = log of mean over 8 px windows of (Y - Gaussian_1(Y))^2, then 4x4 average -> 128
  n2 = log of MAD/0.6745 of the HH sub-band of a 1-level Haar transform (median of |HH|, windows of 8 and 16 px,
       mean of the two logs), 2x2 average -> 128
  n3 = n1 - median of n1 over 64 px (16 cells)      n4 = n2 - median of n2 over 64 px
Per-image z-score, clip +-8 -> maps/{n1,n2,n3,n4}_{train,test}_<method>.npz (names in ds.meta order, logit128 float16).

  python noise_maps.py           # export (8 processes, 1 thread each)
  python noise_maps.py --pilot   # AUC T/F + complementarity with v12a on T -> W/results_noise_pilot.md
"""
import os
import sys
from multiprocessing import Pool
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np  # noqa: E402
from scipy import ndimage as ndi  # noqa: E402

sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, METHODS  # noqa: E402

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent; TAGS = ("n1", "n2", "n3", "n4"); DS = None


def pool(x, k):
    h = x.shape[0] // k; return x.reshape(h, k, h, k).mean((1, 3))


def zimg(m):
    return np.clip((m - m.mean()) / (m.std() + 1e-6), -8, 8)


def maps_of(img):
    Y = img.astype(np.float64) @ np.array([0.299, 0.587, 0.114])
    hp = Y - ndi.gaussian_filter(Y, 1.0)
    n1 = np.log(pool(ndi.uniform_filter(hp ** 2, 8), 4) + 1e-6)
    HH = np.abs(Y[0::2, 0::2] - Y[0::2, 1::2] - Y[1::2, 0::2] + Y[1::2, 1::2]) / 2   # 256x256, 1 coeff per 2 px
    n2 = pool(0.5 * sum(np.log(ndi.median_filter(HH, size=w) / 0.6745 + 1e-3) for w in (4, 8)), 2)
    n3 = n1 - ndi.median_filter(n1, size=16); n4 = n2 - ndi.median_filter(n2, size=16)
    return np.stack([zimg(m) for m in (n1, n2, n3, n4)]).astype(np.float16)


def work(i):
    return maps_of(np.asarray(DS[i]["image"]))


def export():
    global DS
    for split in ("train", "test"):
        DS = load_split(split)
        with Pool(8) as P:
            for meth in METHODS:
                idx = [i for i, m in enumerate(DS.meta) if m["method"] == meth]; names = np.array([DS.meta[i]["image_name"] for i in idx])
                M = np.stack(P.map(work, idx, chunksize=4)); assert np.isfinite(M.astype(np.float32)).all()
                for k, t in enumerate(TAGS):
                    np.savez(HERE / "maps" / f"{t}_{split}_{meth}.npz", names=names, logit128=M[:, k])
                print(split, meth, len(idx), flush=True)


def auc(s, y):
    from scipy.stats import rankdata
    s = np.asarray(s, np.float64).ravel(); y = np.asarray(y).astype(bool).ravel(); n1, n0 = y.sum(), (~y).sum()
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s); return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def logreg(X, y, lam=1e-3, iters=30):
    mu, sd = X.mean(0), X.std(0) + 1e-6; Z = np.c_[(X - mu) / sd, np.ones(len(X))]; w = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = 1 / (1 + np.exp(-Z @ w)); g = Z.T @ (p - y) / len(y) + lam * np.r_[w[:-1], 0]
        H = Z.T @ (Z * (p * (1 - p))[:, None]) / len(y) + lam * np.eye(len(w)); w -= np.linalg.solve(H, g)
    return lambda X_: np.c_[(X_ - mu) / sd, np.ones(len(X_))] @ w


def pilot(tags=TAGS, out="results_noise_pilot.md"):
    import torch
    tr = load_split("train"); d = torch.load(ROOT / "sam" / "submission_v12a" / "probs_train_oof.pt", weights_only=True)
    pv = {n: np.clip(p, 1e-4, 1 - 1e-4) for n, p in zip(d["image_names"], d["probs"].numpy())}
    lines = ["| carte | méthode | AUC T méd. | AUC F méd. | AUC T v12a | AUC T [v12a+carte] | gain T | gain T trous ≤ 6.5 % (n) |", "|---|---|---|---|---|---|---|---|"]
    for t in tags:
        for meth in METHODS:
            if not (HERE / "maps" / f"{t}_train_{meth}.npz").exists():
                continue
            z = np.load(HERE / "maps" / f"{t}_train_{meth}.npz"); names = z["names"].tolist(); M = z["logit128"].astype(np.float32)
            gt = np.stack([tr.m128[n] for n in names]).astype(bool)
            full = {m["image_name"]: m["full_watermark"] for m in tr.meta}; isT = np.array([full[n] for n in names])
            a = np.array([auc(M[i], gt[i]) for i in range(len(names))])
            Ti = np.where(isT)[0]; L = np.clip(np.stack([np.log(pv[names[i]] / (1 - pv[names[i]])) for i in Ti]), -8, 8); G = gt[Ti]; Zm = M[Ti]
            low = (~G).reshape(len(Ti), -1).mean(1) <= 0.065
            base = np.array([auc(L[j], G[j]) for j in range(len(Ti))]); comb = np.full(len(Ti), np.nan); half = np.arange(len(Ti)) % 2 == 0
            for trm in (half, ~half):
                tri = np.where(trm)[0]; f = logreg(np.c_[L[tri].reshape(-1)[::3], Zm[tri].reshape(-1)[::3]], G[tri].reshape(-1)[::3].astype(float))
                for j in np.where(~trm)[0]:
                    comb[j] = auc(f(np.c_[L[j].ravel(), Zm[j].ravel()]), G[j])
            dl = comb - base
            lines.append(f"| {t} | {meth} | {np.nanmedian(a[isT]):.3f} | {np.nanmedian(a[~isT]):.3f} | {np.nanmedian(base):.3f} | "
                         f"{np.nanmedian(comb):.3f} | {np.nanmean(dl):+.4f} | {np.nanmean(dl[low]):+.4f} ({low.sum()}) |")
            print(lines[-1], flush=True)
    (ROOT / out).write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    if "--pilot" in sys.argv:
        t = [a for a in sys.argv[1:] if not a.startswith("--")]
        pilot(t or TAGS, f"results_{t[0]}_pilot.md" if t else "results_noise_pilot.md")
    else:
        export()
