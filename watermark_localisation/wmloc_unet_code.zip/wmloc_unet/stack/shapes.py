"""Structured masks: exploit that the true regions come from a few shape families (rectangle, object, blobs,
rectangle with holes, rectangle + shape) instead of thresholding cell by cell (CPU only).

For every image:
  1. candidates from the fused probability map P (calibrated: the fusion is a logistic regression):
       thresholds at several levels, each in several shape versions (raw, single component, holes filled,
       small pieces removed, closed), on the minority side (holes for type T, regions for type F);
       for type F with a decoder box: the box, the box minus the predicted holes, the box + the largest component;
       all-1 / all-0.
  2. pick the candidate with the highest EXPECTED mIoU under P (no label used -> applies to test as is), with
     a temperature on P fitted by cross-validation.
Reports, per method and type: current pipeline (route/v3 output if given), expected-mIoU choice, and the ORACLE
(best candidate per image, chosen with the ground truth) = how well the candidate families cover the true shapes.

    python shapes.py --maps fused      (uses maps/fused_{train,test}_<method>.npz written by v3.py --dump)
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi

from v3 import HERE, ROOT, METHODS, load_split, miou_batch, load_rect, folds

THRS = (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8)


def comps(m):
    lab, n = ndi.label(m)
    if n == 0:
        return lab, np.zeros(0)
    return lab, ndi.sum(m, lab, range(1, n + 1))


def shape_versions(region):
    """Minority-side region -> dict of shape versions."""
    out = {"raw": region}
    lab, sz = comps(region)
    if len(sz):
        big = lab == 1 + int(np.argmax(sz))
        out["largest"] = big; out["largest+fill"] = ndi.binary_fill_holes(big)
        keep = np.zeros(len(sz) + 1, bool); keep[1:] = sz >= 16; out["drop<16"] = keep[lab]
        keep2 = np.zeros(len(sz) + 1, bool); keep2[1:] = sz >= 64; out["drop<64"] = keep2[lab]
    out["fill"] = ndi.binary_fill_holes(region)
    out["close3+fill"] = ndi.binary_fill_holes(ndi.binary_closing(region, np.ones((3, 3))))
    out["open3"] = ndi.binary_opening(region, np.ones((3, 3)))
    return out


def candidates(P, typeT, box):
    """P [128,128] prob of watermark; typeT: minority = holes (P low) else regions (P high); box: [128,128] bool or None."""
    C = {"all1": np.ones_like(P, bool), "all0": np.zeros_like(P, bool)}
    for t in THRS:
        minority = (P < t) if typeT else (P > t)
        for k, m in shape_versions(minority).items():
            C[f"t{t}:{k}"] = ~m if typeT else m
    if box is not None and not typeT:
        C["box"] = box
        for t in (0.2, 0.3, 0.4):
            C[f"box-holes(P<{t})"] = box & ~(P < t)
        lab, sz = comps(P > 0.5)
        if len(sz):
            C["box+largest"] = box | (lab == 1 + int(np.argmax(sz)))
    return C


def expected_miou(P, M):
    """Expected per-image mIoU of mask M if the truth were drawn cell-wise from P (ratio-of-expectations approximation)."""
    p1 = P[M].sum(); q1 = P[~M].sum(); n1 = M.sum(); n0 = (~M).sum()
    iou1 = 1.0 if n1 == 0 and q1 < 0.5 else p1 / max(n1 + q1, 1e-6)
    p0 = (1 - P)[~M].sum(); q0 = (1 - P)[M].sum()
    iou0 = 1.0 if n0 == 0 and q0 < 0.5 else p0 / max(n0 + q0, 1e-6)
    return (iou1 + iou0) / 2


def run(meth, L, g, gt, full, names, B, temps=(0.5, 0.75, 1.0, 1.5, 2.0), tg=None):
    N = len(L); typT = g > tg
    cand_scores = {}            # temp -> per image chosen score
    oracle = np.zeros(N); chosen = {}
    all_c = []
    for i in range(N):
        box = B[names[i]][0] if (B and names[i] in B and B[names[i]][1] >= 0.85) else None
        C = candidates(1 / (1 + np.exp(-L[i])), bool(typT[i]), box)
        keys = list(C); masks = np.stack([C[k] for k in keys])
        true = miou_batch(masks, np.broadcast_to(gt[i], masks.shape)); oracle[i] = true.max()
        all_c.append((keys, masks, true))
    for T in temps:
        s = np.zeros(N); pick = []
        for i, (keys, masks, true) in enumerate(all_c):
            P = 1 / (1 + np.exp(-L[i] / T)); e = np.array([expected_miou(P, m) for m in masks]); j = int(e.argmax())
            s[i] = true[j]; pick.append(keys[j])
        cand_scores[T] = (s, pick)
    # temperature chosen by CV (selection uses labels only through the choice of T)
    cv = np.zeros(N)
    for f in folds(N, 5, 7):
        trn = np.setdiff1d(np.arange(N), f); Tb = max(temps, key=lambda T: cand_scores[T][0][trn].mean()); cv[f] = cand_scores[Tb][0][f]
    Tall = max(temps, key=lambda T: cand_scores[T][0].mean())
    return cv, oracle, Tall, cand_scores[Tall][1]


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--maps", default="fused"); a = ap.parse_args()
    tr = load_split("train"); lines = []
    for meth in METHODS:
        z = np.load(HERE / "maps" / f"{a.maps}_train_{meth}.npz"); names = z["names"].tolist()
        L = z["logit128"].astype(np.float32); g = z["g"]
        gt = np.stack([tr.m128[n] for n in names]).astype(bool); full = np.array([next(m for m in tr.meta if m["image_name"] == n)["full_watermark"] for n in names])
        from evalkit import fit_switch
        tg = fit_switch(L, gt, g, np.arange(len(L)))["tg"]
        B = load_rect(meth, "train") if load_rect(meth, "test") else {}
        cv, oracle, T, pick = run(meth, L, g, gt, full, names, B, tg=tg)
        from collections import Counter
        fam = Counter(p.split(":")[-1] if ":" in p else p for p in pick).most_common(6)
        lines.append(f"| {meth} | {cv.mean():.4f} | {cv[full].mean():.4f} | {cv[~full].mean():.4f} | {oracle.mean():.4f} | {oracle[full].mean():.4f} | {oracle[~full].mean():.4f} | T={T} | {fam} |")
        print(lines[-1], flush=True)
    hdr = ["| method | expected-mIoU choice (CV) | type T | type F | ORACLE best candidate | type T | type F | temperature | most chosen shapes |", "|---|---|---|---|---|---|---|---|---|"]
    (ROOT / "results_shapes.md").write_text("\n".join(hdr + lines) + "\n")


if __name__ == "__main__":
    main()
