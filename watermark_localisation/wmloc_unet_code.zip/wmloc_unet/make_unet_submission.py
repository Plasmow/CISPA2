"""Write a submission .pt from the U-Net test maps (mean over the 5 fold models). Does NOT upload.

    python make_unet_submission.py --variant rgb_glob --thr cv --out submission_unet.pt
--variant : a run name, or "ensemble" (mean of the given --members)
--thr     : "0.5" (fixed) or "cv" (per-method threshold fitted on all OOF train maps)
"""
import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(TASK / "starter_kit"))
from wmloc.data import LocalisationDataset  # noqa: E402
from evalkit import fit_single  # noqa: E402

METHODS = ("pixelseal", "trustmark", "stegastamp")


def load_maps(v, members):
    vs = members if v == "ensemble" else [v]
    oof = [np.load(HERE / "runs" / m / "oof_all.npz") for m in vs]; te = [np.load(HERE / "runs" / m / "test_mean.npz") for m in vs]
    return (oof[0]["names"], np.mean([o["prob"].astype(np.float32) for o in oof], 0),
            te[0]["names"], np.mean([t["prob"].astype(np.float32) for t in te], 0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", required=True); ap.add_argument("--members", nargs="*", default=[])
    ap.add_argument("--thr", default="cv", choices=["0.5", "cv"]); ap.add_argument("--out", default="submission_unet.pt")
    a = ap.parse_args()
    tr = LocalisationDataset(TASK / "release", "train"); te = LocalisationDataset(TASK / "release", "test")
    tr_names, oof, te_names, test = load_maps(a.variant, a.members)
    assert list(tr_names) == [m["image_name"] for m in tr.meta]
    te_meth = {m["image_name"]: m["method"] for m in te.meta}; tr_meth = np.array([m["method"] for m in tr.meta])
    gt = np.stack([tr.m128[n] for n in tr_names]).astype(bool)
    thr = {}
    for m in METHODS:
        thr[m] = 0.5 if a.thr == "0.5" else float(fit_single(oof, gt, np.where(tr_meth == m)[0])["t"])
    masks = np.stack([test[i] > thr[te_meth[n]] for i, n in enumerate(te_names)])
    names = [str(n) for n in te_names]
    # checks: every test image exactly once, shape, binary values, size
    assert sorted(names) == sorted(m["image_name"] for m in te.meta) and len(set(names)) == len(names) == 1020
    sub = {"image_names": names, "masks": torch.from_numpy(masks).bool()}
    assert sub["masks"].shape == (1020, 128, 128)
    out = HERE / a.out; torch.save(sub, out)
    re = torch.load(out, weights_only=True)
    assert re["masks"].dtype == torch.bool and re["image_names"] == names
    size = os.path.getsize(out) / 2 ** 20
    assert size < 20, size
    print(json.dumps(dict(out=str(out), thresholds=thr, size_MB=round(size, 2),
                          frac_pred_1=float(masks.mean()))))


if __name__ == "__main__":
    main()
