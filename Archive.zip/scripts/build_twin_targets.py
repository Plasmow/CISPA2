"""Build per-image gold-proxy targets from unseen twins (scripts/gen_twins.py output). CPU only.

target(x) = average over the k twins v of x of softmax(orig(v))   ("mean"; "geo" = normalised geometric mean)
Labels = the original's argmax on the clean forget image (≈100% correct on training images).

Writes output/targets/tw<s>.pt in the build_targets.py format (probs_mean, probs_geo, labels), so it plugs into
  python scripts/distill.py --run X --target output/targets/tw0.5.pt [--proxy_twins 'output/twins/s0.7_sh*.npz']
and prints the stats the leaderboard has taught us to watch (see memory: SCRUB C@180 0.96±2.12, maxp 0.83 -> 0.0998;
confidently-wrong outputs with maxp >= 0.97 score 0).

Usage (from unlearning/):  python scripts/build_twin_targets.py [--strengths 0.3,0.5,0.7]
"""
import argparse
import glob
import json
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
TW = ROOT / "output" / "twins"
TDIR = ROOT / "output" / "targets"
SINKS = [85, 48, 86, 28, 27]  # wrong-mass sinks of the strong augmentation targets


def load_strength(s):
    files = sorted(glob.glob(str(TW / f"s{s:g}_sh*.npz")))
    files = [f for f in files if ".tmp" not in f]
    if not files:
        return None, None
    idx, logits = [], []
    for f in files:
        with np.load(f) as d:
            idx.append(d["idx"])
            logits.append(d["logits"])
    return np.concatenate(idx), torch.from_numpy(np.concatenate(logits)).float()


def stats(q, y, clean_logits, counts):
    loss = -q.clamp_min(1e-12).log().gather(1, y[:, None])[:, 0]
    qT = F.softmax(q.clamp_min(1e-12).log() / 2, -1)
    wrong = q.argmax(1) != y
    top2 = clean_logits.topk(2, 1).indices[:, 1]
    full = torch.isin(y, torch.tensor([0, 6, 7, 8, 29, 30, 31, 33, 38]))
    q_wrong = q * (1 - F.one_hot(y, q.shape[1]))
    return {
        "n": len(y),
        "acc": 1 - wrong.float().mean().item(),
        "loss_mean": loss.mean().item(), "loss_std": loss.std().item(),
        "loss_median": loss.median().item(), "loss_p90": loss.quantile(0.9).item(),
        "maxp": q.max(1).values.mean().item(),
        "ent_T2": (-(qT * qT.clamp_min(1e-12).log()).sum(1)).mean().item(),
        "wrong_is_orig_top2": (q.argmax(1)[wrong] == top2[wrong]).float().mean().item() if wrong.any() else float("nan"),
        "wrong_mass_to_sinks": (q_wrong[:, SINKS].sum(1) / q_wrong.sum(1).clamp_min(1e-12)).mean().item(),
        "loss_mean_130cap": loss[full].mean().item(), "loss_mean_other": loss[~full].mean().item(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strengths", default="0.3,0.5,0.7")
    a = ap.parse_args()
    d = torch.load(ROOT / "output" / "diag_orig.pt", map_location="cpu", weights_only=False)
    z, y_all = d["logits"].float(), d["labels"]
    counts = torch.bincount(y_all, minlength=z.shape[1])
    TDIR.mkdir(parents=True, exist_ok=True)
    summary_path = TDIR / "summary_twins.json"
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}

    for s in [float(v) for v in a.strengths.split(",")]:
        idx, lg = load_strength(s)
        if idx is None:
            print(f"s={s:g}: no shards yet")
            continue
        n_have = len(idx)
        # twin agreement with the clean label, per twin (how often a twin keeps the class)
        y = y_all[idx]
        P = F.softmax(lg, -1)                                   # [n, k, C]
        keep = (lg.argmax(-1) == y[:, None]).float().mean().item()
        q_mean = P.mean(1)
        lp = F.log_softmax(lg, -1).mean(1)
        q_geo = F.softmax(lp, -1)
        st = {"mean": stats(q_mean, y, z[idx], counts), "geo": stats(q_geo, y, z[idx], counts),
              "twin_keeps_label": keep}
        summary[f"tw{s:g}"] = st
        print(f"\n=== tw{s:g}  ({n_have}/{len(y_all)} images, k={lg.shape[1]}, twins keep label {keep:.3f})")
        for agg in ("mean", "geo"):
            print(f"  {agg:4s} " + "  ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}"
                                            for k, v in st[agg].items()))
        if n_have == len(y_all):
            order = np.argsort(idx)
            assert np.array_equal(idx[order], np.arange(len(y_all)))
            torch.save({"probs_mean": q_mean[order], "probs_geo": q_geo[order], "labels": y_all,
                        "level": f"twins_s{s:g}", "k": int(lg.shape[1]), "stats": ["mean", "geo"]},
                       TDIR / f"tw{s:g}.pt")
            print(f"  wrote {TDIR / f'tw{s:g}.pt'}")
    summary_path.write_text(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
