| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet', 'wmunet0'] | 0.6097 | 0.6184 | 0.6009 |
| pixelseal | fusion top3 ['wmunet', 'wmunet0', 'wmunetF'] | 0.6097 | 0.6204 | 0.5990 |
| pixelseal | fusion all ['wmunet', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6139 | 0.6264 | 0.6014 |
| pixelseal | fusion all + rule switch | 0.6139 | 0.6264 | 0.6014 |
| pixelseal | fusion all + rule expected_area | 0.6121 | 0.6300 | 0.5941 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6153 | 0.6272 | 0.6033 |
| pixelseal | fusion all + rule regressed_area | 0.5920 | 0.6093 | 0.5747 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6464 | 0.6585 | 0.6343 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: otsu_in_regime) | 0.6153 | 0.6272 | 0.6033 |
| pixelseal | **v2 pipeline**: fusion all + otsu_in_regime + post T:close_holes5 / F:drop<64 | **0.6144** | 0.6272 | 0.6015 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6162 | 0.6283 | 0.6041 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6323 | 0.6283 | 0.6363 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6452 | 0.6283 | 0.6621 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6469 | 0.6283 | 0.6655 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6484 | 0.6283 | 0.6685 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6377 | 0.6283 | 0.6470 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6340 | 0.6283 | 0.6396 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6467** | 0.6283 | 0.6650 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6078 | 0.6100 | 0.6055 |
| trustmark | fusion top3 + rule switch | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion top3 + rule expected_area | 0.6132 | 0.6235 | 0.6029 |
| trustmark | fusion top3 + rule otsu_in_regime | 0.6108 | 0.6149 | 0.6067 |
| trustmark | fusion top3 + rule regressed_area | 0.5947 | 0.6109 | 0.5786 |
| trustmark | fusion top3 + ORACLE per-image threshold (upper bound) | 0.6438 | 0.6548 | 0.6329 |
| trustmark | fusion top3 + CV-selected rule (whole-train choice: expected_area) | 0.6132 | 0.6235 | 0.6029 |
| trustmark | **v2 pipeline**: fusion top3 + expected_area + post T:close_holes5 / F:largest | **0.6170** | 0.6223 | 0.6117 |
| trustmark | + rect override none (boxes for 85 train images) | 0.6175 | 0.6232 | 0.6117 |
| trustmark | + rect override rect>=0.7 (boxes for 85 train images) | 0.6457 | 0.6232 | 0.6682 |
| trustmark | + rect override rect>=0.75 (boxes for 85 train images) | 0.6723 | 0.6232 | 0.7213 |
| trustmark | + rect override rect>=0.8 (boxes for 85 train images) | 0.6796 | 0.6232 | 0.7359 |
| trustmark | + rect override rect>=0.85 (boxes for 85 train images) | 0.6827 | 0.6232 | 0.7421 |
| trustmark | + rect override rect>=0.9 (boxes for 85 train images) | 0.6827 | 0.6232 | 0.7421 |
| trustmark | + rect override rect>=0.95 (boxes for 85 train images) | 0.6827 | 0.6232 | 0.7421 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6723** | 0.6232 | 0.7213 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot', 'headsyn2', 'headmulti', 'remark'] | 0.6861 | 0.7246 | 0.6477 |
| stegastamp | fusion all + rule switch | 0.6861 | 0.7246 | 0.6477 |
| stegastamp | fusion all + rule expected_area | 0.6937 | 0.7278 | 0.6596 |
| stegastamp | fusion all + rule otsu_in_regime | 0.6898 | 0.7294 | 0.6501 |
| stegastamp | fusion all + rule regressed_area | 0.6766 | 0.7099 | 0.6432 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7251 | 0.7602 | 0.6899 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.6937 | 0.7278 | 0.6596 |
| stegastamp | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<64 / F:largest | **0.6935** | 0.7292 | 0.6579 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "otsu_in_regime",
  "post_T": "close_holes5",
  "post_F": "drop<64",
  "rect": "rect>=0.85",
  "cv": 0.6467,
  "cv_T": 0.6283,
  "cv_F": 0.665,
  "test_frac_pred_1": 0.486
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0"
  ],
  "rule": "expected_area",
  "post_T": "close_holes5",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6723,
  "cv_T": 0.6232,
  "cv_F": 0.7213,
  "test_frac_pred_1": 0.497
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "none",
  "cv": 0.6935,
  "cv_T": 0.7292,
  "cv_F": 0.6579,
  "test_frac_pred_1": 0.484
 },
 "expected_cv_mIoU": 0.6708,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v4_wmunet.pt",
 "size_MB": 15.96
}
```
