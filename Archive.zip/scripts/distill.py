"""Targeted unlearning: distil the model toward per-image soft targets on the forget set, while staying close to the
original elsewhere.

  forget loss : KL(q_i || p_student(aug(x_i)))      q_i = soft target from build_targets.py (optionally re-tempered)
  retain loss : alpha * KL(p_teacher || p_student)  on proxy inputs (mixup/cutmix of augmented forget images)
  anchor      : l2sp * ||theta - theta_orig||^2     (optional)

Unlike SCRUB's unbounded "push away" objective, this objective has a fixed point: the model stops moving once it
predicts q_i, so no rewinding is needed to avoid over-forgetting, and the wrong class it picks comes from the target.

Usage (from unlearning/):
  python scripts/distill.py --run d_s2 --target output/targets/s2.pt [--agg mean --tau 1.0 --lr 1e-5 --epochs 8]
"""
import argparse
import copy
import json
import time

import torch
import torch.nn.functional as F

import common as C


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--agg", default="mean", choices=["mean", "geo"])
    ap.add_argument("--tau", type=float, default=1.0, help="re-temper targets: q ∝ q^(1/tau)  (>1 softer)")
    ap.add_argument("--mix", type=float, default=0.0, help="q = (1-mix)*q + mix*teacher_clean (less forgetting)")
    ap.add_argument("--lr", type=float, default=1e-5)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--bs_f", type=int, default=64)
    ap.add_argument("--bs_r", type=int, default=128)
    ap.add_argument("--alpha", type=float, default=1.0)
    ap.add_argument("--l2sp", type=float, default=0.0)
    ap.add_argument("--train_from_block", type=int, default=0)
    ap.add_argument("--clean_frac", type=float, default=0.0, help="fraction of each forget batch left un-augmented")
    ap.add_argument("--init", default="", help="state dict to initialise the student from (default: model.pt)")
    ap.add_argument("--proxy_twins", default="", help="glob(s) of output/twins/*.npz used as retain proxies")
    ap.add_argument("--twin_frac", type=float, default=1.0, help="fraction of each retain batch taken from twins")
    ap.add_argument("--outside", default="", help="npz of outside images (key 'images') used as retain anchors, "
                                                  "e.g. output/outside_task1/images_224.npz")
    ap.add_argument("--tail_w", type=float, default=0.0, help="forget-loss weight per image = (1 + target loss)^tail_w "
                                                               "(normalised to mean 1); 0 = unweighted")
    ap.add_argument("--outside_minconf", type=float, default=0.9, help="keep outside images with teacher maxp > this")
    ap.add_argument("--outside_frac", type=float, default=0.0, help="fraction of each retain batch from outside images")
    ap.add_argument("--outside_holdout", type=float, default=0.2, help="fraction of kept outside images held out "
                                                                       "to measure retain drift (KL orig||student)")
    ap.add_argument("--warmup", type=int, default=20)
    ap.add_argument("--eval_every", type=int, default=50)
    ap.add_argument("--save", type=int, default=1)
    ap.add_argument("--keep", type=int, default=0, help="keep only the last K checkpoints of this run (0 = keep all)")
    ap.add_argument("--seed", type=int, default=0)
    return ap.parse_args()


def soft_ce(q, logits):
    """KL(q || softmax(logits)) up to a constant = cross-entropy with soft targets."""
    return -(q * F.log_softmax(logits, -1)).sum(1).mean()


def kd(t_logits, s_logits, T=2.0):
    return F.kl_div(F.log_softmax(s_logits / T, -1), F.log_softmax(t_logits / T, -1),
                    reduction="batchmean", log_target=True) * T * T


def main():
    a = parse()
    torch.manual_seed(a.seed)
    out = C.ROOT / "output" / a.run
    out.mkdir(parents=True, exist_ok=True)
    (out / "args.json").write_text(json.dumps(vars(a), indent=1))
    log = out / "log.jsonl"
    log.unlink(missing_ok=True)

    teacher, imgs = C.load_all()
    for p in teacher.parameters():
        p.requires_grad_(False)
    student = copy.deepcopy(teacher)
    if a.init:  # start the student from another checkpoint (e.g. a SCRUB model); teacher stays the original
        student.load_state_dict(torch.load(a.init, map_location=C.DEVICE, weights_only=True), strict=True)
        print(f"student initialised from {a.init}", flush=True)
    ev = C.Evaluator(teacher, imgs)
    N = len(imgs)

    tg = torch.load(a.target, map_location="cpu")
    q = tg[f"probs_{a.agg}"].to(C.DEVICE).clamp_min(1e-8)
    if a.tau != 1.0:
        q = F.softmax(q.log() / a.tau, -1)
    if a.mix > 0:
        q = (1 - a.mix) * q + a.mix * F.softmax(ev.t_clean, -1)
    q = q / q.sum(1, keepdim=True)
    ql = -q.log().gather(1, ev.labels[:, None])[:, 0]
    wq = (1 + ql) ** a.tail_w
    wq = wq / wq.mean()
    tstats = {"target_acc": (q.argmax(1) == ev.labels).float().mean().item(),
              "target_loss_mean": ql.mean().item(), "target_loss_std": ql.std().item()}
    print("target:", tstats, flush=True)
    (out / "target_stats.json").write_text(json.dumps(tstats))

    params, anchors = [], []
    for n, p in student.named_parameters():
        trainable = True
        if a.train_from_block > 0:
            if n.startswith(("patch_embed", "cls_token", "pos_embed")):
                trainable = False
            elif n.startswith("blocks."):
                trainable = int(n.split(".")[1]) >= a.train_from_block
        p.requires_grad_(trainable)
        if trainable:
            params.append(p)
            anchors.append(p.detach().clone())
    print(f"trainable params: {sum(p.numel() for p in params) / 1e6:.1f}M", flush=True)
    opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
    iters = a.epochs * (N // a.bs_f)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / a.warmup) * 0.5 * (1 + torch.cos(torch.tensor(s / iters * 3.14159)).item()))
    g = torch.Generator(device=C.DEVICE).manual_seed(a.seed)

    twins = None
    if a.proxy_twins:
        import glob
        import numpy as np
        files = sorted(f for pat in a.proxy_twins.split(",") for f in glob.glob(str(C.ROOT / pat)))
        arr = [np.load(f)["images"] for f in files]
        twins = torch.from_numpy(np.concatenate([x.reshape(-1, *x.shape[-3:]) for x in arr])).to(C.DEVICE)
        print(f"twin proxies: {len(twins)} images from {len(files)} files", flush=True)

    out_tr = out_ho = out_ho_t = None
    if a.outside:
        import numpy as np
        ou = torch.from_numpy(np.load(C.ROOT / a.outside)["images"]).to(C.DEVICE)
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            tl = torch.cat([teacher(C.norm(C.u8_to01(ou[i:i + 128]))).float() for i in range(0, len(ou), 128)])
        conf, lab = tl.softmax(1).max(1)
        keep = (conf > a.outside_minconf).nonzero()[:, 0]
        keep = keep[torch.randperm(len(keep), generator=torch.Generator().manual_seed(0)).to(C.DEVICE)]
        nho = int(round(a.outside_holdout * len(keep)))
        out_ho, out_tr = ou[keep[:nho]], ou[keep[nho:]]
        out_ho_t = tl[keep[:nho]]
        print(f"outside anchors: {len(keep)}/{len(ou)} with maxp>{a.outside_minconf} covering "
              f"{lab[keep].unique().numel()} classes -> {len(out_tr)} train / {len(out_ho)} held out", flush=True)

    @torch.no_grad()
    def outside_drift():
        """KL(orig || student) at T=2 and argmax agreement on held-out outside images (retain-score proxy)."""
        if out_ho is None or len(out_ho) == 0:
            return {}
        student.eval()
        with torch.autocast(device_type="cuda", dtype=torch.float16):
            s = torch.cat([student(C.norm(C.u8_to01(out_ho[i:i + 128]))).float() for i in range(0, len(out_ho), 128)])
        lt, ls = F.log_softmax(out_ho_t / 2, -1), F.log_softmax(s / 2, -1)
        return {"out_kl": (lt.exp() * (lt - ls)).sum(1).mean().item(),
                "out_agree": (s.argmax(1) == out_ho_t.argmax(1)).float().mean().item()}

    def evaluate(step, extra):
        r = ev(student)
        r.update(outside_drift())
        # how close the student is to the targets (on clean forget images, temperature 2 like the server)
        c = ev.sets.logits(student, "clean")
        qT = F.softmax(q.log() / 2, -1)
        r["kl_target_T2"] = (qT * (qT.clamp_min(1e-12).log() - F.log_softmax(c / 2, -1))).sum(1).mean().item()
        r.update(step=step, t=round(time.time() - t0, 1), **extra)
        C.log_jsonl(log, r)
        print(f"[{step:5d}] clean acc {r['clean_acc']:.3f} loss {r['clean_loss_mean']:.3f}±{r['clean_loss_std']:.3f} "
              f"| mild acc {r['mild_acc']:.3f} loss {r['mild_loss_mean']:.3f}±{r['mild_loss_std']:.3f} "
              f"| KL->target {r['kl_target_T2']:.3f} | proxy KL {r['proxy_kl']:.4f} agree {r['proxy_agree']:.3f} "
              f"| wrong=top2 {r['wrong_is_teacher_top2']:.2f} "
              + (f"| out KL {r['out_kl']:.4f} agree {r['out_agree']:.3f} " if "out_kl" in r else "")
              + f"| {extra}", flush=True)
        if a.save:
            C.save_state_dict(student, out / f"ckpt_{step:05d}.pt")
            if a.keep > 0:  # disk quota: keep only this run's last `keep` checkpoints
                for old in sorted(out.glob("ckpt_*.pt"))[:-a.keep]:
                    old.unlink(missing_ok=True)
        student.train()

    t0 = time.time()
    evaluate(0, {})
    step = 0
    for epoch in range(a.epochs):
        student.train()
        perm = torch.randperm(N, generator=g, device=C.DEVICE)
        for it in range(N // a.bs_f):
            idx = perm[it * a.bs_f:(it + 1) * a.bs_f]
            x01 = C.u8_to01(imgs[idx])
            xa = C.augment(x01, g)
            if a.clean_frac > 0:  # half the forget score is on the EXACT images: train on them too
                nc = int(round(a.clean_frac * len(idx)))
                xa[:nc] = x01[:nc]
            xf = C.norm(xa)
            no = int(round(a.outside_frac * a.bs_r)) if out_tr is not None else 0
            nt = min(int(round(a.twin_frac * a.bs_r)), a.bs_r - no) if twins is not None else 0
            parts = []
            if no > 0:  # outside images: student must stay = teacher there (covers the non-forget classes)
                io_ = torch.randint(0, len(out_tr), (no,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(out_tr[io_]), g, scale=(0.7, 1.0), noise=0.02))
            if nt > 0:  # unseen in-distribution twins: student must stay = teacher there
                it_ = torch.randint(0, len(twins), (nt,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(twins[it_]), g, scale=(0.7, 1.0), noise=0.02))
            nm = a.bs_r - nt - no  # remaining slots: mixup/cutmix of FORGET images (pins forget-like inputs to orig)
            if nm > 0:
                ia = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                ib = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                parts.append(C.mix_proxy(C.augment(C.u8_to01(imgs[ia]), g), C.augment(C.u8_to01(imgs[ib]), g), g))
            xr = C.norm(torch.cat(parts))
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                with torch.no_grad():
                    tr = teacher(xr).float()
                s = student(torch.cat([xf, xr])).float()
            if a.tail_w > 0:  # per-image weights: push harder on high-target-loss images (heavy tail -> loss std)
                lf = (wq[idx] * -(q[idx] * F.log_softmax(s[:len(xf)], -1)).sum(1)).mean()
            else:
                lf = soft_ce(q[idx], s[:len(xf)])
            lr_ = kd(tr, s[len(xf):])
            loss = lf + a.alpha * lr_
            if a.l2sp > 0:
                loss = loss + a.l2sp * sum(((p - p0) ** 2).sum() for p, p0 in zip(params, anchors))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            sched.step()
            step += 1
            if step % a.eval_every == 0:
                evaluate(step, {"ep": epoch, "lf": round(lf.item(), 4), "lr": round(lr_.item(), 5)})
    if step % a.eval_every != 0:
        evaluate(step, {"ep": a.epochs - 1})
    print(f"done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
