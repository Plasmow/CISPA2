"""Extra encoder families for the "stack" U-Net (diversity for the fusion), without modifying train_unet.py.

    python train_unet_more.py --variant hrw18_hp_glob_stack --epochs 60      # same CLI as train_unet.py
    python train_unet_more.py --collect hrw18_hp_glob_stack ...               # fold files -> oof_all.npz / test_mean.npz
Outputs: runs/<variant>/fold<k>/..., then runs/<variant>/{oof_all.npz,test_mean.npz} (same format as eval_unet.py).
"""
import sys
from pathlib import Path

import numpy as np

import train_unet as T

NEW = {
    "regy040_hp_glob_stack": "regnety_040.ra3_in1k",
    "effv2m_hp_glob_stack": "tf_efficientnetv2_m.in21k_ft_in1k",
    "effb4_hp_glob_stack": "efficientnet_b4.ra2_in1k",
    "hrw18_hp_glob_stack": "hrnet_w18.ms_aug_in1k",
    "rx50_hp_glob_stack": "resnext50_32x4d.a1h_in1k",
    "serx50_hp_glob_stack": "seresnext50_32x4d.gluon_in1k",
    "r2n50_hp_glob_stack": "res2net50_26w_4s.in1k",
    "regzd8_hp_glob_stack": "regnetz_d8.ra3_in1k",
}
for v, enc in NEW.items():
    T.VARIANTS[v] = dict(highpass=True, glob_dim=5, encoder=enc, stack=True)


def collect(variants):
    """Only touches the given variants (eval_unet.py would rewrite every run directory)."""
    ds = T.LocalisationDataset(T.TASK / "release", "train")
    names = [m["image_name"] for m in ds.meta]
    for v in variants:
        d = Path(T.HERE) / "runs" / v
        fs = sorted(d.glob("fold*/oof.npz"))
        if len(fs) < 5:
            print(f"skip {v}: {len(fs)}/5 folds", flush=True); continue
        oof = {}
        for f in fs:
            z = np.load(f); oof.update(zip(z["names"].tolist(), z["prob"].astype(np.float32)))
        tz = [np.load(f.parent / "test.npz") for f in fs]
        tn = tz[0]["names"]; assert all((t["names"] == tn).all() for t in tz)
        np.savez(d / "oof_all.npz", names=np.array(names), prob=np.stack([oof[n] for n in names]).astype(np.float16))
        np.savez(d / "test_mean.npz", names=tn, prob=np.mean([t["prob"].astype(np.float32) for t in tz], 0).astype(np.float16))
        print(f"collected {v}", flush=True)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--collect":
        collect(sys.argv[2:])
    else:
        T.main()
