"""VAE reconstruction residual maps (AEROBLADE-like), no training.

Idea: content produced by a latent-diffusion VAE decoder is reconstructed almost exactly by encode + decode with the same
VAE, whereas the watermark residual added after generation is off the VAE manifold and is removed by the reconstruction.
|y - VAE(y)| should therefore be larger in watermarked zones than in holes / generated zones.

Maps (grid 128 by 4x4 average pooling of the 512 pixel map), y in [-1, 1], encoding = mean of latent_dist, fp32:
    v1 = log(mean over channels |y - rec| + 1e-4)
    v2 = the same on the high-passed residual: hp(d) = d - GaussianBlur_sigma1(d), d = y - rec
VAEs: sd-mse = stabilityai/sd-vae-ft-mse, sdxl = madebyollin/sdxl-vae-fp16-fix, sd-ema = stabilityai/sd-vae-ft-ema.

Pilot (CPU, 8 threads):  python vae_rec.py --pilot 15 --vaes sd-mse sdxl
    15 T + 15 F train images per method. Per image AUC of the map against m128 (1 = watermarked; AUC > 0.5 = map higher
    where watermarked), median for T and for F. Complementarity on the T images: 2-fold CV by image of a logistic
    regression on [v12a OOF logit, per-image z-scored VAE map] vs the v12a logit alone (per-image AUC).
    Writes W/results_vae_pilot.md and W/stack/maps/vaepilot.npz.
Export (GPU):  python vae_rec.py --export --vaes sd-mse --variant v1 --dev cuda
    All train + test images, 3 methods; per-image z-score, clip +-8 -> W/stack/maps/vaerec_{train,test}_<m>.npz
    (names in the order of the other maps, logit128 float16). Not learned, hence trivially out-of-fold on the train.
"""
import argparse
import os
import sys
import time
from pathlib import Path

P1 = "/p/project1/training2666/debbah2"
for k, v in {"HF_HOME": f"{P1}/hf", "HF_HUB_CACHE": f"{P1}/hf/hub", "HUGGINGFACE_HUB_CACHE": f"{P1}/hf/hub",
             "HF_XET_CACHE": f"{P1}/hf/xet"}.items():
    os.environ[k] = v                                            # never the /p/scratch cache of the user's profile
os.environ.setdefault("HF_HUB_OFFLINE", "1")
sys.path.insert(0, f"{P1}/pylibs")
import safetensors.torch  # noqa: E402,F401  (diffusers 0.32 + safetensors 0.8 needs the submodule imported first)
import numpy as np  # noqa: E402
import torch  # noqa: E402
import torch.nn.functional as F  # noqa: E402
from diffusers import AutoencoderKL  # noqa: E402

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, METHODS  # noqa: E402

VAES = {"sd-mse": "stabilityai/sd-vae-ft-mse", "sdxl": "madebyollin/sdxl-vae-fp16-fix", "sd-ema": "stabilityai/sd-vae-ft-ema"}


def gauss_kernel(sigma=1.0, r=3):
    t = torch.arange(-r, r + 1, dtype=torch.float32); k = torch.exp(-t ** 2 / (2 * sigma ** 2)); return k / k.sum()


def blur(x, sigma=1.0):
    k = gauss_kernel(sigma).to(x); C = x.shape[1]; r = (len(k) - 1) // 2
    x = F.pad(x, (r, r, r, r), mode="reflect")
    x = F.conv2d(x, k.view(1, 1, 1, -1).expand(C, 1, 1, -1), groups=C)
    return F.conv2d(x, k.view(1, 1, -1, 1).expand(C, 1, -1, 1), groups=C)


@torch.no_grad()
def vae_maps(vae, x01):
    """x01 [B,3,512,512] in [0,1] -> dict variant -> [B,128,128] float32 (numpy)."""
    y = x01 * 2 - 1
    rec = vae.decode(vae.encode(y).latent_dist.mean).sample.clamp(-1, 1)
    d = y - rec
    v1 = torch.log(d.abs().mean(1, keepdim=True) + 1e-4)
    v2 = torch.log((d - blur(d, 1.0)).abs().mean(1, keepdim=True) + 1e-4)
    return {k: F.avg_pool2d(v, 4)[:, 0].float().cpu().numpy() for k, v in (("v1", v1), ("v2", v2))}


def auc(s, y):
    from scipy.stats import rankdata
    s = np.asarray(s, np.float64).ravel(); y = np.asarray(y).astype(bool).ravel(); n1, n0 = y.sum(), (~y).sum()
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s); return float((r[y].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def zimg(m):
    return np.clip((m - m.mean()) / (m.std() + 1e-6), -8, 8)


def logreg(X, y, lam=1e-3, iters=30):
    mu, sd = X.mean(0), X.std(0) + 1e-6; Z = np.c_[(X - mu) / sd, np.ones(len(X))]; w = np.zeros(Z.shape[1])
    for _ in range(iters):
        p = 1 / (1 + np.exp(-Z @ w)); g = Z.T @ (p - y) / len(y) + lam * np.r_[w[:-1], 0]
        H = Z.T @ (Z * (p * (1 - p))[:, None]) / len(y) + lam * np.eye(len(w)); w -= np.linalg.solve(H, g)
    return lambda X_: np.c_[(X_ - mu) / sd, np.ones(len(X_))] @ w


def load_vae(name, dev):
    return AutoencoderKL.from_pretrained(VAES[name], torch_dtype=torch.float32).to(dev).eval()


def pilot(a):
    torch.set_num_threads(8)
    tr = load_split("train"); P = torch.load(ROOT / "sam" / "submission_v12a" / "probs_train_oof.pt", weights_only=True)
    pv = dict(zip(P["image_names"], P["probs"].numpy().astype(np.float32)))
    sel = {}
    for meth in METHODS:
        ms = [m for m in tr.meta if m["method"] == meth]
        T = [m["image_name"] for m in ms if m["full_watermark"]][:: 85 // a.pilot][:a.pilot]
        Fn = [m["image_name"] for m in ms if not m["full_watermark"]][:: 85 // a.pilot][:a.pilot]
        sel[meth] = (T, Fn)
    idx = {m["image_name"]: i for i, m in enumerate(tr.meta)}
    store = {}; lines = ["| VAE | variante | méthode | AUC T (médiane) | AUC F (médiane) | AUC T v12a seul | AUC T logistique [v12a, VAE] (CV 2 plis) | gain T |",
                         "|---|---|---|---|---|---|---|---|"]
    for vname in a.vaes:
        vae = load_vae(vname, "cpu"); t0 = time.time()
        for meth in METHODS:
            T, Fn = sel[meth]; names = T + Fn; maps = {"v1": [], "v2": []}
            for n in names:
                x = torch.from_numpy(np.array(tr[idx[n]]["image"])).permute(2, 0, 1).float()[None] / 255
                mm = vae_maps(vae, x)
                for k in maps:
                    maps[k].append(mm[k][0])
            print(f"[{vname}] {meth}: {len(names)} images, {(time.time() - t0):.0f}s", flush=True)
            for var in ("v1", "v2"):
                M = np.stack(maps[var]); store[f"{vname}_{var}_{meth}"] = M.astype(np.float16)
                gt = np.stack([tr.m128[n] for n in names]).astype(bool); isT = np.array([n in T for n in names])
                a_img = np.array([auc(M[i], gt[i]) for i in range(len(names))])
                # complementarity on T: 2-fold CV by image
                Ti = np.where(isT)[0]; L = np.stack([np.log(np.clip(pv[names[i]], 1e-4, 1 - 1e-4) / (1 - np.clip(pv[names[i]], 1e-4, 1 - 1e-4))) for i in Ti])
                Zm = np.stack([zimg(M[i]) for i in Ti]); G = gt[Ti]
                a_base = np.array([auc(L[j], G[j]) for j in range(len(Ti))]); a_comb = np.full(len(Ti), np.nan)
                half = np.arange(len(Ti)) % 2 == 0
                for trm in (half, ~half):
                    tri, tei = np.where(trm)[0], np.where(~trm)[0]
                    X = np.c_[np.clip(L[tri], -8, 8).reshape(-1)[::2], Zm[tri].reshape(-1)[::2]]; y = G[tri].reshape(-1)[::2].astype(float)
                    f = logreg(X, y)
                    for j in tei:
                        a_comb[j] = auc(f(np.c_[np.clip(L[j], -8, 8).ravel(), Zm[j].ravel()]), G[j])
                gain = np.nanmean(a_comb - a_base)
                lines.append(f"| {vname} | {var} | {meth} | {np.nanmedian(a_img[isT]):.3f} | {np.nanmedian(a_img[~isT]):.3f} | "
                             f"{np.nanmedian(a_base):.3f} | {np.nanmedian(a_comb):.3f} | {gain:+.3f} |")
                print(lines[-1], flush=True)
        del vae
    np.savez(HERE / "maps" / "vaepilot.npz", **store, **{f"names_{m}": np.array(sel[m][0] + sel[m][1]) for m in METHODS})
    (ROOT / "results_vae_pilot.md").write_text("\n".join(lines) + "\n")


def export(a):
    dev = a.dev; vae = load_vae(a.vaes[0], dev)
    for split in ("train", "test"):
        allm = load_split(split)
        for meth in METHODS:
            names = [m["image_name"] for m in allm.meta if m["method"] == meth]; idx = {m["image_name"]: i for i, m in enumerate(allm.meta)}
            out = np.zeros((len(names), 128, 128), np.float16); t0 = time.time()
            for b in range(0, len(names), a.bs):
                xs = torch.stack([torch.from_numpy(np.array(allm[idx[n]]["image"])).permute(2, 0, 1).float() / 255 for n in names[b:b + a.bs]]).to(dev)
                M = vae_maps(vae, xs)[a.variant]
                for j in range(len(M)):
                    out[b + j] = zimg(M[j]).astype(np.float16)
            assert np.isfinite(out.astype(np.float32)).all()
            np.savez(HERE / "maps" / f"{a.tag}_{split}_{meth}.npz", names=np.array(names), logit128=out)
            print(f"{split} {meth}: {len(names)} maps in {time.time() - t0:.0f}s -> maps/{a.tag}_{split}_{meth}.npz", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pilot", type=int, default=0); ap.add_argument("--export", action="store_true")
    ap.add_argument("--vaes", nargs="+", default=["sd-mse", "sdxl"]); ap.add_argument("--variant", default="v1")
    ap.add_argument("--tag", default="vaerec"); ap.add_argument("--dev", default="cpu"); ap.add_argument("--bs", type=int, default=4)
    a = ap.parse_args()
    pilot(a) if a.pilot else export(a)
