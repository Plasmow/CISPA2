#!/bin/bash
# Whole-node worker: 4 GPU slots, each runs queued command files (output/queue/pending/*.sh, oldest name first)
# with CUDA_VISIBLE_DEVICES set. Drop a file in pending/ to schedule; touch output/queue/STOP to end after current work.
# Side task at start: extra s0.625 twins (seed 1, k=8) on all GPUs, concurrently with the slots.
# Launch: sbatch --job-name=dzw --time=02:30:00 scripts/run4.sh scripts/gpu_worker.sh
cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
export HF_HOME=/p/scratch/training2666/ayadi1/automateam2/.cache
export HUGGINGFACE_HUB_CACHE=/p/scratch/training2666/ayadi1/automateam2/.cache/hub
export HF_HUB_OFFLINE=1
Q=output/queue
mkdir -p $Q/pending $Q/running $Q/done
rm -f $Q/STOP
if [ ! -f output/twins/s0.625b_sh3.npz ]; then
  for i in 0 1 2 3; do
    CUDA_VISIBLE_DEVICES=$i .venv/bin/python scripts/gen_twins.py --shard $i --nshards 4 --steps 8 --strengths 0.625 \
      --k 8 --seed 1 --tag b > output/twins3_sh$i.log 2>&1 &
  done
fi
slot() {
  local gpu=$1
  while true; do
    f=$(ls -1 $Q/pending/*.sh 2>/dev/null | sort | head -1)
    if [ -n "$f" ]; then
      b=$(basename "$f")
      if mv "$f" "$Q/running/gpu${gpu}_$b" 2>/dev/null; then
        echo "[gpu$gpu $(date +%T)] start $b" >> $Q/worker.log
        CUDA_VISIBLE_DEVICES=$gpu bash "$Q/running/gpu${gpu}_$b" > "$Q/running/gpu${gpu}_$b.log" 2>&1
        echo "[gpu$gpu $(date +%T)] done $b rc=$?" >> $Q/worker.log
        mv "$Q/running/gpu${gpu}_$b" "$Q/running/gpu${gpu}_$b.log" $Q/done/
      fi
    else
      [ -f $Q/STOP ] && break
      sleep 5
    fi
  done
}
for i in 0 1 2 3; do slot $i & done
wait
