"""'Maximum expected mIoU' decision rule (Agent B, task 2). CPU only, nothing written.

For each image, with P = calibrated probabilities of the fused map, consider the prefix masks m_k = the k most probable
cells (k = 0..16384; the order does not depend on a monotone calibration) and keep the k that maximises the expected
soft mIoU   E(k) = (IoU_1 + IoU_0) / 2,   IoU_c = sum(p_c m_c) / (sum p_c + sum m_c - sum p_c m_c)   (ratio of expectations).
Calibration of the logits, fitted on the training rows only, separately for each predicted type (g > tg, as 'switch'):
  none      : P = sigmoid(L)
  temp      : P = sigmoid(a L + b), (a, b) on a grid, chosen to maximise the REALISED mIoU of the rule on the training rows
  temp_type : same, one (a, b) per predicted type                                                    (default)
  iso_type  : isotonic regression of the cell labels on L (64 quantile bins + pool-adjacent-violators), per type

Interface (same as the rules of v3.rule_preds; L may hold train rows followed by test rows, gt is read on tr_idx only):
    pred, info = emiou_rule(L, g, gt, tr_idx, calib="temp_type")          # pred [N,128,128] bool
    out, p = rule_preds_plus(L, g, gt, tr_idx)   # = v3.rule_preds + "emiou_<calib>" + hybrids "emiouT|<rule>"
                                                 #   (emiou on predicted-T images, <rule> on predicted-F images)
Evaluation on the v7 fused OOF maps (sam/submission_v7/probs_train_oof.pt), per method and per sub-type, rule only
(before post-processing, rectangles and SAM), same folds as v3 (folds(N, 5, 0)):
    python rule_emiou.py            # rule only, all variants
    python rule_emiou.py --post     # rule + post-processing chosen in CV (v3 steps 3-4), current rule vs emiou
"""
import json
import sys
from pathlib import Path

import numpy as np

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc"))
from evalkit import fit_switch, miou_batch  # noqa: E402

C = 128 * 128
A_GRID = np.exp(np.linspace(np.log(0.25), np.log(4.0), 9))
B_GRID = np.linspace(-3.0, 3.0, 13)


def _sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -30, 30)))


def _best_k(Ps):
    """Ps [n, C] probabilities sorted in the cell order -> (k* [n], E(k*) [n]) for prefix masks."""
    Ps = Ps.astype(np.float32); n = len(Ps); S = Ps.sum(1, keepdims=True)
    I1 = np.concatenate([np.zeros((n, 1), np.float32), np.cumsum(Ps, 1)], 1); k = np.arange(C + 1, dtype=np.float32)[None]
    U1 = S + k - I1; iou1 = np.where(U1 > 1e-6, I1 / np.maximum(U1, 1e-6), 1.0)
    I0 = (C - k) - (S - I1); U0 = (C - S) + (C - k) - I0; iou0 = np.where(U0 > 1e-6, I0 / np.maximum(U0, 1e-6), 1.0)
    E = (iou1 + iou0) / 2; kb = E.argmax(1)
    return kb, E[np.arange(n), kb]


def _realised(cumgt, kb):
    """cumgt [n, C+1] cumulative GT along the cell order, kb [n] -> official mIoU of the prefix masks."""
    n = len(kb); G = cumgt[:, -1].astype(np.float64); TP = cumgt[np.arange(n), kb].astype(np.float64)
    FP = kb - TP; FN = G - TP; TN = C - kb - FN
    u1 = TP + FP + FN; u0 = TN + FN + FP
    return (np.where(u1 > 0, TP / np.maximum(u1, 1), 1.0) + np.where(u0 > 0, TN / np.maximum(u0, 1), 1.0)) / 2


def _fit_iso(z, y, nb=64):
    qs = np.unique(np.quantile(z, np.linspace(0, 1, nb + 1))); nb = len(qs) - 1
    b = np.clip(np.searchsorted(qs, z, "right") - 1, 0, nb - 1)
    cnt = np.bincount(b, minlength=nb).astype(float); pos = np.bincount(b, weights=y, minlength=nb)
    zc = np.bincount(b, weights=z, minlength=nb) / np.maximum(cnt, 1); keep = cnt > 0
    rate, w, zc = list((pos[keep] + 0.5) / (cnt[keep] + 1)), list(cnt[keep]), zc[keep]
    blocks = []                                                         # pool adjacent violators
    for r, ww, zz in zip(rate, w, zc):
        blocks.append([r, ww, [zz]])
        while len(blocks) > 1 and blocks[-2][0] > blocks[-1][0]:
            r2, w2, z2 = blocks.pop(); r1, w1, z1 = blocks.pop()
            blocks.append([(r1 * w1 + r2 * w2) / (w1 + w2), w1 + w2, z1 + z2])
    xs = np.concatenate([b_[2] for b_ in blocks]); ys = np.concatenate([[b_[0]] * len(b_[2]) for b_ in blocks])
    return xs, ys


def emiou_rule(L, g, gt, tr_idx, calib="temp_type", p_switch=None):
    """-> (pred [N,128,128] bool, info). Thresholds / calibration fitted on tr_idx only."""
    L = np.asarray(L, np.float32); N = len(L); tr_idx = np.asarray(tr_idx)
    p = p_switch if p_switch is not None else fit_switch(L, gt, g, tr_idx)
    typT = g > p["tg"]; is_tr = np.zeros(N, bool); is_tr[tr_idx] = True
    flat = L.reshape(N, -1); order = np.argsort(-flat, 1, kind="stable"); Zs = np.take_along_axis(flat, order, 1)
    groups = [np.ones(N, bool)] if calib in ("none", "temp") else [typT, ~typT]
    kb = np.zeros(N, int); info = {"tg": float(p["tg"]), "calib": calib, "params": []}
    for grp in groups:
        rows = np.where(grp)[0]; trr = np.where(grp & is_tr)[0]
        if len(rows) == 0:
            continue
        if calib == "none" or len(trr) == 0:
            a, b = 1.0, 0.0; P = _sigmoid(Zs[rows])
        elif calib.startswith("temp"):
            cg = np.concatenate([np.zeros((len(trr), 1), np.int32),
                                 np.cumsum(np.take_along_axis(gt[trr].reshape(len(trr), -1), order[trr], 1), 1, dtype=np.int32)], 1)
            best = (-1, 1.0, 0.0)
            for a_ in A_GRID:
                for b_ in B_GRID:
                    s = _realised(cg, _best_k(_sigmoid(a_ * Zs[trr] + b_))[0]).mean()
                    if s > best[0]:
                        best = (s, a_, b_)
            _, a, b = best; P = _sigmoid(a * Zs[rows] + b)
        else:                                                           # iso_type
            sub = (slice(None), slice(None, None, 4))
            xs, ys = _fit_iso(flat[trr][sub].ravel(), gt[trr].reshape(len(trr), -1)[sub].ravel().astype(float))
            a, b = None, None; P = np.interp(Zs[rows], xs, ys)
        kb[rows] = _best_k(P)[0]; info["params"].append(dict(n=int(len(rows)), n_train=int(len(trr)), a=a, b=b))
    pred = np.zeros((N, C), bool)
    pred[np.arange(N)[:, None], order] = np.arange(C)[None] < kb[:, None]
    return pred.reshape(L.shape), info


def rule_preds_plus(L, g, gt, tr_idx, calibs=("none",)):
    """Drop-in for v3.rule_preds: same outputs plus 'emiou_<calib>' and hybrids 'emiouT|<rule>'."""
    from v3 import rule_preds
    out, p = rule_preds(L, g, gt, tr_idx); typT = g > p["tg"]; base_rules = list(out)
    for c in calibs:
        e, _ = emiou_rule(L, g, gt, tr_idx, c, p); out[f"emiou_{c}"] = e
        for r in base_rules:
            out[f"emiouT|{r}"] = np.where(typT[:, None, None], e, out[r])
    return out, p


# ------------------------------------------------------------------------------------------------ evaluation
def post_eval():
    """Rule + post-processing (both chosen in CV exactly as v3.py steps 3-4) with and without the emiou rule."""
    import torch
    from v3 import ROOT, METHODS, load_split, folds, g_of, rule_preds, post_scores, cv_select
    P = torch.load(ROOT / "sam" / "submission_v7" / "probs_train_oof.pt", weights_only=True); prob = dict(zip(P["image_names"], P["probs"].numpy()))
    rep = json.loads((ROOT / "submissions" / "submission_v7.json").read_text())
    tr_all = load_split("train"); meta = {m["image_name"]: m for m in tr_all.meta}
    typo = {r["name"]: r for r in json.loads((TASK / "loc" / "cache" / "typo_stats.json").read_text())}
    subt = lambda n: "T" if typo[n]["full"] else ("F-rect" if typo[n]["fill_bbox"] >= 0.99 else "F-seg")
    acc = {}
    print("| method | rule + CV post (v3 steps 3-4, before rect/SAM) | all | T | F-rect | F-seg | post T / F |\n|---|---|---|---|---|---|---|")
    for meth in METHODS:
        names = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; N = len(names)
        pr = np.clip(np.stack([prob[n] for n in names]), 1e-4, 1 - 1e-4); L = np.log(pr / (1 - pr)).astype(np.float32)
        g = g_of("train", names, meta); gt = np.stack([tr_all.m128[n] for n in names]).astype(bool); st = np.array([subt(n) for n in names])
        for rule in (rep[meth]["rule"], "emiou_none", "emiouT_none|cur"):
            pred = np.zeros(gt.shape, bool); typT = np.zeros(N, bool)
            for f in folds(N, 5, 0):
                tr = np.setdiff1d(np.arange(N), f); out, p = rule_preds(L, g, gt, tr); tT = g > p["tg"]
                e = emiou_rule(L, g, gt, tr, "none", p)[0] if rule != rep[meth]["rule"] else None
                m = out[rule] if e is None else (e if rule == "emiou_none" else np.where(tT[:, None, None], e, out[rep[meth]["rule"]]))
                pred[f] = m[f]; typT[f] = tT[f]
            PS = post_scores(pred, gt, typT)
            sT, pT = cv_select({k[1]: v for k, v in PS.items() if k[0] == "T"}, typT); sF, pF = cv_select({k[1]: v for k, v in PS.items() if k[0] == "F"}, ~typT)
            s = np.zeros(N); s[typT] = sT; s[~typT] = sF; acc.setdefault(rule if rule != rep[meth]["rule"] else "current", []).append((s, st))
            print(f"| {meth} | {rule} | {s.mean():.4f} | {s[st == 'T'].mean():.4f} | {s[st == 'F-rect'].mean():.4f} | {s[st == 'F-seg'].mean():.4f} | {pT} / {pF} |", flush=True)
    for k, lst in acc.items():
        s = np.concatenate([a for a, _ in lst]); st = np.concatenate([b for _, b in lst])
        print(f"| all | {k} | {s.mean():.4f} | {s[st == 'T'].mean():.4f} | {s[st == 'F-rect'].mean():.4f} | {s[st == 'F-seg'].mean():.4f} | |")


def main():
    import torch
    from v3 import ROOT, METHODS, load_split, folds, g_of, rule_preds, oracle
    sub = ROOT / "sam" / "submission_v7"; rep = json.loads((ROOT / "submissions" / "submission_v7.json").read_text())
    P = torch.load(sub / "probs_train_oof.pt", weights_only=True); prob = dict(zip(P["image_names"], P["probs"].numpy()))
    tr_all = load_split("train"); meta = {m["image_name"]: m for m in tr_all.meta}
    typo = {r["name"]: r for r in json.loads((TASK / "loc" / "cache" / "typo_stats.json").read_text())}
    subt = lambda n: "T" if typo[n]["full"] else ("F-rect" if typo[n]["fill_bbox"] >= 0.99 else "F-seg")
    calibs = ("none", "temp", "temp_type", "iso_type")
    rows, allS = [], {}
    for meth in METHODS:
        names = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; N = len(names)
        L = np.log(np.clip(np.stack([prob[n] for n in names]), 1e-4, 1 - 1e-4) / (1 - np.clip(np.stack([prob[n] for n in names]), 1e-4, 1 - 1e-4))).astype(np.float32)
        g = g_of("train", names, meta); gt = np.stack([tr_all.m128[n] for n in names]).astype(bool)
        cur = rep[meth]["rule"]; S = {}
        for f in folds(N, 5, 0):
            tr = np.setdiff1d(np.arange(N), f); out, p = rule_preds(L, g, gt, tr); typT = g > p["tg"]
            cand = {f"current ({cur})": out[cur], **{k: out[k] for k in out if k != cur}}
            for c in calibs:
                e, info = emiou_rule(L, g, gt, tr, c, p); cand[f"emiou_{c}"] = e
                cand[f"emiouT_{c} | {cur}"] = np.where(typT[:, None, None], e, out[cur])
            for k, v in cand.items():
                S.setdefault(k, np.zeros(N))[f] = miou_batch(v[f], gt[f])
        S["ORACLE per-image threshold"] = oracle(L, gt)
        st = np.array([subt(n) for n in names])
        for k, s in S.items():
            rows.append((meth, k, s.mean(), *(s[st == t].mean() for t in ("T", "F-rect", "F-seg"))))
            allS.setdefault(k.replace(f"({cur})", "").replace(f"| {cur}", "| current").strip(), []).append((s, st))
    print("| method | rule (CV, rule only, before post/rect/SAM) | all | T | F-rect | F-seg |\n|---|---|---|---|---|---|")
    for r in rows:
        print(f"| {r[0]} | {r[1]} | {r[2]:.4f} | {r[3]:.4f} | {r[4]:.4f} | {r[5]:.4f} |")
    print("\n| all methods (510) | all | T | F-rect | F-seg |\n|---|---|---|---|---|")
    for k, lst in allS.items():
        if len(lst) != 3:
            continue
        s = np.concatenate([a for a, _ in lst]); st = np.concatenate([b for _, b in lst])
        print(f"| {k} | {s.mean():.4f} | {s[st == 'T'].mean():.4f} | {s[st == 'F-rect'].mean():.4f} | {s[st == 'F-seg'].mean():.4f} |")


if __name__ == "__main__":
    post_eval() if "--post" in sys.argv else main()
