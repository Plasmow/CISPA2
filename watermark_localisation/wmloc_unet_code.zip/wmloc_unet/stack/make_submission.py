"""Per-method best source -> thresholds -> submission .pt (does not upload; see --submit).

Candidate maps per method (train: out-of-fold, test: mean of fold models), all as probabilities:
  head          : sigmoid(head logit)                       (PixelSeal, TrustMark only)
  unet_effb3    : U-Net effb3_hp_glob
  unet_ens      : mean of the 4 U-Net variants
  head+unet     : mean(head, unet_effb3)
Each is scored by 5-fold CV with the regime 'switch' rule; the best one per method is kept, its thresholds are fitted on
the whole train split and applied to the test maps.
    python make_submission.py --out ../submissions/submission_v1.pt [--submit]
"""
import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np
import torch

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(TASK / "starter_kit"))
from common import load_split, CACHE  # noqa: E402
from evalkit import cv_eval, fit_switch, apply_switch  # noqa: E402

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
METHODS = ("pixelseal", "trustmark", "stegastamp")
UNETS = ("rgb", "rgb_glob", "rgb_hp_glob", "effb3_hp_glob")


def sig(x):
    return 1 / (1 + np.exp(-x))


def load_unet(v):
    a = np.load(ROOT / "runs" / v / "oof_all.npz"); b = np.load(ROOT / "runs" / v / "test_mean.npz")
    return (dict(zip(a["names"].tolist(), a["prob"].astype(np.float32))), dict(zip(b["names"].tolist(), b["prob"].astype(np.float32))))


def g_values(split, meth, names, msgs):
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item(); lut = dict(zip(gl[meth]["names"], gl[meth]["logits"]))
    return np.array([(lut[n] * (m * 2 - 1)).mean() for n, m in zip(names, msgs)])


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=str(ROOT / "submissions" / "submission_v1.pt"))
    ap.add_argument("--submit", action="store_true")
    ap.add_argument("--extra", nargs="*", default=[], help="more runs/<name> to consider as candidates")
    a = ap.parse_args()
    unet = {v: load_unet(v) for v in list(UNETS) + a.extra}
    names_out, masks_out, report = [], [], {}
    te_all = load_split("test"); test_order = [m["image_name"] for m in te_all.meta]
    for meth in METHODS:
        tr, te = load_split("train", [meth]), load_split("test", [meth])
        n_tr = [m["image_name"] for m in tr.meta]; n_te = [m["image_name"] for m in te.meta]
        msg_tr = [np.array([int(c) for c in m["message"]], np.float32) for m in tr.meta]
        msg_te = [np.array([int(c) for c in m["message"]], np.float32) for m in te.meta]
        g_tr, g_te = g_values("train", meth, n_tr, msg_tr), g_values("test", meth, n_te, msg_te)
        gt = np.stack([tr.m128[n] for n in n_tr]).astype(bool); full = np.array([m["full_watermark"] for m in tr.meta])
        U = lambda v, split, nn: np.stack([unet[v][0 if split == "train" else 1][n] for n in nn])  # noqa: E731
        cands = {"unet_effb3": (U("effb3_hp_glob", "train", n_tr), U("effb3_hp_glob", "test", n_te)),
                 "unet_ens": (np.mean([U(v, "train", n_tr) for v in UNETS], 0), np.mean([U(v, "test", n_te) for v in UNETS], 0))}
        for v in a.extra:
            cands[f"unet:{v}"] = (U(v, "train", n_tr), U(v, "test", n_te))
        if meth != "stegastamp":
            h_tr = np.load(HERE / "maps" / f"head_train_{meth}.npz"); h_te = np.load(HERE / "maps" / f"head_test_{meth}.npz")
            assert h_tr["names"].tolist() == n_tr and h_te["names"].tolist() == n_te
            ht, he = sig(h_tr["logit128"].astype(np.float32)), sig(h_te["logit128"].astype(np.float32))
            cands["head"] = (ht, he)
            cands["head+unet"] = ((ht + cands["unet_effb3"][0]) / 2, (he + cands["unet_effb3"][1]) / 2)
        scores = {}
        for k, (mtr, _) in cands.items():
            s = cv_eval(mtr, gt, g_tr, "switch"); scores[k] = (s.mean(), s[full].mean(), s[~full].mean())
            print(f"{meth:10s} {k:11s} CV mIoU={s.mean():.4f}  T={s[full].mean():.4f}  F={s[~full].mean():.4f}", flush=True)
        best = max(scores, key=lambda k: scores[k][0])
        p = fit_switch(cands[best][0], gt, g_tr, np.arange(len(n_tr)))
        pred = apply_switch(cands[best][1], g_te, p)
        report[meth] = dict(source=best, cv=round(scores[best][0], 4), cv_T=round(scores[best][1], 4), cv_F=round(scores[best][2], 4),
                            thresholds={k: float(v) for k, v in p.items()}, test_frac_pred_1=round(float(pred.mean()), 3))
        names_out += n_te; masks_out.append(pred)
    masks = np.concatenate(masks_out); order = {n: i for i, n in enumerate(names_out)}
    masks = masks[[order[n] for n in test_order]]; names = list(test_order)
    # validity checks
    assert len(names) == len(set(names)) == 1020 and masks.shape == (1020, 128, 128)
    sub = {"image_names": names, "masks": torch.from_numpy(masks).bool()}
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True); torch.save(sub, out)
    re = torch.load(out, weights_only=True)
    assert re["image_names"] == names and re["masks"].dtype == torch.bool and set(torch.unique(re["masks"].to(torch.uint8)).tolist()) <= {0, 1}
    size = os.path.getsize(out) / 2 ** 20; assert size < 20
    report["expected_cv_mIoU"] = round(float(np.mean([report[m]["cv"] for m in METHODS])), 4)
    report["file"] = str(out); report["size_MB"] = round(size, 2)
    print(json.dumps(report, indent=1))
    (out.with_suffix(".json")).write_text(json.dumps(report, indent=1))
    if a.submit:
        from submission_template import submit
        submit(str(out))


if __name__ == "__main__":
    main()
