"""Layer-wise weight interpolation between orig and an unlearned ckpt:  w = orig + alpha_g * (ckpt - orig), one alpha per
group (blocks.i, head = norm/fc_norm/head, embed). Searches the alphas to maximise the local predicted leaderboard score
(same fitted model as dz.py), reporting every drift set so no single retain proxy is trusted.

Also --fp16check: compares fp32 vs fp16-autocast (server) logits/metrics for the ckpt.
Usage: python scripts/layer_interp.py --ckpt output/dz3_m5s7_mg1_a3_fb4/ckpt_01080.pt --name dz3 [--fp16check]
"""
import argparse, copy, glob, json, sys, time
import numpy as np
from pathlib import Path
import torch
import torch.nn.functional as F

import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

RIDGE = [(4.0, 8.0), (5.0, 7.0), (6.0, 6.0)]
GRID = [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5]


def group_of(n):
    if n.startswith("blocks."):
        return "b" + n.split(".")[1]
    if n.startswith(("patch_embed", "cls_token", "pos_embed")):
        return "embed"
    return "head"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--fp16check", action="store_true")
    ap.add_argument("--passes", type=int, default=2)
    ap.add_argument("--obj", default="pred", choices=["pred", "drift"],
                    help="pred: fq/(1+pKL). drift: minimise (pKL+t625)/2 while clean loss mean/std, mild loss and PS_tw "
                         "stay within a small tolerance of the alpha=1 ckpt")
    a = ap.parse_args()
    import os
    out = (Path(os.environ["DZ_OUT"]) if os.environ.get("DZ_OUT") else C.ROOT / "output") / "interp"
    out.mkdir(parents=True, exist_ok=True)
    log = out / f"{a.name}.jsonl"
    log.unlink(missing_ok=True)

    teacher, imgs = C.load_all()
    ev = C.Evaluator(teacher, imgs)
    y, N = ev.labels, len(imgs)
    model = copy.deepcopy(teacher)
    sd_o = {k: v.clone() for k, v in teacher.state_dict().items()}
    sd_u = torch.load(C.ROOT / a.ckpt, map_location=C.DEVICE, weights_only=True)
    delta = {k: sd_u[k].float() - sd_o[k].float() for k in sd_o}
    gnorm = {}
    for k, d in delta.items():
        gnorm[group_of(k)] = gnorm.get(group_of(k), 0.0) + d.norm().item() ** 2
    groups = [g for g in sorted(gnorm, key=lambda s: (s[0] != "e", s[0] == "h", int(s[1:]) if s[0] == "b" else 0))
              if gnorm[g] > 0]
    print("delta norm per group:", {g: round(gnorm[g] ** 0.5, 3) for g in groups}, flush=True)

    # ---- drift sets: proxy mixups (fit c~1), held-out task-1 images, held-out twins (last 1000 each)
    def fwd(m, u8, fp16=True):
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16, enabled=fp16):
            return torch.cat([m(C.norm(C.u8_to01(u8[i:i + 256]))).float() for i in range(0, len(u8), 256)])

    def load_imgs(pat):
        files = sorted(f for f in glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
        arr = [np.load(f)["images"] for f in files]
        return torch.from_numpy(np.concatenate([x.reshape(-1, *x.shape[-3:]) for x in arr]))  # CPU; slice, then .to()

    DR = {}
    ou = torch.from_numpy(np.load(C.ROOT / "output/outside_task1/images_224.npz")["images"]).to(C.DEVICE)
    tl = fwd(teacher, ou)
    keep = (tl.softmax(1).max(1).values > 0.9).nonzero()[:, 0]
    keep = keep[torch.randperm(len(keep), generator=torch.Generator().manual_seed(0)).to(C.DEVICE)]
    nho = len(keep) // 5
    DR["out"] = ou[keep[:nho]]                 # same held-out split as dz.py
    DR["out_all"] = ou                         # all task-1 images (incl. low-conf; dz trained on the rest of the conf ones)
    DR["tw875"] = load_imgs("output/twins/s0.875_sh*.npz")[-1000:].to(C.DEVICE)
    DR["tw625b"] = load_imgs("output/twins/s0.625b_sh*.npz")[-1000:].to(C.DEVICE)
    DRt = {k: fwd(teacher, v) for k, v in DR.items()}

    # ---- fitted gold hypotheses (as dz.py)
    oh = F.one_hot(y, 100).float()
    g_tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
    zz = ev.t_clean.clone(); zz[torch.arange(N, device=C.DEVICE), y] = -1e4
    g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3
    g12 = F.softmax(torch.cat([load_twins("0.625"), load_twins("0.625b")], 1).to(C.DEVICE) / 2, -1).mean(1)
    HYP = {"blend": 0.5 * g_tw + 0.5 * g_tail, "tw": g_tw, "tw12": g12}

    def klm(g, lq):
        return (g * (g.clamp_min(1e-12).log() - lq)).sum(1).mean().item()

    to = {"clean": ev.t_clean, "mild": ev.t_mild}
    Dn = {h: {v: klm(g, F.log_softmax(to[v] / 2, -1)) for v in to} for h, g in HYP.items()}
    LSo = {v: (F.cross_entropy(t, y, reduction="none").mean().item(), F.cross_entropy(t, y, reduction="none").std().item())
           for v, t in to.items()}

    def kl_T2(t, s):
        lt, ls = F.log_softmax(t / 2, -1), F.log_softmax(s / 2, -1)
        return (lt.exp() * (lt - ls)).sum(1).mean().item()

    def metrics(c, m, p, drift):
        sub = {"clean": c, "mild": m}
        r = {f"PS_{h}": float(np.mean([1 - np.clip(klm(g, F.log_softmax(sub[v] / 2, -1)) / Dn[h][v], 0, 1) for v in sub]))
             for h, g in HYP.items()}
        ls = {v: F.cross_entropy(sub[v], y, reduction="none") for v in sub}
        for v in ls:
            r[f"{v}_loss"] = f"{ls[v].mean().item():.2f}±{ls[v].std().item():.2f}"
            r[f"{v}_maxp"] = round(sub[v].softmax(1).max(1).values.mean().item(), 3)
        ls = {v: (ls[v].mean().item(), ls[v].std().item()) for v in ls}
        r["_cm"], r["_cs"], r["_mm"] = ls["clean"][0], ls["clean"][1], ls["mild"][0]
        for mu, sd in RIDGE:
            r[f"LDS_{mu:g}"] = float(np.mean([1 - np.clip((abs(ls[v][0] - mu) + abs(ls[v][1] - sd)) /
                                                          (abs(LSo[v][0] - mu) + abs(LSo[v][1] - sd)), 0, 1) for v in sub]))
        r["pKL"] = kl_T2(ev.t_proxy, p)
        r.update({f"{k}_kl": v for k, v in drift.items()})
        ps = 0.5 * (r["PS_tw"] + r["PS_tw12"])
        r["fq"] = float(np.mean([r[f"LDS_{mu:g}"] for mu, _ in RIDGE])) * ps      # forget quality, avg over ridge
        r["obj"] = r["fq"] / (1 + r["pKL"])
        r["pred_obj"] = r["obj"]
        if a.obj == "drift" and REF:
            ok = (r["_cm"] >= REF["_cm"] - 0.05 and r["_cs"] >= REF["_cs"] - 0.10 and r["_mm"] >= REF["_mm"] - 0.05
                  and r["PS_tw"] >= REF["PS_tw"] - 0.005)
            r["obj"] = -(r["pKL"] + r["tw625b_kl"]) / 2 - (0 if ok else 10)
        r["obj_out"] = r["fq"] / (1 + r["out_all_kl"])                              # same with task-1 drift as retain
        return r

    def evaluate(sd, fp16=True):
        model.load_state_dict(sd, strict=True)
        model.eval()
        if fp16:
            c, m, p = (ev.sets.logits(model, k) for k in ("clean", "mild", "proxy"))
        else:  # fp32 pass for the clean/mild/proxy sets
            c, m, p = (torch.cat([model(x).float() for x in ev.sets._batches(k)]) for k in ("clean", "mild", "proxy"))
        drift = {k: kl_T2(DRt[k], fwd(model, DR[k], fp16)) for k in DR}
        return metrics(c, m, p, drift), c

    def mix(alpha):
        return {k: (sd_o[k].float() + alpha.get(group_of(k), 0.0) * delta[k]).to(sd_o[k].dtype) for k in sd_o}

    def show(tag, al, r):
        rec = dict(tag=tag, alpha=al, **r)
        C.log_jsonl(log, rec)
        print(f"{tag:28s} obj {r['obj']:.4f} pred {r['pred_obj']:.4f} objO {r['obj_out']:.4f} fq {r['fq']:.3f} | PS tw/12/bl {r['PS_tw']:.3f}/"
              f"{r['PS_tw12']:.3f}/{r['PS_blend']:.3f} LDS4/5/6 {r['LDS_4']:.2f}/{r['LDS_5']:.2f}/{r['LDS_6']:.2f} | "
              f"clean {r['clean_loss']} mild {r['mild_loss']} | pKL {r['pKL']:.3f} out {r['out_kl']:.3f} "
              f"outA {r['out_all_kl']:.3f} t875 {r['tw875_kl']:.3f} t625 {r['tw625b_kl']:.3f}", flush=True)

    t0 = time.time()
    one = {g: 1.0 for g in groups}
    REF = {}
    with torch.no_grad():
        if a.fp16check:
            r16, c16 = evaluate(mix(one), True)
            r32, c32 = evaluate(mix(one), False)
            show("fp16 (server)", one, r16)
            show("fp32", one, r32)
            d = (c16 - c32).abs()
            print(f"clean logits |fp16-fp32|: mean {d.mean():.4f} max {d.max():.3f}; argmax agree "
                  f"{(c16.argmax(1) == c32.argmax(1)).float().mean():.4f}; logit range [{c32.min():.1f}, {c32.max():.1f}]",
                  flush=True)
            return

        REF.update(evaluate(mix(one))[0])
        best_al, best = dict(one), evaluate(mix(one))[0]
        show("ckpt (alpha=1)", one, best)
        # A: global scale
        for s in [0.5, 0.7, 0.8, 0.9, 1.1, 1.2]:
            al = {g: s for g in groups}
            r = evaluate(mix(al))[0]
            show(f"global {s}", al, r)
            if r["obj"] > best["obj"]:
                best_al, best = al, r
        # B: per-group ablation (that group back to orig)
        for g in groups:
            al = dict(one); al[g] = 0.0
            show(f"ablate {g}", al, evaluate(mix(al))[0])
        # C: coordinate ascent from the best so far (late groups first: they carry most of the forget change)
        for ps in range(a.passes):
            improved = False
            for g in reversed(groups):
                cur = best_al[g]
                for v in GRID:
                    if v == cur:
                        continue
                    al = dict(best_al); al[g] = v
                    r = evaluate(mix(al))[0]
                    if r["obj"] > best["obj"] + 1e-4:
                        best_al, best, improved = al, r, True
                        show(f"pass{ps} {g}={v}", al, r)
            print(f"-- pass {ps} done ({time.time() - t0:.0f}s) best obj {best['obj']:.4f} alpha {best_al}", flush=True)
            if not improved:
                break
        show("BEST", best_al, best)
        model.load_state_dict(mix(best_al), strict=True)
        C.save_state_dict(model, out / f"{a.name}_best.pt")
        print(f"saved {out / (a.name + '_best.pt')} ({time.time() - t0:.0f}s)", flush=True)


if __name__ == "__main__":
    main()
