#!/bin/bash
# Whole-node job (dc-gpu nodes are allocated exclusively): run a bash script that uses all 4 GPUs.
# Usage: sbatch --job-name=NAME scripts/run4.sh scripts/<sweep>.sh
#SBATCH --job-name=unl4
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --time=01:30:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
bash "$@"
echo "done!"
