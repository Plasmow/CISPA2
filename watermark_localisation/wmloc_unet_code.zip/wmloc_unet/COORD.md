# Coordination des agents (W = /p/project1/training2666/debbah2/wmloc_unet)

Chaque agent ne modifie que sa propre section.

## Agent A (rectangles, SAM, intégration)

Mis à jour : 08:55. A est le seul à modifier v3.py, sam_stage.py, snap_sam_local.py, sam_rank.py, rect_*.py et à produire des soumissions.

### Diagnostic par sous-type (masques OOF finaux de v7 = règle + post + rectangles, AVANT SAM)
Sous-types d'après le masque 512 du train : T = `full_watermark` ; F-rect = masque exactement rectangulaire ;
F-seg = autre F. « Oracle SAM » = pour chaque image, le meilleur entre le masque v7 et le meilleur segment SAM (avec la
vérité terrain). Les gains sont des gains sur le score de la méthode (lignes par méthode) ou sur le score global (ligne « toutes »).

| Méthode | Sous-type | n | v7 | Oracle SAM | Gain si oracle SAM | Gain si parfait (mIoU = 1) |
|---|---|---|---|---|---|---|
| PixelSeal | T | 85 | 0.632 | 0.632 | +0.000 | +0.184 |
| PixelSeal | F-rect | 43 | 0.628 | 0.665 | +0.009 | +0.094 |
| PixelSeal | F-seg | 42 | 0.714 | 0.969 | +0.063 | +0.071 |
| TrustMark | T | 85 | 0.623 | 0.625 | +0.001 | +0.188 |
| TrustMark | F-rect | 43 | 0.803 | 0.831 | +0.007 | +0.050 |
| TrustMark | F-seg | 42 | 0.648 | 0.938 | +0.072 | +0.087 |
| StegaStamp | T | 85 | 0.736 | 0.737 | +0.000 | +0.132 |
| StegaStamp | F-rect | 43 | 0.687 | 0.746 | +0.015 | +0.079 |
| StegaStamp | F-seg | 42 | 0.727 | 0.933 | +0.051 | +0.067 |
| **toutes** | **T** | 255 | **0.664** | 0.664 | +0.000 | **+0.168** |
| toutes | F-rect | 129 | 0.706 | 0.747 | +0.010 | +0.074 |
| toutes | F-seg | 126 | 0.696 | 0.947 | +0.062 | +0.075 |

- CV de v7 : 0.6825. L'étape SAM (v7_sam, CV 0.7066, leaderboard public 0.7094) a déjà récupéré environ +0.024 au total, presque entièrement sur F-seg.
- **Pour B** : le type T ne bénéficie ni de SAM ni des rectangles ; toute la marge T (+0.168) passe par de meilleures cartes de trous et par la règle de seuil.

### Tâche 0 : rectangles StegaStamp du test (recherche locale de la coéquipière) → v8
- `loc/cache/rect_stegastamp_test_local.npz` est déjà lu par `v3.load_rect` : le motif `rect_stegastamp_test_*` le couvre.
  Aucun changement de code ; le train est inchangé (85 / 86 / 85 boîtes).
- v8 (configuration exacte de v7 + cette source) : CV **0.6825**, identique à v7, avec des tableaux de train identiques.
  StegaStamp : rectangles appliqués sur **36 → 42** images du test.
- v8_sam : CV **0.7066**, identique à v7_sam. Rejeu conforme (cv_json = cv_replay, accord pixel 1.0). 220 segments SAM sur le test.
- Différence v8_sam / v7_sam : **14 images, toutes StegaStamp, toutes dans le fichier local, chacune égale à sa boîte**.
  - 6 nouvelles boîtes : acc 1.0, alors que la boîte de rect2 plafonnait à 0.66–0.72.
  - 1 boîte d'acc légèrement supérieure.
  - 7 égalités à acc 1.0 : load_rect lit le fichier local avant rect2 et garde la première boîte en cas d'égalité.
    Les boîtes diffèrent de 1 à 5 px (IoU de 0.92 à 0.98 entre les deux masques).
- **Envoyé avec l'accord de debbah2 : v8_sam = 0.7101 au leaderboard public** (n° 3310 ; précédent 0.7094, soit +0.0007).
  **v8 / v8_sam est la nouvelle base** pour toute intégration (mêmes extras que v7).

### Tâche 1 : choix du segment SAM appris (sam_rank) : NÉGATIF, rien n'est intégré
- Évaluation strictement hors pli (5 plis, seed 0 ; tout est réglé sur les 4 plis d'entraînement), sur les 192 images
  éligibles de v8 : 68 F-rect manqués et 124 F-seg. Scripts : `stack/sam_rank.py`, `stack/sam_rank2.py` ;
  rapports : `W/results_submission_v8_samrank2.md` et `W/results_submission_v7_samrank*.md`.

  | Variante | Toutes | PixelSeal | TrustMark | StegaStamp | F-rect | F-seg | Effet sur la CV moyenne |
  |---|---|---|---|---|---|---|---|
  | **règle actuelle (snap_sam)** | **0.6886** | 0.6626 | 0.6899 | 0.7111 | 0.5101 | 0.7865 | **+0.0241** |
  | MLP listwise, tous les segments | 0.6786 | | | | | | +0.0203 |
  | MLP listwise, top 5 + base | 0.6852 | | | | | | +0.0228 |
  | décision logistique (même segment) | 0.6849 | 0.6596 | 0.6939 | 0.7009 | 0.5055 | 0.7833 | +0.0227 |
  | segment de mIoU attendu maximal | 0.6881 | 0.6530 | **0.7204** | 0.6952 | 0.4971 | 0.7929 | +0.0239 |
  | seuil de score + gain de mIoU attendu | 0.6796 | | | | | | +0.0207 |
  | classeur linéaire, top 10 + base | 0.6865 | 0.6440 | 0.7040 | 0.7115 | 0.4997 | 0.7889 | +0.0233 |
  | choix de la variante par méthode (imbriqué) | 0.6921 | 0.6527 | 0.7204 | 0.7061 | 0.5038 | 0.7954 | +0.0254 (**+0.0013**) |
  | oracle de la décision (segment de la règle) | 0.7064 | | | | | | +0.0308 |

- Aucune variante n'atteint +0.003 sur la moyenne.
  - La variante « mIoU attendu » gagne sur TrustMark (choisie dans 5 plis sur 5), mais elle perd sur PixelSeal et StegaStamp.
  - Utilisée sur TrustMark seulement, elle donnerait +0.0033 ; ce chiffre est choisi après coup, donc il n'est pas retenu.
- Sur les F-rect manqués, SAM n'apporte rien (0.511 → 0.510).
- Même une décision parfaite « recaler ou non » ne vaut que +0.007 de plus.

### Intégration de la règle de B (`rule_emiou.py`) → v9 : GAGNE (+0.0038)
- **Code** : `v3.rule_preds_any` appelle `rule_emiou.rule_preds_plus` si `WMLOC_RULES_PLUS=1`, sinon exactement `rule_preds`.
  - L'option `--rules_plus` de v3.py positionne cette variable et écrit `"rules_plus": true` dans le .json.
  - sam_stage.py lit ce champ pour rejouer la version à l'identique.
  - Sans l'option, rien ne change, y compris pour rejouer v8 et les versions antérieures.
- **v9** = configuration exacte de v8 + `--rules_plus`. La CV choisit `emiou_none` pour les 3 méthodes ; post-traitement :
  PixelSeal T `fill_holes<64` (au lieu de close_holes5), les autres choix sont inchangés.

  | Méthode | v8 | v9 | v8_sam | v9_sam |
  |---|---|---|---|---|
  | PixelSeal | 0.6511 | 0.6547 | 0.6714 | 0.6748 |
  | TrustMark | 0.6749 | 0.6778 | 0.7027 | 0.7042 |
  | StegaStamp | 0.7215 | 0.7308 | 0.7458 | 0.7521 |
  | **Moyenne** | 0.6825 | **0.6878** | 0.7066 | **0.7104 (+0.0038)** |

  Par sous-type (masques OOF avant SAM, v8 → v9) : T 0.6638 → 0.6707 (+0.0069) ; F-rect 0.7060 → 0.7053 (−0.0007) ;
  F-seg 0.6964 → 0.7043 (+0.0079).
- **Contrôles** : rejeu de sam_stage conforme (cv_json = cv_replay, mêmes choix, accord pixel 1.0).
  Sur le test, 642 images changent par rapport à v8_sam (effet de la règle de seuil) et 204 segments SAM sont appliqués.
- **Pour B** : si tu ajoutes des cartes (`--extras`), je les passerai avec `--rules_plus`, sur la base de v9.
- **Envoyé avec l'accord de debbah2 : v9_sam = 0.7131 au leaderboard public** (n° 3345 ; précédent 0.7101, soit +0.0030).
  **v9 / v9_sam est la nouvelle base** : mêmes extras que v7, plus `--rules_plus`.

### Tâche 2 : rectangles manqués, recherche par paires de bords (PixelSeal, TrustMark)
- **Étude de tolérance** (CPU) : 12 boîtes déjà trouvées (train, acc ≥ 0.85) par méthode ; un bord décalé de d px, vers
  l'intérieur ou l'extérieur. Valeurs moyennes :

  | Décalage d'un bord (px) | 1 | 2 | 3 | 4 | 6 | 8 | 12 | 16 |
  |---|---|---|---|---|---|---|---|---|
  | TrustMark, acc | 1.000 | 0.999 | 0.999 | 0.999 | 0.999 | 0.998 | 0.985 | 0.949 |
  | TrustMark, pire bord, acc | 0.999 | 0.998 | 0.998 | 0.998 | 0.993 | 0.988 | 0.945 | 0.850 |
  | TrustMark, confiance (9.92 sans décalage) | 9.85 | 9.76 | 9.68 | 9.59 | 9.42 | 9.16 | 8.42 | 7.48 |
  | PixelSeal, acc (0.949 sans décalage) | 0.936 | 0.931 | 0.928 | 0.925 | 0.917 | 0.900 | 0.879 | 0.847 |
  | PixelSeal, pire bord, acc | 0.924 | 0.912 | 0.894 | 0.886 | 0.856 | 0.788 | 0.723 | 0.661 |
  | PixelSeal, confiance (4.98 sans décalage) | 4.90 | 4.84 | 4.78 | 4.76 | 4.63 | 4.46 | 4.23 | 3.82 |

  - **TrustMark est très tolérant** : acc ≈ 1 jusqu'à 8 px. **PixelSeal décroît doucement**, et agrandir la boîte coûte plus que la réduire.
  - StegaStamp, pour mémoire : ±2–4 px.
  - Ces chiffres viennent de boîtes déjà trouvées, souvent grandes. Pour les petits rectangles manqués (~45 px de côté),
    le même décalage pèse beaucoup plus en relatif.
  - **Choix pour le script** : grille au pas de 2 px ; pas de 1 px à la fin pour PixelSeal seulement.
- **Script** `W/stack/rect_pairs.py`, testé sur CPU (une image TrustMark train, une image PixelSeal test). Graines :
  - boîtes déjà trouvées (cache de la coéquipière + rect2) ;
  - graines de la carte ;
  - boîtes du plus grand blob et de tout le premier plan des masques v3 à v9 (test), ou des masques OOF v4b, v7 et v9 (train).
  Recherche : grilles 2D sur (x0, x1) puis (y0, y1) à ±24 px au pas de 2, en 3 tours au plus ; passage final à 1 px pour PixelSeal ;
  12 graines au plus par image.
- **Images visées** (prédites F, sans boîte ≥ 0.85) : TrustMark 52 train / 100 test ; PixelSeal 66 train / 129 test.
  Presque toutes ont déjà une meilleure boîte entre 0.6 et 0.85.
- **Sortie** : `W/stack/maps/rect3_<m>_<split>_<k>.npz` (format rect2 + `seed_acc`).
  - `v3.load_rect` lit rect3 ; sans fichier rect3, le comportement est inchangé (vérifié).
  - `WMLOC_NO_RECT3=1` ignore rect3. v3.py écrit `"rect3"` dans le .json, et sam_stage.py rejoue automatiquement
    les versions ≤ v9 sans rect3.
- **Job** : `W/run_rect_pairs_devel.sh` (dc-gpu-devel, 4 GPU, 1 h 30 au plus, 1/4 de chaque liste par GPU).
  **Job 15905447**, soumis par debbah2 ; il tourne depuis 07:01 sur jrc0384, sans réservation (vérifié). Environ 5 à 9 s par image ;
  Terminé à 07:30 (COMPLETED, 28 min). Journal : `W/logs/rect_pairs_15905447.out`.
- **Résultat rect3 : REJETÉ.** Le rendement est faible : 12 boîtes ≥ 0.85 (TrustMark test 2, PixelSeal train 3, PixelSeal test 7).
  Plusieurs boîtes PixelSeal couvrent presque toute l'image.
  - **v10** (v9 + rect3) : CV **0.6874**, contre 0.6878 pour v9 (PixelSeal 0.6547 → 0.6526, TrustMark 0.6778 → 0.6789,
    StegaStamp inchangé). Les boîtes PixelSeal du train font baisser le score.
  - Pas d'étape SAM ni d'envoi. Les fichiers rect3 restent dans `maps/`, mais **les versions suivantes sont construites avec
    `WMLOC_NO_RECT3=1`** (le .json indique `"rect3": false`, et sam_stage rejoue en conséquence).

### Cartes T de B (`wmunetTi`, `wmunetTio`) → v11 : SOUS LE SEUIL (+0.0026), non retenu par défaut
- Construites sur la base v9 (`--rules_plus`, `WMLOC_NO_RECT3=1`, mêmes extras + les tags de B).

  | Version | PixelSeal | TrustMark | StegaStamp | Moyenne | Après SAM |
  |---|---|---|---|---|---|
  | v9 | 0.6547 | 0.6778 | 0.7308 | 0.6878 | 0.7104 |
  | v11a (+ `wmunetTi`) | 0.6575 | 0.6784 | 0.7315 | 0.6891 (+0.0013) | non calculé |
  | v11b (+ `wmunetTi` + `wmunetTio`) | 0.6569 | 0.6813 | 0.7320 | 0.6901 (+0.0023) | **0.7130 (+0.0026)** |

  - v11b_sam par méthode : PixelSeal 0.6768 (+0.002), TrustMark 0.7080 (+0.004), StegaStamp 0.7541 (+0.002).
  - Par sous-type (OOF avant SAM, v9 → v11b) : T +0.0027, F-rect −0.0005, F-seg +0.0045.
  - Rejeu de sam_stage conforme (cv_json = cv_replay, accord pixel 1.0).
- Tout est de même signe, mais **+0.0026 < +0.003**, et v11b a été préférée à v11a après coup. Fichier prêt, non envoyé :
  `W/submissions/submission_v11b_sam.pt`. Décision d'envoi laissée à debbah2.
- **Pour B** : `wmunetTi2` (2e graine) existe dans `maps/`, mais n'est pas marqué prêt ; je ne l'ai pas utilisé.

### U-Nets entraînés sur la machine de debbah2 (`to_send.zip`) → v12 : GAGNE (+0.008 après SAM)
- **Import** : l'archive ne contient que des .npz, des journaux et un rapport. Extraite dans `W/runs_local2/`, puis les runs
  sont déplacés sans rien écraser dans `W/runs/loc_{effb3,effv2s,r50,regy032}_hp_glob_stack/`
  (`oof_all.npz` pour 510 images train OOF, `test_mean.npz` pour 1020 images test).
  - Scores seuls (rapport de debbah2, mIoU@0.5) : effv2s 0.562, regy032 0.561, r50 0.536 ; effb3 0.553 (nouvel
    entraînement du run cluster, corrélation 0.994 avec lui).
  - Sur StegaStamp, effv2s et regy032 font environ 0.68.
- **Versions** (base v9 : `--rules_plus`, `WMLOC_NO_RECT3=1`) :

  | Version | PixelSeal | TrustMark | StegaStamp | Moyenne | Après SAM |
  |---|---|---|---|---|---|
  | v9 | 0.6547 | 0.6778 | 0.7308 | 0.6878 | 0.7104 |
  | **v12a** (+ loc effv2s, r50, regy032) | 0.6525 | 0.6778 | **0.7594** | 0.6966 | **0.7187 (+0.0083)** |
  | v12b (+ les 4, effb3 local compris) | 0.6530 | 0.6778 | 0.7587 | 0.6965 | non calculé |
  | v12c (v12a + `wmunetTi`, `wmunetTio`) | 0.6564 | 0.6784 | 0.7604 | 0.6984 | 0.7189 (+0.0085) |

  - v12a_sam par méthode : PixelSeal 0.6729 (−0.002), TrustMark 0.7022 (−0.002, effet du seuil SAM commun), StegaStamp 0.7810 (+0.029).
  - Par sous-type (OOF avant SAM, v9 → v12a) : T +0.012, F-rect +0.006, F-seg +0.006. Toute la hausse vient de StegaStamp
    (T +0.037, F-rect +0.019, F-seg +0.022) ; PixelSeal recule de −0.001 à −0.005, TrustMark ne change pas.
  - Gain StegaStamp par image : +0.029, IC 95 % (bootstrap) [+0.020, +0.038] ; 97 images améliorées, 32 dégradées.
- **Choix** : v12a. v12c n'apporte que +0.0002 après SAM, donc les cartes T de B restent hors de la version.
  - Rejeu de sam_stage conforme (cv_json = cv_replay, mêmes choix, accord pixel 1.0).
  - Sur le test, 473 images changent par rapport à v9_sam (PixelSeal 245, TrustMark 13, StegaStamp 215).
- **Commande de v12a** : celle de v9 + `--runs effb3_hp_glob effb3_hp_glob_stack rgb_hp_glob_synth8k loc_effv2s_hp_glob_stack
  loc_r50_hp_glob_stack loc_regy032_hp_glob_stack`, avec `WMLOC_NO_RECT3=1`.
- **Envoyé avec l'accord de debbah2 : v12a_sam = 0.7192 au leaderboard public** (n° 3521 ; précédent 0.7131, soit +0.0061).
  **v12a / v12a_sam est la nouvelle base** (B : compare tes cartes à v12a, avec les mêmes `--runs`).

### Prior de position des trous T (`posT`, `posF`) → v13p : NÉGATIF
- Heatmap des trous des 25 % de masques les plus blancs du train (`W/heatmap_trous_top25.png`, tous de type T) :
  les trous sont plus fréquents sur les bords, les coins et le tiers inférieur.
- Sources ajoutées : fréquence lissée (σ = 8 cases) des trous T et des zones tatouées F, en leave-one-out sur le train
  (prior de tout le train pour le test). Cartes : `W/stack/maps/pos{T,F}_{train,test}_<m>.npz`.
- **v13p** (v12a + posT, posF) : CV avant SAM **0.6958**, contre 0.6966 pour v12a.
  - PixelSeal 0.6528 (+0.0003) ; StegaStamp 0.7568 (−0.0026) ; TrustMark inchangé (la fusion choisit le top 3, sans prior).
  - Sur l'ensemble des T, le contraste est faible : 8.3 % de trous au centre contre 10 % sur les bords.
- Pas d'étape SAM, rien n'est retenu.

### Diagnostic du remplissage des trous T (pari « données synthétiques fidèles ») : SANS OBJET, arrêt
- 08:59 Cartes de bruit local n1–n4 (stack/noise_maps.py, maps/n{1..4}_*) : NO-GO. AUC T médiane max 0.609 (n2 StegaStamp), gain de complémentarité T avec v12a ≤ +0.0003 (aussi sur les 132 T peu troués). Pas d'intégration, rien envoyé. Détail : results_noise_pilot.md.
- **(a) Générateurs existants** :
  - **A** : `W/synth/generator.py`, utilisé par wm_unet.py, éditions `hole` (30 %) et `addition` (20 %) pour les T.
    - Le `hole` **recolle l'image d'origine propre** dans la région (l'image entière est tatouée, la région est restaurée).
    - Formes : 70 % de vrais masques T du train (rotation, symétrie, décalage), 30 % de blobs (bruit blanc flouté σ = 15–60 px,
      seuillé au quantile d'une couverture de 2 à 30 %).
    - Bord adouci (σ = 0.7–3 px) dans 70 % des cas.
  - **B** : `wm_unet_T.py` : mêmes éditions `hole` (60 %) et `addition` (40 %), blobs sans fuite, calibrés sur les vrais trous.
- **(b) Recadrages 2×** (12 images T du train, 4 par méthode) : `W/diag_fill/crops_grid.png`, `W/diag_fill/crop_*.png`.
  Le contenu est **continu à travers toutes les frontières** : serviette, veste, lavabo, camion, aucune couture ni objet
  redessiné. Pas d'inpainting visible.
- **(c) Mesures** (20 images T par méthode ; anneaux de 2 à 10 px de part et d'autre de la frontière ; `W/stack/diag_fill.py`) :

  | Méthode | Énergie HP dedans/dehors (anneaux) | Intérieurs lointains | Gradient sur la frontière / anneaux | corr(hp y, hp r) dedans / dehors |
  |---|---|---|---|---|
  | PixelSeal | 1.093 | 0.346 | 1.023 | −0.035 / −0.027 |
  | TrustMark | 0.941 | 0.391 | 1.054 | −0.091 / −0.078 |
  | StegaStamp | 0.669 | 0.144 | 1.110 | +0.547 / +0.637 |

  - Les anneaux appariés sont au même niveau, sauf pour StegaStamp (son watermark ajoute de la haute fréquence dehors).
  - Il n'y a pas de couture.
  - Le rapport des intérieurs lointains est biaisé par le contenu : les grands trous tombent près des bords et en bas,
    là où l'arrière-plan est souvent flou.
  - Le re-marquage ne sépare pas dedans et dehors pour PixelSeal et TrustMark.
- **(d) Conclusion** :
  - Le remplissage est **l'image d'origine non tatouée**.
  - **Le générateur existant (édition `hole`) fait déjà exactement cela**, et ses formes sont de vrais masques T ou des blobs
    de la même famille. Le pari d'un générateur « plus fidèle » est donc sans objet ; arrêt, sans job GPU ni wmunetS.
  - Écarts mineurs, non testés : bord adouci (70 % de nos trous ; le réel semble net, non vérifiable à l'œil) ; éditions
    `addition` (contenu d'une autre image) pour les T, alors que les vrais trous T n'en contiennent pas.

### Lissage gaussien du logit avant la règle du mIoU attendu (trous T = blobs lisses) : NO-GO
- Test rapide (08:38, CPU) : cartes OOF de v12a (`sam/submission_v12a/probs_train_oof.pt`) ;
  logit → `gaussian_filter(σ)` → `emiou_rule(calib="none")`, sans post-traitement ; mIoU moyen.
  Les T sont tirés de `full_watermark`, les F-seg de `typo_stats` (pour information).

  | Méthode | Sous-type | n | σ=0 | σ=0.75 | σ=1 | σ=1.5 | σ=2 | σ=3 | Meilleur gain |
  |---|---|---|---|---|---|---|---|---|---|
  | PixelSeal | T | 85 | 0.6330 | 0.6331 | 0.6331 | 0.6333 | 0.6333 | 0.6330 | +0.0004 |
  | PixelSeal | F-seg | 42 | 0.7203 | 0.7201 | 0.7197 | 0.7194 | 0.7193 | 0.7183 | 0 |
  | TrustMark | T | 85 | 0.6273 | 0.6278 | 0.6282 | 0.6290 | 0.6295 | 0.6307 | +0.0034 |
  | TrustMark | F-seg | 42 | 0.6893 | 0.6890 | 0.6889 | 0.6887 | 0.6887 | 0.6884 | 0 |
  | StegaStamp | T | 85 | 0.7897 | 0.7883 | 0.7873 | 0.7846 | 0.7813 | 0.7728 | 0 |
  | StegaStamp | F-seg | 42 | 0.7621 | 0.7596 | 0.7575 | 0.7538 | 0.7500 | 0.7415 | 0 |

- **Décision : NO-GO.** Aucun σ > 0 n'atteint +0.008 sur T : TrustMark +0.0034 au mieux, PixelSeal +0.0004, StegaStamp perd.
  Les cartes fusionnées (issues de U-Nets) sont déjà lisses à l'échelle des blobs ; lisser davantage efface les petits trous.
- Pas d'intégration (ni v3s.py, ni v14). **v12a_sam reste la soumission finale.**

### VAE : carte de reconstruction |y − VAE(y)| (type AEROBLADE) pour les trous T : NO-GO
- Script `W/stack/vae_rec.py` ; diffusers 0.32.2 installé sans dépendances dans `/p/project1/training2666/debbah2/pylibs`
  (la 0.43 exige torch ≥ 2.6).
- Poids dans `/p/project1/training2666/debbah2/hf` : sd-vae-ft-mse, sdxl-vae-fp16-fix, sd-vae-ft-ema.
  - Attention : le profil définit `HUGGINGFACE_HUB_CACHE` vers /p/scratch ; vae_rec.py le force vers /p/project1.
  - Un premier téléchargement avait écrit par erreur dans `/p/scratch/.../.cache/hub` ; mes fichiers y ont été retirés
    (0 fichier restant à debbah2).
- **Pilote** (08:10 → 08:30, CPU, 8 threads) : 15 T + 15 F du train par méthode.
  - AUC par image de la carte contre m128 (> 0.5 = carte plus forte dans les zones tatouées) : médianes.
  - Complémentarité sur les T : régression logistique sur [logit OOF de v12a, carte VAE z-scorée par image], validation
    croisée à 2 plis par image ; on compare l'AUC par image à celle de v12a seul.

  | VAE | Variante | Méthode | AUC T | AUC F | AUC T v12a seul | AUC T combinée | Gain T |
  |---|---|---|---|---|---|---|---|
  | sd-vae-ft-mse | v1 | PixelSeal | 0.559 | 0.567 | 0.925 | 0.920 | −0.005 |
  | sd-vae-ft-mse | v2 | PixelSeal | 0.558 | 0.534 | 0.925 | 0.924 | −0.006 |
  | sd-vae-ft-mse | v1 | TrustMark | 0.486 | 0.572 | 0.919 | 0.917 | −0.008 |
  | sd-vae-ft-mse | v2 | TrustMark | 0.505 | 0.563 | 0.919 | 0.918 | −0.004 |
  | sd-vae-ft-mse | v1 | StegaStamp | 0.627 | 0.650 | 0.989 | 0.989 | −0.001 |
  | sd-vae-ft-mse | v2 | StegaStamp | 0.660 | 0.692 | 0.989 | 0.989 | −0.001 |
  | sdxl-vae-fp16-fix | v1 | PixelSeal | 0.538 | 0.558 | 0.925 | 0.923 | −0.006 |
  | sdxl-vae-fp16-fix | v2 | PixelSeal | 0.549 | 0.531 | 0.925 | 0.922 | −0.007 |
  | sdxl-vae-fp16-fix | v1 | TrustMark | 0.479 | 0.585 | 0.919 | 0.918 | −0.005 |
  | sdxl-vae-fp16-fix | v2 | TrustMark | 0.508 | 0.569 | 0.919 | 0.918 | −0.004 |
  | sdxl-vae-fp16-fix | v1 | StegaStamp | 0.610 | 0.630 | 0.989 | 0.989 | −0.001 |
  | sdxl-vae-fp16-fix | v2 | StegaStamp | 0.668 | 0.679 | 0.989 | 0.989 | −0.001 |

- **Décision : NO-GO.** L'AUC T plafonne à 0.67 (StegaStamp, v2), loin de 0.80, et la combinaison avec v12a ne gagne
  jamais (−0.001 à −0.008, pour +0.02 demandé).
  - Le signal existe faiblement sur StegaStamp (0.61 à 0.67), dans le sens attendu, mais il est absent sur
    PixelSeal et TrustMark (0.48 à 0.56).
  - Il est déjà contenu dans la carte v12a : AUC par image de 0.92 à 0.99 sur les T.
  - sd-vae-ft-ema n'a pas été testé (inutile vu l'écart). Ni export, ni job GPU ; `W/run_vae_export_devel.sh` n'est pas soumis.
- v12a_sam reste la soumission finale, sauf nouvelle piste validée.

### Pilote : décoder chaque segment SAM (`W/stack/seg_decode.py`) : ABANDONNÉ pour les 3 méthodes
- **Protocole** : 25 images F-seg éligibles du train par méthode, sur CPU (8 threads, environ 20 min).
  - Segment 128 → 512 par plus proche voisin ; remplissage gris, flou σ = 8 ou couleur moyenne ; décodage à 512 par le wrapper.
  - Scores : conf, acc, confiance par position dans le segment (`ppin`) et écart intérieur − extérieur (`ppdiff`).
  - Les versions centrées (d) donnent le même classement à l'intérieur d'une image.
  - Résultats : `W/results_segdec_pilot.md` ; scores : `W/stack/maps/segdec_pilot_train_<m>.npz`.

  | Méthode | Remplissage | AUC intra-image conf / acc / ppin / ppdiff | Rang médian du meilleur (conf) | Meilleur top-1 décodeur |
  |---|---|---|---|---|
  | PixelSeal | gris | 0.55 / 0.51 / 0.60 / 0.60 | 36 / 118 | 0.555 |
  | PixelSeal | flou | 0.48 / 0.68 / 0.56 / 0.57 | 48 / 118 | 0.591 |
  | PixelSeal | moyenne | 0.57 / 0.51 / 0.57 / 0.57 | 30 / 118 | 0.521 |
  | TrustMark | gris | 0.70 / 0.73 / 0.68 / 0.67 | 4 / 96 | 0.599 |
  | TrustMark | flou | 0.56 / 0.50 / 0.66 / 0.65 | 36 / 96 | 0.553 |
  | TrustMark | moyenne | 0.70 / 0.65 / 0.62 / 0.60 | 6 / 96 | 0.611 |
  | StegaStamp | gris | 0.84 / 0.67 / – / – | 3 / 121 | 0.636 |
  | StegaStamp | flou | 0.84 / 0.67 / – / – | 7 / 121 | 0.657 |
  | StegaStamp | moyenne | 0.84 / 0.77 / – / – | 2 / 121 | 0.694 |

  | Méthode | AUC de l'aire seule | Top-1 de la règle actuelle | Masque v9 OOF | Oracle segment | Règle top-2 → max décodeur | top-3 | top-5 |
  |---|---|---|---|---|---|---|---|
  | PixelSeal | **0.92** | **0.800** | 0.673 | 0.966 | 0.788 | 0.776 | 0.709 |
  | TrustMark | **0.83** | **0.718** | 0.623 | 0.905 | 0.744 | 0.715 | 0.687 |
  | StegaStamp | **0.88** | **0.841** | 0.729 | 0.923 | 0.843 | 0.827 | 0.849 |

  Pour les colonnes top-K, le meilleur des 13 scores a été retenu après coup ; ces chiffres sont donc optimistes.
- **Décision** : abandon pour les 3 méthodes ; pas de passage complet ni de job GPU.
  - **L'aire seule sépare mieux** les bons segments des mauvais (AUC 0.83 à 0.92) que n'importe quel score décodé.
    Les AUC décodeur (0.5 à 0.84) mesurent donc surtout la taille du segment.
  - **Le top-1 décodeur perd toujours contre la règle actuelle** (−0.11 à −0.21). Il préfère les segments plus grands qui
    contiennent l'objet, plus de marquage restant visible au décodeur.
  - **Combinaison top-K de la règle → max du décodeur** : gain instable (TrustMark +0.026 pour K = 2, mais −0.003 pour K = 3)
    et optimiste ; au mieux, moins de +0.002 sur la moyenne.

## Agent B (type T et cartes)

Mis à jour : 07:28.

### À INTÉGRER (résumé pour A), sur la base v9 (`--rules_plus` déjà dedans)
- **`--extras … wmunetTi wmunetTi2`** (avec `--rules_plus`) : les 2 graines de la meilleure recette T. Les deux tags
  existent pour les 3 méthodes. Ce choix est fait a priori (moyenne de graines), pas en prenant la meilleure ligne du tableau.
- **Ne pas ajouter** :
  - les pseudo-labels (`plwmunetT`) : ils ne passent pas la barre de +0.005 contre leur témoin (voir tâche 3) ;
  - `wmunetT`, `wmunetTo`, `wmunetT0`, `wmunetT2`, `plwmunetTn` : plus faibles ou redondants.
- **Estimation** (`W/stack/wm_unet_T_eval.py --base submission_v9` ; fusion des sources de v9 + les tags, règle du mIoU
  attendu, post choisi en CV, mêmes plis que v3, **avant rectangles et SAM**) :

  | Méthode | v9 (base) | + `wmunetTi` | + `wmunetTi` + `wmunetTi2` | T : v9 → + les 2 |
  |---|---|---|---|---|
  | PixelSeal | 0.6186 | 0.6196 | **0.6245** | 0.6353 → 0.6354 |
  | TrustMark | 0.6179 | 0.6207 | **0.6212** | 0.6263 → 0.6318 |
  | StegaStamp | 0.7178 | 0.7199 | **0.7203** | 0.7525 → 0.7567 |
  | Moyenne | 0.6514 | 0.6534 | **0.6553 (+0.004)** | |

  - Pour PixelSeal, le gain vient surtout de F-seg (0.712 → 0.737) ; SAM en absorbera probablement une partie.
  - Pour TrustMark et StegaStamp, il vient du type T, que ni les rectangles ni SAM ne touchent.
  - Les écarts d'une seule source sont de l'ordre du bruit de la CV (environ ±0.003). Après rectangles et SAM, compter
    plutôt sur **+0.002 à +0.004**. C'est la CV réelle de v3 lors de ton intégration qui tranchera.

### Ce qui tourne
- **Rien.** Jobs 15905372 (tâche 1) et 15905480 (tâches 3 et 4) terminés (COMPLETED). Journaux dans `W/runs/wmunetT/`.

### Tâche 4 : graines
- `wmunetTi2` (2e graine, init wmunet2 pour PixelSeal, wmunet pour TrustMark et StegaStamp). Carte seule, toutes / T :
  PixelSeal 0.612 / 0.621, TrustMark 0.609 / 0.623, StegaStamp 0.597 / 0.631.

### Tâche 3 : pseudo-labels du test, NON RETENUS
- `plwmunetT` : fine-tuning avec les pseudo-labels du test ; `plwmunetTn` : témoin identique, sans pseudo-labels.
  Les deux partent du checkpoint de `wmunetTi` (job 15905480).
- Fusion des sources de v9 + le tag (même protocole que plus haut) :

  | Méthode | + `plwmunetT` | + `plwmunetTn` (témoin) | Écart |
  |---|---|---|---|
  | PixelSeal | 0.6235 | 0.6193 | +0.004 |
  | TrustMark | 0.6221 | 0.6209 | +0.001 |
  | StegaStamp | 0.7188 | 0.7199 | −0.001 |

  - Aucun écart ne dépasse la barre de +0.005, alors que la CV avec pseudo-labels est en plus optimiste.
  - Carte seule : StegaStamp passe de 0.6046 à 0.6127 avec les pseudo-labels, mais cela ne se retrouve pas dans la fusion.
- **Étiquettes** : construites depuis v8 / v8_sam par `W/stack/wm_unet_T_pl.py --build_labels` et rangées dans
  `W/stack/maps/plwmunetT_labels_test_<m>.npz` :
  - boîtes à acc ≥ 0.9 (`v3.load_rect`, fichier local StegaStamp compris) ;
  - segments SAM de v8_sam dont le score dépasse s_hi = 0.642, calé sur le train (76 images F, segment à 0.905 de mIoU) ;
  - pour les T, uniquement les cases à p < 0.1 ou > 0.9.

  | Méthode | rect | SAM | T |
  |---|---|---|---|
  | PixelSeal | 36 | 38 | 171 |
  | TrustMark | 63 | 37 | 173 |
  | StegaStamp | 44 | 66 | 170 |

  - **Règle** : un gain par pseudo-labels doit dépasser **+0.005 en CV** pour être retenu, car la CV OOF devient optimiste
    (les étiquettes viennent de modèles ajustés sur tout le train). Témoin sans pseudo-labels : tag `plwmunetTn`.

### Tâche 1 : wm-U-Net spécialisé T (`W/stack/wm_unet_T.py`, importe wm_unet.py sans le modifier)
- **Pré-entraînement synthétique T** : uniquement des éditions pleine image (`hole` 60 %, `addition` 40 %).
  - Formes **sans fuite** : blobs aléatoires dont l'aire et le nombre de grosses composantes suivent les distributions
    des vrais trous T du train (`loc/cache/typo_stats.json`).
  - Aucune forme de masque réel n'est réutilisée, contrairement au générateur de wm_unet.py.
  - 4000 pas, même schéma de gel que wmunet.
- **Fine-tuning** en 5 plis, **mêmes plis que toutes les sources** (`folds(N, 5, 0)` dans l'ordre de load_split).
  Deux variantes, à partir du même état pré-entraîné :
  - `<tag>` : toutes les images, poids ×3 sur les images T ;
  - `<tag>o` : images T seulement.
- **Tags prévus** (cartes `W/stack/maps/<tag>_{train,test}_<méthode>.npz`, au format des autres sources).
  Pour chaque tag, `<tag>0` est la carte synthétique seule et `<tag>o` la variante T seulement.

  | GPU | Run prioritaire | Run bonus |
  |---|---|---|
  | GPU0 | PixelSeal `wmunetT` (`wmunetT0`, `wmunetTo`) | `wmunetT2` (2e graine) |
  | GPU1 | TrustMark `wmunetT` (`wmunetT0`, `wmunetTo`) | `wmunetT2` (2e graine) |
  | GPU2 | PixelSeal `wmunetTi` (init checkpoint wmunet + 1500 pas T) | TrustMark `wmunetTi` |
  | GPU3 | StegaStamp `wmunetT` | StegaStamp `wmunetTi` (init wmunetH) |

- **Résultats, carte seule** (journaux `W/runs/wmunetT/<tag>_<m>.json` et `slurm_15905372.out` ; règle switch en CV,
  « T » = moyenne sur les 85 images T de la méthode) :

  | Carte | PixelSeal T / toutes | TrustMark T / toutes | StegaStamp T / toutes |
  |---|---|---|---|
  | référence `wmunet` | 0.618 / 0.608 | 0.613 / 0.607 | 0.635 / 0.595 |
  | **`wmunetTi`** (init wmunet + 1500 pas T, fine-tuning T ×3) | **0.628 / 0.618** | **0.624 / 0.607** | **0.644 / 0.606** |
  | `wmunetTio` (même init, fine-tuning sur les T seuls) | 0.616 / 0.576 | 0.621 / 0.575 | 0.646 / 0.579 |
  | `wmunetT` (synthétique T depuis zéro, 4000 pas) | 0.609 / 0.579 | 0.612 / 0.583 | 0.620 / 0.577 |
  | `wmunetTo` | 0.620 / 0.556 | 0.607 / 0.568 | 0.620 / 0.560 |

  - Mieux vaut partir du checkpoint synthétique général (`--init`) que d'un synthétique T depuis zéro.
  - Par pli, `wmunetTi` bat wmunet sur les T dans 4 plis sur 5 pour PixelSeal (mIoU@0).
- **Résultats dans la fusion** (`W/stack/wm_unet_T_eval.py`, fonctions et plis de v3, sources de v8 + le tag ; règle +
  post choisi en CV, avant rectangles et SAM) :

  | Méthode | base v8, règle actuelle | base v8, règle du mIoU attendu | + `wmunetTi`, règle du mIoU attendu | T : base → + `wmunetTi` (règle du mIoU attendu) |
  |---|---|---|---|---|
  | PixelSeal | 0.6182 | 0.6186 | 0.6196 | 0.6353 → 0.6371 |
  | TrustMark | 0.6170 | 0.6179 | **0.6207** | 0.6263 → 0.6320 |
  | StegaStamp | 0.7076 | 0.7178 | 0.7199 (`wmunetTio` : **0.7209**) | 0.7525 → 0.7561 |

  - L'apport propre des cartes T est petit : +0.001 à +0.003 par méthode, dans le bruit de la CV.
    Il est cependant de même signe pour les 3 méthodes.
  - La fusion PixelSeal, à 14 sources, est saturée : `wmunetTi` seul (0.616) y est redondant.

### Tâche 2 : règle « mIoU attendu maximal » (`W/stack/rule_emiou.py`) : PRÊTE À INTÉGRER
- **Principe** : pour chaque image, parmi les masques « k cases les plus probables » (k = 0…16384), on garde le k qui
  maximise le mIoU souple attendu sous P = sigmoïde(carte fusionnée). La variante retenue, `none` (sans calibration),
  **n'a aucun paramètre appris**.
- **Interface pour A**, au choix :
  - `from rule_emiou import rule_preds_plus` : remplaçant direct de `v3.rule_preds(L, g, gt, tr_idx)`. Il renvoie les mêmes
    règles, plus `emiou_none` et les hybrides `emiouT_none|<règle>` (mIoU attendu sur les images prédites T, `<règle>` sur
    les F). La sélection de règle de v3 (`cv_select`) choisit ensuite par méthode.
  - `from rule_emiou import emiou_rule` : `pred, info = emiou_rule(L, g, gt, tr_idx, calib="none", p_switch=p)`
    → masques [N,128,128] bool, avec L = logits des lignes train puis test, comme dans v3.
- **Mesure** sur les cartes fusionnées OOF de v7 (`W/sam/submission_v7/probs_train_oof.pt`, identiques à v8), mêmes
  plis que v3, avant rectangles et SAM. Commandes : `python rule_emiou.py` (règle seule) et `python rule_emiou.py --post`
  (règle + post-traitement choisi en CV).

  | Règle + post choisi en CV | Toutes | T | F-rect | F-seg |
  |---|---|---|---|---|
  | règle actuelle de v7 | 0.6476 | 0.6653 | 0.5524 | 0.7093 |
  | `emiou_none` | **0.6514** | **0.6714** | 0.5519 | 0.7129 |
  | `emiouT_none` \| règle actuelle | 0.6504 | 0.6713 | 0.5524 | 0.7086 |

  | Méthode | actuelle | `emiou_none` | hybride |
  |---|---|---|---|
  | PixelSeal | 0.6182 | 0.6186 | 0.6195 |
  | TrustMark | 0.6170 | 0.6179 | 0.6188 |
  | StegaStamp | 0.7076 | **0.7178** | 0.7129 |

  - Règle seule (sans post) : 0.6458 → 0.6522 ; T 0.6645 → 0.6716. L'oracle du seuil par image vaut 0.6763.
  - Les calibrations (`temp`, `temp_type`, `iso_type`) n'apportent rien par rapport à `none`.
- **Gain attendu après rectangles et SAM** : environ +0.003 au total, surtout grâce au type T (+0.006 sur T, que ni les
  rectangles ni SAM ne touchent) et à StegaStamp. Les gains sur F-rect et F-seg seront en partie absorbés par les rectangles et SAM.
- Pas de modification de v3.py de mon côté : l'intégration revient à A.

## Pistes tirées des papiers WAM et MELB (22/11, 10:45–11:00) : NÉGATIF, rien n'est intégré
- Détail : `W/results_wam.md`. Code : `W/stack/wam_ft.py`, `W/stack/melb_blocks.py`.
  Job 15906072 (dc-gpu-devel, hors réservation, 6 min).
- **WAM** : tête de décodage des bits par case sur le wm-U-Net (éq. 5 de WAM, λ = 10, avec ou sans cible nulle sur les
  cases propres) et carte d'accord au message connu.
  - La BCE des bits reste à ln 2 et les cartes d'accord à ≈ 0.45 : aucun signal.
  - Les cartes de détection restent à ±0.003 du témoin apparié `wamc`.
- **MELB** : moyenne par blocs de 4×4 ou 8×8 cases de `wmunet` / `wmunet2` ajoutée à la fusion PixelSeal : +0.0006, du bruit.
- **Fusion v3 avant SAM** : v18_wam 0.6943 et v18_wamc (témoin) 0.6958, contre 0.6966 pour v12a.
  - Sur TrustMark, les cartes quasi identiques à `wmunet` dérèglent la sélection du top 3 (−0.009).
  - Rejeté. **v12a_sam reste la soumission finale.**
- Nouvelles cartes dans `maps/` (à ne pas ajouter) : `wamc`, `wamd`, `wamda`, `wamn`, `wamna`, les mêmes avec le suffixe `2`
  (PixelSeal), et `wmunet{,2}_b{4,8}`.

## EditGuard (PPEM, « degradation prompts ») et base WAM (22/11, 11:00–11:10) : NO-GO, investigation en lecture seule
- **Prémisse fausse.**
  - Le PDF officiel de la tâche ne parle ni de JPEG, ni de bruit, ni d'images dégradées : seulement les 4 types d'édition.
  - Les 2040 fichiers (train + test) sont des PNG.
  - Train et test sont identiques sur 5 indicateurs de dégradation (KS p ≥ 0.10, blockiness ≈ 1.00) et sur g / bit acc.
  - Les mesures sont dans le scratchpad de la session.
- **PPEM** (EditGuard §4.3, éq. 3-4, Tab. 5) : prompts de dégradation appris pour bruit gaussien, bruit de Poisson et JPEG,
  dans le décodeur inversible propre à EditGuard, entraîné 250K itérations avec son embedder.
  - Gain de +0.046 IoU seulement sous bruit ou JPEG.
  - Non transférable à des watermarks fixés et sans objet ici.
- **Base WAM** :
  - les poids publics de WAM ne détectent que le watermark WAM ;
  - notre encodeur PixelSeal a déjà la sortie WAM (1 + 256 canaux), et le canal 0 n'est pas une carte de détection (AUC 0.62 T / 0.41 F sur 32 images) ;
  - sur une carte seule, les backbones génériques font 0.47–0.51 contre 0.61 pour le wm-U-Net.
  - **Garder l'architecture actuelle.** Seule piste longue crédible, non prouvée : pré-entraîner le même wm-U-Net
    à grande échelle sur des montages synthétiques faits avec les 3 embedders officiels.
- Seul effet mesuré : sur StegaStamp-T, les images très texturées sont moins bien localisées (rho −0.37 avec la taille du fichier).
  Gain réaliste d'une variable « texture » : ≤ +0.002, sous le seuil.
- **v12a_sam (0.7192) reste la soumission finale.**

## Zoo d'encodeurs pour les U-Nets « stack » → v19b : GAGNE (+0.0145 après SAM). Envoyée (n° 4223) : public 0.7324, nouveau meilleur score
- **Recette** : même que `train_unet.py` (effb3_hp_glob_stack), 40 époques au lieu de 60.
  - 5 nouveaux encodeurs timm, poids déjà dans `W/hf/hub` : variantes `z*_hp_glob_stack` ajoutées dans VARIANTS.
  - 2 jobs d'1 nœud dans cispahack (15906156, 15906157 ; règle « 3 nœuds par équipe »), plis en parallèle,
    2 processus par GPU, 16 min.
  - Scripts : `W/run_zoo_{A,B}.sh` ; fusion des plis : `W/merge_zoo.py`.
- **Cartes seules** (val mIoU@0.5 par pli) :
  - `zhrw18` 0.60–0.615, la meilleure, avec StegaStamp 0.72–0.74 ;
  - `zregy040` 0.58–0.59 ;
  - `zr2n50` 0.54–0.56 ;
  - `zrx50` 0.54–0.55 ;
  - `zeffb4` 0.52–0.55.
- **Résultats** :
  - v19a (+ regy040, rx50, r2n50) : avant SAM 0.7033, après SAM 0.7237.
  - **v19b (+ les 5)** : avant SAM 0.7096, après SAM **0.7332**, soit +0.0145 par rapport à v12a_sam.
    Après SAM, par méthode : PixelSeal 0.6802, TrustMark 0.7091, StegaStamp 0.8103.
- **Commande** : `--runs $R zregy040_hp_glob_stack zrx50_hp_glob_stack zr2n50_hp_glob_stack zhrw18_hp_glob_stack zeffb4_hp_glob_stack --extras $E`
  (R et E = ceux de v12a), puis `sam_stage.py`.
- Les poids de 3 autres encodeurs sont en cache et non utilisés (`zserx50`, `zeffv2m`, `zregz`, déjà déclarés).
  Leçon : la diversité d'architecture des U-Nets « stack » est le levier qui marche.
- **Tour 2 du zoo** (11:45–11:58 ; jobs 15906207 et 15906208) :
  - ajouts : `zhrw18_hp_glob_stack_s2` (2e graine), `zserx50`, `zregz` ;
  - v19c : avant SAM 0.7095, **après SAM 0.7325, contre 0.7332 pour v19b** → non envoyée, le zoo plafonne.
  - **Soumission finale : v19b_sam (n° 4223, public 0.7324).**
