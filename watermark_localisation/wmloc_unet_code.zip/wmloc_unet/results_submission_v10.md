| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wmunet20'] | 0.6125 | 0.6218 | 0.6032 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6164 | 0.6295 | 0.6032 |
| pixelseal | fusion all + rule switch | 0.6164 | 0.6295 | 0.6032 |
| pixelseal | fusion all + rule expected_area | 0.6137 | 0.6317 | 0.5956 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6180 | 0.6305 | 0.6055 |
| pixelseal | fusion all + rule regressed_area | 0.5942 | 0.6111 | 0.5774 |
| pixelseal | fusion all + rule emiou_none | 0.6206 | 0.6346 | 0.6066 |
| pixelseal | fusion all + rule emiouT|switch | 0.6186 | 0.6350 | 0.6022 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6156 | 0.6343 | 0.5969 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6196 | 0.6348 | 0.6044 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6070 | 0.6332 | 0.5808 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6484 | 0.6609 | 0.6358 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6189 | 0.6346 | 0.6031 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:drop<256 | **0.6186** | 0.6353 | 0.6019 |
| pixelseal | + rect override none (boxes for 86 train images) | 0.6222 | 0.6362 | 0.6082 |
| pixelseal | + rect override rect>=0.7 (boxes for 86 train images) | 0.6346 | 0.6320 | 0.6372 |
| pixelseal | + rect override rect>=0.75 (boxes for 86 train images) | 0.6506 | 0.6320 | 0.6692 |
| pixelseal | + rect override rect>=0.8 (boxes for 86 train images) | 0.6526 | 0.6320 | 0.6732 |
| pixelseal | + rect override rect>=0.85 (boxes for 86 train images) | 0.6532 | 0.6320 | 0.6743 |
| pixelseal | + rect override rect>=0.9 (boxes for 86 train images) | 0.6437 | 0.6362 | 0.6511 |
| pixelseal | + rect override rect>=0.95 (boxes for 86 train images) | 0.6399 | 0.6362 | 0.6436 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6526** | 0.6320 | 0.6732 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6078 | 0.6100 | 0.6055 |
| trustmark | fusion top3 + rule switch | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion top3 + rule expected_area | 0.6132 | 0.6235 | 0.6029 |
| trustmark | fusion top3 + rule otsu_in_regime | 0.6108 | 0.6149 | 0.6067 |
| trustmark | fusion top3 + rule regressed_area | 0.5947 | 0.6109 | 0.5786 |
| trustmark | fusion top3 + rule emiou_none | 0.6181 | 0.6273 | 0.6090 |
| trustmark | fusion top3 + rule emiouT|switch | 0.6170 | 0.6279 | 0.6062 |
| trustmark | fusion top3 + rule emiouT|expected_area | 0.6151 | 0.6269 | 0.6033 |
| trustmark | fusion top3 + rule emiouT|otsu_in_regime | 0.6170 | 0.6275 | 0.6065 |
| trustmark | fusion top3 + rule emiouT|regressed_area | 0.6041 | 0.6257 | 0.5825 |
| trustmark | fusion top3 + ORACLE per-image threshold (upper bound) | 0.6438 | 0.6548 | 0.6329 |
| trustmark | fusion top3 + CV-selected rule (whole-train choice: emiou_none) | 0.6164 | 0.6273 | 0.6055 |
| trustmark | **v2 pipeline**: fusion top3 + emiou_none + post T:close_holes5 / F:largest | **0.6179** | 0.6263 | 0.6094 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6204 | 0.6273 | 0.6135 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6272 | 0.6255 | 0.6289 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6663 | 0.6255 | 0.7070 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6789 | 0.6273 | 0.7304 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6789** | 0.6273 | 0.7304 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'wmunetH0', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.6977 | 0.7413 | 0.6541 |
| stegastamp | fusion all + rule switch | 0.6977 | 0.7413 | 0.6541 |
| stegastamp | fusion all + rule expected_area | 0.7062 | 0.7395 | 0.6729 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7035 | 0.7455 | 0.6615 |
| stegastamp | fusion all + rule regressed_area | 0.6887 | 0.7210 | 0.6563 |
| stegastamp | fusion all + rule emiou_none | 0.7180 | 0.7529 | 0.6831 |
| stegastamp | fusion all + rule emiouT|switch | 0.7021 | 0.7511 | 0.6530 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7129 | 0.7528 | 0.6730 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7068 | 0.7528 | 0.6609 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7046 | 0.7529 | 0.6564 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7368 | 0.7671 | 0.7066 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7180 | 0.7529 | 0.6831 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<64 | **0.7178** | 0.7525 | 0.6831 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7191 | 0.7540 | 0.6842 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.6815 | 0.7485 | 0.6145 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7189 | 0.7485 | 0.6893 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7270 | 0.7485 | 0.7055 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7308 | 0.7485 | 0.7130 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7335 | 0.7540 | 0.7130 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7335 | 0.7540 | 0.7130 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7308** | 0.7485 | 0.7130 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.6526,
  "cv_T": 0.632,
  "cv_F": 0.6732,
  "test_frac_pred_1": 0.497
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6789,
  "cv_T": 0.6273,
  "cv_F": 0.7304,
  "test_frac_pred_1": 0.496
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "wmunetH0",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<64",
  "rect": "rect>=0.9",
  "cv": 0.7308,
  "cv_T": 0.7485,
  "cv_F": 0.713,
  "test_frac_pred_1": 0.493
 },
 "rules_plus": true,
 "rect3": true,
 "expected_cv_mIoU": 0.6874,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v10.pt",
 "size_MB": 15.96
}
```
