#!/bin/bash
# Wait until the team has no job in the cispahack reservation, then submit the GPU worker (CLAUDE.md one-job rule).
# After submitting, re-check: if another team job appeared at the same time, cancel ours.
cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
T=$(pwd | grep -oE '/p/scratch/training2666/[^/]+/[^/]+')
while true; do
  n=$(squeue -r --reservation=cispahack -h -o "%u|%T|%Z" | grep -c "$T")
  if [ "$n" -eq 0 ]; then
    jid=$(sbatch --parsable --job-name=dzw --time=02:00:00 scripts/run4.sh scripts/gpu_worker.sh)
    echo "$(date +%T) submitted $jid"
    sleep 15
    others=$(squeue -r --reservation=cispahack -h -o "%i|%Z" | grep "$T" | grep -vc "^$jid|")
    if [ "$others" -gt 0 ]; then
      scancel "$jid"; echo "$(date +%T) another team job appeared -> cancelled $jid"; continue
    fi
    squeue -j "$jid" -h -o "%i %T %M %N"
    exit 0
  fi
  sleep 20
done
