"""What fills the holes of type-T images? (CPU, read-only on the data)

(b) 2x crops around hole borders, contour overlaid, for 12 train T images (4 per method) -> W/diag_fill/*.png
(c) per method, on N train T images: matched rings on both sides of the hole border (2..10 px inside the hole vs
    2..10 px outside), and the far interiors (> 10 px):
      - high-pass energy of the luminance, hp = Y - Gaussian_1(Y), mean hp^2 ;
      - gradient magnitude ON the border vs in the rings (a pasted / inpainted patch leaves a seam) ;
      - Pearson correlation between hp(Y) and hp(r_Y), r = embed(y, m) - y with the official embedder and the known
        message (re-marking residual) -> the watermark already present in y should correlate with r.
"""
import sys
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi

sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT, METHODS  # noqa: E402

OUT = Path("/p/project1/training2666/debbah2/wmloc_unet/diag_fill"); OUT.mkdir(exist_ok=True)
N_STAT = int(sys.argv[1]) if len(sys.argv) > 1 else 20


def lum(img):
    return img.astype(np.float64) @ np.array([0.299, 0.587, 0.114])


def hp(Y):
    return Y - ndi.gaussian_filter(Y, 1.0)


def pick(ds, meth, n, rng):
    out = []
    for i, m in enumerate(ds.meta):
        if m["method"] != meth or not m["full_watermark"]:
            continue
        hole = ~ds.m128[m["image_name"]].astype(bool)
        if 0.02 <= hole.mean() <= 0.35:
            out.append(i)
    rng.shuffle(out); return out[:n]


def crop_panel(img, hole, rng):
    """2x crop (128 px window -> 256) around a border point of the largest hole; returns (plain, with contour)."""
    lab, k = ndi.label(hole); sz = ndi.sum(hole, lab, range(1, k + 1)); big = lab == 1 + int(np.argmax(sz))
    border = big & ~ndi.binary_erosion(big)
    ys, xs = np.where(border); j = rng.randint(len(ys)); cy, cx = ys[j], xs[j]
    y0 = int(np.clip(cy - 64, 0, 512 - 128)); x0 = int(np.clip(cx - 64, 0, 512 - 128))
    c = img[y0:y0 + 128, x0:x0 + 128].repeat(2, 0).repeat(2, 1)
    h = hole[y0:y0 + 128, x0:x0 + 128].repeat(2, 0).repeat(2, 1)
    edge = h & ~ndi.binary_erosion(h, iterations=1)
    c2 = c.copy(); c2[edge] = [255, 0, 0]
    return c, c2


def main():
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    rng = np.random.RandomState(0); tr = load_split("train")
    # (b) crops
    fig, axs = plt.subplots(6, 4, figsize=(16, 24)); k = 0
    for meth in METHODS:
        for i in pick(tr, meth, 4, rng):
            it = tr[i]; img = np.asarray(it["image"]); hole = ~it["mask"].astype(bool)
            c, c2 = crop_panel(img, hole, rng)
            ax1, ax2 = axs[(k // 2), (k % 2) * 2], axs[(k // 2), (k % 2) * 2 + 1]
            ax1.imshow(c); ax1.set_title(f"{meth} {it['image_name']} (trou {hole.mean():.0%})", fontsize=9); ax1.axis("off")
            ax2.imshow(c2); ax2.set_title("contour du trou en rouge", fontsize=9); ax2.axis("off")
            if k < 3:
                plt.imsave(OUT / f"crop_{k}_{meth}_{it['image_name']}.png", np.concatenate([c, c2], 1))
            k += 1
    plt.tight_layout(); plt.savefig(OUT / "crops_grid.png", dpi=70); plt.close()
    print("crops written", flush=True)
    # (c) statistics
    print(f"\n| méthode | n | énergie HP dedans/dehors (anneaux 2-10 px) | intérieurs lointains dedans/dehors | gradient sur la frontière / anneaux | corr(hp y, hp r) dedans | dehors |")
    print("|---|---|---|---|---|---|---|")
    for meth in METHODS:
        wm = load_watermark(meth, KIT / "models", "cpu"); R = {k_: [] for k_ in ("e_ring", "e_far", "seam", "c_in", "c_out")}
        for i in pick(tr, meth, N_STAT, np.random.RandomState(1)):
            it = tr[i]; img = np.asarray(it["image"]); hole = ~it["mask"].astype(bool); msg = it["message"]
            Y = lum(img); H = hp(Y)
            din = ndi.distance_transform_edt(hole); dout = ndi.distance_transform_edt(~hole)
            rin = hole & (din >= 2) & (din <= 10); rout = ~hole & (dout >= 2) & (dout <= 10)
            fin = hole & (din > 10); fout = ~hole & (dout > 10)
            if rin.sum() < 200 or rout.sum() < 200:
                continue
            R["e_ring"].append((H[rin] ** 2).mean() / (H[rout] ** 2).mean())
            if fin.sum() > 200 and fout.sum() > 200:
                R["e_far"].append((H[fin] ** 2).mean() / (H[fout] ** 2).mean())
            g = np.hypot(*np.gradient(ndi.gaussian_filter(Y, 0.7)))
            bd = (din > 0) & (din <= 1.5) | (dout > 0) & (dout <= 1.5)
            R["seam"].append(g[bd].mean() / g[rin | rout].mean())
            r = lum(wm.embed(img, msg).astype(np.float64)) - Y; Hr = hp(r)
            R["c_in"].append(np.corrcoef(H[rin], Hr[rin])[0, 1]); R["c_out"].append(np.corrcoef(H[rout], Hr[rout])[0, 1])
        med = {k_: np.median(v) for k_, v in R.items()}
        print(f"| {meth} | {len(R['e_ring'])} | {med['e_ring']:.3f} | {med['e_far']:.3f} | {med['seam']:.3f} | {med['c_in']:+.3f} | {med['c_out']:+.3f} |", flush=True)


if __name__ == "__main__":
    main()
