"""Post-processing stage: snap the U-Net map onto a sharp SAM segment, for regime-F images only.

SAM candidates are computed once from the images (gen_candidates.py sam ...). For each image in regime F
(whole-image bit acc < GACC) that was not already replaced by a decoder rectangle:
    best candidate = argmax_c softIoU(prob_map, c)        conf = that softIoU
    if conf >= s: mask = candidate   else: keep the base mask
s is tuned on the train OOF maps (5-fold CV estimate of the gain is reported); the stage switches itself off
(s = inf) if it does not improve the OOF score.

Inputs (.pt, torch.save dicts):
  --oof        train OOF probabilities  {"image_names", "probs" [N,128,128] float in [0,1]}
  --oof-masks  (optional) train OOF final binary masks of the same pipeline {"image_names", "masks"}; default probs>0.5
  --test       test probabilities, same format
  --base       test submission to post-process {"image_names", "masks"}
  --out        output submission
Dev mode: --oof heads  uses the cached head OOF maps (PixelSeal, TrustMark) instead of a U-Net.
Nothing is submitted.

LOCAL COPY of loc/snap_sam.py (teammate's file, read-only), used by stack/sam_stage.py. Only change: rect_names() uses
v3.load_rect for the 3 methods, i.e. loc/cache/rect_* AND stack/maps/rect2_* (map-seeded boxes, StegaStamp included),
best acc per image, so that SAM never overrides a mask already replaced by a rectangle. WMLOC_NO_RECT2=1 (read by
v3.load_rect) ignores rect2_* to replay versions made before them (<= v4b)."""
import argparse, glob, json
from pathlib import Path
import numpy as np
import torch
from scipy import ndimage
from v3 import load_rect                 # also puts loc/ on sys.path (common, evalkit)
from common import CACHE, DATA, METHODS, folds
from evalkit import miou_batch

SP_DEFAULT = str(CACHE / "sam_cands")   # SAM candidates (gen_candidates.py sam), computed once from the images
ap = argparse.ArgumentParser()
ap.add_argument("--oof", required=True); ap.add_argument("--oof-masks"); ap.add_argument("--test"); ap.add_argument("--base")
ap.add_argument("--out"); ap.add_argument("--cands", default=SP_DEFAULT); ap.add_argument("--gacc", type=float, default=0.8)
ap.add_argument("--rect-thr", default="trustmark=0.85,pixelseal=0.7", help="images whose rectangle passes are left alone")
a = ap.parse_args()
N = 128 * 128
RECT_THR = {k: float(v) for k, v in (kv.split("=") for kv in a.rect_thr.split(",") if kv)}


def global_acc(split):
    g = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item()
    md = {m["image_name"]: m for m in json.loads((DATA / split / "metadata.json").read_text())}
    return {n: float(((l > 0) == np.array([int(c) for c in md[n]["message"]])).mean()) for d in g.values()
            for n, l in zip(d["names"], d["logits"])}, {n: m["method"] for n, m in md.items()}


def rect_names(split):
    """Images whose decoder rectangle passes its method's threshold (v3.load_rect: cache rect_* + maps rect2_*, best acc)."""
    out = set()
    for meth, thr in RECT_THR.items():
        out |= {n for n, (_, acc) in load_rect(meth, split).items() if acc >= thr}
    return out


def load_cands(split):
    out = {}
    for f in glob.glob(f"{a.cands}/sam_{split}*.npz"):
        d = np.load(f, allow_pickle=True)
        for n, c in zip(d["names"], d["cands"]):
            out[str(n)] = np.unpackbits(c, axis=1)[:, :N].astype(bool) if len(c) else np.zeros((0, N), bool)
    return out


def load_maps(path, key):
    d = torch.load(path, weights_only=True)
    return {n: np.asarray(m, np.float32 if key == "probs" else bool).ravel() for n, m in zip(d["image_names"], d[key].numpy())}


def snap(prob, C):
    """-> (best candidate [N] bool, conf). Score = soft IoU with the min-max normalised map, weighted by the contrast
    between the mean probability inside the candidate and in a 4-cell ring around it (in units of the map's std).
    Robust to badly calibrated maps (regime-F maps are often uniformly low)."""
    if len(C) == 0:
        return None, -1.0
    Cf = C.astype(np.float32); area = Cf.sum(1)
    inside = (Cf @ prob) / (area + 1e-6)
    R = np.stack([ndimage.binary_dilation(c.reshape(128, 128), iterations=4).ravel() & ~c for c in C]).astype(np.float32)
    ring = (R @ prob) / (R.sum(1) + 1e-6)
    pn = (prob - prob.min()) / (prob.max() - prob.min() + 1e-6)
    inter = Cf @ pn
    soft = inter / (area + pn.sum() - inter + 1e-6)
    sc = soft * np.clip((inside - ring) / (prob.std() + 1e-6), 0, None)
    j = sc.argmax()
    return C[j], float(sc[j])


# ---------------- train: OOF maps -> tune s
gacc, meth_of = global_acc("train"); rects = rect_names("train"); cands = load_cands("train")
z = np.load(DATA / "train" / "masks_128.npz"); gt = {n: m.astype(bool).ravel() for n, m in zip(z["names"].tolist(), z["masks"])}
if a.oof == "heads":                                     # dev proxy: head OOF heat (logits) + switch-rule masks
    probs, base = {}, {}
    for meth in ("pixelseal", "trustmark"):
        d = np.load(CACHE / f"head_oof_{meth}.npz")
        for n, h, p in zip(d["names"], d["heat"].astype(np.float32), d["pred"]):
            probs[str(n)] = (1 / (1 + np.exp(-h))).ravel(); base[str(n)] = p.ravel()
else:
    probs = load_maps(a.oof, "probs")
    base = load_maps(a.oof_masks, "masks") if a.oof_masks else {n: p > 0.5 for n, p in probs.items()}

names = [n for n in probs if gacc[n] < a.gacc and n not in rects and n in cands]
print(f"train: {len(probs)} OOF maps, {len(names)} regime-F images eligible (excluding {len(rects & set(probs))} rectangle images)")
B = np.stack([base[n] for n in names]); G = np.stack([gt[n] for n in names])
S, conf = [], []
for n in names:
    c, s = snap(probs[n], cands[n]); S.append(c if c is not None else base[n]); conf.append(s)
S = np.stack(S); conf = np.array(conf)
sb, ss = miou_batch(B.reshape(-1, 128, 128), G.reshape(-1, 128, 128)), miou_batch(S.reshape(-1, 128, 128), G.reshape(-1, 128, 128))
meths = np.array([meth_of[n] for n in names])


def best_s(idx):
    cand_s = np.r_[np.inf, np.unique(np.quantile(conf[idx], np.linspace(0, 1, 41)))]
    vals = [np.where(conf[idx] >= t, ss[idx], sb[idx]).mean() for t in cand_s]
    return cand_s[int(np.argmax(vals))]


cv = np.zeros(len(names))
for f in folds(len(names), 5, seed=0):
    tr = np.setdiff1d(np.arange(len(names)), f); t = best_s(tr)
    cv[f] = np.where(conf[f] >= t, ss[f], sb[f])
s_final = best_s(np.arange(len(names)))
print(f"regime-F eligible images: base {sb.mean():.4f} | always snap {ss.mean():.4f} | CV-tuned snap {cv.mean():.4f} "
      f"(gain {cv.mean() - sb.mean():+.4f}) | s = {s_final:.3f}, snaps {(conf >= s_final).mean():.0%} of them")
for m in METHODS:
    k = meths == m
    if k.any():
        print(f"   {m:10s} n={k.sum():3d}  base {sb[k].mean():.4f}  always snap {ss[k].mean():.4f}  CV snap {cv[k].mean():.4f}")
n_all = len(set(probs))
print(f"-> estimated effect on the overall score over these {n_all} train images: {(cv.sum() - sb.sum()) / n_all:+.4f}")
if cv.mean() <= sb.mean():
    s_final = np.inf; print("no CV gain -> stage disabled (output = base submission)")

# ---------------- test: apply
if a.test and a.base and a.out:
    gacc_t, _ = global_acc("test"); rects_t = rect_names("test"); cands_t = load_cands("test")
    probs_t = load_maps(a.test, "probs"); d = torch.load(a.base, weights_only=True)
    out_names = list(d["image_names"]); M = d["masks"].numpy().astype(bool).copy(); used = 0
    for i, n in enumerate(out_names):
        if gacc_t[n] < a.gacc and n not in rects_t and n in cands_t and n in probs_t:
            c, s = snap(probs_t[n], cands_t[n])
            if c is not None and s >= s_final:
                M[i] = c.reshape(128, 128); used += 1
    missing = sum(1 for n in out_names if gacc_t[n] < a.gacc and n not in rects_t and n not in cands_t)
    torch.save({"image_names": out_names, "masks": torch.from_numpy(M)}, a.out)
    print(f"test: {used} masks snapped to SAM segments ({missing} regime-F images had no candidates) -> {a.out}")
