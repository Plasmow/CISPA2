| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source wamn | 0.6060 | 0.6177 | 0.5942 |
| pixelseal | source wamd | 0.6055 | 0.6173 | 0.5938 |
| pixelseal | source wamn2 | 0.6070 | 0.6227 | 0.5913 |
| pixelseal | source wamd2 | 0.6077 | 0.6245 | 0.5908 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wamd2'] | 0.6079 | 0.6202 | 0.5955 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wamd2', 'wamn2', 'wamn', 'wamd', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6148 | 0.6269 | 0.6027 |
| pixelseal | fusion all + rule switch | 0.6148 | 0.6269 | 0.6027 |
| pixelseal | fusion all + rule expected_area | 0.6132 | 0.6286 | 0.5978 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6163 | 0.6280 | 0.6047 |
| pixelseal | fusion all + rule regressed_area | 0.5931 | 0.6084 | 0.5779 |
| pixelseal | fusion all + rule emiou_none | 0.6196 | 0.6320 | 0.6073 |
| pixelseal | fusion all + rule emiouT|switch | 0.6171 | 0.6323 | 0.6019 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6154 | 0.6317 | 0.5992 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6180 | 0.6321 | 0.6038 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6061 | 0.6306 | 0.5816 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6479 | 0.6590 | 0.6368 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6196 | 0.6320 | 0.6073 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:drop<256 | **0.6176** | 0.6325 | 0.6027 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6213 | 0.6339 | 0.6087 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6374 | 0.6339 | 0.6410 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6503 | 0.6339 | 0.6666 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6519 | 0.6339 | 0.6699 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6536 | 0.6339 | 0.6733 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6426 | 0.6339 | 0.6514 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6389 | 0.6339 | 0.6439 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6536** | 0.6339 | 0.6733 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source wamn | 0.6052 | 0.6097 | 0.6008 |
| trustmark | source wamd | 0.6031 | 0.6063 | 0.5998 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wamn'] | 0.6049 | 0.6106 | 0.5992 |
| trustmark | fusion top3 ['wmunet', 'wamn', 'wamd'] | 0.6054 | 0.6117 | 0.5992 |
| trustmark | fusion all ['wmunet', 'wamn', 'wamd', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_r50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6059 | 0.6073 | 0.6045 |
| trustmark | wmunet + rule switch | 0.6071 | 0.6136 | 0.6006 |
| trustmark | wmunet + rule expected_area | 0.6091 | 0.6170 | 0.6013 |
| trustmark | wmunet + rule otsu_in_regime | 0.6081 | 0.6156 | 0.6007 |
| trustmark | wmunet + rule regressed_area | 0.5765 | 0.5992 | 0.5538 |
| trustmark | wmunet + rule emiou_none | 0.6098 | 0.6167 | 0.6029 |
| trustmark | wmunet + rule emiouT|switch | 0.6088 | 0.6169 | 0.6007 |
| trustmark | wmunet + rule emiouT|expected_area | 0.6091 | 0.6168 | 0.6014 |
| trustmark | wmunet + rule emiouT|otsu_in_regime | 0.6088 | 0.6170 | 0.6007 |
| trustmark | wmunet + rule emiouT|regressed_area | 0.5867 | 0.6159 | 0.5574 |
| trustmark | wmunet + ORACLE per-image threshold (upper bound) | 0.6365 | 0.6453 | 0.6277 |
| trustmark | wmunet + CV-selected rule (whole-train choice: emiou_none) | 0.6069 | 0.6150 | 0.5987 |
| trustmark | **v2 pipeline**: wmunet + emiou_none + post T:close_holes5 / F:largest | **0.6075** | 0.6109 | 0.6041 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6106 | 0.6160 | 0.6053 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6427 | 0.6160 | 0.6694 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6687 | 0.6160 | 0.7214 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6758 | 0.6160 | 0.7355 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6788 | 0.6160 | 0.7416 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6788 | 0.6160 | 0.7416 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6788 | 0.6160 | 0.7416 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6687** | 0.6160 | 0.7214 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | source wamn | 0.5959 | 0.6154 | 0.5765 |
| stegastamp | source wamd | 0.6027 | 0.6306 | 0.5749 |
| stegastamp | fusion top2 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack'] | 0.7072 | 0.7546 | 0.6598 |
| stegastamp | fusion top3 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack'] | 0.7050 | 0.7542 | 0.6557 |
| stegastamp | fusion all ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wamd', 'wmunetH', 'wamn', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7329 | 0.7889 | 0.6769 |
| stegastamp | fusion all + rule switch | 0.7329 | 0.7889 | 0.6769 |
| stegastamp | fusion all + rule expected_area | 0.7341 | 0.7773 | 0.6909 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7402 | 0.7945 | 0.6859 |
| stegastamp | fusion all + rule regressed_area | 0.7173 | 0.7512 | 0.6834 |
| stegastamp | fusion all + rule emiou_none | 0.7484 | 0.7922 | 0.7045 |
| stegastamp | fusion all + rule emiouT|switch | 0.7330 | 0.7899 | 0.6760 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7418 | 0.7922 | 0.6914 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7388 | 0.7920 | 0.6856 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7382 | 0.7925 | 0.6839 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7567 | 0.7913 | 0.7221 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7484 | 0.7922 | 0.7045 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<16 | **0.7470** | 0.7920 | 0.7020 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7492 | 0.7934 | 0.7050 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7078 | 0.7875 | 0.6281 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7488 | 0.7875 | 0.7102 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7568 | 0.7875 | 0.7260 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7605 | 0.7875 | 0.7335 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7634 | 0.7934 | 0.7335 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7634 | 0.7934 | 0.7335 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7605** | 0.7875 | 0.7335 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wamd2",
   "wamn2",
   "wamn",
   "wamd",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.6536,
  "cv_T": 0.6339,
  "cv_F": 0.6733,
  "test_frac_pred_1": 0.491
 },
 "trustmark": {
  "map": "wmunet",
  "sources": null,
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6687,
  "cv_T": 0.616,
  "cv_F": 0.7214,
  "test_frac_pred_1": 0.5
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wamd",
   "wmunetH",
   "wamn",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<16",
  "rect": "rect>=0.9",
  "cv": 0.7605,
  "cv_T": 0.7875,
  "cv_F": 0.7335,
  "test_frac_pred_1": 0.493
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.6943,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v18_wam.pt",
 "size_MB": 15.96
}
```
