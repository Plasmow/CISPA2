"""Re-marking maps for StegaStamp (the only method where the test showed a signal), CPU only.
x1 = round(x + r0), r_k = embed(x_k, m) - x_k. Per image, 128x128 maps: NCC(hp r0, hp r1) (sigma 16) and
-E(hp(r0 - r1)) / E(hp r0) (sigma 8). A logistic regression per cell on [both maps, g] gives the source map
(train: 5-fold out-of-fold, test: mean of fold models) -> stack/maps/remark_{train,test}_stegastamp.npz."""
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]; HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(TASK / "loc"))
from common import load_split, load_watermark, KIT, CACHE, folds, auc  # noqa: E402
from evalkit import cv_eval  # noqa: E402
from heads import fit_logreg, predict_logreg  # noqa: E402
from residual import residual_float, hp  # noqa: E402
from unet import gaussian_blur  # noqa: E402

_wm = None


def _init():
    global _wm
    torch.set_num_threads(2); _wm = load_watermark("stegastamp", KIT / "models", "cpu")


def maps_one(args):
    img, msg = args; x = np.asarray(img); R = []
    for _ in range(2):
        r = residual_float(_wm, x, msg, "cpu"); R.append(hp(r, 2.0))
        x = np.clip(x.astype(np.float32) + r.permute(1, 2, 0).numpy(), 0, 255).round().astype(np.uint8)
    a, b = R
    ab, aa, bb = ((a * b).sum(0)[None, None], (a * a).sum(0)[None, None], (b * b).sum(0)[None, None])
    m16 = [gaussian_blur(t, 16) for t in (ab, aa, bb)]
    ncc = m16[0] / (m16[1] * m16[2] + 1e-6).sqrt()
    d = a - b; e = gaussian_blur((d * d).sum(0)[None, None], 8) / (gaussian_blur(aa, 8) + 1e-6)
    return np.stack([F.avg_pool2d(ncc, 4)[0, 0].numpy(), -F.avg_pool2d(e, 4)[0, 0].numpy()]).astype(np.float32)


def compute(split):
    path = HERE / "maps" / f"remark_feats_{split}_stegastamp.npz"
    if path.exists():
        z = np.load(path); return z["names"].tolist(), z["maps"]
    ds = load_split(split, ["stegastamp"]); names = [m["image_name"] for m in ds.meta]; t = time.time()
    with Pool(48, initializer=_init) as pool:
        maps = np.stack(pool.map(maps_one, [(ds[i]["image"], ds[i]["message"]) for i in range(len(ds))], chunksize=4))
    print(split, maps.shape, f"{time.time() - t:.0f}s", flush=True)
    np.savez(path, names=np.array(names), maps=maps); return names, maps


def g_of(split, names):
    ds = load_split(split, ["stegastamp"]); meta = {m["image_name"]: m for m in ds.meta}
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item(); lut = dict(zip(gl["stegastamp"]["names"], gl["stegastamp"]["logits"]))
    return np.array([(lut[n] * (np.array([int(c) for c in meta[n]["message"]]) * 2. - 1)).mean() for n in names])


def main():
    n_tr, M = compute("train"); n_te, Mt = compute("test")
    ds = load_split("train", ["stegastamp"]); gt = np.stack([ds.m128[n] for n in n_tr]).astype(bool)
    full = np.array([m["full_watermark"] for m in ds.meta]); g, tg = g_of("train", n_tr), g_of("test", n_te)
    def X(m, gg):
        G = np.broadcast_to((gg / 5)[:, None, None, None], (len(gg), 1, 128, 128))
        return np.concatenate([m, G, m * G], 1).transpose(0, 2, 3, 1)
    Xtr, Xte = X(M, g), X(Mt, tg); N, D = len(n_tr), Xtr.shape[-1]
    oof = np.zeros((N, 128, 128), np.float32); test = np.zeros((len(n_te), 128, 128), np.float32)
    for f in folds(N, 5, 0):
        tr = np.setdiff1d(np.arange(N), f)
        m = fit_logreg(Xtr[tr][:, ::2, ::2].reshape(-1, D), gt[tr][:, ::2, ::2].reshape(-1).astype(np.float32), 1e-3, 200, "cpu")
        oof[f] = predict_logreg(m, Xtr[f].reshape(-1, D), "cpu").reshape(len(f), 128, 128)
        test += predict_logreg(m, Xte.reshape(-1, D), "cpu").reshape(-1, 128, 128) / 5
    s = cv_eval(oof, gt, g, "switch", seed=1)
    print(f"remark source: AUC T={auc(oof[full], gt[full]):.3f} F={auc(oof[~full], gt[~full]):.3f} | "
          f"CV switch mIoU={s.mean():.4f} T={s[full].mean():.4f} F={s[~full].mean():.4f}", flush=True)
    np.savez(HERE / "maps" / "remark_train_stegastamp.npz", names=np.array(n_tr), logit128=oof.astype(np.float16))
    np.savez(HERE / "maps" / "remark_test_stegastamp.npz", names=np.array(n_te), logit128=test.astype(np.float16))


if __name__ == "__main__":
    main()
