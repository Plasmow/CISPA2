#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:00:00
#SBATCH --job-name=wm_rect_seeded
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/rect_seeded_%j.out
# dc-gpu-devel: 12 nodes OUTSIDE the cispahack reservation, account training2666 allowed, QoS part_dc_gpu_devel (2 h max).
# Submit from the team folder; after start check:  scontrol show job <id> | grep Reservation   (must be empty)
#
# Map-seeded rectangle search (stack/rect_seeded.py): the fused heatmap proposes rectangles, the decoder refines them.
# StegaStamp first (blind search found 3/43 train rectangles, never run on test), then TrustMark. Writes stack/maps/rect2_*.npz.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }
run() {  # gpu split shard
  CUDA_VISIBLE_DEVICES=$1 $PY rect_seeded.py stegastamp $2 $3 2 2>&1 | tagged gpu$1
  CUDA_VISIBLE_DEVICES=$1 $PY rect_seeded.py trustmark  $2 $3 2 2>&1 | tagged gpu$1
}
run 0 train 0 & run 1 train 1 & run 2 test 0 & run 3 test 1 &
wait
echo done
