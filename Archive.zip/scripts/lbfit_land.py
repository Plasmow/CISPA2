"""RMSE landscape over gold (mu, sigma) and retain c for a few hypotheses."""
import sys
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "scripts")
from lbfit_lib import *

subs = load_subs()
orig = torch.load(LB / "orig.pt"); y = orig["clean"].float().argmax(1); N = len(y)
Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
score = np.array([s["score"] for s in subs]); PK = np.array([s["pkl"] for s in subs])
LS = {k: {v: loss_stats_from_logits(Z[k][v], y) for v in ("clean", "mild")} for k in Z}
LSo = {v: loss_stats_from_logits(orig[v], y) for v in ("clean", "mild")}
lq = lambda z: F.log_softmax(z.float() / T, -1)
LQ = {k: {v: lq(Z[k][v]) for v in ("clean", "mild")} for k in Z}; LQo = {v: lq(orig[v]) for v in ("clean", "mild")}
tw = load_twins("0.625")
g625 = F.softmax(tw / T, -1).mean(1)
z = orig["clean"].float().clone(); z[torch.arange(N), y] = -1e4
tail = F.softmax(z / T, -1)
Hs = {"tw0.625": g625, "origtail_P0.3": tail * 0.7 + F.one_hot(y, 100) * 0.3,
      "blend": 0.5 * g625 + 0.5 * (tail * 0.7 + F.one_hot(y, 100) * 0.3)}
for name, g in Hs.items():
    ps = np.array([np.mean([1 - np.clip(kl_mean(g, LQ[s['key']][v]) / kl_mean(g, LQo[v]), 0, 1) for v in ("clean", "mild")]) for s in subs])
    print(f"\n== {name}: denominators clean {kl_mean(g, LQo['clean']):.3f} mild {kl_mean(g, LQo['mild']):.3f}")
    grid = {}
    for mu in np.arange(1, 8.01, 0.5):
        for sd in np.arange(2, 16.01, 1):
            l = np.array([np.mean([lds(*LS[s['key']][v], *LSo[v], mu, sd) for v in ("clean", "mild")]) for s in subs])
            for c in (0, 0.5, 1, 2):
                pred = l * ps / (1 + c * PK)
                grid[(mu, sd, c)] = np.sqrt(((pred - score) ** 2).mean())
    best = sorted(grid.items(), key=lambda t: t[1])[:12]
    for (mu, sd, c), r in best:
        print(f"  mu {mu:.1f} sd {sd:.0f} c {c}: rmse {r:.4f}")
    # best rmse per mu (min over sd, c)
    print("  per-mu best:", " ".join(f"{mu:.1f}:{min(r for (m, s, c), r in grid.items() if m == mu):.4f}" for mu in np.arange(1, 8.01, 1)))
    print("  per-sd best:", " ".join(f"{sd:.0f}:{min(r for (m, s, c), r in grid.items() if s == sd):.4f}" for sd in np.arange(2, 16.01, 2)))
    print("  per-c best:", " ".join(f"{c}:{min(r for (m, s, cc), r in grid.items() if cc == c):.4f}" for c in (0, 0.5, 1, 2)))
