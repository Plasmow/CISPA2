| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wmunet20'] | 0.6125 | 0.6218 | 0.6032 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6151 | 0.6274 | 0.6027 |
| pixelseal | fusion all + rule switch | 0.6151 | 0.6274 | 0.6027 |
| pixelseal | fusion all + rule expected_area | 0.6139 | 0.6299 | 0.5979 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6163 | 0.6284 | 0.6042 |
| pixelseal | fusion all + rule regressed_area | 0.5939 | 0.6102 | 0.5776 |
| pixelseal | fusion all + rule emiou_none | 0.6201 | 0.6330 | 0.6073 |
| pixelseal | fusion all + rule emiouT|switch | 0.6175 | 0.6333 | 0.6018 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6160 | 0.6327 | 0.5993 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6182 | 0.6331 | 0.6033 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6066 | 0.6317 | 0.5816 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6483 | 0.6595 | 0.6371 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6201 | 0.6330 | 0.6073 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:drop<16+box>=0.85 | **0.6176** | 0.6341 | 0.6011 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6213 | 0.6350 | 0.6076 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6363 | 0.6350 | 0.6377 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6493 | 0.6350 | 0.6636 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6509 | 0.6350 | 0.6669 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6525 | 0.6350 | 0.6701 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6417 | 0.6350 | 0.6485 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6383 | 0.6350 | 0.6415 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6525** | 0.6350 | 0.6701 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_r50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6043 | 0.6076 | 0.6010 |
| trustmark | fusion top3 + rule switch | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion top3 + rule expected_area | 0.6132 | 0.6235 | 0.6029 |
| trustmark | fusion top3 + rule otsu_in_regime | 0.6108 | 0.6149 | 0.6067 |
| trustmark | fusion top3 + rule regressed_area | 0.5947 | 0.6109 | 0.5786 |
| trustmark | fusion top3 + rule emiou_none | 0.6181 | 0.6273 | 0.6090 |
| trustmark | fusion top3 + rule emiouT|switch | 0.6170 | 0.6279 | 0.6062 |
| trustmark | fusion top3 + rule emiouT|expected_area | 0.6151 | 0.6269 | 0.6033 |
| trustmark | fusion top3 + rule emiouT|otsu_in_regime | 0.6170 | 0.6275 | 0.6065 |
| trustmark | fusion top3 + rule emiouT|regressed_area | 0.6041 | 0.6257 | 0.5825 |
| trustmark | fusion top3 + ORACLE per-image threshold (upper bound) | 0.6438 | 0.6548 | 0.6329 |
| trustmark | fusion top3 + CV-selected rule (whole-train choice: emiou_none) | 0.6164 | 0.6273 | 0.6055 |
| trustmark | **v2 pipeline**: fusion top3 + emiou_none + post T:close_holes5 / F:largest | **0.6179** | 0.6263 | 0.6094 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6204 | 0.6273 | 0.6135 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6508 | 0.6273 | 0.6743 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6778 | 0.6273 | 0.7283 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6852 | 0.6273 | 0.7430 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6883 | 0.6273 | 0.7492 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6778** | 0.6273 | 0.7283 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | fusion top2 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack'] | 0.7072 | 0.7546 | 0.6598 |
| stegastamp | fusion top3 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack'] | 0.7050 | 0.7542 | 0.6557 |
| stegastamp | fusion all ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7332 | 0.7894 | 0.6770 |
| stegastamp | fusion all + rule switch | 0.7332 | 0.7894 | 0.6770 |
| stegastamp | fusion all + rule expected_area | 0.7328 | 0.7748 | 0.6908 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7409 | 0.7951 | 0.6867 |
| stegastamp | fusion all + rule regressed_area | 0.7169 | 0.7490 | 0.6848 |
| stegastamp | fusion all + rule emiou_none | 0.7468 | 0.7897 | 0.7040 |
| stegastamp | fusion all + rule emiouT|switch | 0.7317 | 0.7874 | 0.6761 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7405 | 0.7897 | 0.6913 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7379 | 0.7894 | 0.6864 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7376 | 0.7899 | 0.6853 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7568 | 0.7912 | 0.7225 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7468 | 0.7897 | 0.7040 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<16 | **0.7468** | 0.7915 | 0.7020 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7483 | 0.7915 | 0.7051 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7068 | 0.7856 | 0.6280 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7478 | 0.7856 | 0.7100 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7557 | 0.7856 | 0.7259 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7594 | 0.7856 | 0.7333 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7624 | 0.7915 | 0.7333 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7624 | 0.7915 | 0.7333 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7594** | 0.7856 | 0.7333 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "drop<16+box>=0.85",
  "rect": "rect>=0.85",
  "cv": 0.6525,
  "cv_T": 0.635,
  "cv_F": 0.6701,
  "test_frac_pred_1": 0.494
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6778,
  "cv_T": 0.6273,
  "cv_F": 0.7283,
  "test_frac_pred_1": 0.497
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<16",
  "rect": "rect>=0.9",
  "cv": 0.7594,
  "cv_T": 0.7856,
  "cv_F": 0.7333,
  "test_frac_pred_1": 0.493
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.6966,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v12a.pt",
 "size_MB": 15.96
}
```
