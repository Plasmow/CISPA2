
**pixelseal** : 25 images F-seg, dont 24 avec au moins un bon segment (IoU > 0.7). Règle actuelle (top-1) : 0.7998 ; masque v9 OOF : 0.6731 ; oracle segment : 0.9664

| score | AUC intra-image | rang médian du meilleur segment | mIoU du top-1 |
|---|---|---|---|
| conf_gray | 0.552 | 36 / 118 | 0.5045 |
| acc_gray | 0.512 | 57 / 118 | 0.5403 |
| conf0_gray | 0.552 | 36 / 118 | 0.5045 |
| ppin_gray | 0.599 | 42 / 118 | 0.5548 |
| ppdiff_gray | 0.604 | 24 / 118 | 0.5334 |
| ppin0_gray | 0.599 | 42 / 118 | 0.5548 |
| conf_blur | 0.484 | 48 / 118 | 0.5316 |
| acc_blur | 0.676 | 15 / 118 | 0.5595 |
| conf0_blur | 0.484 | 48 / 118 | 0.5316 |
| ppin_blur | 0.555 | 52 / 118 | 0.5911 |
| ppdiff_blur | 0.569 | 45 / 118 | 0.5809 |
| ppin0_blur | 0.555 | 52 / 118 | 0.5911 |
| conf_mean | 0.565 | 30 / 118 | 0.5205 |
| acc_mean | 0.511 | 51 / 118 | 0.4806 |
| conf0_mean | 0.565 | 30 / 118 | 0.5205 |
| ppin_mean | 0.571 | 47 / 118 | 0.5088 |
| ppdiff_mean | 0.572 | 39 / 118 | 0.5137 |
| ppin0_mean | 0.571 | 47 / 118 | 0.5088 |
| area | 0.924 | 8 / 118 | 0.2876 |

**trustmark** : 25 images F-seg, dont 20 avec au moins un bon segment (IoU > 0.7). Règle actuelle (top-1) : 0.7178 ; masque v9 OOF : 0.6231 ; oracle segment : 0.9045

| score | AUC intra-image | rang médian du meilleur segment | mIoU du top-1 |
|---|---|---|---|
| conf_gray | 0.704 | 4 / 96 | 0.5330 |
| acc_gray | 0.727 | 12 / 96 | 0.5742 |
| conf0_gray | 0.704 | 4 / 96 | 0.5330 |
| ppin_gray | 0.678 | 34 / 96 | 0.5990 |
| ppdiff_gray | 0.674 | 34 / 96 | 0.5940 |
| ppin0_gray | 0.678 | 34 / 96 | 0.5990 |
| conf_blur | 0.562 | 36 / 96 | 0.5531 |
| acc_blur | 0.500 | 55 / 96 | 0.5116 |
| conf0_blur | 0.562 | 36 / 96 | 0.5531 |
| ppin_blur | 0.662 | 25 / 96 | 0.5438 |
| ppdiff_blur | 0.653 | 28 / 96 | 0.5091 |
| ppin0_blur | 0.662 | 25 / 96 | 0.5438 |
| conf_mean | 0.704 | 6 / 96 | 0.5335 |
| acc_mean | 0.652 | 15 / 96 | 0.6007 |
| conf0_mean | 0.704 | 6 / 96 | 0.5335 |
| ppin_mean | 0.619 | 38 / 96 | 0.6107 |
| ppdiff_mean | 0.596 | 51 / 96 | 0.5984 |
| ppin0_mean | 0.619 | 38 / 96 | 0.6107 |
| area | 0.828 | 12 / 96 | 0.3900 |

**stegastamp** : 25 images F-seg, dont 22 avec au moins un bon segment (IoU > 0.7). Règle actuelle (top-1) : 0.8410 ; masque v9 OOF : 0.7286 ; oracle segment : 0.9231

| score | AUC intra-image | rang médian du meilleur segment | mIoU du top-1 |
|---|---|---|---|
| conf_gray | 0.843 | 3 / 121 | 0.6363 |
| acc_gray | 0.672 | 22 / 121 | 0.5943 |
| conf0_gray | 0.843 | 3 / 121 | 0.6363 |
| conf_blur | 0.837 | 7 / 121 | 0.6569 |
| acc_blur | 0.669 | 9 / 121 | 0.5105 |
| conf0_blur | 0.837 | 7 / 121 | 0.6569 |
| conf_mean | 0.837 | 2 / 121 | 0.6936 |
| acc_mean | 0.770 | 16 / 121 | 0.5679 |
| conf0_mean | 0.837 | 2 / 121 | 0.6936 |
| area | 0.881 | 10 / 121 | 0.2592 |
