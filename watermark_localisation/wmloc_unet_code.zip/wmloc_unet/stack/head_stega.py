"""First localisation head for StegaStamp (CPU only).

The decoder (ONNX) is: STN -> 7 convs -> dense(21632 -> 512) -> ReLU -> dense(512 -> 100 logits). A copy of the graph
exposing conv5 (64x50x50), conv6 (128x25x25) and conv7 (128x13x13) is in stack/stega_feats.onnx.

  1. feature-space occlusion (exact, no gradient): hidden_pre = sum_p c_p + b with c_p = conv7[p] . W_dense[p];
     for each of the 13x13 positions, remove c_p, recompute the logits, and take the drop of the signed confidence.
  2. logistic heads per position on conv layers brought to one grid (+ occlusion map, g, position), 5-fold CV.
Best map -> stack/maps/headmulti_{train,test}_stegastamp.npz (train out-of-fold, test = mean of fold heads).
"""
import sys
import time
from pathlib import Path

import numpy as np
import onnx
import onnxruntime as ort
import torch
import torch.nn.functional as F
from onnx import numpy_helper

LOC = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
sys.path.insert(0, str(LOC))
from common import load_split, CACHE, folds, auc  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels, pos_feats, fit_logreg, predict_logreg  # noqa: E402
from head_multi import to_grid  # noqa: E402

HERE = Path(__file__).resolve().parent; MODEL = HERE / "stega_feats.onnx"
OUTS = ["gen_decoder/dec_conv_5/Relu:0", "gen_decoder/dec_conv_6/Relu:0", "gen_decoder/dec_conv_7/Relu:0", "gen_decoder/decoder_out/BiasAdd:0"]
torch.set_num_threads(32)


def dense_weights():
    m = onnx.load(str(MODEL)); init = {i.name: numpy_helper.to_array(i) for i in m.graph.initializer}
    def mm(prefix):
        n = [n for n in m.graph.node if n.op_type == "MatMul" and n.name.startswith(prefix)][0]
        W = next(init[i] for i in n.input if i in init)
        add = [a for a in m.graph.node if a.op_type == "Add" and n.output[0] in a.input][0]
        return W, next(init[i] for i in add.input if i in init)
    return mm("gen_decoder/dec_dense"), mm("gen_decoder/decoder_out")


def extract(split):
    path = HERE / "maps" / f"stega_feats_{split}.npz"
    if path.exists():
        return dict(np.load(path))
    ds = load_split(split, ["stegastamp"]); names = [m["image_name"] for m in ds.meta]
    so = ort.SessionOptions(); so.intra_op_num_threads = 32
    sess = ort.InferenceSession(str(MODEL), so, providers=["CPUExecutionProvider"])
    (W1, b1), (W2, b2) = dense_weights()
    msg = np.array([[int(c) for c in m["message"]] for m in ds.meta], np.float32) * 2 - 1
    c5, c6, c7, occ, lg = [], [], [], [], []; t = time.time()
    for b in range(0, len(names), 16):
        x = torch.stack([torch.from_numpy(np.array(ds[i]["image"])).permute(2, 0, 1).float() / 255 for i in range(b, min(b + 16, len(names)))])
        x = F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)   # = wrapper _prep
        r = sess.run(OUTS, {"image": x.permute(0, 2, 3, 1).numpy(), "secret": np.zeros((len(x), 100), np.float32)})
        f7 = r[2]                                                            # [B,128,13,13]
        contrib = np.einsum("bchw,hwcj->bhwj", f7, W1.reshape(13, 13, 128, -1))   # flatten order is NHWC
        pre = contrib.sum((1, 2)) + b1                                       # [B,512]
        sg = msg[b:b + len(x)]
        base = ((np.maximum(pre, 0) @ W2 + b2) * sg).mean(1)
        drop = base[:, None, None] - ((np.maximum(pre[:, None, None] - contrib, 0) @ W2 + b2) * sg[:, None, None]).mean(-1)
        c5.append(r[0].astype(np.float16)); c6.append(r[1].astype(np.float16)); c7.append(f7.astype(np.float16)); occ.append(drop.astype(np.float32)); lg.append(r[3])
        if b % 160 == 0:
            print(split, b, f"{time.time() - t:.0f}s | logits check vs dense recompute: "
                  f"{np.abs((np.maximum(pre, 0) @ W2 + b2) - r[3]).max():.2e}", flush=True)
    d = dict(names=np.array(names), c5=np.concatenate(c5), c6=np.concatenate(c6), c7=np.concatenate(c7), occ=np.concatenate(occ), logits=np.concatenate(lg))
    np.savez(path, **d); return d


def g_of(split, names, ds):
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item(); lut = dict(zip(gl["stegastamp"]["names"], gl["stegastamp"]["logits"]))
    meta = {m["image_name"]: m for m in ds.meta}
    return np.array([(lut[n] * (np.array([int(c) for c in meta[n]["message"]]) * 2. - 1)).mean() for n in names])


def main():
    (HERE / "maps").mkdir(exist_ok=True); lines = []
    dtr, dte = extract("train"), extract("test")
    ds = load_split("train", ["stegastamp"]); dst = load_split("test", ["stegastamp"])
    names, tnames = dtr["names"].tolist(), dte["names"].tolist(); N = len(names)
    g, tg = g_of("train", names, ds), g_of("test", tnames, dst)
    gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([m["full_watermark"] for m in ds.meta])
    occ128 = to128(dtr["occ"])
    a = [auc(occ128[full], gt[full]), auc(occ128[~full], gt[~full])]; s = cv_eval(occ128, gt, g, "switch", seed=1)
    lines.append(f"| feature-space occlusion 13x13 | 1 | - | AUC T={a[0]:.3f} F={a[1]:.3f} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |"); print(lines[-1], flush=True)
    best = (s.mean(), "occlusion", occ128, to128(dte["occ"]))
    L = {"c5": dtr["c5"], "c6": dtr["c6"], "c7": dtr["c7"], "occ": dtr["occ"][:, None]}
    Lt = {"c5": dte["c5"], "c6": dte["c6"], "c7": dte["c7"], "occ": dte["occ"][:, None]}
    def build(LL, keys, hw, gg):
        n = len(gg); parts = [to_grid(LL[k].astype(np.float32), hw) for k in keys]
        parts += [np.broadcast_to(gg[:, None, None, None], (n, 1, hw, hw)).astype(np.float32), pos_feats(n, hw, hw)]
        return np.concatenate(parts, 1).transpose(0, 2, 3, 1).reshape(n, hw * hw, -1)
    for name, hw, keys in (("g25 c6", 25, ["c6"]), ("g25 c6+c7+occ", 25, ["c6", "c7", "occ"]),
                           ("g25 c5+c6+c7+occ", 25, ["c5", "c6", "c7", "occ"]), ("g13 c6+c7+occ", 13, ["c6", "c7", "occ"])):
        X = build(L, keys, hw, g); Y = soft_labels(gt, (hw, hw)).reshape(N, -1); D = X.shape[-1]
        for wd in (1e-3, 1e-2, 1e-1):
            oof = np.zeros((N, hw * hw), np.float32); models = []
            for f in folds(N, 5, 0):
                tr = np.setdiff1d(np.arange(N), f)
                m = fit_logreg(X[tr].reshape(-1, D), Y[tr].reshape(-1), wd, iters=200, dev="cpu"); models.append(m)
                oof[f] = predict_logreg(m, X[f].reshape(-1, D), dev="cpu").reshape(len(f), -1)
            o128 = to128(oof.reshape(N, hw, hw)); a = [auc(o128[full], gt[full]), auc(o128[~full], gt[~full])]
            s = cv_eval(o128, gt, g, "switch", seed=1)
            lines.append(f"| head {name} | {D} | {wd:g} | AUC T={a[0]:.3f} F={a[1]:.3f} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |"); print(lines[-1], flush=True)
            if s.mean() > best[0]:
                Xt = build(Lt, keys, hw, tg)
                t = np.mean([predict_logreg(mm, Xt.reshape(-1, D), dev="cpu").reshape(len(tnames), hw, hw) for mm in models], 0)
                best = (s.mean(), f"head {name} wd={wd:g}", o128, to128(t))
    sc, name, o128, t128 = best
    np.savez(HERE / "maps" / "headmulti_train_stegastamp.npz", names=np.array(names), logit128=o128.astype(np.float16))
    np.savez(HERE / "maps" / "headmulti_test_stegastamp.npz", names=np.array(tnames), logit128=t128.astype(np.float16))
    lines.append(f"| **best: {name}** | | | | **{sc:.4f}** | | |"); print(lines[-1], flush=True)
    hdr = ["| StegaStamp map | dims | L2 | AUC within type | mIoU (CV switch) | type T | type F |", "|---|---|---|---|---|---|---|"]
    (HERE.parent / "results_head_stega.md").write_text("\n".join(hdr + lines) + "\n")


if __name__ == "__main__":
    main()
