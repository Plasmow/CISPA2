| method | expected-mIoU choice | **learned selector (CV)** | type T | type F | oracle | most chosen |
|---|---|---|---|---|---|---|
| pixelseal | 0.6176 | **0.6510** | 0.6281 | 0.6739 | 0.6806 | [('largest+fill', 31), ('largest', 25), ('drop<16', 17), ('raw', 17), ('box', 16), ('open3', 16)] |
| trustmark | 0.6148 | **0.6798** | 0.6231 | 0.7364 | 0.7055 | [('largest+fill', 26), ('box', 21), ('largest', 21), ('drop<16', 20), ('fill', 16), ('open3', 16)] |
| stegastamp | 0.7094 | **0.7075** | 0.7469 | 0.6681 | 0.7409 | [('largest+fill', 29), ('close3+fill', 24), ('fill', 23), ('raw', 21), ('drop<16', 17), ('largest', 16)] |

```json
{
 "pixelseal": {
  "cv": 0.651,
  "cv_T": 0.6281,
  "cv_F": 0.6739,
  "expected_miou_choice": 0.6176,
  "oracle": 0.6806,
  "test_frac_pred_1": 0.491
 },
 "trustmark": {
  "cv": 0.6798,
  "cv_T": 0.6231,
  "cv_F": 0.7364,
  "expected_miou_choice": 0.6148,
  "oracle": 0.7055,
  "test_frac_pred_1": 0.498
 },
 "stegastamp": {
  "cv": 0.7075,
  "cv_T": 0.7469,
  "cv_F": 0.6681,
  "expected_miou_choice": 0.7094,
  "oracle": 0.7409,
  "test_frac_pred_1": 0.492
 },
 "expected_cv_mIoU": 0.6794,
 "size_MB": 15.96
}
```
