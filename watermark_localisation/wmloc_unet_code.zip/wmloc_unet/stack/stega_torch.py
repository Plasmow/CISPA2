"""StegaStamp decoder re-implemented in PyTorch (differentiable), weights read from the official ONNX export.

Graph (from stega_stamp_logits.onnx):
  STN  : (image - 0.5) -> 3 x [conv3x3 s2, TF 'SAME' pads (0,0,1,1)] + ReLU -> flatten NHWC (50*50*128) -> dense 128 + ReLU
         -> dense 6 = affine theta (2x3) -> TF-style bilinear sampling of the [0,1] image on the constant grid of the
         graph (x = (x_s + 1) * W / 2, floor, indices clipped to [0, W-1], weights from the clipped indices)
  decoder: (warped - 0.5) -> 7 convs (strides 2,1,2,1,2,2,2; TF pads) + ReLU -> flatten NHWC (13*13*128) -> dense 512
         + ReLU -> dense 100 = logits
Input: images [B,3,400,400] in [0,1] (the official wrapper resizes 512 -> 400 bicubic, antialias, clamp).
"""
from pathlib import Path

import numpy as np
import onnx
import torch
import torch.nn as nn
import torch.nn.functional as F
from onnx import numpy_helper

ONNX = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/starter_kit/models/stegastamp/stega_stamp_logits.onnx")
DEC_STRIDES = [2, 1, 2, 1, 2, 2, 2]
DEC_PADS = [(0, 0, 1, 1), (1, 1, 1, 1), (0, 0, 1, 1), (1, 1, 1, 1), (0, 0, 1, 1), (0, 0, 1, 1), (1, 1, 1, 1)]   # top, left, bottom, right


def _load():
    m = onnx.load(str(ONNX)); init = {i.name: numpy_helper.to_array(i) for i in m.graph.initializer}
    nodes = {n.name: n for n in m.graph.node}
    def conv(name):
        n = nodes[name]; return init[n.input[1]], init[n.input[2]]
    def dense(mm_name, add_name):
        w = next(init[i] for i in nodes[mm_name].input if i in init); b = next(init[i] for i in nodes[add_name].input if i in init)
        return w, b
    W = {f"stn_conv_{k}": conv(f"gen_stn/stn_conv_{k}/BiasAdd") for k in (1, 2, 3)}
    W.update({f"dec_conv_{k}": conv(f"gen_decoder/dec_conv_{k}/BiasAdd") for k in range(1, 8)})
    W["stn_dense"] = dense("gen_stn/dense_1/MatMul", "gen_stn/dense_1/BiasAdd")
    W["stn_fc"] = dense("gen_stn/MatMul", "gen_stn/add")
    W["dec_dense"] = dense("gen_decoder/dec_dense/MatMul", "gen_decoder/dec_dense/BiasAdd")
    W["dec_out"] = dense("gen_decoder/decoder_out/MatMul", "gen_decoder/decoder_out/BiasAdd")
    W["grid"] = init["gen_stn/ExpandDims__52"]                       # [1, 3, 160000]: (x_t, y_t, 1) on a 400x400 grid
    return W


def tf_conv(x, conv, stride, pads):
    t, l, b, r = pads
    return F.conv2d(F.pad(x, (l, r, t, b)), conv.weight, conv.bias, stride=stride)


class StegaDecoder(nn.Module):
    def __init__(self):
        super().__init__()
        W = _load()
        def mk_conv(w, b):
            c = nn.Conv2d(w.shape[1], w.shape[0], 3, bias=True); c.weight.data = torch.from_numpy(w.copy()); c.bias.data = torch.from_numpy(b.copy()); return c
        def mk_lin(w, b):
            l = nn.Linear(w.shape[0], w.shape[1]); l.weight.data = torch.from_numpy(w.T.copy()); l.bias.data = torch.from_numpy(b.copy()); return l
        self.stn_convs = nn.ModuleList([mk_conv(*W[f"stn_conv_{k}"]) for k in (1, 2, 3)])
        self.stn_dense = mk_lin(*W["stn_dense"]); self.stn_fc = mk_lin(*W["stn_fc"])
        self.dec_convs = nn.ModuleList([mk_conv(*W[f"dec_conv_{k}"]) for k in range(1, 8)])
        self.dec_dense = mk_lin(*W["dec_dense"]); self.dec_out = mk_lin(*W["dec_out"])
        self.register_buffer("grid", torch.from_numpy(W["grid"].copy()))

    def theta(self, x):
        h = x - 0.5
        for c in self.stn_convs:
            h = F.relu(tf_conv(h, c, 2, (0, 0, 1, 1)))
        return self.stn_fc(F.relu(self.stn_dense(h.permute(0, 2, 3, 1).reshape(len(x), -1)))).view(-1, 2, 3)

    def warp(self, x, th):
        """TF spatial-transformer bilinear sampling (exact replica of the graph)."""
        B, C, H, Wd = x.shape
        Tg = th @ self.grid.expand(B, -1, -1)                          # [B, 2, H*W]
        xx = (Tg[:, 0] + 1) * 0.5 * (Wd - 2); yy = (Tg[:, 1] + 1) * 0.5 * (H - 2)   # the graph scales by 398 (= W - 2), not 400
        x0 = torch.floor(xx); y0 = torch.floor(yy)
        x0c, x1c = x0.clamp(0, Wd - 1), (x0 + 1).clamp(0, Wd - 1); y0c, y1c = y0.clamp(0, H - 1), (y0 + 1).clamp(0, H - 1)
        flat = x.reshape(B, C, H * Wd)
        def gather(yc, xc):
            idx = (yc * Wd + xc).long()[:, None, :].expand(B, C, -1); return torch.gather(flat, 2, idx)
        wa = ((x1c - xx) * (y1c - yy))[:, None]; wb = ((x1c - xx) * (yy - y0c))[:, None]
        wc = ((xx - x0c) * (y1c - yy))[:, None]; wd = ((xx - x0c) * (yy - y0c))[:, None]
        out = wa * gather(y0c, x0c) + wb * gather(y1c, x0c) + wc * gather(y0c, x1c) + wd * gather(y1c, x1c)
        return out.view(B, C, H, Wd)

    def features(self, x):
        """x [B,3,400,400] in [0,1] -> (list of the 7 conv outputs, theta)."""
        th = self.theta(x); h = self.warp(x, th) - 0.5; outs = []
        for c, s, p in zip(self.dec_convs, DEC_STRIDES, DEC_PADS):
            h = F.relu(tf_conv(h, c, s, p)); outs.append(h)
        return outs, th

    def head(self, f7):
        """f7 [B,128,13,13] -> (logits [B,100], per-position contributions to the dense pre-activation [B,13,13,512])."""
        flat = f7.permute(0, 2, 3, 1)                                   # NHWC
        contrib = torch.einsum("bhwc,hwcj->bhwj", flat, self.dec_dense.weight.T.reshape(13, 13, 128, -1))
        pre = contrib.sum((1, 2)) + self.dec_dense.bias
        return self.dec_out(F.relu(pre)), contrib, pre

    def forward(self, x):
        outs, _ = self.features(x)
        return self.head(outs[-1])[0]


if __name__ == "__main__":
    import sys
    import onnxruntime as ort
    sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
    from common import load_split
    torch.backends.cudnn.allow_tf32 = False; torch.backends.cuda.matmul.allow_tf32 = False
    ds = load_split("train", ["stegastamp"]); idx = list(range(0, 170, 11))
    xs = torch.stack([torch.from_numpy(np.array(ds[i]["image"])).permute(2, 0, 1).float() / 255 for i in idx])
    x = F.interpolate(xs, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
    sess = ort.InferenceSession(str(ONNX), providers=["CPUExecutionProvider"])
    ref = sess.run(["gen_decoder/decoder_out/BiasAdd:0"], {"image": x.permute(0, 2, 3, 1).numpy(), "secret": np.zeros((len(x), 100), np.float32)})[0]
    dec = StegaDecoder().eval()
    with torch.no_grad():
        out = dec(x).numpy()
    msgs = np.stack([ds[i]["message"] for i in idx]).astype(bool)
    print("max |torch - onnx| logits:", float(np.abs(out - ref).max()), "| mean:", float(np.abs(out - ref).mean()))
    print("bit acc onnx :", ((ref > 0) == msgs).mean(1).round(3))
    print("bit acc torch:", ((out > 0) == msgs).mean(1).round(3))
