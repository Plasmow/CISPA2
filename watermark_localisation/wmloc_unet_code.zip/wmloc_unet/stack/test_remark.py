"""Go / no-go test of the 're-mark 1x / 2x / 3x' idea (CPU only, 40 train images per method: 20 type T + 20 type F).

x0 = image, x1 = round(x0 + r0), x2 = round(x1 + r1) with r_k = embed(x_k, m) - x_k (float residual, known message m).
Hypothesis: where x0 already carries the watermark, the embedder 'sees' it and r0 ~ r1 (marking twice changes little);
where x0 is clean, r0 (clean input) and r1 (watermarked input) differ more.
Local maps (gaussian window sigma, pooled to 128x128): NCC(hp r0, hp r1), NCC(hp r1, hp r2), energy ratios
E(r1)/E(r0), E(r2)/E(r1), and the energy of hp(r0 - r1) relative to E(r0). AUC against the GT inside each type.
"""
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(TASK / "loc"))
from common import load_split, load_watermark, KIT, auc  # noqa: E402
from residual import residual_float, hp  # noqa: E402
from unet import gaussian_blur  # noqa: E402

torch.set_num_threads(32); dev = "cpu"


def local(a, b, s):
    ab = (a * b).sum(0)[None, None]; aa = (a * a).sum(0)[None, None]; bb = (b * b).sum(0)[None, None]
    m = [gaussian_blur(t, s) for t in (ab, aa, bb)]
    return m[0] / (m[1] * m[2] + 1e-6).sqrt(), m[1], m[2]


def pool(t):
    return F.avg_pool2d(t, 4)[0, 0].numpy()


def main():
    ds = load_split("train"); rng = np.random.RandomState(0)
    for meth in ("pixelseal", "trustmark", "stegastamp"):
        wm = load_watermark(meth, KIT / "models", dev)
        it_t = [i for i, m in enumerate(ds.meta) if m["method"] == meth and m["full_watermark"]]
        it_f = [i for i, m in enumerate(ds.meta) if m["method"] == meth and not m["full_watermark"]]
        M, G, Fl = {}, [], []; t = time.time()
        for i in list(rng.permutation(it_t)[:20]) + list(rng.permutation(it_f)[:20]):
            it = ds[i]; x = np.asarray(it["image"]); msg = it["message"]; R = []
            for _ in range(3):
                r = residual_float(wm, x, msg, dev); R.append(r)
                x = np.clip(x.astype(np.float32) + r.permute(1, 2, 0).numpy(), 0, 255).round().astype(np.uint8)
            h = [hp(r, 2.0) for r in R]
            for s in (8, 16):
                n01, e0, e1 = local(h[0], h[1], s); n12, _, e2 = local(h[1], h[2], s)
                d = h[0] - h[1]; ed = gaussian_blur((d * d).sum(0)[None, None], s)
                for k, v in ((f"ncc(r0,r1)_s{s}", n01), (f"ncc(r1,r2)_s{s}", n12), (f"E(r1)/E(r0)_s{s}", e1 / (e0 + 1e-6)),
                             (f"E(r2)/E(r1)_s{s}", e2 / (e1 + 1e-6)), (f"E(r0-r1)/E(r0)_s{s}", ed / (e0 + 1e-6))):
                    M.setdefault(k, []).append(pool(v))
            G.append(it["mask128"]); Fl.append(it["full_watermark"])
        G = np.stack(G).astype(bool); Fl = np.array(Fl)
        print(f"\n{meth}: {(time.time() - t) / len(G):.1f}s/img (3 embeds, CPU)", flush=True)
        for k, v in M.items():
            v = np.stack(v)
            print(f"  {k:22s} AUC type T={auc(v[Fl], G[Fl]):.3f}  type F={auc(v[~Fl], G[~Fl]):.3f} | "
                  f"mean in GT={v[G].mean():.3f} out={v[~G].mean():.3f}", flush=True)


if __name__ == "__main__":
    main()
