"""Minimal stand-in for the cluster's loc/common.py: only what evalkit.py needs (no watermark models)."""
import numpy as np


def folds(n, k=5, seed=0):
    idx = np.random.RandomState(seed).permutation(n)
    return [np.sort(idx[i::k]) for i in range(k)]
