#!/bin/bash
# JiT sweep 1 (scripts/jit.py): perturbation size, output space, lr, aug-neighbourhood, optional proxy KD. 2 runs/GPU.
P=".venv/bin/python scripts/jit.py --epochs 2 --eval_every 50"
run() { $P --run "$1" "${@:2}" > "output/$1.log" 2>&1; }
(export CUDA_VISIBLE_DEVICES=0
 run jit1_n0.1_lr5e-5        --sigma 0.1 --lr 5e-5
 run jit1_n0.2_lr5e-5        --sigma 0.2 --lr 5e-5) &
(export CUDA_VISIBLE_DEVICES=1
 run jit1_n0.3_lr5e-5        --sigma 0.3 --lr 5e-5
 run jit1_n0.2_lr1e-5        --sigma 0.2 --lr 1e-5) &
(export CUDA_VISIBLE_DEVICES=2
 run jit1_n0.2_lr5e-5_probs  --sigma 0.2 --lr 5e-5 --space probs
 run jit1_aug_lr5e-5         --pert aug --lr 5e-5) &
(export CUDA_VISIBLE_DEVICES=3
 run jit1_aug_lr5e-5_probs   --pert aug --lr 5e-5 --space probs
 run jit1_n0.2_lr5e-5_kd0.3  --sigma 0.2 --lr 5e-5 --alpha 0.3 --bs_r 32) &
wait
