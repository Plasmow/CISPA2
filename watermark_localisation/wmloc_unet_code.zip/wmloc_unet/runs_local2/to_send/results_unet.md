Baselines (CV): whole-image score threshold = 0.4512 | regime oracle = 0.4547

| variant | mIoU@0.5 | pixelseal | trustmark | stegastamp | full=T | full=F | CV thr/method | CV switch/method |
|---|---|---|---|---|---|---|---|---|
| effb3_hp_glob_stack | **0.5528** | 0.5042 | 0.4997 | 0.6544 | 0.5666 | 0.5390 | 0.5550 | 0.5560 |
| effv2s_hp_glob_stack | **0.5618** | 0.5055 | 0.4955 | 0.6845 | 0.5771 | 0.5465 | 0.5625 | 0.5618 |
| r50_hp_glob_stack | **0.5359** | 0.5013 | 0.4917 | 0.6147 | 0.5366 | 0.5353 | 0.5346 | 0.5462 |
| regy032_hp_glob_stack | **0.5612** | 0.5005 | 0.5007 | 0.6825 | 0.5702 | 0.5522 | 0.5630 | 0.5643 |
| ensemble | **0.5707** | 0.5058 | 0.5057 | 0.7007 | 0.5798 | 0.5617 | 0.5693 | 0.5789 |
