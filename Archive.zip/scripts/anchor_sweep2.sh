#!/bin/bash
# Sweep 2: push along what worked in anchor_sweep.sh (tail weighting + longer/stronger fit + more exact-image steps).
# Best so far: an_tail1_e20_lr2e-4 @810 -> 1.61±2.09, KL->target 0.26, out KL 0.18 (target 2.0±3.0, maxp ~0.77);
#              an_tail1_cf0.8_e20 @1080 -> 1.43±1.84, out KL 0.11.
# Anchors: Task-1 images with maxp>0.9 + s0.875 twins. Saves every 108 steps, keeps the last 3 checkpoints per run.
# Run: sbatch --job-name=anchor3 --dependency=afterany:<scrubG id> scripts/run4.sh scripts/anchor_sweep2.sh
T=output/targets/a1_m2_s3_T1.5_w1_tw.pt
TWP="output/twins/s0.875_sh*.npz"  # quoted below so the shell does not expand it
COMMON="--target $T --outside output/outside_task1/images_224.npz --outside_frac 0.5 --outside_minconf 0.9
        --twin_frac 0.5 --eval_every 108 --keep 3"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON --proxy_twins "$TWP" "$@" \
    > output/$name.log 2>&1 & }

# wave 1: stronger fit on the tail
run 0 an2_t1.5_e30_lr2e-4        --tail_w 1.5 --epochs 30 --lr 2e-4 --clean_frac 0.5
run 1 an2_t1_e30_lr3e-4          --tail_w 1   --epochs 30 --lr 3e-4 --clean_frac 0.5
run 2 an2_t1.5_cf0.8_e30_lr2e-4  --tail_w 1.5 --epochs 30 --lr 2e-4 --clean_frac 0.8
run 3 an2_t2_cf0.8_e30_lr3e-4    --tail_w 2   --epochs 30 --lr 3e-4 --clean_frac 0.8
wait

# wave 2: same fit, retain weight up (cuts drift) and target loss level up (student lands below target)
run 0 an2_t1.5_cf0.8_e30_lr2e-4_a2 --tail_w 1.5 --epochs 30 --lr 2e-4 --clean_frac 0.8 --alpha 2
run 1 an2_t1_e30_lr3e-4_a2         --tail_w 1   --epochs 30 --lr 3e-4 --clean_frac 0.5 --alpha 2
run 2 an2_t1.5_e30_lr2e-4_m1.5s3   --tail_w 1.5 --epochs 30 --lr 2e-4 --clean_frac 0.5 \
                                   --target output/targets/a1_m1.5_s3_T1.5_w1_tw.pt
run 3 an2_t1.5_e30_lr2e-4_t625     --tail_w 1.5 --epochs 30 --lr 2e-4 --clean_frac 0.5 \
                                   --target output/targets/a1_m2_s3_T1.5_w1_tw625.pt
wait
