"""WAM-ft: wm-U-Net fine-tuning with a per-cell MESSAGE-DECODING head (ideas from the papers in TASK/paper/).

WAM (Sander et al., "Watermark Anything with Localized Messages", ICLR 2025): the extractor outputs, for every pixel,
1 detection logit + n_bits message logits. Detection loss = pixel-wise BCE; decoding loss = bit-wise BCE ONLY on the
watermarked pixels (their eq. 5), lambda_dec = 10, lambda_det = 1. Trained with a single message, the decoding
"spills" over non-watermarked areas; their 2nd phase (several messages) forces local decoding.
MELB (Bulychev et al., "Where is the Watermark?", 2025): block-level statistical test on local agreement counts
(applied post hoc on CPU to the agreement maps written here, see results_wam.md).

Here (the message is known, also on the test set):
  - the wm-U-Net (stack/wm_unet.py, NOT modified) gets a 1x1 head dhead: 32 -> n_bits on the final decoder features
    (output of up0; for StegaStamp on the STN grid, resampled with the SAME inverse affine as the detection logit);
  - agreement map a = mean_k (2 m_k - 1) * dec_k  (a positive where the known bits are decoded locally);
  - arms (paired: same folds folds(N,5,0), same torch / numpy seeds per fold, same recipe as wm_unet fine-tuning):
      c : control, no decoding head                                    -> tag wamc<suf>
      d : WAM, + lam * BCE(bits) on GT-watermarked cells               -> tags wamd<suf> (det), wamda<suf> (agreement)
      n : WAM + null, + mu * BCE(bits -> 0.5) on GT-clean cells        -> tags wamn<suf> (det), wamna<suf> (agreement)
Outputs: stack/maps/<tag>_{train,test}_<method>.npz (names, logit128 float16; train = out-of-fold, test = fold mean),
logs/wam<suf>_<method>.json.

    python wam_ft.py --method pixelseal --init wmunet --arms n,d,c
    python wam_ft.py --method stegastamp --init wmunetH --enc_lr 3e-5 --arms n,d,c
    python wam_ft.py --method pixelseal --smoke          # CPU shape / loss check, writes nothing
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

W = Path("/p/project1/training2666/debbah2/wmloc_unet")
for p in (W / "stack", W, W / "synth"):
    sys.path.insert(0, str(p))
import wm_unet as WU                                   # noqa: E402  (also puts TASK/loc on sys.path)
from unet import miou_loss                             # noqa: E402
from common import load_watermark, KIT, folds          # noqa: E402
from evalkit import cv_eval                            # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--method", required=True); ap.add_argument("--init", default="wmunet")
ap.add_argument("--arms", default="n,d,c"); ap.add_argument("--suffix", default="")
ap.add_argument("--epochs", type=int, default=15); ap.add_argument("--lr", type=float, default=1e-4)
ap.add_argument("--enc_lr", type=float, default=1e-5); ap.add_argument("--nfolds", type=int, default=5)
ap.add_argument("--lam", type=float, default=10.0); ap.add_argument("--mu", type=float, default=1.0)
ap.add_argument("--smoke", action="store_true")
a = ap.parse_args(); meth = a.method; t0 = time.time()
dev = "cpu" if a.smoke else "cuda"
if a.smoke:
    torch.set_num_threads(8)
torch.backends.cuda.matmul.allow_tf32 = False; torch.backends.cudnn.allow_tf32 = False
MAPS = W / "stack" / "maps"; LOGS = W / "logs"


def build(with_dec, nbits):
    m = WU.StegaUNet().to(dev) if meth == "stegastamp" else WU.WMUNet(meth, load_watermark(meth, KIT / "models", dev)).to(dev)
    m.load_state_dict({k: v.float() for k, v in torch.load(MAPS / f"{a.init}_{meth}_synthetic.pt",
                                                             map_location=dev, weights_only=True).items()})
    if with_dec:
        m.dhead = nn.Conv2d(32, nbits, 1).to(dev)
    return m


def fwd(m, x, sgn):
    """Copy of WMUNet.forward / StegaUNet.forward (wm_unet.py) that also returns the decoding head output."""
    dh = getattr(m, "dhead", None)
    if m.meth == "stegastamp":
        x4 = F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
        outs, th = m.enc.features(x4)
        logits, contrib, pre = m.enc.head(outs[6])
        base = (logits * sgn).mean(1)
        occ = base[:, None, None] - ((F.relu(pre[:, None, None] - contrib) @ m.enc.dec_out.weight.T + m.enc.dec_out.bias) * sgn[:, None, None]).mean(-1)
        g = base[:, None, None, None].expand(-1, 1, 13, 13)
        y = m.bott(torch.cat([outs[6], occ[:, None] / 5, g / 5], 1))
        y = m.up3(y, outs[5]); y = m.up2(y, outs[4]); y = m.up1(y, outs[3]); y = m.up0(y, outs[1])
        w = m.head(y) if dh is None else torch.cat([m.head(y), dh(y)], 1)        # warped frame, 200x200
        A, b = th[:, :, :2], th[:, :, 2:]
        p = torch.linalg.solve(A, (m.cells[None].transpose(1, 2) - b))
        grid = p.transpose(1, 2).reshape(-1, 128, 128, 2)
        o = F.grid_sample(w, grid, mode="bilinear", padding_mode="border", align_corners=True)
    else:
        outs, pp = m.encode(x)
        conf = (pp * sgn[:, :, None, None]).mean(1, keepdim=True)
        g = conf.mean((2, 3), keepdim=True).expand_as(conf)
        y = m.bott(torch.cat([outs[3], conf / 5, g / 5], 1))
        y = m.up3(y, outs[2]); y = m.up2(y, outs[1]); y = m.up1(y, outs[0])
        s = m.stem(torch.cat([x, (x - WU.gaussian_blur(x, 1.5)) * 20], 1))
        f = m.up0(y, s)
        o = m.head(f) if dh is None else torch.cat([m.head(f), dh(f)], 1)
    return o[:, 0], (o[:, 1:] if dh is not None else None)


def loss_fn(det, dec, y, sgn, arm):
    loss = F.binary_cross_entropy_with_logits(det, y) + miou_loss(det, y)
    parts = {}
    if dec is not None:
        tgt = ((sgn + 1) / 2)[:, :, None, None].expand_as(dec)
        bce = F.binary_cross_entropy_with_logits(dec, tgt, reduction="none").mean(1)          # [B,128,128]
        ld = (bce * y).sum() / y.sum().clamp_min(1.0)                                           # WAM eq. 5
        loss = loss + a.lam * ld; parts["dec"] = float(ld)
        if arm == "n":
            nb = F.binary_cross_entropy_with_logits(dec, torch.full_like(dec, 0.5), reduction="none").mean(1)
            cl = 1 - y
            ln = (nb * cl).sum() / cl.sum().clamp_min(1.0)
            loss = loss + a.mu * ln; parts["null"] = float(ln)
    return loss, parts


def make_opt(model):
    enc = [p for n, p in model.named_parameters() if n.startswith("enc.")]
    dec = [p for n, p in model.named_parameters() if not n.startswith("enc.")]
    return torch.optim.AdamW([{"params": dec, "lr": a.lr}, {"params": enc, "lr": a.enc_lr / 2}], weight_decay=1e-4)


@torch.no_grad()
def predict(m, d, idx, bs=16):
    m.eval(); det_o, agr_o = [], []
    for b in range(0, len(idx), bs):
        ii = idx[b:b + bs]
        sgn = d["msgs"][ii].to(dev) * 2 - 1
        det, dec = fwd(m, d["imgs"][ii].to(dev).float() / 255, sgn)
        det_o.append(det.float().cpu())
        if dec is not None:
            agr_o.append((dec * sgn[:, :, None, None]).mean(1).float().cpu())
    m.train()
    return torch.cat(det_o).numpy(), (torch.cat(agr_o).numpy() if agr_o else None)


def score(L, real):
    s = cv_eval(L, real["gt"], real["g"], "switch", seed=1); fl = real["full"]
    return dict(cv_switch=round(float(s.mean()), 4), cv_T=round(float(s[fl].mean()), 4), cv_F=round(float(s[~fl].mean()), 4))


def save(tag, real, test, oof, tmean):
    np.savez(MAPS / f"{tag}_train_{meth}.npz", names=np.array(real["names"]), logit128=oof.astype(np.float16))
    np.savez(MAPS / f"{tag}_test_{meth}.npz", names=np.array(test["names"]), logit128=tmean.astype(np.float16))


real = WU.load_real(meth, "train", nmax=16 if a.smoke else None)
test = WU.load_real(meth, "test", nmax=8 if a.smoke else None)
N = len(real["names"]); NT = len(test["names"]); nbits = real["msgs"].shape[1]
print(f"[{meth}] loaded train {N} test {NT} nbits {nbits} ({time.time() - t0:.0f}s)", flush=True)
log_path = LOGS / f"wam{a.suffix}_{meth}.json"
log = {"args": vars(a), "results": {}}
TAGS = {"c": ("wamc", None), "d": ("wamd", "wamda"), "n": ("wamn", "wamna")}
for arm in a.arms.split(","):
    with_dec = arm in ("d", "n")
    oof = np.zeros((N, 128, 128), np.float32); tmean = np.zeros((NT, 128, 128), np.float32)
    oofa = np.zeros_like(oof) if with_dec else None; tmeana = np.zeros_like(tmean) if with_dec else None
    fl_list = folds(N, a.nfolds, 0)
    for k, f in enumerate(fl_list):
        torch.manual_seed(k); model = build(with_dec, nbits); tr = np.setdiff1d(np.arange(N), f)
        opt = make_opt(model); rng = np.random.RandomState(k); model.train(); run = None
        for ep in range(1 if a.smoke else a.epochs):
            perm = rng.permutation(tr)
            nb = 2 if a.smoke else len(perm)
            for b in range(0, min(len(perm), nb * 8) if a.smoke else len(perm), 8):
                ii = perm[b:b + 8]
                x = real["imgs"][ii].to(dev).float() / 255; y = torch.from_numpy(real["gt"][ii].astype(np.float32)).to(dev)
                sgn = real["msgs"][ii].to(dev) * 2 - 1
                det, dec = fwd(model, x, sgn)
                loss, parts = loss_fn(det, dec, y, sgn, arm)
                opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
                run = loss.item() if run is None else 0.95 * run + 0.05 * loss.item()
                if a.smoke:
                    print(f"[{meth}] smoke arm {arm} det {tuple(det.shape)} dec {None if dec is None else tuple(dec.shape)} "
                          f"loss {loss.item():.4f} {parts}", flush=True)
        L, La = predict(model, real, f); oof[f] = L
        T, Ta = predict(model, test, np.arange(NT)); tmean += T / len(fl_list)
        if with_dec:
            oofa[f] = La; tmeana += Ta / len(fl_list)
        print(f"[{meth}] arm {arm} fold {k} done ({time.time() - t0:.0f}s) run-loss {run:.4f} {parts if with_dec else ''}", flush=True)
        del model, opt
        if dev == "cuda":
            torch.cuda.empty_cache()
        if a.smoke:
            print(f"[{meth}] smoke predict: oof {L.shape} {np.isfinite(L).all()} test {T.shape} agr {None if La is None else La.shape}", flush=True)
            break
    if a.smoke:
        continue
    det_tag, agr_tag = TAGS[arm]
    det_tag += a.suffix; r = {"det": score(oof, real)}; save(det_tag, real, test, oof, tmean)
    if with_dec:
        agr_tag += a.suffix; r["agreement"] = score(oofa, real); save(agr_tag, real, test, oofa, tmeana)
    log["results"][arm] = r
    print(f"[{meth}] ARM {arm} 5-fold OOF: {json.dumps(r)}  -> maps {det_tag}{' ' + agr_tag if with_dec else ''}", flush=True)
    log_path.write_text(json.dumps(log, indent=1))
print(f"[{meth}] done {(time.time() - t0) / 60:.1f} min", flush=True)
