"""Design forget targets that maximise the predicted score averaged over the ADAPTIVE-TWIN gold hypotheses
(twin_hyp.ENSEMBLE: confidence-band rule c=0.55..0.625 + DINO semantic gate), each with its own leaderboard-fitted
gold loss (mu, sd). Hedges the unidentified c / mu instead of betting on one point.

Target family (same as design_targets.py, dz.py-compatible output):
  q_i (T=2) = [t_i on y, (1 - t_i) * r_i elsewhere],  r_i = weighted mix of the hypotheses' wrong-class shapes
  T=1 logits z_i = 2 log q_i  ->  loss l_i = -log softmax(z_i)_y
objective = sum_k w_k * LDS(mean l, std l; mu_k, sd_k) * PS_k(q),  PS_k = 1 - mean_i KL(g_k,i || q_i) / D_k
w_k ∝ 1 / LOO_k^2 (leave-one-out RMSE of hypothesis k on the leaderboard), or --only NAME for a single hypothesis.
Usage: .venv/bin/python scripts/design_adapt.py --name ad_ens   [--only conf0.6] [--mu_shift 0]
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, str(Path(__file__).resolve().parent))
import twin_hyp as H  # noqa: E402
from lbfit_lib import ROOT, LB, T, kl_mean  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
ap.add_argument("--only", default="", help="use a single hypothesis from twin_hyp.ENSEMBLE")
ap.add_argument("--mu_shift", type=float, default=0.0, help="add to every fitted mu (robustness probe)")
ap.add_argument("--iters", type=int, default=3000)
ap.add_argument("--tmin", type=float, default=1e-9)
a = ap.parse_args()
torch.set_num_threads(16)

o, y = H.orig(); N = len(y); oh = F.one_hot(y, 100).float(); ar = torch.arange(N)
lq_o = F.log_softmax(o["clean"].float() / T, -1)
hyps = []
for name, fn in H.ENSEMBLE:
    if a.only and name != a.only:
        continue
    g = fn(); f = H.fit(g)
    f["mu"] += a.mu_shift
    hyps.append(dict(name=name, g=g, f=f, D=kl_mean(g, lq_o)))
    print(f"{name:12s} fit rmse {f['rmse']:.4f} LOO {f['loo']:.4f}  gold loss {f['mu']:.1f}±{f['sd']:.1f}  c {f['c']}"
          f"  p_true2 {g[ar, y].mean():.3f}±{g[ar, y].std():.3f}", flush=True)
w = torch.tensor([1 / h["f"]["loo"] ** 2 for h in hyps]); w = w / w.sum()
print("weights:", {h["name"]: round(float(wi), 3) for h, wi in zip(hyps, w)})

rest = sum(wi * h["g"] * (1 - oh) for wi, h in zip(w, hyps)); rest = rest / rest.sum(1, keepdim=True)
gy_mix = sum(wi * h["g"][ar, y] for wi, h in zip(w, hyps))
lrest = rest.clamp_min(1e-30).log()
neg_ent = [(h["g"] * h["g"].clamp_min(1e-12).log()).sum(1) for h in hyps]


def terms(t):
    lq = lrest + (1 - t)[:, None].log()
    lq = torch.where(oh.bool(), t[:, None].log().expand_as(lq), lq)       # log q
    l = -F.log_softmax(2 * lq, -1)[ar, y]                                  # T=1 loss of logits 2 log q
    m, s = l.mean(), l.std()
    out = []
    for h, ne in zip(hyps, neg_ent):
        kl = (ne - (h["g"] * lq).sum(1)).mean()
        ps = 1 - kl / h["D"]
        ld = 1 - ((m - h["f"]["mu"]).abs() + (s - h["f"]["sd"]).abs()) / (h["f"]["mu"] + h["f"]["sd"])
        out.append((ld, ps))
    return out, m, s, l, lq


u = torch.logit(gy_mix.clamp(1e-4, 1 - 1e-4)).clone().requires_grad_(True)
opt = torch.optim.Adam([u], lr=0.05)
for it in range(a.iters):
    t = torch.sigmoid(u).clamp(a.tmin, 1 - 1e-6)
    out, m, s, _, _ = terms(t)
    obj = sum(wi * ld * ps for wi, (ld, ps) in zip(w, out))
    opt.zero_grad(); (-obj).backward(); opt.step()
    if it % 1000 == 0:
        print(f"  it {it} obj {obj.item():.4f} loss {m.item():.2f}±{s.item():.2f}", flush=True)
with torch.no_grad():
    t = torch.sigmoid(u).clamp(a.tmin, 1 - 1e-6)
    out, m, s, l, lq = terms(t)
    obj = sum(wi * ld * ps for wi, (ld, ps) in zip(w, out)).item()
print(f"\n{a.name}: weighted LDSxPS {obj:.3f}  loss {m:.2f}±{s:.2f}  t quantiles "
      f"{[round(v, 4) for v in t.quantile(torch.tensor([.05, .25, .5, .75, .95])).tolist()]}")
print(f"  loss quantiles 10/50/90/99%: {[round(v, 2) for v in l.quantile(torch.tensor([.1, .5, .9, .99])).tolist()]}"
      f"  acc(T2 argmax) {(lq.argmax(1) == y).float().mean():.3f}")
for h, (ld, ps) in zip(hyps, out):
    print(f"  under {h['name']:12s}: LDS {ld:.3f} PS {ps:.3f} -> perfect-student {ld * ps:.3f} (before retain factor)")
# how far is the tail placement from the twin signal? (corr of t with the high-spread dino hypothesis' p_true)
try:
    gd = H.dino_gate(0.25)[ar, y]
    print(f"  spearman(t, dino-gate p_true) {np.corrcoef(t.argsort().argsort(), gd.argsort().argsort())[0, 1]:.3f}")
except Exception as e:  # noqa
    print("  (no dino)", e)
z1 = 2 * lq; z1 = z1 - z1.mean(1, keepdim=True)
stats = dict(hyp="adapt:" + ",".join(h["name"] for h in hyps), loss_mean=float(m), loss_std=float(s), score_model=obj,
             fits={h["name"]: h["f"] for h in hyps})
torch.save({"logits": z1, "q2": lq.exp(), "labels": y, "t": t, "stats": stats},
           ROOT / "output/targets" / f"dz_{a.name}.pt")
print("  wrote", ROOT / "output/targets" / f"dz_{a.name}.pt")
