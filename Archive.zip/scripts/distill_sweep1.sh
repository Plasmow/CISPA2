#!/bin/bash
# Targeted distillation, first sweep over target strength (4 configs in parallel, one per GPU)
P=".venv/bin/python scripts/distill.py --epochs 8 --lr 1e-5 --eval_every 50"
CUDA_VISIBLE_DEVICES=0 $P --run d1_s2mean        --target output/targets/s2.pt --agg mean > output/d1_s2mean.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 $P --run d1_s2geo         --target output/targets/s2.pt --agg geo  > output/d1_s2geo.log 2>&1 &
CUDA_VISIBLE_DEVICES=2 $P --run d1_s2mean_mix0.4 --target output/targets/s2.pt --agg mean --mix 0.4 > output/d1_s2mean_mix0.4.log 2>&1 &
CUDA_VISIBLE_DEVICES=3 $P --run d1_s3mean_mix0.3 --target output/targets/s3.pt --agg mean --mix 0.3 > output/d1_s3mean_mix0.3.log 2>&1 &
wait
