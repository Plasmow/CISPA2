#!/bin/bash
# Run from the wmloc_local folder (the one already used for effb3_hp_glob_stack), after copying train_unet.py and
# unet.py from this patch over the old ones. Trains 3 other encoder families of the "everything connected" U-Net,
# one after the other (~1 h each on an RTX 4060), and refreshes the per-variant outputs after each one.
export WMLOC_TASK=$PWD
for v in effv2s_hp_glob_stack r50_hp_glob_stack regy032_hp_glob_stack; do
  python train_unet.py --variant $v --epochs 60 --bs 8 2>&1 | tee train_$v.log
  if [ "$(grep -c 'final val' train_$v.log)" -lt 5 ]; then       # out of memory or crash -> retry with batch 4
    python train_unet.py --variant $v --epochs 60 --bs 4 2>&1 | tee train_${v}_bs4.log
  fi
  python eval_unet.py                                           # writes runs/<variant>/oof_all.npz + test_mean.npz
done
