"""Join leaderboard scores (output/submissions.csv) with each run's settings and local metrics, so the next experiment
is chosen from what actually scored. Prints a table sorted by score and writes output/results.csv.

For a submitted file output/RUN/ckpt_STEP[_aALPHA].pt it reads output/RUN/args.json, output/RUN/target_stats.json,
the target's own params (A1 targets) and the log.jsonl record at STEP.

Usage (from unlearning/):  python scripts/results.py [--all]   (--all: also list failed / unscored submissions)
"""
import argparse
import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "output"

ARG_KEYS = ["target", "agg", "tau", "mix", "lr", "epochs", "alpha", "clean_frac", "train_from_block", "kd_T", "msteps",
            "pert", "sigma", "n_pert", "space", "detach_anchor"]
LOG_KEYS = ["clean_acc", "clean_loss_mean", "clean_loss_std", "mild_acc", "mild_loss_mean", "mild_loss_std",
            "proxy_kl", "kl_target_T2", "wrong_is_teacher_top2"]


def load_json(p):
    try:
        return json.loads(Path(p).read_text())
    except Exception:
        return {}


def log_at(run_dir, step):
    rec = {}
    p = run_dir / "log.jsonl"
    if p.exists():
        for line in p.read_text().splitlines():
            r = json.loads(line)
            if r.get("step") == step:
                rec = r
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    rows = []
    with open(OUT / "submissions.csv") as f:
        for s in csv.DictReader(f):
            score = float(s["score"]) if s["score"] else None
            if score is None and not a.all:
                continue
            path = Path(s["file"])
            m = re.match(r"ckpt_(\d+)(?:_a([\d.]+))?$", path.stem)
            run_dir = (ROOT / path).parent
            row = {"time": s["time"], "score": score, "run": run_dir.name,
                   "step": int(m.group(1)) if m else None, "interp": float(m.group(2)) if m and m.group(2) else 1.0}
            args = load_json(run_dir / "args.json")
            for k in ARG_KEYS:
                if k in args:
                    row[k] = Path(args[k]).stem if k == "target" else args[k]
            tparams = load_json(OUT / "targets" / "summary_a1.json").get(row.get("target", ""), {}).get("params", {})
            for k in ("loss_mean", "loss_std", "wrong_T", "wrong_aug", "class_w", "rank_noise"):
                if k in tparams:
                    row[f"t_{k}"] = tparams[k]
            for k, v in load_json(run_dir / "target_stats.json").items():
                row[k] = round(v, 3)
            rec = log_at(run_dir, row["step"]) if row["step"] is not None else {}
            for k in LOG_KEYS:
                if k in rec:
                    row[k] = round(rec[k], 3)
            rows.append(row)
    rows.sort(key=lambda r: -1 if r["score"] is None else r["score"], reverse=True)
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(OUT / "results.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    show = ["score", "run", "step", "interp", "target", "lr", "alpha", "clean_frac", "target_acc", "target_loss_mean",
            "clean_acc", "clean_loss_mean", "clean_loss_std", "mild_loss_mean", "proxy_kl", "kl_target_T2"]
    show = [k for k in show if k in keys]
    width = {k: max(len(k), *(len(str(r.get(k, ""))) for r in rows)) for k in show} if rows else {}
    print("  ".join(k.ljust(width[k]) for k in show))
    for r in rows:
        print("  ".join(str(r.get(k, "")).ljust(width[k]) for k in show))
    print(f"\n{len(rows)} rows -> {OUT / 'results.csv'}")


if __name__ == "__main__":
    main()
