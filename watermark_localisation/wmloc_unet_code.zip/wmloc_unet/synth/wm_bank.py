"""Watermarked bank for synthetic training data.

For each clean image (center-crop + resize to 512) and each method, with a random message:
  full : the whole 512 image watermarked (embed at the full-image scale, like full_watermark=True images)
  rect : a random rectangle watermarked AT ITS OWN SCALE (crop -> embed -> paste back), like the partial images.
         Aspect ratio <= 16 (PixelSeal, StegaStamp) or <= 2 (TrustMark), side >= 64 px.
Output: bank/<method>/<id>.npz with clean, full, rect (uint8 512x512x3), rect box (y, x, h, w), msg_full, msg_rect.

    python wm_bank.py --src ../clean/val2017 --n 2000 --shard 0 --nshards 1
"""
import argparse
import zlib
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "starter_kit"))
from wmloc.watermarks import load_watermark  # noqa: E402

MAX_AR = {"pixelseal": 16, "trustmark": 2, "stegastamp": 16}
HERE = Path(__file__).resolve().parent


def load_clean(path, size=512):
    im = Image.open(path).convert("RGB"); w, h = im.size; s = min(w, h)
    im = im.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
    return np.asarray(im.resize((size, size), Image.Resampling.BICUBIC), np.uint8)


def random_rect(rng, max_ar, H=512, min_side=64):
    """Area fraction log-uniform in [0.02, 0.5], aspect ratio log-uniform in [1, max_ar], random orientation."""
    for _ in range(100):
        area = np.exp(rng.uniform(np.log(0.02), np.log(0.5))) * H * H   # real partial images: ~9% watermarked on average
        ar = np.exp(rng.uniform(0, np.log(max_ar)))
        h = int(round(np.sqrt(area * ar))); w = int(round(np.sqrt(area / ar)))
        if rng.rand() < 0.5:
            h, w = w, h
        if min_side <= h <= H and min_side <= w <= H:
            return rng.randint(0, H - h + 1), rng.randint(0, H - w + 1), h, w
    return 128, 128, 256, 256


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=str(HERE.parent / "clean" / "val2017")); ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--shard", type=int, default=0); ap.add_argument("--nshards", type=int, default=1)
    ap.add_argument("--methods", nargs="+", default=["pixelseal", "trustmark", "stegastamp"])
    a = ap.parse_args()
    files = sorted(Path(a.src).glob("*.jpg"))[:a.n][a.shard::a.nshards]
    for meth in a.methods:
        wm = load_watermark(meth, TASK / "starter_kit" / "models", "cuda")
        out = HERE / "bank" / meth; out.mkdir(parents=True, exist_ok=True); t = time.time()
        for j, f in enumerate(files):
            dst = out / f"{f.stem}.npz"
            if dst.exists():
                continue
            rng = np.random.RandomState(zlib.crc32(f"{f.stem}-{meth}".encode()))   # deterministic per (image, method)
            clean = load_clean(f)
            m_full = rng.randint(0, 2, wm.nbits); m_rect = rng.randint(0, 2, wm.nbits)
            full = wm.embed(clean, m_full)
            y, x, h, w = random_rect(rng, MAX_AR[meth])
            rect = clean.copy(); rect[y:y + h, x:x + w] = wm.embed(np.ascontiguousarray(clean[y:y + h, x:x + w]), m_rect)
            np.savez(dst, clean=clean, full=full, rect=rect, box=np.array([y, x, h, w]),
                     msg_full=m_full.astype(np.uint8), msg_rect=m_rect.astype(np.uint8))
            if j % 100 == 0:
                print(meth, j, f"{time.time() - t:.0f}s", flush=True)


if __name__ == "__main__":
    main()
