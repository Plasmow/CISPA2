"""How do unlearned models behave on img2img near-duplicates (possible form of the server's 'altered copies')?
For each ckpt: loss mean/std (vs forget label) and T=2 KL to the model's own clean-image distribution, on clean images,
our mild aug, and twins s0.3 / s0.5 / s0.625 (first twin of each image). Usage: python scripts/twin_view_eval.py ck1.pt ck2.pt"""
import sys, glob
import numpy as np, torch, torch.nn.functional as F
import common as C
teacher, imgs = C.load_all()
def tw(s):
    fs = sorted(f for f in glob.glob(str(C.ROOT / f"output/twins/s{s}_sh*.npz")) if ".tmp" not in f)
    ii = np.concatenate([np.load(f)["idx"] for f in fs]); im = np.concatenate([np.load(f)["images"][:, 0] for f in fs])
    return torch.from_numpy(im[np.argsort(ii)]).to(C.DEVICE)
views = {"clean": imgs, "s0.3": tw("0.3"), "s0.5": tw("0.5"), "s0.625": tw("0.625")}
def logits(m, u8, aug=False):
    m.eval(); out = []; g = torch.Generator(device=C.DEVICE).manual_seed(1234)
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        for i in range(0, len(u8), 256):
            x = C.u8_to01(u8[i:i + 256])
            if aug: x = C.augment(x, g, scale=(0.6, 1.0), rot_deg=10, bright=0.2, contrast=0.2, noise=0.05)
            out.append(m(C.norm(x)).float())
    return torch.cat(out)
y = logits(teacher, imgs).argmax(1)
model = C.tt.build_model().to(C.DEVICE)
for p in ["orig"] + sys.argv[1:]:
    model.load_state_dict(teacher.state_dict() if p == "orig" else torch.load(C.ROOT / p, map_location=C.DEVICE, weights_only=True))
    zc = logits(model, imgs)
    row = [f"{Path(p).parent.name if p != 'orig' else 'orig':22s}"] if False else [f"{p.split('/')[-2] if p != 'orig' else 'orig':22s}"]
    for name, u8 in list(views.items()) + [("mild", imgs)]:
        z = zc if name == "clean" else logits(model, u8, aug=(name == "mild"))
        l = F.cross_entropy(z, y, reduction="none")
        kl = C.kl_T(zc, z).mean().item()
        row.append(f"{name} {l.mean():5.2f}±{l.std():5.2f} acc {(z.argmax(1) == y).float().mean():.2f} kl {kl:.2f}")
    print(" | ".join(row), flush=True)
