"""U-Net whose ENCODER IS THE WATERMARK DECODER (PixelSeal ConvNeXt / TrustMark ResNet-50).

Why: the best sources so far are small heads on the frozen decoder features trained on synthetic edits; their limit is
resolution (16x16 / 31x31). Here the decoder backbone feeds a U-Net decoder through its fine stages, so the
watermark-sensitive features get the resolution of a segmentation network.

  encoder  : official decoder backbone, input resized exactly as the official decoder does (PixelSeal 256 bilinear,
             TrustMark 245 bilinear, x*2-1), kept in fp32 (the watermark is ~1 grey level: bf16 would erase it),
             BatchNorm statistics frozen (eval mode). Frozen for --freeze_steps, then lr --enc_lr (or always frozen).
  bottleneck: deepest stage (8x8) + per-position signed confidence of the decoder (8x8) + whole-image score g
  decoder  : 4 up blocks with skips from the decoder stages (16, 32/31, 64/62) and from a light full-resolution
             stem (image + high-pass, stride 4 -> 128x128). Output: logits 128x128.
  training : 1) synthetic edits only (realistic generator, method-specific), no geometric augmentation;
             2) 5-fold fine-tuning on the real train images of the method (out-of-fold maps) + test maps.
Outputs (stack/maps): <tag>0_{train,test}_<method>.npz (synthetic only), <tag>_{train,test}_<method>.npz (fine-tuned).

    python wm_unet.py --method pixelseal --steps 6000 --freeze_steps 2000 --tag wmunet
"""
import argparse
import copy
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, IterableDataset, get_worker_info

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
for p in (HERE, ROOT, ROOT / "synth", TASK / "loc"):
    sys.path.insert(0, str(p))
from common import load_split, load_watermark, KIT, CACHE, folds  # noqa: E402
from evalkit import cv_eval, miou_batch  # noqa: E402
from unet import ConvBlock, Up, gaussian_blur, miou_loss  # noqa: E402

CH = {"pixelseal": [96, 192, 384, 768], "trustmark": [256, 512, 1024, 2048], "stegastamp": None}


class WMUNet(nn.Module):
    def __init__(self, meth, wm, dec=(256, 128, 64, 32)):
        super().__init__()
        self.meth = meth; c = CH[meth]
        self.enc = copy.deepcopy(wm.det if meth == "pixelseal" else wm.net).float()
        self.bott = ConvBlock(c[3] + 2, dec[0])
        self.up3 = Up(dec[0], c[2], dec[0]); self.up2 = Up(dec[0], c[1], dec[1]); self.up1 = Up(dec[1], c[0], dec[2])
        self.stem = nn.Sequential(nn.Conv2d(6, 32, 4, stride=4), nn.ReLU(inplace=True), nn.Conv2d(32, 32, 3, padding=1), nn.ReLU(inplace=True))
        self.up0 = Up(dec[2], 32, dec[3]); self.head = nn.Conv2d(dec[3], 1, 1)

    def train(self, mode=True):
        super().train(mode); self.enc.eval()          # BatchNorm statistics / drop-path stay as in the official decoder
        return self

    def encode(self, x):
        if self.meth == "pixelseal":
            d = self.enc; h = d.preprocess(F.interpolate(x, size=(256, 256), mode="bilinear", align_corners=False, antialias=True))
            outs = []
            for i in range(4):
                h = d.convnext.stages[i](d.convnext.downsample_layers[i](h)); outs.append(h)
            emb = d.pixel_decoder.output_upscaling(outs[3]); lin = d.pixel_decoder.linear
            pp = (torch.einsum("bchw,oc->bohw", emb, lin.weight) + lin.bias[None, :, None, None])[:, 1:]
        else:
            n = self.enc; h = F.interpolate(x, size=(245, 245), mode="bilinear", align_corners=False, antialias=True) * 2 - 1
            h = n.maxpool(n.relu(n.bn1(n.conv1(h)))); outs = []
            for k in ("layer1", "layer2", "layer3", "layer4"):
                h = getattr(n, k)(h); outs.append(h)
            pp = torch.einsum("bchw,oc->bohw", outs[3], n.fc.weight) + n.fc.bias[None, :, None, None]
        return outs, pp

    def forward(self, x, sgn):
        """x [B,3,512,512] in [0,1]; sgn [B,nbits] = 2*message-1 -> logits [B,128,128]."""
        outs, pp = self.encode(x)
        conf = (pp * sgn[:, :, None, None]).mean(1, keepdim=True)
        g = conf.mean((2, 3), keepdim=True).expand_as(conf)
        y = self.bott(torch.cat([outs[3], conf / 5, g / 5], 1))
        y = self.up3(y, outs[2]); y = self.up2(y, outs[1]); y = self.up1(y, outs[0])
        s = self.stem(torch.cat([x, (x - gaussian_blur(x, 1.5)) * 20], 1))
        return self.head(self.up0(y, s))[:, 0]


class StegaUNet(nn.Module):
    """Same idea for StegaStamp: encoder = the official decoder re-implemented in PyTorch (stega_torch.py, exact).
    The decoder works in the frame warped by its STN, so the U-Net predicts in that frame (200x200) and the map is
    resampled back to the image frame (128x128 cells) with the inverse of the per-image affine transform."""

    def __init__(self, dec=(256, 128, 64, 32)):
        super().__init__()
        from stega_torch import StegaDecoder
        self.meth = "stegastamp"; self.enc = StegaDecoder()
        self.bott = ConvBlock(128 + 2, dec[0])
        self.up3 = Up(dec[0], 128, dec[0]); self.up2 = Up(dec[0], 64, dec[1]); self.up1 = Up(dec[1], 64, dec[2]); self.up0 = Up(dec[2], 32, dec[3])
        self.head = nn.Conv2d(dec[3], 1, 1)
        k = torch.arange(128, dtype=torch.float32); u = ((k + 0.5) * 4 + 0.5) * 400 / 512 - 0.5      # cell centres in 400-px coords
        s = 2 * u / 398 - 1                                                                            # inverse of x = (s + 1) * 199
        sy, sx = torch.meshgrid(s, s, indexing="ij"); self.register_buffer("cells", torch.stack([sx, sy], -1).view(-1, 2))

    def train(self, mode=True):
        super().train(mode); self.enc.eval(); return self

    def forward(self, x, sgn):
        x4 = F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
        outs, th = self.enc.features(x4)                     # c1..c7 (warped frame)
        logits, contrib, pre = self.enc.head(outs[6])
        base = (logits * sgn).mean(1)                        # whole-image signed confidence
        occ = base[:, None, None] - ((F.relu(pre[:, None, None] - contrib) @ self.enc.dec_out.weight.T + self.enc.dec_out.bias) * sgn[:, None, None]).mean(-1)
        g = base[:, None, None, None].expand(-1, 1, 13, 13)
        y = self.bott(torch.cat([outs[6], occ[:, None] / 5, g / 5], 1))
        y = self.up3(y, outs[5]); y = self.up2(y, outs[4]); y = self.up1(y, outs[3]); y = self.up0(y, outs[1])
        warped_logits = self.head(y)                         # [B,1,200,200] on the STN grid (linspace(-1, 1) -> align_corners=True)
        A, b = th[:, :, :2], th[:, :, 2:]                    # image coords s = A p + b  ->  p = A^-1 (s - b)
        p = torch.linalg.solve(A, (self.cells[None].transpose(1, 2) - b))           # [B,2,128*128]
        grid = p.transpose(1, 2).reshape(-1, 128, 128, 2)
        return F.grid_sample(warped_logits, grid, mode="bilinear", padding_mode="border", align_corners=True)[:, 0]


class SynthStream(IterableDataset):
    def __init__(self, meth, seed):
        self.meth, self.seed = meth, seed

    def __iter__(self):
        from generator import SynthGenerator
        wi = get_worker_info(); g = SynthGenerator(methods=(self.meth,), seed=self.seed + (wi.id if wi else 0), realistic=True)
        while True:
            s = g.sample()
            yield (torch.from_numpy(s["image"].astype(np.uint8)).permute(2, 0, 1), torch.from_numpy(s["mask128"].astype(np.float32)),
                   torch.from_numpy(s["message"].astype(np.float32)))


def load_real(meth, split, nmax=None):
    ds = load_split(split, [meth]); n = len(ds) if nmax is None else min(nmax, len(ds))
    names = [ds.meta[i]["image_name"] for i in range(n)]
    imgs = torch.from_numpy(np.stack([np.asarray(ds[i]["image"]) for i in range(n)])).permute(0, 3, 1, 2).contiguous()
    msgs = torch.from_numpy(np.stack([ds[i]["message"].astype(np.float32) for i in range(n)]))
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item()[meth]; lut = dict(zip(gl["names"], gl["logits"]))
    g = np.array([(lut[nm] * (msgs[i].numpy() * 2 - 1)).mean() for i, nm in enumerate(names)])
    out = dict(names=names, imgs=imgs, msgs=msgs, g=g)
    if ds.train:
        out["gt"] = np.stack([ds.m128[nm] for nm in names]).astype(bool); out["full"] = np.array([ds.meta[i]["full_watermark"] for i in range(n)])
    return out


@torch.no_grad()
def predict(model, d, idx, dev, bs=16):
    model.eval(); out = []
    for b in range(0, len(idx), bs):
        ii = idx[b:b + bs]
        out.append(model(d["imgs"][ii].to(dev).float() / 255, d["msgs"][ii].to(dev) * 2 - 1).float().cpu())
    model.train(); return torch.cat(out).numpy()


def zero_shot_report(model, real, dev, tag):
    L = predict(model, real, np.arange(len(real["names"])), dev)
    s05 = miou_batch(L > 0, real["gt"]); s = cv_eval(L, real["gt"], real["g"], "switch", seed=1); f = real["full"]
    return L, dict(tag=tag, miou05=round(float(s05.mean()), 4), cv_switch=round(float(s.mean()), 4),
                   cv_T=round(float(s[f].mean()), 4), cv_F=round(float(s[~f].mean()), 4))


def set_encoder_trainable(model, flag):
    for p in model.enc.parameters():
        p.requires_grad_(flag)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--method", required=True, choices=list(CH)); ap.add_argument("--tag", default="wmunet")
    ap.add_argument("--steps", type=int, default=6000); ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--freeze_steps", type=int, default=2000, help="encoder frozen for these steps; -1 = always frozen")
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--enc_lr", type=float, default=1e-5)
    ap.add_argument("--workers", type=int, default=14); ap.add_argument("--eval_every", type=int, default=2000)
    ap.add_argument("--ft_epochs", type=int, default=15); ap.add_argument("--ft_lr", type=float, default=1e-4)
    ap.add_argument("--max_real", type=int, default=None, help="debug: subsample real images"); ap.add_argument("--dev", default="cuda")
    a = ap.parse_args(); dev = a.dev; meth = a.method; t0 = time.time()
    torch.backends.cuda.matmul.allow_tf32 = False; torch.backends.cudnn.allow_tf32 = False   # keep the encoder at full fp32
    if meth == "stegastamp":
        model = StegaUNet().to(dev)
    else:
        wm = load_watermark(meth, KIT / "models", dev); model = WMUNet(meth, wm).to(dev); del wm
    real = load_real(meth, "train", a.max_real); test = load_real(meth, "test", a.max_real)
    log = {"args": vars(a), "evals": []}
    # ---- 1. synthetic pre-training
    set_encoder_trainable(model, False)
    dec_params = [p for n, p in model.named_parameters() if not n.startswith("enc.")]
    opt = torch.optim.AdamW(dec_params, lr=a.lr, weight_decay=1e-4); opt_enc = None
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, a.lr, total_steps=a.steps, pct_start=0.05)
    dl = DataLoader(SynthStream(meth, 4242), batch_size=a.bs, num_workers=a.workers, pin_memory=True, persistent_workers=a.workers > 0)
    run = None
    for step, (x, y, msg) in enumerate(dl, 1):
        if a.freeze_steps >= 0 and step == a.freeze_steps + 1:
            set_encoder_trainable(model, True)
            opt_enc = torch.optim.AdamW(model.enc.parameters(), lr=a.enc_lr, weight_decay=0)
            print(f"[{meth}] step {step}: encoder unfrozen (lr {a.enc_lr})", flush=True)
        x = x.to(dev, non_blocking=True).float() / 255; y = y.to(dev); sgn = msg.to(dev) * 2 - 1
        lg = model(x, sgn); loss = F.binary_cross_entropy_with_logits(lg, y) + miou_loss(lg, y)
        opt.zero_grad(set_to_none=True)
        if opt_enc: opt_enc.zero_grad(set_to_none=True)
        loss.backward(); opt.step(); sched.step()
        if opt_enc: opt_enc.step()
        run = loss.item() if run is None else 0.98 * run + 0.02 * loss.item()
        if step % 100 == 0:
            print(f"[{meth}] step {step}/{a.steps} loss {run:.4f} {(time.time() - t0) / step:.2f}s/step", flush=True)
        if step % a.eval_every == 0 or step == a.steps:
            _, r = zero_shot_report(model, real, dev, f"synthetic step {step}"); log["evals"].append(r)
            print(f"[{meth}] ZERO-SHOT on real train: {json.dumps(r)}", flush=True)
        if step >= a.steps:
            break
    pre_state = copy.deepcopy(model.state_dict())
    L0, r0 = zero_shot_report(model, real, dev, "synthetic only (final)"); T0 = predict(model, test, np.arange(len(test["names"])), dev)
    np.savez(HERE / "maps" / f"{a.tag}0_train_{meth}.npz", names=np.array(real["names"]), logit128=L0.astype(np.float16))
    np.savez(HERE / "maps" / f"{a.tag}0_test_{meth}.npz", names=np.array(test["names"]), logit128=T0.astype(np.float16))
    # ---- 2. 5-fold fine-tuning on the real train images of the method
    N = len(real["names"]); oof = np.zeros((N, 128, 128), np.float32); tmean = np.zeros((len(test["names"]), 128, 128), np.float32)
    for k, f in enumerate(folds(N, 5, 0)):
        model.load_state_dict(pre_state); tr = np.setdiff1d(np.arange(N), f)
        set_encoder_trainable(model, a.freeze_steps >= 0)
        groups = [{"params": [p for n, p in model.named_parameters() if not n.startswith("enc.")], "lr": a.ft_lr}]
        if a.freeze_steps >= 0:
            groups.append({"params": list(model.enc.parameters()), "lr": a.enc_lr / 2})
        opt = torch.optim.AdamW(groups, weight_decay=1e-4); rng = np.random.RandomState(k)
        for ep in range(a.ft_epochs):
            perm = rng.permutation(tr)
            for b in range(0, len(perm), 8):
                ii = perm[b:b + 8]
                x = real["imgs"][ii].to(dev).float() / 255; y = torch.from_numpy(real["gt"][ii].astype(np.float32)).to(dev)
                lg = model(x, real["msgs"][ii].to(dev) * 2 - 1)
                loss = F.binary_cross_entropy_with_logits(lg, y) + miou_loss(lg, y)
                opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
        oof[f] = predict(model, real, f, dev); tmean += predict(model, test, np.arange(len(test["names"])), dev) / 5
        print(f"[{meth}] fine-tune fold {k}: val mIoU@0 = {miou_batch(oof[f] > 0, real['gt'][f]).mean():.4f} ({time.time() - t0:.0f}s)", flush=True)
    s = cv_eval(oof, real["gt"], real["g"], "switch", seed=1); fl = real["full"]
    r1 = dict(tag="fine-tuned 5-fold (out-of-fold)", cv_switch=round(float(s.mean()), 4), cv_T=round(float(s[fl].mean()), 4), cv_F=round(float(s[~fl].mean()), 4))
    log["evals"] += [r0, r1]; print(f"[{meth}] {json.dumps(r0)}\n[{meth}] {json.dumps(r1)}", flush=True)
    np.savez(HERE / "maps" / f"{a.tag}_train_{meth}.npz", names=np.array(real["names"]), logit128=oof.astype(np.float16))
    np.savez(HERE / "maps" / f"{a.tag}_test_{meth}.npz", names=np.array(test["names"]), logit128=tmean.astype(np.float16))
    torch.save({k: v.half() for k, v in pre_state.items()}, HERE / "maps" / f"{a.tag}_{meth}_synthetic.pt")
    (ROOT / "logs" / f"{a.tag}_{meth}.json").write_text(json.dumps(log, indent=1))
    print(f"[{meth}] done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
