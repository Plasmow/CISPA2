"""Shared pieces of the leaderboard-fit model (see lbfit.py): load scored submissions, gold hypotheses, score model."""
import csv, glob
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
LB = ROOT / "output" / "lbfit"
T = 2.0
CAP = torch.tensor([0, 6, 7, 8, 29, 30, 31, 33, 38])


def load_subs():
    rows = list(csv.DictReader(open(ROOT / "output" / "results.csv")))
    pkl = {(r["run"], r["step"]): float(r["proxy_kl"]) if r["proxy_kl"] else np.nan for r in rows}
    seen = {}
    for r in csv.DictReader(open(ROOT / "output" / "submissions.csv")):
        if not r["score"]:
            continue
        key = r["file"].replace("output/", "").replace("/", "__").replace(".pt", "")
        if not (LB / f"{key}.pt").exists():
            continue
        run = r["file"].split("/")[1]
        step = r["file"].split("ckpt_")[-1].replace(".pt", "").lstrip("0") if "ckpt_" in r["file"] else ""
        p = pkl.get((run, step), np.nan)
        if np.isnan(p) and step and (ROOT / "output" / run / "log.jsonl").exists():   # dz-style runs: read the run log
            import json
            for line in open(ROOT / "output" / run / "log.jsonl"):
                d_ = json.loads(line)
                if d_.get("step") == int(step) and "proxy_kl" in d_:
                    p = float(d_["proxy_kl"])
        seen[key] = dict(key=key, score=float(r["score"]), pkl=0.3 if np.isnan(p) else p)
    return list(seen.values())


def load_twins(s):
    idx, lg = [], []
    for g in sorted(glob.glob(str(ROOT / f"output/twins/s{s}_sh*.npz"))):
        if ".tmp" in g:
            continue
        with np.load(g) as d:
            idx.append(d["idx"]); lg.append(d["logits"])
    idx = np.concatenate(idx); lg = torch.from_numpy(np.concatenate(lg)).float()
    return lg[np.argsort(idx)]


def loss_stats_from_logits(z, y):
    l = F.cross_entropy(z.float(), y, reduction="none")
    return l.mean().item(), l.std().item()


def kl_mean(pg, lq):
    return (pg * (pg.clamp_min(1e-12).log() - lq)).sum(1).mean().item()


def lds(m, s, mo, so, mu, sd):
    d = abs(m - mu) + abs(s - sd)
    do = abs(mo - mu) + abs(so - sd)
    return 1 - np.clip(d / do, 0, 1)
