| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source zregy040_hp_glob_stack | 0.5171 | 0.5159 | 0.5183 |
| pixelseal | source zrx50_hp_glob_stack | 0.5069 | 0.5085 | 0.5052 |
| pixelseal | source zr2n50_hp_glob_stack | 0.5223 | 0.5175 | 0.5272 |
| pixelseal | source zhrw18_hp_glob_stack | 0.5356 | 0.5297 | 0.5414 |
| pixelseal | source zeffb4_hp_glob_stack | 0.4988 | 0.4957 | 0.5018 |
| pixelseal | source zhrw18_hp_glob_stack_s2 | 0.5437 | 0.5319 | 0.5555 |
| pixelseal | source zserx50_hp_glob_stack | 0.5064 | 0.5061 | 0.5068 |
| pixelseal | source zregz_hp_glob_stack | 0.5218 | 0.5224 | 0.5211 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wmunet20'] | 0.6125 | 0.6218 | 0.6032 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'zhrw18_hp_glob_stack_s2', 'zhrw18_hp_glob_stack', 'head', 'zr2n50_hp_glob_stack', 'zregz_hp_glob_stack', 'zregy040_hp_glob_stack', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'zserx50_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'zeffb4_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6216 | 0.6298 | 0.6135 |
| pixelseal | fusion all + rule switch | 0.6216 | 0.6298 | 0.6135 |
| pixelseal | fusion all + rule expected_area | 0.6201 | 0.6300 | 0.6102 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6226 | 0.6307 | 0.6146 |
| pixelseal | fusion all + rule regressed_area | 0.5972 | 0.6130 | 0.5814 |
| pixelseal | fusion all + rule emiou_none | 0.6245 | 0.6323 | 0.6167 |
| pixelseal | fusion all + rule emiouT|switch | 0.6228 | 0.6328 | 0.6128 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6217 | 0.6321 | 0.6114 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6232 | 0.6326 | 0.6138 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6087 | 0.6308 | 0.5866 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6549 | 0.6595 | 0.6503 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6245 | 0.6323 | 0.6167 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<256 / F:drop<64 | **0.6205** | 0.6298 | 0.6113 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6255 | 0.6336 | 0.6173 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6373 | 0.6336 | 0.6410 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6500 | 0.6336 | 0.6664 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6513 | 0.6336 | 0.6690 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6533 | 0.6336 | 0.6729 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6446 | 0.6336 | 0.6556 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6422 | 0.6336 | 0.6509 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6533** | 0.6336 | 0.6729 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source zregy040_hp_glob_stack | 0.5310 | 0.4989 | 0.5632 |
| trustmark | source zrx50_hp_glob_stack | 0.5027 | 0.5014 | 0.5040 |
| trustmark | source zr2n50_hp_glob_stack | 0.5187 | 0.5122 | 0.5253 |
| trustmark | source zhrw18_hp_glob_stack | 0.5535 | 0.5253 | 0.5817 |
| trustmark | source zeffb4_hp_glob_stack | 0.4957 | 0.4990 | 0.4924 |
| trustmark | source zhrw18_hp_glob_stack_s2 | 0.5467 | 0.5262 | 0.5671 |
| trustmark | source zserx50_hp_glob_stack | 0.4937 | 0.4865 | 0.5009 |
| trustmark | source zregz_hp_glob_stack | 0.5289 | 0.4934 | 0.5643 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'zhrw18_hp_glob_stack', 'headsyn', 'zhrw18_hp_glob_stack_s2', 'zregy040_hp_glob_stack', 'zregz_hp_glob_stack', 'headmulti', 'zr2n50_hp_glob_stack', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_r50_hp_glob_stack', 'zeffb4_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'zserx50_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6304 | 0.6077 | 0.6530 |
| trustmark | fusion all + rule switch | 0.6304 | 0.6077 | 0.6530 |
| trustmark | fusion all + rule expected_area | 0.6366 | 0.6228 | 0.6505 |
| trustmark | fusion all + rule otsu_in_regime | 0.6347 | 0.6082 | 0.6612 |
| trustmark | fusion all + rule regressed_area | 0.6105 | 0.6059 | 0.6150 |
| trustmark | fusion all + rule emiou_none | 0.6424 | 0.6260 | 0.6588 |
| trustmark | fusion all + rule emiouT|switch | 0.6397 | 0.6248 | 0.6546 |
| trustmark | fusion all + rule emiouT|expected_area | 0.6383 | 0.6260 | 0.6505 |
| trustmark | fusion all + rule emiouT|otsu_in_regime | 0.6424 | 0.6247 | 0.6602 |
| trustmark | fusion all + rule emiouT|regressed_area | 0.6221 | 0.6253 | 0.6190 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6677 | 0.6540 | 0.6814 |
| trustmark | fusion all + CV-selected rule (whole-train choice: emiouT|otsu_in_regime) | 0.6408 | 0.6247 | 0.6569 |
| trustmark | **v2 pipeline**: fusion all + emiouT|otsu_in_regime + post T:close_holes5 / F:drop<16+box>=0.85 | **0.6426** | 0.6266 | 0.6587 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6440 | 0.6273 | 0.6607 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6551 | 0.6273 | 0.6828 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6805 | 0.6273 | 0.7336 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6879 | 0.6273 | 0.7486 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6916 | 0.6273 | 0.7559 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6916 | 0.6273 | 0.7559 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6916 | 0.6273 | 0.7559 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6805** | 0.6273 | 0.7336 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source zregy040_hp_glob_stack | 0.7245 | 0.7618 | 0.6872 |
| stegastamp | source zrx50_hp_glob_stack | 0.6326 | 0.6485 | 0.6166 |
| stegastamp | source zr2n50_hp_glob_stack | 0.6583 | 0.6886 | 0.6279 |
| stegastamp | source zhrw18_hp_glob_stack | 0.7537 | 0.7954 | 0.7119 |
| stegastamp | source zeffb4_hp_glob_stack | 0.5963 | 0.6236 | 0.5690 |
| stegastamp | source zhrw18_hp_glob_stack_s2 | 0.7198 | 0.7583 | 0.6813 |
| stegastamp | source zserx50_hp_glob_stack | 0.6708 | 0.7153 | 0.6263 |
| stegastamp | source zregz_hp_glob_stack | 0.6989 | 0.7404 | 0.6575 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | fusion top2 ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack'] | 0.7624 | 0.8006 | 0.7243 |
| stegastamp | fusion top3 ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack', 'zhrw18_hp_glob_stack_s2'] | 0.7608 | 0.7995 | 0.7222 |
| stegastamp | fusion all ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack', 'zhrw18_hp_glob_stack_s2', 'zregz_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'zserx50_hp_glob_stack', 'zr2n50_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'zrx50_hp_glob_stack', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wmunetH', 'zeffb4_hp_glob_stack', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7731 | 0.8197 | 0.7264 |
| stegastamp | fusion all + rule switch | 0.7731 | 0.8197 | 0.7264 |
| stegastamp | fusion all + rule expected_area | 0.7650 | 0.8017 | 0.7282 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7801 | 0.8245 | 0.7357 |
| stegastamp | fusion all + rule regressed_area | 0.7450 | 0.7666 | 0.7234 |
| stegastamp | fusion all + rule emiou_none | 0.7838 | 0.8222 | 0.7454 |
| stegastamp | fusion all + rule emiouT|switch | 0.7737 | 0.8222 | 0.7252 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7754 | 0.8224 | 0.7285 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7783 | 0.8219 | 0.7348 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7730 | 0.8214 | 0.7246 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7819 | 0.8109 | 0.7529 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7838 | 0.8222 | 0.7454 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<64 | **0.7830** | 0.8187 | 0.7473 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7861 | 0.8232 | 0.7489 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7352 | 0.8177 | 0.6527 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7824 | 0.8177 | 0.7472 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7912 | 0.8177 | 0.7648 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7948 | 0.8177 | 0.7720 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7976 | 0.8232 | 0.7720 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7976 | 0.8232 | 0.7720 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7948** | 0.8177 | 0.7720 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "zhrw18_hp_glob_stack_s2",
   "zhrw18_hp_glob_stack",
   "head",
   "zr2n50_hp_glob_stack",
   "zregz_hp_glob_stack",
   "zregy040_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "zserx50_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "zeffb4_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<256",
  "post_F": "drop<64",
  "rect": "rect>=0.85",
  "cv": 0.6533,
  "cv_T": 0.6336,
  "cv_F": 0.6729,
  "test_frac_pred_1": 0.498
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0",
   "wmunetF",
   "headsyn2",
   "zhrw18_hp_glob_stack",
   "headsyn",
   "zhrw18_hp_glob_stack_s2",
   "zregy040_hp_glob_stack",
   "zregz_hp_glob_stack",
   "headmulti",
   "zr2n50_hp_glob_stack",
   "head",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "zeffb4_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "zserx50_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiouT|otsu_in_regime",
  "post_T": "close_holes5",
  "post_F": "drop<16+box>=0.85",
  "rect": "rect>=0.85",
  "cv": 0.6805,
  "cv_T": 0.6273,
  "cv_F": 0.7336,
  "test_frac_pred_1": 0.498
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "zhrw18_hp_glob_stack",
   "zregy040_hp_glob_stack",
   "zhrw18_hp_glob_stack_s2",
   "zregz_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "zserx50_hp_glob_stack",
   "zr2n50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "zrx50_hp_glob_stack",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wmunetH",
   "zeffb4_hp_glob_stack",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<64",
  "rect": "rect>=0.9",
  "cv": 0.7948,
  "cv_T": 0.8177,
  "cv_F": 0.772,
  "test_frac_pred_1": 0.495
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.7095,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v19c.pt",
 "size_MB": 15.96
}
```
