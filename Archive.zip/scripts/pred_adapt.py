"""Predicted public score under the adaptive-twin hypotheses (twin_hyp.ENSEMBLE, each with its leaderboard fit).

  --targets a.pt,b.pt  : score target files as if a perfect student matched them (clean logits used for both views,
                         retain factor 1)
  --runs dirA,dirB     : score checkpoints of dz runs. Needs their logits on the lbfit views: dumps them with
                         lbfit_dump-compatible views (GPU if available) into output/lbfit/extra/<run>__<ckpt>.pt;
                         proxy_kl read from <run>/log.jsonl.
Prints per-hypothesis predictions and the LOO-weighted mean (the design objective).
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, torch
sys.path.insert(0, str(Path(__file__).resolve().parent))
import twin_hyp as H  # noqa: E402
from lbfit_lib import ROOT, LB  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--targets", default="")
ap.add_argument("--runs", default="")
ap.add_argument("--keys", default="", help="existing output/lbfit/<key>.pt dumps (scored subs), proxy_kl from results.csv")
a = ap.parse_args()
torch.set_num_threads(16)

hyps = [(n, fn()) for n, fn in H.ENSEMBLE]
fits = {n: H.fit(g) for n, g in hyps}
w = np.array([1 / fits[n]["loo"] ** 2 for n, _ in hyps]); w /= w.sum()


def report(label, logits_by_view, pkl):
    preds = [H.predict(g, fits[n], logits_by_view, pkl) for n, g in hyps]
    wm = float(np.dot(w, [p[0] for p in preds]))
    print(f"{label:46s} pKL {pkl:.3f} | wmean {wm:.4f} | " + " ".join(f"{n}:{p[0]:.3f}" for (n, _), p in zip(hyps, preds))
          + f" | LDS/PS@c0.6 {preds[0][1]:.3f}/{preds[0][2]:.3f}", flush=True)
    return wm


for f in [s for s in a.targets.split(",") if s]:
    z = torch.load(ROOT / f)["logits"].float()
    report(Path(f).stem + " (target)", {"clean": z, "mild": z}, 0.0)

if a.keys:
    subs = {s["key"]: s for s in H.lb()["subs"]}
    for k in a.keys.split(","):
        d = torch.load(LB / f"{k}.pt")
        report(k + (f" [actual {subs[k]['score']:.4f}]" if k in subs else ""), d, subs[k]["pkl"] if k in subs else 0.5)

if a.runs:
    import subprocess
    jobs = []
    for run in [s for s in a.runs.split(",") if s]:
        rd = ROOT / "output" / run
        log = {}
        if (rd / "log.jsonl").exists():
            for line in open(rd / "log.jsonl"):
                r = json.loads(line); log[int(r.get("step", -1))] = r
        for ck in sorted(rd.glob("ckpt_*.pt")):
            if int(ck.stem.split("_")[1]) > 0:
                jobs.append((run, ck, log))
    need = [f"output/{run}/{ck.name}" for run, ck, _ in jobs if not (LB / f"{run}__{ck.stem}.pt").exists()]
    if need:   # same views as the scored subs (lbfit_dump.py, n=3500)
        subprocess.run([sys.executable, str(ROOT / "scripts/lbfit_dump.py"), "--n", "3500", "--threads", "16",
                        "--extra", ",".join(need)], check=True, cwd=ROOT)
    for run, ck, log in jobs:
        step = int(ck.stem.split("_")[1])
        d = torch.load(LB / f"{run}__{ck.stem}.pt")
        report(f"{run}@{step}", d, log.get(step, {}).get("proxy_kl", 0.5))
