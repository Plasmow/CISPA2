#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:30:00
#SBATCH --job-name=wm_rect_pairs
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/rect_pairs_%j.out
# Agent A, task 2. dc-gpu-devel: 12 nodes OUTSIDE the cispahack reservation, account training2666 allowed, 2 h max.
# Submit from the team folder; after start:  scontrol show job <id> | grep Reservation   (must be empty)
#
# Missed decoder rectangles, PixelSeal / TrustMark, train + test: pairs-of-edges search around many seeds
# (stack/rect_pairs.py). Each GPU takes 1/4 of every (method, split) list. Writes stack/maps/rect3_<m>_<split>_<k>.npz
# every 5 images (partial results stay usable if the time limit is hit). Nothing else is written, nothing is uploaded.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }
run() {  # gpu shard
  for job in "trustmark train" "trustmark test" "pixelseal train" "pixelseal test"; do
    CUDA_VISIBLE_DEVICES=$1 $PY rect_pairs.py $job $2 4 2>&1 | tagged gpu$1
  done
}
run 0 0 & run 1 1 & run 2 2 & run 3 3 &
wait
echo done
