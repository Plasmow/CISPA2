"""On-the-fly synthetic edits from the watermarked bank (wm_bank.py). Each sample mimics one edit type of the task:

  hole        (full=True)  : whole image watermarked, a region restored to the clean original      GT = 1 - region
  addition    (full=True)  : whole image watermarked, an object from another clean image pasted     GT = 1 - object
  transplant  (full=False) : object cut from a watermarked image, pasted onto another clean image  GT = object
  outpaint    (full=False) : watermark embedded on a rectangle at its own scale, rest clean         GT = rectangle
  rect_hole   (full=False) : as outpaint, then a clean region punched inside the rectangle         GT = rect - region

Region / object shapes: random GT masks from the train split (blob holes for full=True images, object masks for
full=False ones), randomly flipped/rotated/shifted, or random smooth blobs. Output: uint8 image, GT 512, GT 128
(official downsampling), method, message, full flag, edit type.
"""
import sys
from pathlib import Path

import numpy as np
try:                                      # one OpenCV thread per process (many generator processes run in parallel)
    import cv2
    cv2.setNumThreads(1)
except ImportError:
    pass
from scipy.ndimage import gaussian_filter, shift as nd_shift

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "starter_kit"))
from wmloc.data import LocalisationDataset  # noqa: E402
from wmloc.utils import downsample_mask  # noqa: E402

HERE = Path(__file__).resolve().parent
METHODS = ("pixelseal", "trustmark", "stegastamp")
EDITS = {"hole": 0.3, "addition": 0.2, "transplant": 0.25, "outpaint": 0.15, "rect_hole": 0.1}


class MaskBank:
    """Region shapes: train GT masks (minority region of each image) + random smooth blobs."""

    def __init__(self, min_frac=0.005, max_frac=0.6):
        ds = LocalisationDataset(TASK / "release", "train"); self.hole, self.obj = [], []
        for i in range(len(ds)):
            it = ds[i]; m = it["mask"].astype(bool)
            region = ~m if it["full_watermark"] else m                  # the minority region
            if min_frac <= region.mean() <= max_frac:
                (self.hole if it["full_watermark"] else self.obj).append(np.packbits(region))

    @staticmethod
    def blob(rng, H=512, lo=0.02, hi=0.3):
        import cv2   # smooth noise made at 1/8 resolution then upsampled: same look, ~50x faster than a 512 filter
        n = gaussian_filter(rng.randn(H // 8, H // 8), sigma=rng.uniform(15, 60) / 8, mode="wrap")
        n = cv2.resize(n.astype(np.float32), (H, H), interpolation=cv2.INTER_CUBIC)
        return n > np.quantile(n, 1 - rng.uniform(lo, hi))   # region = lo..hi of the image (real minority ~10%)

    def sample(self, rng, kind, H=512):
        bank = self.hole if kind == "hole" else self.obj
        if rng.rand() < 0.3 or not bank:
            m = self.blob(rng, H)
        else:
            m = np.unpackbits(bank[rng.randint(len(bank))])[:H * H].reshape(H, H).astype(bool)
            m = np.rot90(m, rng.randint(4))
            if rng.rand() < 0.5:
                m = m[:, ::-1]
            if rng.rand() < 0.5:                                         # random shift (keeps shapes, varies position)
                m = nd_shift(m.astype(np.uint8), rng.randint(-96, 97, 2), order=0, mode="constant") > 0
        return np.ascontiguousarray(m)


class SynthGenerator:
    def __init__(self, methods=METHODS, edits=EDITS, seed=0, realistic=False):
        """realistic=True: feathered blending, rescaled/shifted transplants, colour shift of pasted clean content, mild noise."""
        self.realistic = realistic
        self.files = {m: sorted((HERE / "bank" / m).glob("*.npz")) for m in methods}
        self.methods = [m for m in methods if self.files[m]]
        assert self.methods, "empty bank: run wm_bank.py first"
        self.edits, self.p = list(edits), np.array(list(edits.values())) / sum(edits.values())
        self.masks = MaskBank(); self.rng = np.random.RandomState(seed)

    def _load(self, meth):
        return np.load(self.files[meth][self.rng.randint(len(self.files[meth]))])

    # ---- realistic transforms ------------------------------------------------------------------
    def _paste(self, base, src, R):
        """src where R, base elsewhere; feathered edge (gaussian sigma 0..3 px) in realistic mode."""
        if not self.realistic or self.rng.rand() < 0.3:
            return np.where(R[..., None], src, base)
        a = gaussian_filter(R.astype(np.float32), self.rng.uniform(0.7, 3.0))[..., None]
        return a * src.astype(np.float32) + (1 - a) * base.astype(np.float32)

    def _jitter(self, img):
        """colour shift of pasted clean content (gain +-5 %, bias +-6 levels per channel)."""
        if not self.realistic or self.rng.rand() < 0.5:
            return img
        g = self.rng.uniform(0.95, 1.05, 3); b = self.rng.uniform(-6, 6, 3)
        return np.clip(img.astype(np.float32) * g + b, 0, 255)

    def _move(self, img, R):
        """random scale (x0.75..1.33) + shift of a transplanted object and its mask (watermark scale changes)."""
        if not self.realistic or self.rng.rand() < 0.4:
            return img, R
        import cv2
        s = float(np.exp(self.rng.uniform(np.log(0.75), np.log(1.33)))); ys, xs = np.nonzero(R)
        if len(ys) == 0:
            return img, R
        cy, cx = ys.mean(), xs.mean(); ty, tx = self.rng.uniform(-64, 64, 2)
        M = np.float32([[s, 0, (1 - s) * cx + tx], [0, s, (1 - s) * cy + ty]])
        img2 = cv2.warpAffine(img.astype(np.float32), M, (512, 512), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        R2 = cv2.warpAffine(R.astype(np.uint8), M, (512, 512), flags=cv2.INTER_NEAREST) > 0
        return img2, R2

    def sample(self):
        rng = self.rng; meth = self.methods[rng.randint(len(self.methods))]
        edit = self.edits[rng.choice(len(self.edits), p=self.p)]
        a = self._load(meth)
        if edit == "hole":
            R = self.masks.sample(rng, "hole"); img = self._paste(a["full"], a["clean"], R); gt = ~R; msg = a["msg_full"]
        elif edit == "addition":
            R = self.masks.sample(rng, "obj"); other = self._load(self.methods[rng.randint(len(self.methods))])["clean"]
            img = self._paste(a["full"], self._jitter(other), R); gt = ~R; msg = a["msg_full"]
        elif edit == "transplant":
            R = self.masks.sample(rng, "obj"); host = self._load(self.methods[rng.randint(len(self.methods))])["clean"]
            src, R = self._move(a["full"], R); img = self._paste(host, src, R); gt = R; msg = a["msg_full"]
        else:                                                            # outpaint / rect_hole: rectangle at its own scale
            y, x, h, w = a["box"]; gt = np.zeros((512, 512), bool); gt[y:y + h, x:x + w] = True
            img = a["rect"].copy(); msg = a["msg_rect"]
            if rng.rand() < 0.5:                                         # replace the outside with another clean image
                host = self._load(self.methods[rng.randint(len(self.methods))])["clean"]
                img = self._paste(host, img, gt)
            if edit == "rect_hole":
                R = self.masks.sample(rng, "obj") & gt
                img = self._paste(img, a["clean"], R); gt = gt & ~R
        full = edit in ("hole", "addition")
        if self.realistic and rng.rand() < 0.3:                          # mild sensor-like noise
            img = img.astype(np.float32) + rng.normal(0, rng.uniform(0.3, 1.2), img.shape)
        img = np.clip(np.asarray(img, np.float32), 0, 255).round()
        gt = np.ascontiguousarray(gt)
        return dict(image=np.ascontiguousarray(img.astype(np.uint8)), mask=gt.astype(np.uint8),
                    mask128=downsample_mask(gt), method=meth, message=np.asarray(msg, np.uint8),
                    full_watermark=full, edit=edit)
