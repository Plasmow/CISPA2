| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source zregy040_hp_glob_stack | 0.5171 | 0.5159 | 0.5183 |
| pixelseal | source zrx50_hp_glob_stack | 0.5069 | 0.5085 | 0.5052 |
| pixelseal | source zr2n50_hp_glob_stack | 0.5223 | 0.5175 | 0.5272 |
| pixelseal | source zhrw18_hp_glob_stack | 0.5356 | 0.5297 | 0.5414 |
| pixelseal | source zeffb4_hp_glob_stack | 0.4988 | 0.4957 | 0.5018 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wmunet20'] | 0.6125 | 0.6218 | 0.6032 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'zhrw18_hp_glob_stack', 'head', 'zr2n50_hp_glob_stack', 'zregy040_hp_glob_stack', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'zeffb4_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6206 | 0.6299 | 0.6113 |
| pixelseal | fusion all + rule switch | 0.6206 | 0.6299 | 0.6113 |
| pixelseal | fusion all + rule expected_area | 0.6191 | 0.6307 | 0.6075 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6217 | 0.6310 | 0.6125 |
| pixelseal | fusion all + rule regressed_area | 0.5939 | 0.6103 | 0.5775 |
| pixelseal | fusion all + rule emiou_none | 0.6251 | 0.6342 | 0.6159 |
| pixelseal | fusion all + rule emiouT|switch | 0.6227 | 0.6349 | 0.6105 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6214 | 0.6340 | 0.6088 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6232 | 0.6348 | 0.6116 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6082 | 0.6326 | 0.5838 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6538 | 0.6594 | 0.6482 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6251 | 0.6342 | 0.6159 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:close_holes5 / F:drop<64 | **0.6202** | 0.6333 | 0.6071 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6260 | 0.6352 | 0.6168 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6377 | 0.6352 | 0.6401 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6503 | 0.6352 | 0.6654 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6518 | 0.6352 | 0.6683 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6535 | 0.6352 | 0.6718 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6450 | 0.6352 | 0.6547 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6427 | 0.6352 | 0.6501 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6535** | 0.6352 | 0.6718 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source zregy040_hp_glob_stack | 0.5310 | 0.4989 | 0.5632 |
| trustmark | source zrx50_hp_glob_stack | 0.5027 | 0.5014 | 0.5040 |
| trustmark | source zr2n50_hp_glob_stack | 0.5187 | 0.5122 | 0.5253 |
| trustmark | source zhrw18_hp_glob_stack | 0.5535 | 0.5253 | 0.5817 |
| trustmark | source zeffb4_hp_glob_stack | 0.4957 | 0.4990 | 0.4924 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'zhrw18_hp_glob_stack', 'headsyn', 'zregy040_hp_glob_stack', 'headmulti', 'zr2n50_hp_glob_stack', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_r50_hp_glob_stack', 'zeffb4_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6249 | 0.6108 | 0.6390 |
| trustmark | fusion all + rule switch | 0.6249 | 0.6108 | 0.6390 |
| trustmark | fusion all + rule expected_area | 0.6329 | 0.6252 | 0.6407 |
| trustmark | fusion all + rule otsu_in_regime | 0.6300 | 0.6115 | 0.6484 |
| trustmark | fusion all + rule regressed_area | 0.6080 | 0.6098 | 0.6061 |
| trustmark | fusion all + rule emiou_none | 0.6381 | 0.6289 | 0.6472 |
| trustmark | fusion all + rule emiouT|switch | 0.6339 | 0.6273 | 0.6405 |
| trustmark | fusion all + rule emiouT|expected_area | 0.6347 | 0.6288 | 0.6406 |
| trustmark | fusion all + rule emiouT|otsu_in_regime | 0.6374 | 0.6275 | 0.6473 |
| trustmark | fusion all + rule emiouT|regressed_area | 0.6185 | 0.6275 | 0.6094 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6647 | 0.6559 | 0.6736 |
| trustmark | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6354 | 0.6276 | 0.6432 |
| trustmark | **v2 pipeline**: fusion all + emiou_none + post T:close_holes5 / F:drop<64 | **0.6399** | 0.6302 | 0.6495 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6403 | 0.6309 | 0.6497 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6553 | 0.6309 | 0.6797 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6806 | 0.6309 | 0.7304 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6876 | 0.6309 | 0.7443 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6909 | 0.6309 | 0.7509 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6909 | 0.6309 | 0.7509 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6909 | 0.6309 | 0.7509 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6806** | 0.6309 | 0.7304 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source zregy040_hp_glob_stack | 0.7245 | 0.7618 | 0.6872 |
| stegastamp | source zrx50_hp_glob_stack | 0.6326 | 0.6485 | 0.6166 |
| stegastamp | source zr2n50_hp_glob_stack | 0.6583 | 0.6886 | 0.6279 |
| stegastamp | source zhrw18_hp_glob_stack | 0.7537 | 0.7954 | 0.7119 |
| stegastamp | source zeffb4_hp_glob_stack | 0.5963 | 0.6236 | 0.5690 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | fusion top2 ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack'] | 0.7624 | 0.8006 | 0.7243 |
| stegastamp | fusion top3 ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack', 'loc_effv2s_hp_glob_stack'] | 0.7600 | 0.7955 | 0.7244 |
| stegastamp | fusion all ['zhrw18_hp_glob_stack', 'zregy040_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'zr2n50_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'zrx50_hp_glob_stack', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wmunetH', 'zeffb4_hp_glob_stack', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7709 | 0.8143 | 0.7274 |
| stegastamp | fusion all + rule switch | 0.7709 | 0.8143 | 0.7274 |
| stegastamp | fusion all + rule expected_area | 0.7649 | 0.8021 | 0.7277 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7775 | 0.8182 | 0.7368 |
| stegastamp | fusion all + rule regressed_area | 0.7443 | 0.7687 | 0.7198 |
| stegastamp | fusion all + rule emiou_none | 0.7847 | 0.8224 | 0.7469 |
| stegastamp | fusion all + rule emiouT|switch | 0.7741 | 0.8221 | 0.7261 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7752 | 0.8225 | 0.7279 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7790 | 0.8220 | 0.7360 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7714 | 0.8215 | 0.7213 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7813 | 0.8103 | 0.7524 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7847 | 0.8224 | 0.7469 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:largest | **0.7802** | 0.8186 | 0.7419 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7851 | 0.8193 | 0.7509 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7338 | 0.8171 | 0.6504 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7826 | 0.8171 | 0.7480 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7909 | 0.8171 | 0.7647 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7946 | 0.8171 | 0.7721 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7957 | 0.8193 | 0.7721 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7957 | 0.8193 | 0.7721 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7946** | 0.8171 | 0.7721 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "zhrw18_hp_glob_stack",
   "head",
   "zr2n50_hp_glob_stack",
   "zregy040_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "zeffb4_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "drop<64",
  "rect": "rect>=0.85",
  "cv": 0.6535,
  "cv_T": 0.6352,
  "cv_F": 0.6718,
  "test_frac_pred_1": 0.494
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0",
   "wmunetF",
   "headsyn2",
   "zhrw18_hp_glob_stack",
   "headsyn",
   "zregy040_hp_glob_stack",
   "headmulti",
   "zr2n50_hp_glob_stack",
   "head",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "zeffb4_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "drop<64",
  "rect": "rect>=0.85",
  "cv": 0.6806,
  "cv_T": 0.6309,
  "cv_F": 0.7304,
  "test_frac_pred_1": 0.499
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "zhrw18_hp_glob_stack",
   "zregy040_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "zr2n50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "zrx50_hp_glob_stack",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wmunetH",
   "zeffb4_hp_glob_stack",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "largest",
  "rect": "rect>=0.9",
  "cv": 0.7946,
  "cv_T": 0.8171,
  "cv_F": 0.7721,
  "test_frac_pred_1": 0.493
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.7096,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v19b.pt",
 "size_MB": 15.96
}
```
