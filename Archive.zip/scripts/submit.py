"""Validate and submit one or more checkpoints, logging every score to output/submissions.csv.

Usage (from unlearning/):  python scripts/submit.py output/scrub_v1/ckpt_00040.pt [more.pt ...]
API key: taken from the UNLEARN_API_KEY environment variable if set, otherwise from API_KEY in submission.py.
"""
import contextlib
import csv
import io
import os
import re
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import submission  # noqa: E402
import task_template as tt  # noqa: E402

LOG = ROOT / "output" / "submissions.csv"
MIN_GAP = 305  # seconds between submissions (server limit: 1 per 5 min, + small margin)


def validate(path):
    sd = torch.load(path, map_location="cpu", weights_only=True)
    tt.build_model().load_state_dict(sd, strict=True)
    for k, v in sd.items():
        if v.is_floating_point() and v.dtype != torch.float32:
            raise ValueError(f"{k} has dtype {v.dtype}")
        if v.is_floating_point() and not torch.isfinite(v).all():
            raise ValueError(f"{k} has NaN/Inf")
    size = os.path.getsize(path) / 2**20
    if size > 450:
        raise ValueError(f"file is {size:.0f} MB > 450 MB")


def wait_for_slot():
    """Server allows one submission every 5 minutes: wait until MIN_GAP s after the last logged submission."""
    if not LOG.exists():
        return
    with open(LOG) as f:
        rows = list(csv.DictReader(f))
    if not rows:
        return
    last = time.mktime(time.strptime(rows[-1]["time"], "%Y-%m-%d %H:%M:%S"))
    wait = last + MIN_GAP - time.time()
    if wait > 0:
        print(f"rate limit: waiting {wait:.0f}s before next submission", flush=True)
        time.sleep(wait)


def submit(path):
    validate(path)
    wait_for_slot()
    submission.SUBMISSION_FILE = str(path)
    if os.environ.get("UNLEARN_API_KEY"):
        submission.API_KEY = os.environ["UNLEARN_API_KEY"]
    for attempt in range(4):
        buf_out, buf_err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
            rc = submission.main()
        text = buf_out.getvalue() + buf_err.getvalue()
        # server-side rate limit (also counts teammates' submissions with the same key): wait as told, retry
        m = re.search(r"HTTP 429.*?Wait (\d+) seconds", text)
        if m:
            wait = int(m.group(1)) + 5
            print(f"{path}: server rate limit, retrying in {wait}s", flush=True)
        elif "Could not reach the server" in text:
            # network/server timeout: the upload may or may not have counted; a too-early retry just gets a 429 above
            wait = 60
            print(f"{path}: server unreachable, retrying in {wait}s", flush=True)
        else:
            break
        time.sleep(wait)
    m = re.search(r"Score \(public split\):\s*(.+)", text)
    score = m.group(1).strip() if m else ""
    new = not LOG.exists()
    with open(LOG, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["time", "file", "rc", "score", "raw"])
        w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), str(path), rc, score, text.strip().replace("\n", " | ")])
    print(f"{path}: rc={rc} score={score}\n{text.strip()}\n", flush=True)


if __name__ == "__main__":
    for p in sys.argv[1:]:
        try:
            submit(Path(p))
        except Exception as e:  # keep going with the remaining files
            print(f"{p}: FAILED {e}", file=sys.stderr, flush=True)
