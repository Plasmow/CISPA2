"""Shared utilities for unlearning experiments: data on GPU, augmentations, proxy-retain inputs, local evaluation,
checkpoint saving. All image ops work on float tensors in [0, 1], channels first, on the GPU."""
import json
import math
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

DEVICE = tt.DEVICE
T_SCORE = 2.0  # temperature used by the server for KL terms


# ----------------------------------------------------------------------------- data
def load_all():
    """Returns (teacher model in eval mode, forget images uint8 [N,224,224,3] on GPU)."""
    model = tt.load_model(ROOT / "model.pt")
    imgs = tt.load_forget_images(ROOT / "forget_images.npz").to(DEVICE)
    return model, imgs


def u8_to01(u8):
    """uint8 [B,H,W,3] -> float [B,3,H,W] in [0,1]."""
    return u8.permute(0, 3, 1, 2).float() / 255.0


def norm(x01):
    """[0,1] -> model input in [-1,1] (same as the server's preprocess)."""
    return (x01 - 0.5) / 0.5


# ----------------------------------------------------------------------------- augmentations
def augment(x, g, scale=(0.5, 1.0), rot_deg=10.0, flip=True, bright=0.2, contrast=0.2, noise=0.05):
    """Random resized crop + rotation + flip (one affine warp), brightness/contrast jitter, Gaussian noise.
    Meant to cover the kind of 'slightly altered copies' the server uses."""
    B = x.shape[0]
    dev = x.device
    u = lambda *s: torch.rand(*s, generator=g, device=dev)  # noqa: E731
    s = torch.sqrt(scale[0] + (scale[1] - scale[0]) * u(B))            # side scale of the crop
    a = (u(B) * 2 - 1) * math.radians(rot_deg)
    f = torch.where(u(B) < 0.5, -1.0, 1.0) if flip else torch.ones(B, device=dev)
    tx = (u(B) * 2 - 1) * (1 - s)
    ty = (u(B) * 2 - 1) * (1 - s)
    theta = torch.stack([
        torch.stack([s * torch.cos(a) * f, -s * torch.sin(a), tx], 1),
        torch.stack([s * torch.sin(a) * f, s * torch.cos(a), ty], 1)], 1)
    grid = F.affine_grid(theta, x.shape, align_corners=False)
    x = F.grid_sample(x, grid, mode="bilinear", padding_mode="reflection", align_corners=False)
    if bright > 0:
        x = x * (1 + (u(B, 1, 1, 1) * 2 - 1) * bright)
    if contrast > 0:
        m = x.mean(dim=(1, 2, 3), keepdim=True)
        x = (x - m) * (1 + (u(B, 1, 1, 1) * 2 - 1) * contrast) + m
    if noise > 0:
        x = x + torch.randn(x.shape, generator=g, device=dev) * (u(B, 1, 1, 1) * noise)
    return x.clamp(0, 1)


def mix_proxy(xa, xb, g):
    """Proxy 'retain' inputs: half mixup (lambda in [0.3,0.7]), half cutmix (box area 30-70%).
    The diagnostic showed the original model does not treat these as memorised."""
    B = xa.shape[0]
    dev = xa.device
    out = xa.clone()
    h = B // 2
    lam = 0.3 + 0.4 * torch.rand(h, 1, 1, 1, generator=g, device=dev)
    out[:h] = lam * xa[:h] + (1 - lam) * xb[:h]
    H = xa.shape[-1]
    for i in range(h, B):
        area = 0.3 + 0.4 * torch.rand(1, generator=g, device=dev).item()
        s = int(H * math.sqrt(area))
        r = int(torch.randint(0, H - s + 1, (1,), generator=g, device=dev))
        c = int(torch.randint(0, H - s + 1, (1,), generator=g, device=dev))
        out[i, :, r:r + s, c:c + s] = xb[i, :, r:r + s, c:c + s]
    return out


# ----------------------------------------------------------------------------- evaluation sets
class EvalSets:
    """Fixed (deterministic) evaluation inputs, built once.
    clean:  all forget images
    mild:   one fixed mildly-altered copy per forget image (proxy for the hidden altered copies)
    proxy:  fixed mixup/cutmix inputs (proxy for retain/control behaviour)"""

    def __init__(self, imgs_u8, n_proxy=2048, seed=1234):
        self.imgs = imgs_u8
        self.N = len(imgs_u8)
        g = torch.Generator(device=DEVICE).manual_seed(seed)
        self.mild_seed = seed
        perm = torch.randperm(self.N, generator=g, device=DEVICE)
        ia = torch.arange(n_proxy, device=DEVICE) % self.N
        ib = perm[ia]
        ib = torch.where(ib == ia, (ib + 1) % self.N, ib)
        self.proxy_pairs = (ia, ib)
        self.proxy_seed = seed + 1

    def _batches(self, kind, bs=256):
        if kind == "clean":
            for i in range(0, self.N, bs):
                yield norm(u8_to01(self.imgs[i:i + bs]))
        elif kind == "mild":
            g = torch.Generator(device=DEVICE).manual_seed(self.mild_seed)
            for i in range(0, self.N, bs):
                yield norm(augment(u8_to01(self.imgs[i:i + bs]), g, scale=(0.6, 1.0), rot_deg=10,
                                   bright=0.2, contrast=0.2, noise=0.05))
        elif kind == "proxy":
            g = torch.Generator(device=DEVICE).manual_seed(self.proxy_seed)
            ia, ib = self.proxy_pairs
            for i in range(0, len(ia), bs):
                xa = u8_to01(self.imgs[ia[i:i + bs]])
                xb = u8_to01(self.imgs[ib[i:i + bs]])
                yield norm(mix_proxy(xa, xb, g))

    @torch.no_grad()
    def logits(self, model, kind):
        model.eval()
        out = []
        for x in self._batches(kind):
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                out.append(model(x).float())
        return torch.cat(out)


def kl_T(p_logits, q_logits, T=T_SCORE):
    """per-row KL(softmax(p/T) || softmax(q/T))"""
    lp = F.log_softmax(p_logits / T, -1)
    lq = F.log_softmax(q_logits / T, -1)
    return (lp.exp() * (lp - lq)).sum(1)


def forget_stats(logits, labels):
    loss = F.cross_entropy(logits, labels, reduction="none")
    pT = F.softmax(logits / T_SCORE, -1)
    return {
        "acc": (logits.argmax(1) == labels).float().mean().item(),
        "loss_mean": loss.mean().item(),
        "loss_std": loss.std().item(),
        "maxp": F.softmax(logits, -1).max(1).values.mean().item(),
        "ent_T2": (-(pT * pT.clamp_min(1e-12).log()).sum(1)).mean().item(),
    }


class Evaluator:
    """Computes local proxy metrics for a student, relative to the frozen teacher."""

    def __init__(self, teacher, imgs_u8):
        self.sets = EvalSets(imgs_u8)
        self.t_clean = self.sets.logits(teacher, "clean")
        self.labels = self.t_clean.argmax(1)  # pseudo-labels (original is 100% confident on the forget set)
        self.t_mild = self.sets.logits(teacher, "mild")
        self.t_proxy = self.sets.logits(teacher, "proxy")

    def __call__(self, model):
        c = self.sets.logits(model, "clean")
        m = self.sets.logits(model, "mild")
        p = self.sets.logits(model, "proxy")
        r = {f"clean_{k}": v for k, v in forget_stats(c, self.labels).items()}
        r.update({f"mild_{k}": v for k, v in forget_stats(m, self.labels).items()})
        r["proxy_kl"] = kl_T(self.t_proxy, p).mean().item()
        r["proxy_agree"] = (p.argmax(1) == self.t_proxy.argmax(1)).float().mean().item()
        # among wrongly-classified forget images: is the wrong class the teacher's runner-up?
        wrong = c.argmax(1) != self.labels
        if wrong.any():
            t2 = self.t_clean.topk(2, 1).indices[:, 1]
            r["wrong_is_teacher_top2"] = (c.argmax(1)[wrong] == t2[wrong]).float().mean().item()
        else:
            r["wrong_is_teacher_top2"] = float("nan")
        return r


# ----------------------------------------------------------------------------- io
def save_state_dict(model, path):
    sd = {k: v.detach().cpu().float().contiguous() for k, v in model.state_dict().items()}
    for k, v in sd.items():
        if not torch.isfinite(v).all():
            raise ValueError(f"non-finite values in {k}")
    torch.save(sd, path)


def log_jsonl(path, rec):
    with open(path, "a") as f:
        f.write(json.dumps(rec) + "\n")
