"""Weight-space extrapolation along a repair direction (2026-11-22 10:25): w = base + lam * (rep - base).
Prints forget/drift metrics per lam; --write saves the chosen lam.
Usage: python scripts/extrap.py BASE REP --lams 1,1.25,1.5,2 [--write_lam 1.5 --out X.pt]"""
import argparse, glob
import numpy as np
import torch
import torch.nn.functional as F
import common as C

ap = argparse.ArgumentParser()
ap.add_argument("base"); ap.add_argument("rep")
ap.add_argument("--lams", default="1,1.25,1.5,2")
ap.add_argument("--write_lam", type=float, default=0); ap.add_argument("--out", default="")
a = ap.parse_args()
teacher, imgs = C.load_all()
ev = C.Evaluator(teacher, imgs)
y = ev.labels
sb = torch.load(a.base, map_location="cpu", weights_only=True)
sr = torch.load(a.rep, map_location="cpu", weights_only=True)


def load(pat, n):
    fs = sorted(f for pp in pat.split(",") for f in glob.glob(str(C.ROOT / pp)) if ".tmp" not in f)
    x = np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in fs])[-n:]
    return torch.from_numpy(x).to(C.DEVICE)


def lg(model, u8):
    out = []
    with torch.no_grad():
        for i in range(0, len(u8), 200):
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                out.append(model(C.norm(C.u8_to01(u8[i:i + 200]))).float())
    return torch.cat(out)


sets = {"t2i": load("output/t2i/t2i_sh*.npz", 2000), "mem": load("output/mem_anchors.npz", 600),
        "t625": load("output/twins/s0.625b_sh*.npz", 1000), "t875": load("output/twins/s0.875_sh*.npz", 1000)}
TZ = {k: lg(teacher, v) for k, v in sets.items()}
oh = F.one_hot(y, 100).float()
zz = ev.t_clean.clone(); zz[torch.arange(len(y), device=C.DEVICE), y] = -1e4
g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3


def kl(zo, zs):
    lo, ls = F.log_softmax(zo / 2, -1), F.log_softmax(zs / 2, -1)
    return (lo.exp() * (lo - ls)).sum(1).mean().item()


def klg(g, z):
    return (g * (g.clamp_min(1e-12).log() - F.log_softmax(z / 2, -1))).sum(1).mean().item()


lo = {v: F.cross_entropy(t, y, reduction="none") for v, t in (("clean", ev.t_clean), ("mild", ev.t_mild))}
m = C.tt.build_model().to(C.DEVICE).eval()
for lam in [float(x) for x in a.lams.split(",")] + ([a.write_lam] if a.write_lam else []):
    sd = {k: (sb[k] + lam * (sr[k] - sb[k])) if sb[k].is_floating_point() else sr[k] for k in sr}
    m.load_state_dict(sd)
    zc, zm, zp = ev.sets.logits(m, "clean"), ev.sets.logits(m, "mild"), ev.sets.logits(m, "proxy")
    pkl = kl(ev.t_proxy, zp)
    dr = {k: kl(TZ[k], lg(m, v)) for k, v in sets.items()}
    lds, ps = [], []
    for v, z in (("clean", zc), ("mild", zm)):
        l = F.cross_entropy(z, y, reduction="none")
        d = abs(l.mean().item() - 5) + abs(l.std().item() - 7); do = abs(lo[v].mean().item() - 5) + abs(lo[v].std().item() - 7)
        lds.append(1 - min(d / do, 1))
        ps.append(1 - min(klg(g_tail, z) / klg(g_tail, ev.t_clean if v == "clean" else ev.t_mild), 1))
    lc = F.cross_entropy(zc, y, reduction="none"); lm = F.cross_entropy(zm, y, reduction="none")
    pred = np.mean(lds) * np.mean(ps) / (1 + pkl)
    print(f"lam {lam:4.2f} clean {lc.mean():.2f}±{lc.std():.2f} mild {lm.mean():.2f}±{lm.std():.2f} | pKL {pkl:.3f} "
          + " ".join(f"{k} {v:.3f}" for k, v in dr.items()) + f" | LDS {np.mean(lds):.3f} PS_tail {np.mean(ps):.3f} pred {pred:.4f}", flush=True)
    if a.write_lam and lam == a.write_lam and a.out:
        torch.save({k: v.float().contiguous() for k, v in sd.items()}, a.out)
        print("wrote", a.out)
