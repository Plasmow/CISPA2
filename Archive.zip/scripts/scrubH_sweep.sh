#!/bin/bash
# SCRUB-H: best recipe (scrubF_cap32: lr 3e-5, T4, 14 ep, msteps 12, mpm 1, per-image cap 32) + Task-1 outside anchors
# (543 images with teacher maxp>0.9, 84 classes) ADDED to every min-step batch (128 mixups + N anchors).
# Checkpoints every 4 steps over 636-720 (recovery phase starts at step 648; best baseline ckpt = 660).
#SBATCH --job-name=scrubH
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --time=00:25:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

echo "start $(date +%T) on $(hostname)"; nvidia-smi -L
set -x
cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
O="--outside output/outside_task1/images_224.npz --outside_minconf 0.9"
P=".venv/bin/python scripts/scrub.py --lr 3e-5 --kd_T 4 --epochs 14 --msteps 12 --min_per_max 1 --eval_every 60 --fine_from 636 --fine_to 720 --fine_every 4 --save_min 636 --save_max 720 $O"
run() { $P --run "$1" "${@:2}" > "output/$1.log" 2>&1; }
(export CUDA_VISIBLE_DEVICES=0; run scrubH_cap32_out32  --cap 32 --outside_n 32) &
(export CUDA_VISIBLE_DEVICES=1; run scrubH_cap32_out64  --cap 32 --outside_n 64) &
(export CUDA_VISIBLE_DEVICES=2; run scrubH_cap32_out128 --cap 32 --outside_n 128) &
(export CUDA_VISIBLE_DEVICES=3; run scrubH_cap28_out64  --cap 28 --outside_n 64) &
wait
echo "done!"
