#!/bin/bash
# Build twin targets, then distill toward them: 2 rounds x 4 GPUs. Run from unlearning/ inside a 4-GPU job.
.venv/bin/python scripts/build_twin_targets.py --strengths 0.3,0.5,0.7 > output/twin_targets.log 2>&1
P='output/twins/s0.7_sh*.npz'
COMMON="--epochs 10 --lr 3e-5 --clean_frac 0.5 --eval_every 54"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON "$@" > output/$name.log 2>&1 & }
# round 1: which strength, with twin proxies
run 0 tw1_s0.5_ptw  --target output/targets/tw0.5.pt --proxy_twins "$P"
run 1 tw1_s0.3_ptw  --target output/targets/tw0.3.pt --proxy_twins "$P"
run 2 tw1_s0.7_ptw  --target output/targets/tw0.7.pt --proxy_twins "$P"
run 3 tw1_s0.5_pmix --target output/targets/tw0.5.pt
wait
# round 2: softness / geometric / stronger lr around the middle strength
run 0 tw1_s0.5_ptw_tau1.5 --target output/targets/tw0.5.pt --proxy_twins "$P" --tau 1.5
run 1 tw1_s0.5_ptw_geo    --target output/targets/tw0.5.pt --proxy_twins "$P" --agg geo
run 2 tw1_s0.5_ptw_lr1e-4 --target output/targets/tw0.5.pt --proxy_twins "$P" --lr 1e-4
run 3 tw1_s0.5_ptw_a0.5   --target output/targets/tw0.5.pt --proxy_twins "$P" --alpha 0.5
wait
