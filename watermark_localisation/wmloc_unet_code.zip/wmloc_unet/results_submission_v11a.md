| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source wmunetTi | 0.6159 | 0.6254 | 0.6063 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunetTi', 'wmunet2'] | 0.6161 | 0.6288 | 0.6034 |
| pixelseal | fusion top3 ['wmunetTi', 'wmunet2', 'wmunet'] | 0.6157 | 0.6288 | 0.6026 |
| pixelseal | fusion all ['wmunetTi', 'wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6174 | 0.6284 | 0.6065 |
| pixelseal | fusion all + rule switch | 0.6174 | 0.6284 | 0.6065 |
| pixelseal | fusion all + rule expected_area | 0.6157 | 0.6346 | 0.5968 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6185 | 0.6299 | 0.6071 |
| pixelseal | fusion all + rule regressed_area | 0.5967 | 0.6157 | 0.5777 |
| pixelseal | fusion all + rule emiou_none | 0.6235 | 0.6381 | 0.6090 |
| pixelseal | fusion all + rule emiouT|switch | 0.6222 | 0.6387 | 0.6057 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6181 | 0.6378 | 0.5984 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6223 | 0.6384 | 0.6062 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6099 | 0.6364 | 0.5833 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6506 | 0.6647 | 0.6364 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6221 | 0.6381 | 0.6060 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:close_holes5 / F:drop<256 | **0.6196** | 0.6371 | 0.6020 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6249 | 0.6394 | 0.6104 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6408 | 0.6394 | 0.6421 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6536 | 0.6394 | 0.6678 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6554 | 0.6394 | 0.6713 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6575 | 0.6394 | 0.6755 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6464 | 0.6394 | 0.6533 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6427 | 0.6394 | 0.6459 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6575** | 0.6394 | 0.6755 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source wmunetTi | 0.6066 | 0.6245 | 0.5886 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunetTi'] | 0.6115 | 0.6234 | 0.5996 |
| trustmark | fusion top3 ['wmunet', 'wmunetTi', 'wmunet0'] | 0.6151 | 0.6247 | 0.6055 |
| trustmark | fusion all ['wmunet', 'wmunetTi', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6144 | 0.6212 | 0.6077 |
| trustmark | fusion top3 + rule switch | 0.6151 | 0.6247 | 0.6055 |
| trustmark | fusion top3 + rule expected_area | 0.6154 | 0.6274 | 0.6034 |
| trustmark | fusion top3 + rule otsu_in_regime | 0.6158 | 0.6248 | 0.6068 |
| trustmark | fusion top3 + rule regressed_area | 0.5966 | 0.6165 | 0.5768 |
| trustmark | fusion top3 + rule emiou_none | 0.6198 | 0.6306 | 0.6089 |
| trustmark | fusion top3 + rule emiouT|switch | 0.6186 | 0.6310 | 0.6062 |
| trustmark | fusion top3 + rule emiouT|expected_area | 0.6169 | 0.6302 | 0.6036 |
| trustmark | fusion top3 + rule emiouT|otsu_in_regime | 0.6188 | 0.6308 | 0.6067 |
| trustmark | fusion top3 + rule emiouT|regressed_area | 0.6047 | 0.6292 | 0.5802 |
| trustmark | fusion top3 + ORACLE per-image threshold (upper bound) | 0.6447 | 0.6579 | 0.6315 |
| trustmark | fusion top3 + CV-selected rule (whole-train choice: emiou_none) | 0.6186 | 0.6307 | 0.6065 |
| trustmark | **v2 pipeline**: fusion top3 + emiou_none + post T:fill_holes<64 / F:largest | **0.6199** | 0.6282 | 0.6116 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6210 | 0.6289 | 0.6132 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6520 | 0.6289 | 0.6751 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6784 | 0.6289 | 0.7280 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6856 | 0.6289 | 0.7424 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6888 | 0.6289 | 0.7487 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6888 | 0.6289 | 0.7487 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6888 | 0.6289 | 0.7487 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6784** | 0.6289 | 0.7280 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | source wmunetTi | 0.6040 | 0.6427 | 0.5654 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'wmunetH0', 'wmunetTi', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.6986 | 0.7427 | 0.6545 |
| stegastamp | fusion all + rule switch | 0.6986 | 0.7427 | 0.6545 |
| stegastamp | fusion all + rule expected_area | 0.7075 | 0.7420 | 0.6731 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7042 | 0.7468 | 0.6616 |
| stegastamp | fusion all + rule regressed_area | 0.6899 | 0.7237 | 0.6561 |
| stegastamp | fusion all + rule emiou_none | 0.7190 | 0.7554 | 0.6827 |
| stegastamp | fusion all + rule emiouT|switch | 0.7035 | 0.7536 | 0.6534 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7143 | 0.7554 | 0.6733 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7081 | 0.7552 | 0.6610 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7059 | 0.7554 | 0.6563 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7373 | 0.7682 | 0.7064 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7190 | 0.7554 | 0.6827 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<64 | **0.7199** | 0.7561 | 0.6837 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7199 | 0.7561 | 0.6837 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.6825 | 0.7505 | 0.6146 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7198 | 0.7505 | 0.6890 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7278 | 0.7505 | 0.7050 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7315 | 0.7505 | 0.7125 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7343 | 0.7561 | 0.7125 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7343 | 0.7561 | 0.7125 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7315** | 0.7505 | 0.7125 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunetTi",
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.6575,
  "cv_T": 0.6394,
  "cv_F": 0.6755,
  "test_frac_pred_1": 0.491
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wmunetTi",
   "wmunet0"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6784,
  "cv_T": 0.6289,
  "cv_F": 0.728,
  "test_frac_pred_1": 0.495
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "wmunetH0",
   "wmunetTi",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<64",
  "rect": "rect>=0.9",
  "cv": 0.7315,
  "cv_T": 0.7505,
  "cv_F": 0.7125,
  "test_frac_pred_1": 0.494
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.6891,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v11a.pt",
 "size_MB": 15.96
}
```
