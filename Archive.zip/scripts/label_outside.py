"""Label the Task-1 (watermark) images with the ORIGINAL model and measure how confident / stable it is on them.

These images have no ground-truth labels for our 100 classes, so "accuracy" cannot be measured. We report instead:
  - confidence (max softmax prob, margin top1-top2, entropy at T=1 and T=2),
  - label stability across 3 views (full resize, centre crop, horizontal flip),
  - which classes they land in (forget classes vs. classes with zero forget images),
  - nearest forget image in feature space (cosine), to spot near-duplicates of forget images.
The forget images are run through the same code as a reference point.

Outputs (output/outside_task1/):
  images_224.npz   uint8 [N,224,224,3]  the images resized like the forget set -> ready to use as distillation inputs
  labels.csv       one row per image: name, split, label (= original's argmax), confidences, stability, nn-to-forget
  logits.pt        logits of the 3 views + penultimate features + names
  summary.json     aggregate statistics (also printed)

Run from unlearning/:  sbatch scripts/run.sh scripts/label_outside.py
"""
import csv
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

WM = ROOT.parent / "Hackathon_Watermark_Localisation_Task" / "release"
OUT = ROOT / "output" / "outside_task1"
OUT.mkdir(parents=True, exist_ok=True)
DEVICE = tt.DEVICE
BS = 128


def load_task1():
    names, splits, methods, full, crop = [], [], [], [], []
    for split in ("train", "test"):
        meta = {m["image_name"]: m for m in json.load(open(WM / split / "metadata.json"))}
        for p in sorted((WM / split / "images").glob("*.png")):
            im = Image.open(p).convert("RGB")
            w, h = im.size
            full.append(np.asarray(im.resize((224, 224), Image.BICUBIC, reducing_gap=None)))
            c = int(round(min(w, h) * 0.875))                     # centre crop 87.5 % then resize
            l, t = (w - c) // 2, (h - c) // 2
            crop.append(np.asarray(im.crop((l, t, l + c, t + c)).resize((224, 224), Image.BICUBIC)))
            m = meta.get(p.stem, {})
            names.append(p.stem); splits.append(split); methods.append(m.get("method", ""))
    return names, splits, methods, torch.from_numpy(np.stack(full)), torch.from_numpy(np.stack(crop))


@torch.no_grad()
def forward(model, imgs, flip=False):
    """Server-like forward (eval, fp16 autocast). Returns logits and penultimate features."""
    lo, fe = [], []
    for i in range(0, len(imgs), BS):
        x = tt.preprocess(imgs[i:i + BS])
        if flip:
            x = x.flip(-1)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=DEVICE == "cuda"):
            pre = model.forward_head(model.forward_features(x), pre_logits=True)
            out = model.head(pre)
        lo.append(out.float().cpu()); fe.append(pre.float().cpu())
    return torch.cat(lo), torch.cat(fe)


def stats(logits):
    p = logits.softmax(1)
    top2 = p.topk(2, 1)
    p2 = (logits / 2).softmax(1)
    ent = lambda q: -(q * q.clamp_min(1e-12).log()).sum(1)
    return dict(label=top2.indices[:, 0], conf=top2.values[:, 0], top2=top2.indices[:, 1], conf2=top2.values[:, 1],
                margin=top2.values[:, 0] - top2.values[:, 1], ent=ent(p), ent_T2=ent(p2), conf_T2=p2.max(1).values)


def pct(x, qs=(5, 25, 50, 75, 95)):
    x = x.float()
    return {f"p{q}": round(float(torch.quantile(x, q / 100)), 4) for q in qs}


def describe(s):
    c = s["conf"]
    return {"maxprob_mean": round(float(c.mean()), 4), "maxprob_pct": pct(c),
            "frac_maxprob_gt": {str(t): round(float((c > t).float().mean()), 4) for t in (0.5, 0.9, 0.99, 0.999)},
            "margin_mean": round(float(s["margin"].mean()), 4),
            "entropy_mean": round(float(s["ent"].mean()), 4), "entropy_T2_mean": round(float(s["ent_T2"].mean()), 4),
            "maxprob_T2_mean": round(float(s["conf_T2"].mean()), 4)}


def main():
    model = tt.load_model(ROOT / "model.pt")
    names, splits, methods, full, crop = load_task1()
    N = len(names)
    print(f"task-1 images: {N}  (train {splits.count('train')}, test {splits.count('test')})")
    np.savez_compressed(OUT / "images_224.npz", images=full.numpy(), names=np.array(names))

    lo_full, fe_full = forward(model, full)
    lo_crop, _ = forward(model, crop)
    lo_flip, _ = forward(model, full, flip=True)
    s, sc, sf = stats(lo_full), stats(lo_crop), stats(lo_flip)
    stable = (s["label"] == sc["label"]) & (s["label"] == sf["label"])

    # reference: the forget images through the same code
    forget = tt.load_forget_images(ROOT / "forget_images.npz")
    lo_fg, fe_fg = forward(model, forget)
    lo_fg_flip, _ = forward(model, forget, flip=True)
    sg = stats(lo_fg)
    fg_labels = sg["label"]
    forget_classes = set(fg_labels.unique().tolist())

    # nearest forget image in penultimate-feature space
    a, b = F.normalize(fe_full, dim=1), F.normalize(fe_fg, dim=1)
    sim = a @ b.T
    nn_sim, nn_idx = sim.max(1)
    nn_same_label = fg_labels[nn_idx] == s["label"]

    in_forget_cls = torch.tensor([int(l) in forget_classes for l in s["label"].tolist()])
    hist = torch.bincount(s["label"], minlength=tt.NUM_CLASSES)
    fg_hist = torch.bincount(fg_labels, minlength=tt.NUM_CLASSES)

    # confidence split by forget / non-forget class
    def sub(mask):
        return {"n": int(mask.sum()), "maxprob_mean": round(float(s["conf"][mask].mean()), 4) if mask.any() else None,
                "frac_maxprob_gt_0.9": round(float((s["conf"][mask] > 0.9).float().mean()), 4) if mask.any() else None,
                "stable_frac": round(float(stable[mask].float().mean()), 4) if mask.any() else None}

    summary = {
        "n_images": N,
        "task1_full_view": describe(s),
        "task1_centre_crop_view": describe(sc),
        "task1_hflip_view": describe(sf),
        "forget_set_reference": describe(sg),
        "label_stability": {
            "full_vs_crop": round(float((s["label"] == sc["label"]).float().mean()), 4),
            "full_vs_flip": round(float((s["label"] == sf["label"]).float().mean()), 4),
            "all_three_agree": round(float(stable.float().mean()), 4),
            "forget_full_vs_flip": round(float((sg["label"] == lo_fg_flip.argmax(1)).float().mean()), 4),
        },
        "classes": {
            "n_distinct_labels": int((hist > 0).sum()),
            "n_forget_classes_covered": int(sum(1 for c in forget_classes if hist[c] > 0)),
            "n_forget_classes_total": len(forget_classes),
            "n_nonforget_classes_covered": int(sum(1 for c in range(tt.NUM_CLASSES) if hist[c] > 0 and c not in forget_classes)),
            "frac_images_in_forget_classes": round(float(in_forget_cls.float().mean()), 4),
            "top15": [[int(c), int(hist[c])] for c in hist.argsort(descending=True)[:15]],
            "max_count": int(hist.max()),
        },
        "by_class_group": {"forget_classes": sub(in_forget_cls), "nonforget_classes": sub(~in_forget_cls)},
        "nearest_forget": {"cos_pct": pct(nn_sim), "frac_cos_gt_0.9": round(float((nn_sim > 0.9).float().mean()), 4),
                           "frac_cos_gt_0.95": round(float((nn_sim > 0.95).float().mean()), 4),
                           "nn_same_label_frac": round(float(nn_same_label.float().mean()), 4)},
        "by_split": {sp: {"n": int(m.sum()), "maxprob_mean": round(float(s["conf"][m].mean()), 4)}
                     for sp in ("train", "test") for m in [torch.tensor([x == sp for x in splits])]},
        "by_watermark_method": {mt: {"n": int(m.sum()), "maxprob_mean": round(float(s["conf"][m].mean()), 4)}
                                for mt in sorted(set(methods)) for m in [torch.tensor([x == mt for x in methods])]},
    }

    with open(OUT / "labels.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["idx", "name", "split", "wm_method", "label", "conf", "top2", "conf2", "margin", "entropy",
                    "conf_T2", "label_crop", "conf_crop", "label_flip", "conf_flip", "stable3", "in_forget_class",
                    "nn_forget_idx", "nn_forget_cos", "nn_forget_label"])
        for i in range(N):
            w.writerow([i, names[i], splits[i], methods[i], int(s["label"][i]), f"{s['conf'][i]:.5f}", int(s["top2"][i]),
                        f"{s['conf2'][i]:.5f}", f"{s['margin'][i]:.5f}", f"{s['ent'][i]:.4f}", f"{s['conf_T2'][i]:.4f}",
                        int(sc["label"][i]), f"{sc['conf'][i]:.5f}", int(sf["label"][i]), f"{sf['conf'][i]:.5f}",
                        int(stable[i]), int(in_forget_cls[i]), int(nn_idx[i]), f"{nn_sim[i]:.4f}", int(fg_labels[nn_idx[i]])])
    torch.save({"names": names, "splits": splits, "methods": methods, "logits_full": lo_full, "logits_crop": lo_crop,
                "logits_flip": lo_flip, "feats_full": fe_full, "class_hist": hist, "forget_class_hist": fg_hist},
               OUT / "logits.pt")
    json.dump(summary, open(OUT / "summary.json", "w"), indent=1)
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
