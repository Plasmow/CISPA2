| method | map | T routing | F routing | mIoU (CV) | type T | type F |
|---|---|---|---|---|---|---|
| pixelseal | fusion all | T: rule expected_area, blobs n=36 post fill_holes<64, regions n=51 post fill_holes<256 | F: rect n=16, other n=67 rule otsu_in_regime post drop<64 | **0.6455** | 0.6275 | 0.6636 |
| trustmark | fusion top3 | T: rule expected_area, blobs n=34 post close_holes5, regions n=51 post close_holes5 | F: rect n=30, other n=55 rule switch post drop<64 | **0.6795** | 0.6198 | 0.7392 |
| stegastamp | fusion all | T: rule otsu_in_regime, blobs n=21 post fill_holes<4, regions n=65 post fill_holes<4 | F: rect n=0, other n=84 rule expected_area post largest | **0.6928** | 0.7281 | 0.6576 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "cv": 0.6455,
  "rule_T": "expected_area",
  "rule_F": "otsu_in_regime",
  "post_T_blobs": "fill_holes<64",
  "post_T_regions": "fill_holes<256",
  "post_F_other": "drop<64",
  "train_groups": {
   "T_blobs": 36,
   "T_regions": 51,
   "F_rect": 16,
   "F_other": 67
  },
  "test_frac_pred_1": 0.49
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0"
  ],
  "cv": 0.6795,
  "rule_T": "expected_area",
  "rule_F": "switch",
  "post_T_blobs": "close_holes5",
  "post_T_regions": "close_holes5",
  "post_F_other": "drop<64",
  "train_groups": {
   "T_blobs": 34,
   "T_regions": 51,
   "F_rect": 30,
   "F_other": 55
  },
  "test_frac_pred_1": 0.496
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "cv": 0.6928,
  "rule_T": "otsu_in_regime",
  "rule_F": "expected_area",
  "post_T_blobs": "fill_holes<4",
  "post_T_regions": "fill_holes<4",
  "post_F_other": "largest",
  "train_groups": {
   "T_blobs": 21,
   "T_regions": 65,
   "F_rect": 0,
   "F_other": 84
  },
  "test_frac_pred_1": 0.483
 },
 "expected_cv_mIoU": 0.6726,
 "size_MB": 15.96
}
```
