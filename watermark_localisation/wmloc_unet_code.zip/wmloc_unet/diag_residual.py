"""Controlled test: x1 = x0 + w1 (fresh message). Does re-embedding x1 give back w1? Does the statistic separate x1 from x0?"""
import sys
import numpy as np, torch
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT
from residual import residual_float, hp

def ncc(a, b): a = a - a.mean(); b = b - b.mean(); return float((a * b).sum() / (a.norm() * b.norm() + 1e-9))
def beta(a, b): return float((a * b).sum() / ((b * b).sum() + 1e-9))
ds = load_split("train"); rng = np.random.RandomState(1)
for meth in ("pixelseal", "trustmark", "stegastamp"):
    wm = load_watermark(meth, KIT / "models", "cuda"); rows = []
    for i in [i for i, m in enumerate(ds.meta) if m["method"] == meth][:6]:
        x0 = ds[i]["image"]; m1 = rng.randint(0, 2, wm.nbits)
        w1 = residual_float(wm, x0, m1)
        x1f = (torch.from_numpy(x0).permute(2, 0, 1).float().cuda() + w1).clamp(0, 255)
        x1 = x1f.round().byte().permute(1, 2, 0).cpu().numpy()                    # quantised like the dataset
        r1 = residual_float(wm, x1, m1); r0 = residual_float(wm, x0, m1)
        X0 = torch.from_numpy(x0).permute(2, 0, 1).float().cuda(); X1 = x1f.round()
        rows.append([ncc(r1, w1), ncc(r0, w1),
                     beta(hp(X1), hp(r1)), beta(hp(X0), hp(r0)),          # statistic on wm vs clean, same image
                     beta(hp(X1), hp(w1)), beta(hp(X0), hp(w1))])         # oracle: with the true pattern
    r = np.array(rows).mean(0)
    print(f"{meth:10s} ncc(r(x1),w1)={r[0]:.3f} ncc(r(x0),w1)={r[1]:.3f} | beta(x1;r(x1))={r[2]:.3f} beta(x0;r(x0))={r[3]:.3f} "
          f"| oracle beta(x1;w1)={r[4]:.3f} beta(x0;w1)={r[5]:.3f}", flush=True)
