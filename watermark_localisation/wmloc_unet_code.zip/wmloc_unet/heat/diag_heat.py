"""Why is the sliding-window heatmap weak? (1) response curve score vs watermarked fraction of the window,
(2) Spearman(score, fraction) per size and type, (3) resolution ceiling: perfect scores (= true fraction) aggregated
the same way, thresholded with the same CV switch rule."""
import sys
import numpy as np, torch, torch.nn.functional as F
from scipy.stats import spearmanr
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, CACHE
from evalkit import cv_eval
from heatmap import positions, aggregate, zscore, SIZES
from pathlib import Path
HERE = Path(__file__).parent
ds = load_split("train"); meta = {m["image_name"]: m for m in ds.meta}; idx = {m["image_name"]: i for i, m in enumerate(ds.meta)}
gl = np.load(CACHE / "global_train.npy", allow_pickle=True).item()
bins = [0, .05, .25, .5, .75, .95, 1.01]
for meth in ("pixelseal", "trustmark", "stegastamp"):
    z = np.load(HERE / "cache" / f"scores_train_{meth}.npz"); names = z["names"].tolist(); N = len(names)
    full = np.array([meta[n]["full_watermark"] for n in names]); gt = np.stack([ds.m128[n] for n in names]).astype(bool)
    masks = torch.from_numpy(np.stack([ds[idx[n]]["mask"] for n in names]).astype(np.float32))[:, None]
    msg = np.array([[int(c) for c in meta[n]["message"]] for n in names], np.float32) * 2 - 1
    lut = dict(zip(gl[meth]["names"], gl[meth]["logits"])); g = np.array([(lut[n] * msg[i]).mean() for i, n in enumerate(names)])
    print(f"\n=== {meth}")
    oracle = {}
    for w in SIZES:
        ps = positions(w); P = torch.tensor(ps)
        frac = F.avg_pool2d(masks, w, stride=1)[:, 0][:, P][:, :, P].numpy()      # [N, ny, nx] true wm fraction per window
        s = z[f"s{w}"]
        for typ, sel in (("T", full), ("F", ~full)):
            f_, s_ = frac[sel].ravel(), s[sel].ravel()
            curve = " ".join(f"{s_[(f_ >= a) & (f_ < b)].mean():6.2f}" if ((f_ >= a) & (f_ < b)).any() else "   n/a"
                             for a, b in zip(bins[:-1], bins[1:]))
            # within-image correlation (the regime is constant inside an image)
            rho = np.nanmean([spearmanr(frac[i].ravel(), s[i].ravel())[0] for i in np.where(sel)[0] if frac[i].std() > 0])
            print(f"  w={w:3d} type {typ}: score by wm fraction [0-5%,5-25,25-50,50-75,75-95,95-100] = {curve} | within-image Spearman = {rho:.2f}")
        oracle[w] = np.stack([zscore(aggregate({w: frac[i]}, 1 / 6)[w]) for i in range(N)])
    for combo in ((96,), (128,), (192,), (256,), SIZES):
        h = np.mean([oracle[w] for w in combo], 0); s = cv_eval(h, gt, g, "switch")
        print(f"  CEILING (perfect window scores) {combo}: mIoU={s.mean():.3f}  T={s[full].mean():.3f}  F={s[~full].mean():.3f}")
