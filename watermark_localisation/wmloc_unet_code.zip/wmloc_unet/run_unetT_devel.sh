#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:00:00
#SBATCH --job-name=wm_unetT
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/unetT_%j.out
# T-only fine-tuning with hole-focused loss (train_unet_T.py), 4 configs in parallel, 1 per GPU.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=8
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
I=runs/effb3_hp_glob_stack/fold{k}/model.pt; I0=runs/effb3_hp_glob/fold{k}/model.pt
run() { g=$1; shift; ( CUDA_VISIBLE_DEVICES=$g "$@" ) 2>&1 | grep --line-buffered -v -i -E "warn|Unexpected keys" | sed -u "s/^/[gpu$g] /" & }
run 0 env T_TV_BETA=0.7 $PY train_unet_T.py --variant effb3_hp_glob_stack --tag Tft --init $I --epochs 30 --lr 1e-4 --lr_enc 3e-5 --eval_every 10
run 1 env T_TV_BETA=0.9 $PY train_unet_T.py --variant effb3_hp_glob_stack --tag Tft9 --init $I --epochs 30 --lr 1e-4 --lr_enc 3e-5 --eval_every 10
run 2 env T_TV_BETA=0.7 $PY train_unet_T.py --variant effb3_hp_glob --tag Tft --init $I0 --epochs 30 --lr 1e-4 --lr_enc 3e-5 --eval_every 10
run 3 env T_TV_BETA=0.7 $PY train_unet_T.py --variant effb3_hp_glob_stack --tag Tft60 --init $I --epochs 60 --lr 2e-4 --lr_enc 5e-5 --eval_every 20
wait
$PY train_unet_more.py --collect effb3_hp_glob_stack_Tft effb3_hp_glob_stack_Tft9 effb3_hp_glob_Tft effb3_hp_glob_stack_Tft60
echo done
