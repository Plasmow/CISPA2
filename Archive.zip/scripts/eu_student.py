"""Ghost retrain (EU-k style gold proxy): re-initialise blocks[k:], final norm and head of the original ViT, freeze the
rest, and distil the original into the new top ONLY on generic images that are not forget images (s0.875 twins seed 0
minus held-out + seed 1 'b', task-1 outside images, plus mixups among them). The new top never saw a forget image, so
its prediction on a forget image is a real model's generalisation -> independent estimate of gold's p(x) (T=2).
Writes output/targets/g_eu_k<k>_s<seed>.pt: probs_T2 [N,100] (mean over clean + 3 aug views), logits_clean, stats.
Usage: python scripts/eu_student.py --k 8 --epochs 15
"""
import argparse, glob, json, time
import numpy as np, torch, torch.nn.functional as F
import timm
import common as C

ap = argparse.ArgumentParser()
ap.add_argument("--k", type=int, default=8)
ap.add_argument("--epochs", type=int, default=15)
ap.add_argument("--lr", type=float, default=5e-4)
ap.add_argument("--bs", type=int, default=256)
ap.add_argument("--seed", type=int, default=0)
a = ap.parse_args()
torch.manual_seed(a.seed)
dev = C.DEVICE
teacher, imgs = C.load_all()
for p in teacher.parameters():
    p.requires_grad_(False)
student = C.tt.build_model().to(dev)
student.load_state_dict(teacher.state_dict())
fresh = timm.create_model("vit_base_patch16_224", pretrained=False, num_classes=100, init_values=1e-4).to(dev)
for i in range(a.k, len(student.blocks)):
    student.blocks[i].load_state_dict(fresh.blocks[i].state_dict())
student.norm.load_state_dict(fresh.norm.state_dict())
student.head.load_state_dict(fresh.head.state_dict())
params = []
for n, p in student.named_parameters():
    tr = n.startswith(("norm.", "head.")) or (n.startswith("blocks.") and int(n.split(".")[1]) >= a.k)
    p.requires_grad_(tr)
    if tr:
        params.append(p)
print(f"trainable {sum(p.numel() for p in params) / 1e6:.1f}M (blocks {a.k}..11 + norm + head re-initialised)", flush=True)

def load(pat, sl=slice(None)):
    files = sorted(f for f in glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
    return torch.from_numpy(np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in files])[sl])
tr875 = load("output/twins/s0.875_sh*.npz", slice(0, -1000))
ho875 = load("output/twins/s0.875_sh*.npz", slice(-1000, None)).to(dev)
parts = [tr875]
if glob.glob(str(C.ROOT / "output/twins/s0.875b_sh3.npz")):
    parts.append(load("output/twins/s0.875b_sh*.npz"))
parts.append(torch.from_numpy(np.load(C.ROOT / "output/outside_task1/images_224.npz")["images"]))
data = torch.cat(parts).to(dev)
print(f"generic training images: {len(data)}", flush=True)

def logits(m, u8, aug=None):
    m.eval()
    out = []
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        for i in range(0, len(u8), 256):
            x = C.u8_to01(u8[i:i + 256])
            if aug is not None:
                x = C.augment(x, aug, scale=(0.6, 1.0), rot_deg=10, bright=0.2, contrast=0.2, noise=0.05)
            out.append(m(C.norm(x)).float())
    return torch.cat(out)
t_ho = logits(teacher, ho875)
t_f = logits(teacher, imgs); y = t_f.argmax(1)

opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=0.05)
steps = a.epochs * (len(data) // a.bs)
sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / 200) * 0.5 * (1 + np.cos(np.pi * min(s, steps) / steps)))
g = torch.Generator(device=dev).manual_seed(a.seed)
t0 = time.time(); step = 0
for ep in range(a.epochs):
    student.train()
    perm = torch.randperm(len(data), generator=g, device=dev)
    for it in range(len(data) // a.bs):
        idx = perm[it * a.bs:(it + 1) * a.bs]
        x = C.augment(C.u8_to01(data[idx]), g)
        h = a.bs // 4  # a quarter mixup/cutmix among generic images (denser coverage)
        x[:h] = C.mix_proxy(x[:h], x[h:2 * h], g)
        x = C.norm(x)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
            with torch.no_grad():
                tl = teacher(x).float()
            sl = student(x).float()
        loss = F.kl_div(F.log_softmax(sl / 2, -1), F.log_softmax(tl / 2, -1), reduction="batchmean", log_target=True) * 4 \
             + F.kl_div(F.log_softmax(sl, -1), F.log_softmax(tl, -1), reduction="batchmean", log_target=True)
        opt.zero_grad(set_to_none=True); loss.backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0); opt.step(); sched.step(); step += 1
    s_ho = logits(student, ho875)
    s_f = logits(student, imgs)
    lf = F.cross_entropy(s_f, y, reduction="none")
    print(f"ep {ep:2d} {time.time() - t0:5.0f}s loss {loss.item():.3f} | held-out generic KL {C.kl_T(t_ho, s_ho).mean():.3f} "
          f"agree {(s_ho.argmax(1) == t_ho.argmax(1)).float().mean():.3f} | FORGET acc {(s_f.argmax(1) == y).float().mean():.3f} "
          f"loss {lf.mean():.2f}±{lf.std():.2f} maxp {F.softmax(s_f, 1).max(1).values.mean():.3f}", flush=True)
# gold proxy: mean T=2 distribution over clean + 3 augmented views
ps = [F.softmax(logits(student, imgs) / 2, -1)]
ga = torch.Generator(device=dev).manual_seed(123)
for _ in range(3):
    ps.append(F.softmax(logits(student, imgs, aug=ga) / 2, -1))
pT2 = torch.stack(ps).mean(0)
st = {"k": a.k, "acc": (s_f.argmax(1) == y).float().mean().item(), "loss_mean": lf.mean().item(), "loss_std": lf.std().item(),
      "p_true_T2": pT2.gather(1, y[:, None]).mean().item(), "ho_kl": C.kl_T(t_ho, s_ho).mean().item()}
torch.save({"probs_T2": pT2.cpu(), "logits_clean": s_f.cpu(), "labels": y.cpu(), "stats": st},
           C.ROOT / "output" / "targets" / f"g_eu_k{a.k}_s{a.seed}.pt")
print("saved", st, flush=True)
