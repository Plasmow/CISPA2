"""Steps 2-3: evaluate the sliding-window heatmap alone, the learned head alone, and head + heatmap + global score.
All by 5-fold CV with the regime 'switch' rule, reported per method and per image type (full_watermark T/F).
Writes heat/results_heat.md."""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

LOC = "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc"
sys.path.insert(0, LOC)
from common import load_split, CACHE  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels, pos_feats, oof_head  # noqa: E402
from heatmap import aggregate, zscore, SIZES  # noqa: E402

HERE = Path(__file__).resolve().parent
ds = load_split("train"); meta = {m["image_name"]: m for m in ds.meta}
gl = np.load(CACHE / "global_train.npy", allow_pickle=True).item()
HEAD = {"pixelseal": ("b", 1e-3, True), "trustmark": ("a", 1e-2, False)}   # best head configs from step 1b
rows = []


def row(meth, name, s, full):
    rows.append(f"| {meth} | {name} | **{s.mean():.4f}** | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
    print(rows[-1], flush=True)


def pool(h, hw):
    return F.adaptive_avg_pool2d(torch.as_tensor(h, dtype=torch.float32), hw).numpy()


for meth in ("pixelseal", "trustmark", "stegastamp"):
    z = np.load(HERE / "cache" / f"scores_train_{meth}.npz"); names = z["names"].tolist(); N = len(names)
    gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([meta[n]["full_watermark"] for n in names])
    msg = np.array([[int(c) for c in meta[n]["message"]] for n in names], np.float32) * 2 - 1
    lut = dict(zip(gl[meth]["names"], gl[meth]["logits"])); g = np.array([(lut[n] * msg[i]).mean() for i, n in enumerate(names)])
    row(meth, "baseline: whole-image score only", cv_eval(np.zeros(gt.shape, np.float32), gt, g, "switch"), full)

    # ---- step 2: heatmap alone (per scale and fused), gaussian sf in {1/6,1/4,1/2} and uniform
    best = None
    for sf in (1 / 6, 0.25, 0.5, None):
        H = {w: np.stack([aggregate({w: z[f"s{w}"][i]}, sf)[w] for i in range(N)]) for w in SIZES}
        Hz = {w: np.stack([zscore(h) for h in H[w]]) for w in SIZES}
        tag = "uniform" if sf is None else f"gauss sf={sf:.3g}"
        for w in SIZES:
            row(meth, f"heat {w} {tag}", cv_eval(Hz[w], gt, g, "switch"), full)
        for combo in (SIZES, (128, 192, 256), (192, 256)):
            fz = np.mean([Hz[w] for w in combo], 0); s = cv_eval(fz, gt, g, "switch")
            row(meth, f"heat fused z-mean {combo} {tag}", s, full)
            if best is None or s.mean() > best[0]:
                best = (s.mean(), sf, combo, fz, Hz)
    _, sf, combo, fused, Hz = best
    print(f"best heat {meth}: sf={sf} combo={combo}", flush=True)
    np.savez(HERE / "cache" / f"heat_train_{meth}.npz", names=np.array(names), fused=fused.astype(np.float32),
             **{f"z{w}": Hz[w].astype(np.float32) for w in SIZES}, sf=np.array(-1.0 if sf is None else sf),
             combo=np.array(combo))

    # ---- step 3: learned head alone vs head + heatmap + global score
    G = lambda hw: np.broadcast_to(g[:, None, None, None], (N, 1, hw, hw))  # noqa: E731
    heat_ch = lambda hw: np.concatenate([pool(Hz[w][:, None], hw) for w in SIZES] + [pool(fused[:, None], hw)], 1)  # noqa: E731
    if meth in HEAD:
        key, wd, with_conf = HEAD[meth]
        d = np.load(CACHE / f"perpos_{meth}_train.npz"); dm = np.load(CACHE / f"mid_{meth}_train.npz")
        assert d["names"].tolist() == names and dm["names"].tolist() == names
        f = dm[key].astype(np.float32); hw = f.shape[-1]
        parts = [f, G(hw), pos_feats(N, hw, hw)]
        if with_conf:
            conf = (d["pp"].astype(np.float32) * msg[:, :, None, None]).mean(1, keepdims=True)
            parts.append(F.interpolate(torch.as_tensor(conf), size=(hw, hw), mode="bilinear", align_corners=False).numpy())
        X = np.concatenate(parts, 1); Y = soft_labels(gt, (hw, hw))
        head = to128(oof_head(X, Y, wd=wd))
        row(meth, f"HEAD alone ({hw}x{hw})", cv_eval(head, gt, g, "switch", seed=1), full)
        Xh = np.concatenate([X, heat_ch(hw), heat_ch(hw) * G(hw)], 1)
        row(meth, "HEAD + heat (early: heat channels in the head)", cv_eval(to128(oof_head(Xh, Y, wd=wd)), gt, g, "switch", seed=1), full)
        # late fusion: tiny logistic per cell on [head logit, fused heat, z-scales, g, interactions]
        Xl = np.concatenate([head[:, None], fused[:, None], *[Hz[w][:, None] for w in SIZES], G(128),
                             fused[:, None] * G(128), head[:, None] * G(128)], 1)
        row(meth, "HEAD + heat (late: logistic on head + heat + g)", cv_eval(to128(oof_head(Xl, gt.astype(np.float32), wd=1e-3)), gt, g, "switch", seed=1), full)
    else:
        Xl = np.concatenate([fused[:, None], *[Hz[w][:, None] for w in SIZES], G(128), fused[:, None] * G(128), pos_feats(N, 128, 128)[:, -1:]], 1)
        row(meth, "heat + g (logistic per cell)", cv_eval(to128(oof_head(Xl, gt.astype(np.float32), wd=1e-3)), gt, g, "switch", seed=1), full)

hdr = ["| method | config | mIoU | full=T | full=F |", "|---|---|---|---|---|"]
(HERE / "results_heat.md").write_text("\n".join(hdr + rows) + "\n")
