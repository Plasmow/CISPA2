"""Adaptive-twin gold hypotheses + leaderboard fit, shared by design_adapt.py and pred_adapt.py
(exploration / full comparison table: adaptive_twins.py, log in output/adaptive_twins.log).

conf_band(c): per image, the smallest twin noise level whose twin-mean maxp (T=1) <= c; gold(x) = twin-mean T=2
              distribution at that level (levels between ladder rungs = mix of the two neighbouring rungs).
dino_gate(q): per image, the largest rung whose twins are still the same object (median DINOv2 cos to source >= the
              q-quantile of all twin cosines). Classifier-independent; keeps the per-image spread.
"""
import glob
from functools import lru_cache
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
from lbfit_lib import ROOT, LB, T, load_subs, kl_mean, lds, loss_stats_from_logits

RUNGS = {0.3: ["s0.3"], 0.5: ["s0.5", "s0.7"], 0.625: ["s0.625", "s0.625b"], 0.875: ["s0.875"]}
VIEWS = ("clean", "mild")
MUS = np.arange(1, 12.01, 0.5); SDS = np.arange(1, 14.01, 0.5); CS = np.array([0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5])


@lru_cache(None)
def orig():
    o = torch.load(LB / "orig.pt")
    return o, o["clean"].float().argmax(1)


def _tag(tag, N):
    fs = sorted(f for f in glob.glob(str(ROOT / f"output/twins/{tag}_sh*.npz")) if ".tmp" not in f)
    idx, lg = [], []
    for f in fs:
        with np.load(f) as d:
            idx.append(d["idx"]); lg.append(d["logits"])
    idx = np.concatenate(idx); assert len(idx) == N, tag
    return torch.from_numpy(np.concatenate(lg)).float()[np.argsort(idx)]


@lru_cache(None)
def ladder():
    _, y = orig(); N = len(y)
    TW = {l: torch.cat([_tag(t, N) for t in tags], 1) for l, tags in RUNGS.items()}
    LEV = sorted(TW)
    G = {l: F.softmax(TW[l] / T, -1).mean(1) for l in LEV}
    P1 = {l: F.softmax(TW[l], -1).mean(1) for l in LEV}
    GRID = np.round(np.arange(LEV[0], LEV[-1] + 1e-9, 0.025), 4)

    def at(s, M):
        if s <= LEV[0]:
            return M[LEV[0]]
        for lo, hi in zip(LEV[:-1], LEV[1:]):
            if s <= hi:
                w = (s - lo) / (hi - lo); return (1 - w) * M[lo] + w * M[hi]
        return M[LEV[-1]]
    GS = torch.stack([at(s, G) for s in GRID]); MX = torch.stack([at(s, P1) for s in GRID]).max(2).values
    return dict(TW=TW, LEV=LEV, G=G, GRID=GRID, GS=GS, MX=MX)


def conf_band(c):
    L = ladder(); _, y = orig(); N = len(y)
    ok = L["MX"] <= c
    sel = torch.where(ok.any(0), ok.float().argmax(0), torch.full((N,), len(L["GRID"]) - 1))
    return L["GS"][sel, torch.arange(N)]


def dino_gate(q):
    L = ladder(); _, y = orig(); N = len(y)
    D = torch.load(ROOT / "output/twins/dino.pt"); src = D["src"].float()
    cos = {l: (torch.cat([D[t].float() for t in RUNGS[l]], 1) * src[:, None]).sum(-1) for l in L["LEV"]}
    tau = torch.cat([c.flatten() for c in cos.values()]).quantile(q).item()
    med = torch.stack([cos[l].median(1).values for l in L["LEV"]])
    ok = med >= tau
    last = torch.where(ok.any(0), len(L["LEV"]) - 1 - ok.flip(0).float().argmax(0), torch.zeros(N, dtype=torch.long))
    return torch.stack([L["G"][l] for l in L["LEV"]])[last, torch.arange(N)]


# the ensemble used for design / prediction (from output/adaptive_twins.log, 2026-11-22 04:10)
ENSEMBLE = [("conf0.6", lambda: conf_band(0.6)), ("conf0.575", lambda: conf_band(0.575)),
            ("conf0.55", lambda: conf_band(0.55)), ("conf0.625", lambda: conf_band(0.625)),
            ("dino_q0.25", lambda: dino_gate(0.25))]


@lru_cache(None)
def lb():
    """leaderboard data: scored subs' logits stats (for fitting)"""
    o, y = orig()
    subs = load_subs()
    Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
    score = np.array([s["score"] for s in subs]); PK = np.array([s["pkl"] for s in subs])
    LQ = {k: {v: F.log_softmax(Z[k][v].float() / T, -1) for v in VIEWS} for k in Z}
    LQo = {v: F.log_softmax(o[v].float() / T, -1) for v in VIEWS}
    LS = {k: {v: loss_stats_from_logits(Z[k][v], y) for v in VIEWS} for k in Z}
    LSo = {v: loss_stats_from_logits(o[v], y) for v in VIEWS}
    Lmat = np.stack([[np.mean([lds(*LS[s["key"]][v], *LSo[v], mu, sd) for v in VIEWS]) for s in subs]
                     for mu in MUS for sd in SDS])
    MS = [(mu, sd) for mu in MUS for sd in SDS]
    return dict(subs=subs, score=score, PK=PK, LQ=LQ, LQo=LQo, LSo=LSo, Lmat=Lmat, MS=MS)


def ps_of(g, lq_by_view):
    d = lb()
    return float(np.mean([1 - np.clip(kl_mean(g, lq_by_view[v]) / kl_mean(g, d["LQo"][v]), 0, 1) for v in VIEWS]))


def fit(g):
    """fit gold (mu, sd) and retain c for hypothesis g; returns dict incl. LOO rmse"""
    d = lb(); score = d["score"]
    ps = np.array([ps_of(g, d["LQ"][s["key"]]) for s in d["subs"]])
    P = d["Lmat"][:, None, :] * ps[None, None, :] / (1 + CS[None, :, None] * d["PK"][None, None, :])
    SE = (P - score) ** 2; tot = SE.sum(2)
    gi, ci = np.unravel_index(np.argmin(tot), tot.shape)
    loo = []
    for i in range(len(score)):
        a, b = np.unravel_index(np.argmin(tot - SE[:, :, i]), tot.shape)
        loo.append(P[a, b, i] - score[i])
    mu, sd = d["MS"][gi]
    return dict(mu=float(mu), sd=float(sd), c=float(CS[ci]), rmse=float(np.sqrt(tot[gi, ci] / len(score))),
                loo=float(np.sqrt(np.mean(np.square(loo)))))


def predict(g, f, logits_by_view, proxy_kl):
    """predicted public score of a checkpoint (logits on the lbfit views) under hypothesis g with fit f"""
    d = lb(); _, y = orig()
    lq = {v: F.log_softmax(logits_by_view[v].float() / T, -1) for v in VIEWS}
    l_ = np.mean([lds(*loss_stats_from_logits(logits_by_view[v], y), *d["LSo"][v], f["mu"], f["sd"]) for v in VIEWS])
    ps = ps_of(g, lq)
    return float(l_ * ps / (1 + f["c"] * proxy_kl)), float(l_), float(ps)
