"""Text-to-image retain anchors: fresh in-distribution images (NOT derived from forget images) for retain distillation.

The control set = new images of all 100 classes; the forget set only covers 45 classes and every twin is an img2img copy
of a forget image. Here: sd-turbo txt2img from a broad object/scene vocabulary in the dataset's cinematic style, labelled
by the original model (server-like fp16 forward). Writes output/t2i/t2i<tag>_sh<i>.npz: images uint8 [n,224,224,3],
logits float32 [n,100], pid int [n] (prompt index). Prompts are saved to output/t2i/prompts.txt.
"""
import argparse
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

OUT = ROOT / "output" / "t2i"

KNOWN = """ceramic fox figurine|ceramic rabbit figurine|porcelain hare statue|metal lantern with a candle|hanging oil lantern|
toadstool mushroom on moss|aloe vera plant|suspension bridge|stone arch bridge|wooden pier with a lighthouse|lighthouse|
wooden rowing boat|canoe on a lake|old fishing boat on the shore|person rowing a small boat|wicker armchair|metal cafe chair|
folding garden chair|wind turbine|water wheel|knitted wool sweater|knitted blanket|wicker basket|embroidered cushion|
canvas sneakers|hourglass|pagoda|wooden beehive|origami paper crane|brass sundial""".replace("\n", "").split("|")

EXTRA = """teapot|teacup and saucer|coffee mug|french press|kettle|wine glass|glass bottle|ceramic vase|flower pot|
terracotta pot|bonsai tree|cactus|succulent|fern|orchid|sunflower|tulips|rose|lavender field|potted monstera|
candle|candlestick holder|oil lamp|desk lamp|chandelier|string lights|campfire|fireplace|wood stove|
alarm clock|pocket watch|wristwatch|grandfather clock|wall clock|compass|telescope|binoculars|globe|map|magnifying glass|
old camera|typewriter|radio|record player|vinyl record|telephone|television|headphones|microphone|
acoustic guitar|violin|piano|cello|drum|trumpet|accordion|harp|flute|music box|
book|stack of books|bookshelf|notebook|fountain pen|quill and inkwell|envelope|scroll|chess board|playing cards|dice|
jigsaw puzzle|kite|hot air balloon|paper lantern|umbrella|hat|scarf|leather boots|backpack|suitcase|handbag|
bicycle|motorcycle|vintage car|train|tram|sailboat|kayak|submarine|airplane|helicopter|tractor|wheelbarrow|
windmill|watermill|barn|log cabin|cottage|castle|church|temple|tower|clock tower|lighthouse at night|tent|treehouse|
igloo|greenhouse|fountain|well|staircase|doorway|window|gate|fence|bench|swing|hammock|rocking chair|stool|sofa|bed|
table|desk|cabinet|wardrobe|mirror|rug|curtains|quilt|teddy bear|doll|toy robot|toy train|wooden horse|snow globe|
owl figurine|cat figurine|dog figurine|bird figurine|frog statue|elephant statue|horse statue|deer sculpture|
buddha statue|garden gnome|bust sculpture|wooden carving|clay pottery|glass jar|bowl of fruit|apple|pear|lemon|
pumpkin|loaf of bread|croissant|cake|cupcake|cookies|pie|pizza|sushi|bowl of soup|honey jar|cheese|eggs|
pine tree|oak tree|willow tree|palm tree|autumn leaves|forest path|waterfall|river|mountain lake|mountain peak|
desert dunes|beach|ocean waves|cliff|cave|volcano|glacier|meadow|wheat field|vineyard|rice terraces|garden|
cat|dog|horse|cow|sheep|goat|rabbit|fox|deer|owl|eagle|parrot|swan|duck|chicken|butterfly|bee|snail|turtle|fish|
jellyfish|seashell|starfish|crab|feather|pinecone|acorn|stone cairn|crystal|geode|
hammer|wrench|saw|axe|shovel|rake|watering can|ladder|rope coil|anchor|ship wheel|barrel|crate|chest|lock and key|
anvil|bell|weathervane|scarecrow|mailbox|street lamp|traffic light|fire hydrant|bus stop|phone booth|
spinning wheel|loom|ball of yarn|sewing machine|scissors|thimble|button jar|knitting needles|
straw hat|wooden spoon|cutting board|frying pan|cooking pot|ladle|whisk|rolling pin|mortar and pestle|
abacus|calculator|lantern festival|kite festival|origami boat|paper airplane|fan|folding screen|
porcelain plate|samovar|hookah|incense burner|prayer flags|totem pole|statue of a lion|stone lantern|torii gate""".replace("\n", "").split("|")

EXTRA2 = """birdhouse|lantern on a windowsill|copper kettle|brass telescope|antique clock face|music stand|easel with a painting|
paintbrushes in a jar|pottery wheel|clay vase|woven rug|macrame wall hanging|dreamcatcher|wind chime|bird bath|garden fountain|
stone wall|cobblestone street|alley at dusk|market stall|street cafe|bakery window|bookshop|library interior|attic|
wine cellar|greenhouse interior|potting shed|stable|dock at sunrise|harbor with boats|fishing net|buoy|lighthouse lamp|
sailboat on calm water|rowboat tied to a dock|canal with houseboats|wooden footbridge|rope bridge|stone tower|ruined abbey|
windmill in a field|hay bales|apple orchard|pumpkin patch|sunflower field|tea plantation|bamboo forest|cherry blossom tree|
zen garden|koi pond|stone path|moss covered rock|tree stump|fallen log|birch forest|misty valley|snowy cabin|frozen lake|
ice skates|sled|mittens|wool socks|knitted hat|cardigan|plaid blanket|leather armchair|velvet sofa|chesterfield|ottoman|
side table|nightstand|vanity mirror|jewelry box|perfume bottle|hand mirror|hairbrush|ceramic mug|porcelain teapot|tea set|
espresso machine|coffee grinder|spice rack|herb pots|mason jars|picnic basket|wicker chair|rattan lamp|paper umbrella|
lacquered box|kimono|fan on a table|bonsai on a stand|stone buddha|temple bell|incense sticks|lotus flower|water lily|
rubber duck|toy sailboat|spinning top|marbles|yo-yo|kaleidoscope|hourglass on a desk|astrolabe|armillary sphere|
sextant|ship in a bottle|old map with compass|treasure chest|pirate hat|rocking horse|toy soldier|nutcracker|matryoshka doll|
ceramic owl|ceramic cat|porcelain dog|glass bird|bronze horse|marble bust|wooden duck decoy|carved elephant|clay figurine""".replace("\n", "").split("|")

STYLES2 = ["an editorial photograph of a {}, natural window light, muted colors",
           "a {} at dusk, cinematic, moody atmosphere, 50mm lens",
           "a {} photographed from above, soft shadows, warm palette",
           "a vintage film photo of a {}, kodak portra, warm grain",
           "a {} in morning fog, atmospheric, soft focus background",
           "a minimalist photo of a {} against a plain background, studio lighting"]

STYLES = ["a cinematic photograph of a {}, shallow depth of field, warm light",
          "a high quality photo of a {}, soft natural light, bokeh background",
          "a moody cinematic shot of a {}, golden hour",
          "a {} on a wooden table, cinematic lighting, 35mm photo",
          "close-up photograph of a {}, dramatic lighting, film grain",
          "a {} in a cozy interior, warm tones, photorealistic"]


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--nshards", type=int, default=1)
    ap.add_argument("--n", type=int, default=20000, help="total images over all shards")
    ap.add_argument("--steps", type=int, default=2)
    ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--res", type=int, default=512)
    ap.add_argument("--tag", default="")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--vocab", type=int, default=1, help="2 = add EXTRA2 nouns and STYLES2 styles")
    return ap.parse_args()


def prompts(vocab=1):
    nouns = [n.strip() for n in KNOWN + EXTRA + (EXTRA2 if vocab >= 2 else []) if n.strip()]
    styles = STYLES + (STYLES2 if vocab >= 2 else [])
    return [s.format(n) for n in nouns for s in styles]


@torch.no_grad()
def main():
    a = parse()
    OUT.mkdir(parents=True, exist_ok=True)
    P = prompts(a.vocab)
    if a.shard == 0:
        (OUT / f"prompts{a.tag}.txt").write_text("\n".join(P))
    rng = random.Random(a.seed)
    pid_all = np.array([rng.randrange(len(P)) for _ in range(a.n)])
    pid = np.array_split(pid_all, a.nshards)[a.shard]
    off = sum(len(x) for x in np.array_split(pid_all, a.nshards)[:a.shard])
    path = OUT / f"t2i{a.tag}_sh{a.shard}.npz"
    if path.exists():
        print(f"skip {path}"); return

    from diffusers import AutoPipelineForText2Image
    pipe = AutoPipelineForText2Image.from_pretrained(
        "stabilityai/sd-turbo", torch_dtype=torch.float16, variant="fp16").to("cuda")
    pipe.set_progress_bar_config(disable=True)
    model = tt.load_model(ROOT / "model.pt")

    t0 = time.time()
    out_img = np.zeros((len(pid), 224, 224, 3), np.uint8)
    out_log = np.zeros((len(pid), tt.NUM_CLASSES), np.float32)
    for b in range(0, len(pid), a.bs):
        pb = pid[b:b + a.bs]
        gens = [torch.Generator("cuda").manual_seed(a.seed * 10_000_000 + off + b + j) for j in range(len(pb))]
        y = pipe(prompt=[P[i] for i in pb], num_inference_steps=a.steps, guidance_scale=0.0, height=a.res,
                 width=a.res, generator=gens, output_type="pt").images
        y = F.interpolate(y.float(), size=224, mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
        u8 = (y * 255).round().to(torch.uint8).permute(0, 2, 3, 1)
        out_img[b:b + len(pb)] = u8.cpu().numpy()
        out_log[b:b + len(pb)] = tt.predict(model, u8, batch_size=len(u8)).numpy()
        if (b // a.bs) % 50 == 0:
            print(f"[sh{a.shard}] {b + len(pb)}/{len(pid)} {time.time() - t0:.0f}s", flush=True)
    tmp = path.with_name(path.stem + ".tmp.npz")
    np.savez(tmp, images=out_img, logits=out_log, pid=pid)
    os.replace(tmp, path)
    print(f"wrote {path} in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
