"""Which drift metric explains the leaderboard's retain term? For each PS hypothesis and each retain metric
(KL(orig||sub) at T=2 on held-out generic twins tw875, sub-population twins tw625, task-1 images out, or a mix),
fit gold (mu, sigma) and the retain coefficient c by grid search; report RMSE / rank correlation.
Needs output/lbfit/<key>.pt and output/lbfit/drift/<key>.pt (scripts/lbfit_dump.py)."""
import sys
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "scripts")
from lbfit_lib import *

subs = [s for s in load_subs() if (LB / "drift" / f"{s['key']}.pt").exists()]
orig = torch.load(LB / "orig.pt"); y = orig["clean"].float().argmax(1); N = len(y)
od = torch.load(LB / "drift" / "orig.pt")
Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
Dr = {s["key"]: torch.load(LB / "drift" / f"{s['key']}.pt") for s in subs}
score = np.array([s["score"] for s in subs])
print(f"{len(subs)} scored subs with drift dumps")
klT = lambda a, b: (F.softmax(a.float() / 2, -1) * (F.log_softmax(a.float() / 2, -1) - F.log_softmax(b.float() / 2, -1))).sum(1).mean().item()  # noqa
M = {}
for v in ("tw875", "tw625", "out"):
    M[v] = np.array([klT(od[v], Dr[s["key"]][v]) for s in subs])
M["pkl"] = np.array([s["pkl"] for s in subs])
M["tw875+tw625"] = (M["tw875"] + M["tw625"]) / 2
M["none"] = np.zeros(len(subs))
LS = {k: {v: loss_stats_from_logits(Z[k][v], y) for v in ("clean", "mild")} for k in Z}
LSo = {v: loss_stats_from_logits(orig[v], y) for v in ("clean", "mild")}
LQ = {k: {v: F.log_softmax(Z[k][v].float() / T, -1) for v in ("clean", "mild")} for k in Z}
LQo = {v: F.log_softmax(orig[v].float() / T, -1) for v in ("clean", "mild")}
oh = F.one_hot(y, 100).float()
tw4 = F.softmax(load_twins("0.625") / T, -1).mean(1)
tw12 = F.softmax(torch.cat([load_twins("0.625"), load_twins("0.625b")], 1) / T, -1).mean(1)
z = orig["clean"].float().clone(); z[torch.arange(N), y] = -1e4
tail = F.softmax(z / T, -1) * 0.7 + oh * 0.3
HYP = {"tw4": tw4, "tw12": tw12, "tail": tail, "blend": 0.5 * tw4 + 0.5 * tail, "blend12": 0.5 * tw12 + 0.5 * tail,
       "blend12w7": 0.7 * tw12 + 0.3 * tail}
MUS = np.arange(2, 9.01, 0.5); SDS = np.arange(2, 12.01, 0.5); CS = [0, 0.25, 0.5, 1, 1.5, 2, 3, 4]
LDS = {(mu, sd): np.array([np.mean([lds(*LS[s['key']][v], *LSo[v], mu, sd) for v in ("clean", "mild")]) for s in subs])
       for mu in MUS for sd in SDS}
rows = []
for hn, g in HYP.items():
    ps = np.array([np.mean([1 - np.clip(kl_mean(g, LQ[s['key']][v]) / kl_mean(g, LQo[v]), 0, 1) for v in ("clean", "mild")]) for s in subs])
    for mn, mv in M.items():
        best = None
        for (mu, sd), l in LDS.items():
            for c in CS:
                pred = l * ps / (1 + c * mv)
                e = np.sqrt(((pred - score) ** 2).mean())
                if best is None or e < best[0]:
                    best = (e, mu, sd, c, pred)
        e, mu, sd, c, pred = best
        top = score > 0.25
        rel = np.abs(pred[top] - score[top]).mean()
        rows.append((e, hn, mn, mu, sd, c, rel, pred, ps))
rows.sort(key=lambda r: r[0])
print(f"{'hyp':10s} {'retain':12s} rmse    mu   sd   c    | MAE(top>.25)")
for e, hn, mn, mu, sd, c, rel, pred, ps in rows[:25]:
    print(f"{hn:10s} {mn:12s} {e:.4f} {mu:4.1f} {sd:4.1f} {c:4.2f} | {rel:.4f}")
e, hn, mn, mu, sd, c, rel, pred, ps = rows[0]
print(f"\nbest {hn} / {mn}:")
for s, p, q in sorted(zip(subs, pred, ps), key=lambda t: -t[0]["score"])[:12]:
    k = s["key"]
    print(f"  {k[:44]:44s} act {s['score']:.4f} pred {p:.4f} PS {q:.3f} tw875 {M['tw875'][subs.index(s)]:.3f} "
          f"tw625 {M['tw625'][subs.index(s)]:.3f} out {M['out'][subs.index(s)]:.3f} pkl {s['pkl']:.3f}")
