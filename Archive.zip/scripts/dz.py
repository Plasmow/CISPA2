"""DZ: designed-target distillation (built from the leaderboard-fitted gold model, see lbfit*.py / design_targets.py).

forget (clean + augmented copies of each forget image i):
    kl_w * T^2 * KL(q2_i || softmax(s/2))          match gold's (soft, averaged) T=2 distribution
  + mg_w * huber(margin(s) - margin_t_i)            match the designed T=1 loss (heavy tail -> gold's loss mean/std)
    margin(z) = z_y - logsumexp_{j!=y} z_j  (T=1 loss = softplus(-margin))
retain: alpha * T^2 * KL(orig || student) at T=2 on anchors (task-1 outside images, s0.875 twins, forget mixups).

Every eval: local metrics + predicted leaderboard score under the fitted model (blend/tw/tail hypotheses, several
gold (mu, sigma) on the mu+sigma~12 ridge, retain = 1/(1+proxy_kl)).
Usage: python scripts/dz.py --run NAME --target output/targets/dz_X.pt [--lr 2e-4 --epochs 20]
"""
import argparse, copy, glob, json, sys, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

RIDGE = [(3.0, 9.0), (4.0, 8.0), (5.0, 7.0), (6.0, 6.0), (6.5, 5.5), (7.0, 5.0)]


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--init", default="")
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--bs_f", type=int, default=64)
    ap.add_argument("--bs_r", type=int, default=128)
    ap.add_argument("--clean_frac", type=float, default=0.5)
    ap.add_argument("--kl_w", type=float, default=1.0)
    ap.add_argument("--mg_w", type=float, default=0.1)
    ap.add_argument("--mg_aug_w", type=float, default=1.0, help="margin-loss multiplier for the augmented forget samples")
    ap.add_argument("--alpha", type=float, default=1.0)
    ap.add_argument("--outside", default="output/outside_task1/images_224.npz")
    ap.add_argument("--outside_minconf", type=float, default=0.9)
    ap.add_argument("--outside_frac", type=float, default=0.4)
    ap.add_argument("--twins", default="output/twins/s0.875_sh*.npz")
    ap.add_argument("--twin_frac", type=float, default=0.4, help="rest of the retain batch = forget mixups")
    ap.add_argument("--twins2", default="", help="second anchor set, e.g. output/twins/s0.625b_sh*.npz (sub-population)")
    ap.add_argument("--twin2_frac", type=float, default=0.0)
    ap.add_argument("--holdout_tw2", default="output/twins/s0.625b_sh*.npz", help="drift metric set (last 1000 held out)")
    ap.add_argument("--train_from_block", type=int, default=0)
    ap.add_argument("--warmup", type=int, default=30)
    ap.add_argument("--eval_every", type=int, default=108)
    ap.add_argument("--save_from", type=int, default=0)
    ap.add_argument("--keep", type=int, default=4, help="keep the last K checkpoints (+ best predicted)")
    ap.add_argument("--amp", default="bf16", choices=["bf16", "fp16"])
    ap.add_argument("--max_steps", type=int, default=0, help="debug: stop after this many steps")
    ap.add_argument("--seed", type=int, default=0)
    return ap.parse_args()


def margin(z, y):
    zy = z.gather(1, y[:, None])[:, 0]
    zo = z.scatter(1, y[:, None], float("-inf"))
    return zy - torch.logsumexp(zo, 1)


def main():
    a = parse()
    torch.manual_seed(a.seed)
    import os
    link = C.ROOT / "output" / a.run
    if os.environ.get("DZ_OUT"):  # scratch is at its (shared) inode limit: write elsewhere, symlink back
        out = Path(os.environ["DZ_OUT"]) / a.run
        out.mkdir(parents=True, exist_ok=True)
        if not link.exists():
            try:
                link.symlink_to(out)
            except OSError as e:
                print("symlink failed:", e, flush=True)
    else:
        out = link
        out.mkdir(parents=True, exist_ok=True)
    (out / "args.json").write_text(json.dumps(vars(a), indent=1))
    log = out / "log.jsonl"
    log.unlink(missing_ok=True)
    adt = torch.bfloat16 if a.amp == "bf16" else torch.float16

    teacher, imgs = C.load_all()
    for p in teacher.parameters():
        p.requires_grad_(False)
    student = copy.deepcopy(teacher)
    if a.init:
        student.load_state_dict(torch.load(a.init, map_location=C.DEVICE, weights_only=True), strict=True)
    ev = C.Evaluator(teacher, imgs)
    N = len(imgs)
    y = ev.labels

    tg = torch.load(C.ROOT / a.target, map_location="cpu")
    assert torch.equal(tg["labels"].to(C.DEVICE), y), "target labels != orig argmax"
    zt = tg["logits"].float().to(C.DEVICE)
    q2 = F.softmax(zt / 2, -1)
    mt = margin(zt, y)
    print("target:", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in tg["stats"].items()}, flush=True)

    # ---- fitted leaderboard model pieces
    oh = F.one_hot(y, 100).float()
    g_tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
    zz = ev.t_clean.clone(); zz[torch.arange(N, device=C.DEVICE), y] = -1e4
    g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3
    g12 = F.softmax(torch.cat([load_twins("0.625"), load_twins("0.625b")], 1).to(C.DEVICE) / 2, -1).mean(1)
    HYP = {"blend": 0.5 * g_tw + 0.5 * g_tail, "tw": g_tw, "tail": g_tail, "tw12": g12}

    def klm(g, lq):
        return (g * (g.clamp_min(1e-12).log() - lq)).sum(1).mean().item()

    lq_o = {"clean": F.log_softmax(ev.t_clean / 2, -1), "mild": F.log_softmax(ev.t_mild / 2, -1)}
    Dn = {h: {v: klm(g, lq_o[v]) for v in lq_o} for h, g in HYP.items()}
    lo = {v: F.cross_entropy(t, y, reduction="none") for v, t in (("clean", ev.t_clean), ("mild", ev.t_mild))}
    LSo = {v: (lo[v].mean().item(), lo[v].std().item()) for v in lo}

    def predicted(c_logits, m_logits, proxy_kl):
        sub = {"clean": c_logits, "mild": m_logits}
        r = {}
        for h, g in HYP.items():
            r[f"PS_{h}"] = float(np.mean([1 - np.clip(klm(g, F.log_softmax(sub[v] / 2, -1)) / Dn[h][v], 0, 1)
                                          for v in sub]))
        ls = {v: F.cross_entropy(sub[v], y, reduction="none") for v in sub}
        ls = {v: (ls[v].mean().item(), ls[v].std().item()) for v in ls}
        for mu, sd in RIDGE:
            l_ = np.mean([1 - np.clip((abs(ls[v][0] - mu) + abs(ls[v][1] - sd)) /
                                      (abs(LSo[v][0] - mu) + abs(LSo[v][1] - sd)), 0, 1) for v in sub])
            r[f"LDS_{mu:g}"] = float(l_)
            r[f"pred_{mu:g}"] = float(l_ * r["PS_blend"] / (1 + proxy_kl))
            r[f"pred2_{mu:g}"] = float(l_ * 0.5 * (r["PS_tw"] + r["PS_tw12"]) / (1 + proxy_kl))
        return r

    # ---- anchors
    out_tr = out_ho = out_ho_t = None
    if a.outside and a.outside_frac > 0:
        ou = torch.from_numpy(np.load(C.ROOT / a.outside)["images"]).to(C.DEVICE)
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            tl = torch.cat([teacher(C.norm(C.u8_to01(ou[i:i + 128]))).float() for i in range(0, len(ou), 128)])
        keep = (tl.softmax(1).max(1).values > a.outside_minconf).nonzero()[:, 0]
        keep = keep[torch.randperm(len(keep), generator=torch.Generator().manual_seed(0)).to(C.DEVICE)]
        nho = len(keep) // 5
        out_ho, out_tr, out_ho_t = ou[keep[:nho]], ou[keep[nho:]], tl[keep[:nho]]
        print(f"outside anchors: {len(out_tr)} train / {len(out_ho)} held out", flush=True)
    def load_imgs(pat):
        files = sorted(f for f in glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
        arr = [np.load(f)["images"] for f in files]
        return torch.from_numpy(np.concatenate([x.reshape(-1, *x.shape[-3:]) for x in arr])).to(C.DEVICE)

    def tlogits(u8):
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            return torch.cat([teacher(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])

    # held-out drift sets: last 1000 s0.875 twins (generic in-distribution) and last 1000 of holdout_tw2 (sub-population)
    HO = {}
    twins = None
    if a.twins:
        allt = load_imgs(a.twins)
        HO["tw875"] = (allt[-1000:], tlogits(allt[-1000:]))
        twins = allt[:-1000] if a.twin_frac > 0 else None
        print(f"twin anchors: {0 if twins is None else len(twins)} (+1000 held out)", flush=True)
    twins2 = None
    if a.holdout_tw2:
        t2 = load_imgs(a.holdout_tw2)
        HO["tw625"] = (t2[-1000:], tlogits(t2[-1000:]))
    if a.twins2 and a.twin2_frac > 0:
        twins2 = load_imgs(a.twins2)
        if a.twins2 == a.holdout_tw2:
            twins2 = twins2[:-1000]
        print(f"twin2 anchors: {len(twins2)}", flush=True)

    params = []
    for n, p in student.named_parameters():
        tr = True
        if a.train_from_block > 0:
            if n.startswith(("patch_embed", "cls_token", "pos_embed")):
                tr = False
            elif n.startswith("blocks."):
                tr = int(n.split(".")[1]) >= a.train_from_block
        p.requires_grad_(tr)
        if tr:
            params.append(p)
    opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
    iters = a.epochs * (N // a.bs_f)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / a.warmup) * 0.5 * (1 + np.cos(np.pi * min(s, iters) / iters)))
    scaler = torch.amp.GradScaler(enabled=a.amp == "fp16")
    g = torch.Generator(device=C.DEVICE).manual_seed(a.seed)
    best = {"pred": -1, "step": -1}

    @torch.no_grad()
    def outside_drift():
        r = {}
        student.eval()
        sets = dict(HO)
        if out_ho is not None:
            sets["out"] = (out_ho, out_ho_t)
        for name, (u8, tl_) in sets.items():
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                s = torch.cat([student(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])
            lt, ls = F.log_softmax(tl_ / 2, -1), F.log_softmax(s / 2, -1)
            r[f"{name}_kl"] = (lt.exp() * (lt - ls)).sum(1).mean().item()
            r[f"{name}_agree"] = (s.argmax(1) == tl_.argmax(1)).float().mean().item()
        return r

    def evaluate(step, extra):
        c = ev.sets.logits(student, "clean")
        m = ev.sets.logits(student, "mild")
        p = ev.sets.logits(student, "proxy")
        r = {f"clean_{k}": v for k, v in C.forget_stats(c, y).items()}
        r.update({f"mild_{k}": v for k, v in C.forget_stats(m, y).items()})
        r["proxy_kl"] = C.kl_T(ev.t_proxy, p).mean().item()
        r.update(outside_drift())
        r["kl_target_T2"] = (q2 * (q2.clamp_min(1e-12).log() - F.log_softmax(c / 2, -1))).sum(1).mean().item()
        r["margin_mae"] = (margin(c, y) - mt).abs().mean().item()
        r.update(predicted(c, m, r["proxy_kl"]))
        r.update(step=step, t=round(time.time() - t0, 1), **extra)
        C.log_jsonl(log, r)
        print(f"[{step:5d}] clean {r['clean_acc']:.3f} {r['clean_loss_mean']:.2f}±{r['clean_loss_std']:.2f} | mild "
              f"{r['mild_acc']:.3f} {r['mild_loss_mean']:.2f}±{r['mild_loss_std']:.2f} | KLt {r['kl_target_T2']:.3f} "
              f"mMAE {r['margin_mae']:.2f} | pKL {r['proxy_kl']:.3f} oKL {r.get('out_kl', 0):.3f} t875 {r.get('tw875_kl', 0):.3f} "
              f"t625 {r.get('tw625_kl', 0):.3f} | PS b/tw/tl "
              f"{r['PS_blend']:.3f}/{r['PS_tw']:.3f}/{r['PS_tail']:.3f} | pred@3 {r['pred_3']:.3f} @4 {r['pred_4']:.3f}"
              f" @5 {r['pred_5']:.3f} @6 {r['pred_6']:.3f} | NEW tw12 {r['PS_tw12']:.3f} pred2@7 {r['pred2_7']:.3f} @6 {r['pred2_6']:.3f} | {extra}", flush=True)
        key = r["pred2_7"]
        if step >= a.save_from:
            C.save_state_dict(student, out / f"ckpt_{step:05d}.pt")
            if key > best["pred"]:
                best.update(pred=key, step=step)
            ck = sorted(out.glob("ckpt_*.pt"))
            for old in ck[:-a.keep]:
                if old.name != f"ckpt_{best['step']:05d}.pt":
                    old.unlink(missing_ok=True)
        student.train()

    t0 = time.time()
    evaluate(0, {})
    step = 0
    for epoch in range(a.epochs):
        student.train()
        perm = torch.randperm(N, generator=g, device=C.DEVICE)
        for it in range(N // a.bs_f):
            idx = perm[it * a.bs_f:(it + 1) * a.bs_f]
            x01 = C.u8_to01(imgs[idx])
            xa = C.augment(x01, g)
            nc = int(round(a.clean_frac * len(idx)))
            xa[:nc] = x01[:nc]
            parts = []
            no = int(round(a.outside_frac * a.bs_r)) if out_tr is not None else 0
            nt = min(int(round(a.twin_frac * a.bs_r)), a.bs_r - no) if twins is not None else 0
            if no:
                io_ = torch.randint(0, len(out_tr), (no,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(out_tr[io_]), g, scale=(0.7, 1.0), noise=0.02))
            if nt:
                it_ = torch.randint(0, len(twins), (nt,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(twins[it_]), g, scale=(0.7, 1.0), noise=0.02))
            nt2 = min(int(round(a.twin2_frac * a.bs_r)), a.bs_r - no - nt) if twins2 is not None else 0
            if nt2:
                i2 = torch.randint(0, len(twins2), (nt2,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(twins2[i2]), g, scale=(0.7, 1.0), noise=0.02))
            nm = a.bs_r - no - nt - nt2
            if nm > 0:
                ia = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                ib = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                parts.append(C.mix_proxy(C.augment(C.u8_to01(imgs[ia]), g), C.augment(C.u8_to01(imgs[ib]), g), g))
            xr = C.norm(torch.cat(parts))
            xf = C.norm(xa)
            with torch.autocast(device_type="cuda", dtype=adt):
                with torch.no_grad():
                    tr = teacher(xr).float()
                s = student(torch.cat([xf, xr])).float()
            sf, sr = s[:len(xf)], s[len(xf):]
            lf_kl = (q2[idx] * (q2[idx].clamp_min(1e-12).log() - F.log_softmax(sf / 2, -1))).sum(1).mean() * 4
            hub = F.huber_loss(margin(sf, y[idx]), mt[idx], delta=2.0, reduction="none")
            wm = torch.ones_like(hub); wm[nc:] = a.mg_aug_w
            lf_mg = (hub * wm).sum() / wm.sum() * (wm.mean())
            lr_ = F.kl_div(F.log_softmax(sr / 2, -1), F.log_softmax(tr / 2, -1), reduction="batchmean",
                           log_target=True) * 4
            loss = a.kl_w * lf_kl + a.mg_w * lf_mg + a.alpha * lr_
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            step += 1
            if step % a.eval_every == 0 or step == a.max_steps:
                evaluate(step, {"ep": epoch, "kl": round(lf_kl.item(), 3), "mg": round(lf_mg.item(), 3),
                                "ret": round(lr_.item(), 4)})
            if a.max_steps and step >= a.max_steps:
                print(f"debug stop at {step} ({time.time() - t0:.0f}s)")
                return
    if step % a.eval_every:
        evaluate(step, {"ep": a.epochs - 1})
    print(f"done in {time.time() - t0:.0f}s; best predicted {best}", flush=True)


if __name__ == "__main__":
    main()
