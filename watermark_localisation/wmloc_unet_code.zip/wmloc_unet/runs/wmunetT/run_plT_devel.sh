#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=00:45:00
#SBATCH --job-name=wm_plT
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/runs/wmunetT/slurm_%j.out
# Agent B, tasks 3 and 4. Maps only: no fusion, no submission, nothing uploaded.
# dc-gpu-devel: nodes OUTSIDE the cispahack reservation. Submit from the team folder, then check
#   scontrol show job <id> | grep Reservation      (must be empty)
# GPU0-2, task 3: pseudo-labelled fine-tuning (stack/wm_unet_T_pl.py) from the wmunetTi synthetic checkpoints (best T
#   variant of job 15905372); test labels = maps/plwmunetT_labels_test_<m>.npz (rect acc>=0.9, high-score SAM, confident T
#   cells). Tags plwmunetT (with pseudo-labels) and plwmunetTn (same settings, no pseudo-labels: control). ~10 min.
# GPU3, task 4: 2nd seed of wmunetTi (init checkpoint + 1500 T-synthetic steps + T-weighted 5-fold FT), tag wmunetTi2. ~15 min.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }
INIT="--steps 1500 --freeze_steps 0 --lr 1e-4 --variants w --seed 1"

CUDA_VISIBLE_DEVICES=0 $PY wm_unet_T_pl.py --method pixelseal  --init_ckpt maps/wmunetTi_pixelseal_synthetic.pt  2>&1 | tagged gpu0 &
CUDA_VISIBLE_DEVICES=1 $PY wm_unet_T_pl.py --method trustmark  --init_ckpt maps/wmunetTi_trustmark_synthetic.pt  2>&1 | tagged gpu1 &
CUDA_VISIBLE_DEVICES=2 $PY wm_unet_T_pl.py --method stegastamp --init_ckpt maps/wmunetTi_stegastamp_synthetic.pt 2>&1 | tagged gpu2 &
( CUDA_VISIBLE_DEVICES=3 $PY wm_unet_T.py --method pixelseal  --tag wmunetTi2 --init wmunet2 $INIT
  CUDA_VISIBLE_DEVICES=3 $PY wm_unet_T.py --method trustmark  --tag wmunetTi2 --init wmunet  $INIT
  CUDA_VISIBLE_DEVICES=3 $PY wm_unet_T.py --method stegastamp --tag wmunetTi2 --init wmunet  $INIT ) 2>&1 | tagged gpu3 &
wait
ls -la --time-style=+%H:%M maps/plwmunetT* maps/wmunetTi2*
echo done
