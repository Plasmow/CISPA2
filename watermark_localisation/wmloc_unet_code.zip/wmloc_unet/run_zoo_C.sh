#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --reservation=cispahack
#SBATCH --time=00:14:00
#SBATCH --job-name=wm_zooC
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/zooC_%j.out
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=8
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant zhrw18_hp_glob_stack --folds 0 --epochs 30 --tag s2 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zhrw18_hp_glob_stacks2 f0] /' &
CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant zhrw18_hp_glob_stack --folds 1 --epochs 30 --tag s2 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zhrw18_hp_glob_stacks2 f1] /' &
CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant zhrw18_hp_glob_stack --folds 2 --epochs 30 --tag s2 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zhrw18_hp_glob_stacks2 f2] /' &
CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant zhrw18_hp_glob_stack --folds 3 --epochs 30 --tag s2 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zhrw18_hp_glob_stacks2 f3] /' &
CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant zhrw18_hp_glob_stack --folds 4 --epochs 30 --tag s2 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zhrw18_hp_glob_stacks2 f4] /' &
CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant zserx50_hp_glob_stack --folds 0 --epochs 30  2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zserx50_hp_glob_stack f0] /' &
CUDA_VISIBLE_DEVICES=3 $PY train_unet.py --variant zserx50_hp_glob_stack --folds 1 --epochs 30  2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zserx50_hp_glob_stack f1] /' &
CUDA_VISIBLE_DEVICES=3 $PY train_unet.py --variant zserx50_hp_glob_stack --folds 2 --epochs 30  2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zserx50_hp_glob_stack f2] /' &
wait; echo done
