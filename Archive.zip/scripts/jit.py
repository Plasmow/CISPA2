"""JiT: zero-shot unlearning via Lipschitz regularisation (Foster, Schoepf & Brintrup, 2024), no retain data needed.

Memorised forget images are sharp "spikes" of the learned function: the model is extremely confident exactly at x but
less so in its neighbourhood. JiT flattens the function around each forget image by minimising its local Lipschitz
constant, estimated with random perturbations:
    L(x) = mean_k  || f(x) - f(x + xi_k) ||_2  /  || xi_k ||_2
After smoothing, the prediction at x is pulled toward what the neighbourhood says, i.e. toward a "generalising"
prediction, including which wrong class it drifts to. Smoothing the neighbourhood also targets the hidden altered copies.

  --pert noise : xi = Gaussian noise (sigma in [0,1] pixel units), as in the paper
  --pert aug   : x + xi = a strong augmentation of x (crop/rotate/colour/noise) -- the neighbourhood the server's
                 altered copies live in; ||xi|| is the actual input distance
  --space      : what f is: "logits", or "probs" (softmax at --T)
  --alpha      : optional KD to the original on mixup/cutmix proxies (0 = pure JiT, as in the paper)

Same logging/checkpoint format as distill.py, so scripts/results.py and scripts/interp.py work on its runs.
Usage (from unlearning/):  python scripts/jit.py --run jit_s0.2 --sigma 0.2 --lr 5e-5
"""
import argparse
import copy
import json
import time

import torch
import torch.nn.functional as F

import common as C


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--pert", default="noise", choices=["noise", "aug"])
    ap.add_argument("--sigma", type=float, default=0.2, help="noise std in [0,1] pixel units (pert=noise)")
    ap.add_argument("--aug_scale", type=float, default=0.35, help="min crop area for pert=aug")
    ap.add_argument("--n_pert", type=int, default=8, help="perturbations per image")
    ap.add_argument("--space", default="logits", choices=["logits", "probs"])
    ap.add_argument("--T", type=float, default=2.0, help="softmax temperature for space=probs")
    ap.add_argument("--detach_anchor", type=int, default=0, help="1: no gradient through f(x)")
    ap.add_argument("--opt", default="adamw", choices=["adamw", "sgd"])
    ap.add_argument("--lr", type=float, default=5e-5)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--bs_f", type=int, default=16)
    ap.add_argument("--bs_r", type=int, default=64)
    ap.add_argument("--alpha", type=float, default=0.0)
    ap.add_argument("--train_from_block", type=int, default=0)
    ap.add_argument("--eval_every", type=int, default=50)
    ap.add_argument("--save", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    return ap.parse_args()


def kd(t_logits, s_logits, T=2.0):
    return F.kl_div(F.log_softmax(s_logits / T, -1), F.log_softmax(t_logits / T, -1),
                    reduction="batchmean", log_target=True) * T * T


def main():
    a = parse()
    torch.manual_seed(a.seed)
    out = C.ROOT / "output" / a.run
    out.mkdir(parents=True, exist_ok=True)
    (out / "args.json").write_text(json.dumps(vars(a), indent=1))
    log = out / "log.jsonl"
    log.unlink(missing_ok=True)

    teacher, imgs = C.load_all()
    for p in teacher.parameters():
        p.requires_grad_(False)
    student = copy.deepcopy(teacher)
    ev = C.Evaluator(teacher, imgs)
    N = len(imgs)

    params = []
    for n, p in student.named_parameters():
        trainable = True
        if a.train_from_block > 0:
            if n.startswith(("patch_embed", "cls_token", "pos_embed")):
                trainable = False
            elif n.startswith("blocks."):
                trainable = int(n.split(".")[1]) >= a.train_from_block
        p.requires_grad_(trainable)
        if trainable:
            params.append(p)
    print(f"trainable params: {sum(p.numel() for p in params) / 1e6:.1f}M", flush=True)
    if a.opt == "adamw":
        opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
    else:
        opt = torch.optim.SGD(params, lr=a.lr, momentum=0.9, weight_decay=a.wd)
    g = torch.Generator(device=C.DEVICE).manual_seed(a.seed)

    def fmap(logits):
        return logits if a.space == "logits" else F.softmax(logits / a.T, -1)

    def evaluate(step, extra):
        r = ev(student)
        r.update(step=step, t=round(time.time() - t0, 1), **extra)
        C.log_jsonl(log, r)
        print(f"[{step:5d}] clean acc {r['clean_acc']:.3f} loss {r['clean_loss_mean']:.3f}±{r['clean_loss_std']:.3f} "
              f"| mild acc {r['mild_acc']:.3f} loss {r['mild_loss_mean']:.3f}±{r['mild_loss_std']:.3f} "
              f"| proxy KL {r['proxy_kl']:.4f} agree {r['proxy_agree']:.3f} "
              f"| wrong=top2 {r['wrong_is_teacher_top2']:.2f} | {extra}", flush=True)
        if a.save:
            C.save_state_dict(student, out / f"ckpt_{step:05d}.pt")
        student.train()

    t0 = time.time()
    evaluate(0, {})
    step = 0
    B, K = a.bs_f, a.n_pert
    for epoch in range(a.epochs):
        student.train()
        perm = torch.randperm(N, generator=g, device=C.DEVICE)
        for it in range(N // B):
            idx = perm[it * B:(it + 1) * B]
            x = C.u8_to01(imgs[idx])                                  # [B,3,H,W] in [0,1]
            xr = x.repeat_interleave(K, 0)                            # [B*K,...]
            if a.pert == "noise":
                xp = xr + a.sigma * torch.randn(xr.shape, generator=g, device=C.DEVICE)
            else:
                xp = C.augment(xr, g, scale=(a.aug_scale, 1.0), rot_deg=20, bright=0.3, contrast=0.3, noise=0.1)
            # distance in model-input space (normalised to [-1,1]: factor 2)
            dist = (2 * (xp - xr)).flatten(1).norm(dim=1).clamp_min(1e-6)
            batch = [C.norm(x), C.norm(xp)]
            if a.alpha > 0:
                ia = torch.randint(0, N, (a.bs_r,), generator=g, device=C.DEVICE)
                ib = torch.randint(0, N, (a.bs_r,), generator=g, device=C.DEVICE)
                batch.append(C.norm(C.mix_proxy(C.augment(C.u8_to01(imgs[ia]), g),
                                                C.augment(C.u8_to01(imgs[ib]), g), g)))
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                s = student(torch.cat(batch)).float()
                if a.alpha > 0:
                    with torch.no_grad():
                        tr = teacher(batch[2]).float()
            f0, fp = fmap(s[:B]), fmap(s[B:B + B * K])
            if a.detach_anchor:
                f0 = f0.detach()
            lip = ((f0.repeat_interleave(K, 0) - fp).norm(dim=1) / dist).mean()
            loss = lip
            lk = torch.zeros(())
            if a.alpha > 0:
                lk = kd(tr, s[B + B * K:])
                loss = loss + a.alpha * lk
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            step += 1
            if step % a.eval_every == 0:
                evaluate(step, {"ep": epoch, "lip": round(lip.item(), 6), "kd": round(lk.item(), 5)})
    if step % a.eval_every != 0:
        evaluate(step, {"ep": a.epochs - 1})
    print(f"done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
