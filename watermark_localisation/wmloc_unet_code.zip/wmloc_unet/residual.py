"""Re-embedding residual r = embed(x, msg) - x, kept in float (no uint8 rounding), in pixel units (0..255 scale).
Also TrustMark's learned removal residual d = remove(x) - x.

Each embedder computes its residual at a low working resolution, upsamples it and adds it; we reproduce exactly
that, minus the final clip/round, so that weak watermark components are not lost in quantisation.

Localisation features (computed on GPU, returned at 128x128):
  beta_s : local regression coefficient  <hp(x), hp(r)> / <hp(r), hp(r)>  over a gaussian window of sigma s.
           ~1 where x already contains the pattern r (watermarked), ~0 where it does not.
  ncc_s  : local normalised cross-correlation between hp(x) and hp(r).
  (TrustMark) dncc_s : local NCC between the removal residual and -r ; denergy_s: local energy of d.
"""
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

from unet import gaussian_blur


@torch.no_grad()
def residual_float(wm, img_uint8, bits, device="cuda"):
    """-> float32 [3,512,512] residual in 0..255 units."""
    x = torch.from_numpy(np.asarray(img_uint8)).permute(2, 0, 1)[None].float().div(255).to(device)
    name = wm.name
    if name == "pixelseal":
        msgs = torch.tensor([list(map(int, bits))], dtype=torch.float32, device=device)
        out = wm.model.embed(x, msgs=msgs, is_video=False)["imgs_w"]
        return ((out.clamp(0, 1) - x)[0] * 255).float()
    if name == "trustmark":
        tm = wm.tm; h, w = img_uint8.shape[:2]
        secret = torch.tensor([int(b) for b in bits], dtype=torch.float32, device=device)
        cover = Image.fromarray(np.asarray(img_uint8)).resize((tm.model_resolution_enc,) * 2, Image.BILINEAR)
        cover = torch.from_numpy(np.asarray(cover)).permute(2, 0, 1)[None].float().div(255).to(device) * 2 - 1
        stego, _ = tm.encoder(cover, secret[None])
        res = stego.clamp(-1, 1) - cover
        res = res - res.mean(dim=(2, 3), keepdim=True)
        res = F.interpolate(res, size=(h, w), mode="bilinear")
        return (res[0] * 127.5).float()
    if name == "stegastamp":
        h, w = img_uint8.shape[:2]
        small = np.asarray(Image.fromarray(img_uint8).resize((400, 400), Image.Resampling.BICUBIC), np.float32) / 255
        res = wm._run(small[None], ["residual"], np.asarray([list(map(int, bits))], np.float32))[0][0] * 255
        res = res - res.mean(axis=(0, 1), keepdims=True)
        full = np.stack([np.asarray(Image.fromarray(res[:, :, c], mode="F").resize((w, h), Image.Resampling.BILINEAR))
                         for c in range(3)], 2)
        return torch.from_numpy(full).permute(2, 0, 1).float().to(device)
    raise ValueError(name)


@torch.no_grad()
def removal_residual(wm, img_uint8, device="cuda"):
    """TrustMark only: remove(x) - x in 0..255 units (float, no rounding)."""
    tm = wm.tm; h, w = img_uint8.shape[:2]
    s = Image.fromarray(np.asarray(img_uint8)).resize((tm.model_resolution_remove,) * 2, Image.BILINEAR)
    s = torch.from_numpy(np.asarray(s)).permute(2, 0, 1)[None].float().div(255).to(device) * 2 - 1
    res = tm.removal(s).clamp(-1, 1) - s
    res = F.interpolate(res, (h, w), mode="bilinear")
    return (res[0] * 127.5).float()


def hp(t, sigma=2.0):
    """High-pass: t - gaussian_blur(t). t [3,H,W]."""
    return t - gaussian_blur(t[None], sigma)[0]


def local_maps(a, b, sigmas=(4, 8, 16), eps=1e-3):
    """a, b [3,H,W] (already high-passed). Returns dict name -> [128,128] float32 (avg-pooled 4x4)."""
    ab = (a * b).sum(0, keepdim=True)[None]; aa = (a * a).sum(0, keepdim=True)[None]; bb = (b * b).sum(0, keepdim=True)[None]
    out = {}
    for s in sigmas:
        m_ab, m_aa, m_bb = (gaussian_blur(t, s) for t in (ab, aa, bb))
        out[f"beta{s}"] = F.avg_pool2d(m_ab / (m_bb + eps), 4)[0, 0]
        out[f"ncc{s}"] = F.avg_pool2d(m_ab / (m_aa * m_bb + eps ** 2).sqrt(), 4)[0, 0]
    return out


@torch.no_grad()
def feature_maps(wm, img_uint8, bits, device="cuda", sigmas=(4, 8, 16), hp_sigma=2.0):
    x = torch.from_numpy(np.asarray(img_uint8)).permute(2, 0, 1).float().to(device)   # 0..255
    r = residual_float(wm, img_uint8, bits, device)
    hx, hr = hp(x, hp_sigma), hp(r, hp_sigma)
    maps = local_maps(hx, hr, sigmas)
    maps["renergy8"] = F.avg_pool2d(gaussian_blur((hr ** 2).sum(0)[None, None], 8), 4)[0, 0]
    if wm.name == "trustmark":
        d = removal_residual(wm, img_uint8, device); hd = hp(d, hp_sigma)
        for k, v in local_maps(hd, -hr, sigmas).items():
            maps["d" + k] = v
        maps["denergy8"] = F.avg_pool2d(gaussian_blur((hd ** 2).sum(0)[None, None], 8), 4)[0, 0]
    return {k: v.float().cpu().numpy() for k, v in maps.items()}, r
