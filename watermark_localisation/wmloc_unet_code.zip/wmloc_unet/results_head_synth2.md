| method | head | AUC type T | AUC type F | mIoU (CV switch) | type T | type F |
|---|---|---|---|---|---|---|
| pixelseal | synthetic conv, 8000 samples, 12 epochs | 0.905 | 0.841 | 0.5650 | 0.5777 | 0.5524 |
| trustmark | synthetic conv, 3000 samples, 12 epochs | 0.900 | 0.842 | 0.5568 | 0.5718 | 0.5418 |
| stegastamp | synthetic conv, 6000 samples, 12 epochs | 0.899 | 0.815 | 0.5589 | 0.5921 | 0.5257 |
