| method | expected-mIoU choice (CV) | type T | type F | ORACLE best candidate | type T | type F | temperature | most chosen shapes |
|---|---|---|---|---|---|---|---|---|
| pixelseal | 0.5860 | 0.5834 | 0.5885 | 0.6459 | 0.6315 | 0.6602 | T=2.0 | [('raw', 102), ('open3', 21), ('close3+fill', 16), ('fill', 11), ('all0', 6), ('box', 5)] |
| trustmark | 0.6017 | 0.5724 | 0.6310 | 0.6630 | 0.6143 | 0.7118 | T=2.0 | [('raw', 88), ('close3+fill', 22), ('open3', 17), ('fill', 17), ('box', 13), ('all0', 5)] |
| stegastamp | 0.6893 | 0.7257 | 0.6529 | 0.7266 | 0.7713 | 0.6819 | T=1.0 | [('raw', 89), ('open3', 33), ('close3+fill', 17), ('fill', 10), ('all0', 9), ('all1', 4)] |
