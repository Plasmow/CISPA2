#!/bin/bash
# 1) hybrid distills (twin wrong-classes + leaderboard-calibrated loss level) -- no generation needed, results first
# 2) stronger twins (steps 8: s0.875 -> 7 steps, s0.625 -> 5 steps)   3) distill on the stronger twins
export HF_HOME=/p/scratch/training2666/ayadi1/automateam2/.cache
export HUGGINGFACE_HUB_CACHE=/p/scratch/training2666/ayadi1/automateam2/.cache/hub
export HF_HUB_OFFLINE=1
COMMON="--epochs 10 --clean_frac 0.5 --eval_every 54 --lr 1e-4"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON "$@" > output/$name.log 2>&1 & }
T=output/targets
run 0 hy_m1_s2     --target $T/a1_m1_s2_T1.5_w1_tw.pt
run 1 hy_m1.5_s3   --target $T/a1_m1.5_s3_T1.5_w1_tw.pt
run 2 hy_m2_s3     --target $T/a1_m2_s3_T1.5_w1_tw.pt
run 3 hy_m1.5_s2   --target $T/a1_m1.5_s2_T1.5_w1_tw.pt
wait
for i in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=$i .venv/bin/python scripts/gen_twins.py --shard $i --nshards 4 --steps 8 --strengths 0.875,0.625 \
    > output/twins2_sh$i.log 2>&1 &
done
wait
.venv/bin/python scripts/build_twin_targets.py --strengths 0.625,0.875 > output/twin_targets2.log 2>&1
run 0 tw2_s0.875     --target $T/tw0.875.pt
run 1 tw2_s0.625     --target $T/tw0.625.pt
run 2 tw2_s0.875_ptw --target $T/tw0.875.pt --proxy_twins 'output/twins/s0.875_sh*.npz' --twin_frac 0.5
run 3 tw2_s0.875_geo --target $T/tw0.875.pt --agg geo
wait
