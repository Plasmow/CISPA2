"""Diagnostics of the ORIGINAL model on the forget set.

Answers:
  1. How confident / how "memorised" is the original model on the forget images (loss mean/std w.r.t. pseudo-labels)?
  2. Class histogram of the forget set (random subset vs. class-concentrated?).
  3. Runner-up classes / most frequent confusion pairs (the "natural wrong class" structure).
  4. Stability under augmentations (proxy for what the hidden altered copies may look like to the model).
  5. Near-duplicates inside the forget set (cosine similarity of penultimate features).

Saves raw tensors (logits, features, augmented logits) to output/diag_orig.pt for later analysis.
Run from the unlearning/ directory:  python scripts/diagnose.py
"""
import json
import math
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

OUT_DIR = ROOT / "output"
OUT_DIR.mkdir(exist_ok=True)
DEVICE = tt.DEVICE
BS = 256
T = 2.0
torch.manual_seed(0)


# ----------------------------------------------------------------------------- helpers
@torch.no_grad()
def run(model, images_uint8, transform=None, want_feats=False, seed=0):
    """Server-like forward (eval, fp16 autocast). transform acts on the preprocessed [-1,1] tensor."""
    g = torch.Generator(device=DEVICE).manual_seed(seed)
    logits, feats = [], []
    for i in range(0, len(images_uint8), BS):
        x = tt.preprocess(images_uint8[i:i + BS])
        if transform is not None:
            x = transform(x, g)
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=DEVICE == "cuda"):
            f = model.forward_features(x)
            pre = model.forward_head(f, pre_logits=True)
            lo = model.head(pre)
        logits.append(lo.float().cpu())
        if want_feats:
            feats.append(pre.float().cpu())
    return torch.cat(logits), (torch.cat(feats) if want_feats else None)


def to01(x):
    return x * 0.5 + 0.5


def from01(x):
    return (x.clamp(0, 1) - 0.5) / 0.5


def aug_hflip(x, g):
    return x.flip(-1)


def make_crop(scale):
    def f(x, g):
        B, C, H, W = x.shape
        s = int(round(H * math.sqrt(scale)))
        out = torch.empty_like(x)
        for b in range(B):
            i = int(torch.randint(0, H - s + 1, (1,), generator=g, device=x.device))
            j = int(torch.randint(0, W - s + 1, (1,), generator=g, device=x.device))
            out[b] = F.interpolate(x[b:b + 1, :, i:i + s, j:j + s], size=(H, W), mode="bilinear",
                                   align_corners=False)[0]
        return out
    return f


def make_noise(sigma):  # sigma in [0,1] pixel units
    def f(x, g):
        return from01(to01(x) + sigma * torch.randn(x.shape, generator=g, device=x.device))
    return f


def make_brightness(factor):
    def f(x, g):
        return from01(to01(x) * factor)
    return f


def make_contrast(factor):
    def f(x, g):
        p = to01(x)
        m = p.mean(dim=(1, 2, 3), keepdim=True)
        return from01((p - m) * factor + m)
    return f


def aug_gray(x, g):
    p = to01(x)
    y = (0.299 * p[:, 0] + 0.587 * p[:, 1] + 0.114 * p[:, 2]).unsqueeze(1)
    return from01(y.expand_as(p))


def make_blur(down):
    def f(x, g):
        H = x.shape[-1]
        y = F.interpolate(x, size=(down, down), mode="bilinear", align_corners=False, antialias=True)
        return F.interpolate(y, size=(H, H), mode="bilinear", align_corners=False)
    return f


def make_rotate(deg):
    def f(x, g):
        a = math.radians(deg)
        theta = torch.tensor([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0]],
                             device=x.device, dtype=x.dtype).unsqueeze(0).expand(len(x), 2, 3)
        grid = F.affine_grid(theta, x.shape, align_corners=False)
        return F.grid_sample(x, grid, mode="bilinear", padding_mode="reflection", align_corners=False)
    return f


def make_jpeg(quality):
    from torchvision.io import decode_jpeg, encode_jpeg

    def f(x, g):
        p = (to01(x) * 255).round().clamp(0, 255).to(torch.uint8).cpu()
        enc = encode_jpeg(list(p), quality=quality)
        dec = torch.stack(decode_jpeg(enc)).to(x.device).float() / 255
        return from01(dec)
    return f


def make_cutout(frac):
    def f(x, g):
        B, C, H, W = x.shape
        s = int(H * math.sqrt(frac))
        x = x.clone()
        for b in range(B):
            i = int(torch.randint(0, H - s + 1, (1,), generator=g, device=x.device))
            j = int(torch.randint(0, W - s + 1, (1,), generator=g, device=x.device))
            x[b, :, i:i + s, j:j + s] = 0.0
        return x
    return f


def stats(logits, labels):
    lp = F.log_softmax(logits, -1)
    loss = -lp.gather(1, labels[:, None])[:, 0]
    p = lp.exp()
    top2 = p.topk(2, dim=1)
    pT = F.softmax(logits / T, -1)
    ent = -(pT * pT.clamp_min(1e-12).log()).sum(1)
    return {
        "acc_vs_pseudo": (logits.argmax(1) == labels).float().mean().item(),
        "loss_mean": loss.mean().item(),
        "loss_std": loss.std().item(),
        "loss_median": loss.median().item(),
        "loss_p90": loss.quantile(0.9).item(),
        "loss_p99": loss.quantile(0.99).item(),
        "maxprob_mean": top2.values[:, 0].mean().item(),
        "frac_maxprob_gt_0.99": (top2.values[:, 0] > 0.99).float().mean().item(),
        "margin_top1_top2_mean": (top2.values[:, 0] - top2.values[:, 1]).mean().item(),
        "entropy_T2_mean": ent.mean().item(),
    }


def kl_rows(p_logits, q_logits):
    """mean KL(p || q) at temperature T."""
    lp = F.log_softmax(p_logits / T, -1)
    lq = F.log_softmax(q_logits / T, -1)
    return (lp.exp() * (lp - lq)).sum(1).mean().item()


# ----------------------------------------------------------------------------- main
def main():
    t0 = time.time()
    print(f"device={DEVICE} gpu={torch.cuda.get_device_name() if DEVICE == 'cuda' else '-'}", flush=True)
    model = tt.load_model(ROOT / "model.pt")
    images = tt.load_forget_images(ROOT / "forget_images.npz")
    N = len(images)
    report = {"N": N}

    # 1. clean
    logits, feats = run(model, images, want_feats=True)
    labels = logits.argmax(1)
    report["clean"] = stats(logits, labels)
    print("\n== CLEAN (vs pseudo-labels = original argmax) ==")
    for k, v in report["clean"].items():
        print(f"  {k:24s} {v:.5f}")

    # fp32 vs fp16 sanity
    with torch.no_grad():
        x = tt.preprocess(images[:64])
        l32 = model(x).float().cpu()
    report["fp16_vs_fp32_kl_first64"] = kl_rows(l32, logits[:64])
    report["fp16_vs_fp32_argmax_agree"] = (l32.argmax(1) == labels[:64]).float().mean().item()

    # 2. class histogram
    counts = torch.bincount(labels, minlength=tt.NUM_CLASSES)
    report["class_hist"] = {
        "n_classes_present": int((counts > 0).sum()),
        "min": int(counts.min()), "max": int(counts.max()),
        "mean": counts.float().mean().item(), "std": counts.float().std().item(),
        "uniform_expected": N / tt.NUM_CLASSES,
        "top10_classes": [(int(c), int(counts[c])) for c in counts.argsort(descending=True)[:10]],
        "bottom10_classes": [(int(c), int(counts[c])) for c in counts.argsort()[:10]],
        "counts": counts.tolist(),
    }
    h = report["class_hist"]
    print(f"\n== CLASS HISTOGRAM == present={h['n_classes_present']}/100  min={h['min']} max={h['max']} "
          f"mean={h['mean']:.1f} std={h['std']:.1f} (uniform would be {h['uniform_expected']:.0f}/class)")
    print("  top10   :", h["top10_classes"])
    print("  bottom10:", h["bottom10_classes"])

    # 3. runner-up structure
    p = F.softmax(logits, -1)
    top3 = p.topk(3, dim=1)
    runner = top3.indices[:, 1]
    pairs = {}
    for a, b in zip(labels.tolist(), runner.tolist()):
        key = (min(a, b), max(a, b))
        pairs[key] = pairs.get(key, 0) + 1
    top_pairs = sorted(pairs.items(), key=lambda kv: -kv[1])[:20]
    report["runner_up"] = {
        "p2_mean": top3.values[:, 1].mean().item(),
        "p3_mean": top3.values[:, 2].mean().item(),
        "n_distinct_pairs": len(pairs),
        "top_pairs": [[list(k), v] for k, v in top_pairs],
    }
    # per-class: how consistent is the runner-up class? (high = clean class-similarity structure)
    cons = []
    for c in range(tt.NUM_CLASSES):
        m = labels == c
        if m.sum() >= 5:
            r = runner[m]
            cons.append(torch.bincount(r, minlength=tt.NUM_CLASSES).max().item() / m.sum().item())
    report["runner_up"]["per_class_runnerup_consistency_mean"] = float(sum(cons) / max(len(cons), 1))
    print(f"\n== RUNNER-UP == p2_mean={report['runner_up']['p2_mean']:.4f} p3_mean={report['runner_up']['p3_mean']:.4f} "
          f"distinct pairs={len(pairs)}  per-class runner-up consistency={report['runner_up']['per_class_runnerup_consistency_mean']:.3f}")
    print("  most frequent (top1,top2) pairs:", top_pairs[:10])

    # 4. augmentation stability
    augs = {
        "hflip": aug_hflip,
        "crop_0.8": make_crop(0.8), "crop_0.5": make_crop(0.5), "crop_0.25": make_crop(0.25),
        "noise_0.03": make_noise(0.03), "noise_0.1": make_noise(0.1), "noise_0.2": make_noise(0.2),
        "bright_0.6": make_brightness(0.6), "bright_1.4": make_brightness(1.4),
        "contrast_0.5": make_contrast(0.5), "gray": aug_gray,
        "blur_112": make_blur(112), "blur_56": make_blur(56),
        "rot_10": make_rotate(10), "rot_30": make_rotate(30),
        "jpeg_50": make_jpeg(50), "jpeg_20": make_jpeg(20),
        "cutout_0.25": make_cutout(0.25),
    }
    report["augs"] = {}
    aug_logits = {}
    print("\n== AUGMENTATION STABILITY (vs pseudo-labels) ==")
    print(f"  {'aug':14s} {'acc':>6s} {'loss_mu':>8s} {'loss_sd':>8s} {'maxp':>6s} {'KL(clean||aug)':>14s}")
    for name, fn in augs.items():
        la, _ = run(model, images, transform=fn)
        s = stats(la, labels)
        s["kl_clean_to_aug_T2"] = kl_rows(logits, la)
        report["augs"][name] = s
        aug_logits[name] = la.half()
        print(f"  {name:14s} {s['acc_vs_pseudo']:6.3f} {s['loss_mean']:8.3f} {s['loss_std']:8.3f} "
              f"{s['maxprob_mean']:6.3f} {s['kl_clean_to_aug_T2']:14.4f}", flush=True)

    # mixup between random pairs: does the model still output its memorised label for the dominant image?
    perm = torch.randperm(N)
    for lam in (0.7, 0.5):
        mixed = (images.float() * lam + images[perm].float() * (1 - lam)).round().to(torch.uint8)
        lm, _ = run(model, mixed)
        pm = F.softmax(lm, -1)
        report["augs"][f"mixup_{lam}"] = {
            "argmax_is_A": (lm.argmax(1) == labels).float().mean().item(),
            "argmax_is_B": (lm.argmax(1) == labels[perm]).float().mean().item(),
            "pA_mean": pm.gather(1, labels[:, None]).mean().item(),
            "pB_mean": pm.gather(1, labels[perm][:, None]).mean().item(),
        }
        print(f"  mixup_{lam}: {report['augs'][f'mixup_{lam}']}")

    # 5. near-duplicates (penultimate features)
    fn_ = F.normalize(feats, dim=1).to(DEVICE)
    sim = fn_ @ fn_.T
    sim.fill_diagonal_(-1)
    nn_sim, nn_idx = sim.max(1)
    nn_sim, nn_idx = nn_sim.cpu(), nn_idx.cpu()
    report["near_dup"] = {
        "nn_cos_mean": nn_sim.mean().item(),
        "n_nn_cos_gt_0.95": int((nn_sim > 0.95).sum()),
        "n_nn_cos_gt_0.99": int((nn_sim > 0.99).sum()),
        "nn_same_label_frac": (labels[nn_idx] == labels).float().mean().item(),
    }
    print(f"\n== NEAR-DUPLICATES == {report['near_dup']}")

    # weight-level facts useful later
    sd = model.state_dict()
    report["weights"] = {
        "head_weight_norm": sd["head.weight"].norm().item(),
        "head_bias_mean": sd["head.bias"].mean().item(), "head_bias_std": sd["head.bias"].std().item(),
        "layerscale_gamma_mean_abs_per_block": [
            round(sd[f"blocks.{i}.ls1.gamma"].abs().mean().item(), 5) for i in range(12)],
    }
    print(f"\n== WEIGHTS == {report['weights']}")

    torch.save({"logits": logits, "feats": feats.half(), "labels": labels, "aug_logits": aug_logits,
                "mixup_perm": perm}, OUT_DIR / "diag_orig.pt")
    with open(OUT_DIR / "diag_report.json", "w") as f:
        json.dump(report, f, indent=1)
    print(f"\nSaved output/diag_orig.pt and output/diag_report.json  ({time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
