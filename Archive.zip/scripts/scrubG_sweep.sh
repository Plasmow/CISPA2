#!/bin/bash
# SCRUB-G: recovery-phase sweep. Per-image KL cap, max steps through step 648 (msteps 12 of 14), then min-only recovery.
# Evaluate/save every 4 steps from 636 to 720 to pick the number of recovery steps. cap32@660 scored 0.1435.
# Seed-1 repeats of cap32/cap40 check how stable the recovery point is.
#SBATCH --job-name=scrubG
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --time=00:45:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
P=".venv/bin/python scripts/scrub.py --lr 3e-5 --kd_T 4 --epochs 14 --msteps 12 --min_per_max 1 --eval_every 60 --fine_from 636 --fine_to 720 --fine_every 4 --save_min 636 --save_max 720"
run() { $P --run "$1" "${@:2}" > "output/$1.log" 2>&1; }
(export CUDA_VISIBLE_DEVICES=0
 run scrubG_cap32 --cap 32
 run scrubG_cap32_s1 --cap 32 --seed 1) &
(export CUDA_VISIBLE_DEVICES=1
 run scrubG_cap36 --cap 36
 run scrubG_cap40_s1 --cap 40 --seed 1) &
(export CUDA_VISIBLE_DEVICES=2
 run scrubG_cap40 --cap 40) &
(export CUDA_VISIBLE_DEVICES=3
 run scrubG_cap48 --cap 48) &
wait
echo "done!"
