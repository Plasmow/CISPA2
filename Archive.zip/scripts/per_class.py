"""Per-class analysis of the forget set (45 classes present, pseudo-label = original argmax).

For each "source" (a model's predictions or a step-A target distribution) and each class c:
  - loss distribution of the images of class c: mean / std / median / p90 / max (CE w.r.t. pseudo-label)
  - acc (argmax == pseudo-label)
  - class-mean probability vector  P_c = mean_i p(x_i)  ->  top-1 class/prob, runner-up class/prob
    (computed at T=1 and, for the original, also at T=2 = the server's KL temperature)
  - runner-up consistency: fraction of images of c whose own best wrong class == the class-level runner-up
  - where errors go: most frequent predicted class among misclassified images of c

CPU sources (cached):  orig (clean logits, output/diag_orig.pt), step-A aug-average targets s1..s4
(output/targets/s*.pt, probs_mean), an A1 margin target.
Optional GPU sources:  --ckpt NAME=path.pt  (clean + one fixed mild-altered copy, like common.EvalSets), --orig_mild.

Writes output/per_class/{per_class.csv, summary.json, report.txt}.
Usage (from unlearning/):  python scripts/per_class.py [--ckpt d1=output/d1_s2mean/ckpt_00432.pt --orig_mild]
"""
import argparse
import csv
import json
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "output" / "per_class"
TDIR = ROOT / "output" / "targets"


def per_class(name, P, labels, counts, classes):
    """P: [N,100] probabilities."""
    N, K = P.shape
    loss = -P.clamp_min(1e-12).log().gather(1, labels[:, None])[:, 0]
    pred = P.argmax(1)
    onehot = F.one_hot(labels, K).bool()
    best_wrong = P.masked_fill(onehot, -1).argmax(1)
    rows = []
    for c in classes:
        m = labels == c
        Pc = P[m].mean(0)
        top = Pc.topk(3)
        Pw = Pc.clone()
        Pw[c] = -1
        ru = int(Pw.argmax())
        l = loss[m]
        wrong = m & (pred != labels)
        err_to = int(torch.bincount(pred[wrong], minlength=K).argmax()) if wrong.any() else -1
        err_frac = (pred[wrong] == err_to).float().mean().item() if wrong.any() else float("nan")
        rows.append({
            "source": name, "cls": c, "n": int(m.sum()),
            "acc": (pred[m] == c).float().mean().item(),
            "loss_mean": l.mean().item(), "loss_std": l.std().item(), "loss_med": l.median().item(),
            "loss_p90": l.quantile(0.9).item(), "loss_max": l.max().item(),
            "p_true_mean": Pc[c].item(),
            "top1": int(top.indices[0]), "top1_p": top.values[0].item(),
            "runner_up": ru, "runner_up_p": Pc[ru].item(),
            "runner_up_n_forget": int(counts[ru]),
            "runner_up_consistency": (best_wrong[m] == ru).float().mean().item(),
            "err_to": err_to, "err_to_frac": err_frac,
        })
    return rows, loss


@torch.no_grad()
def gpu_logits(paths, orig_mild):
    import common as C
    model0, imgs = C.load_all()
    sets = C.EvalSets(imgs)
    out = {}
    if orig_mild:
        out["orig_mild"] = sets.logits(model0, "mild").cpu()
    for name, p in paths:
        sd = torch.load(p, map_location="cpu")
        model0.load_state_dict(sd, strict=True)
        out[f"{name}_clean"] = sets.logits(model0, "clean").cpu()
        out[f"{name}_mild"] = sets.logits(model0, "mild").cpu()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", action="append", default=[], help="NAME=path (GPU)")
    ap.add_argument("--orig_mild", action="store_true", help="also original on mild-altered copies (GPU)")
    ap.add_argument("--a1", default="a1_m1.2_s2.4_T1.5_w0.5")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)

    d = torch.load(ROOT / "output" / "diag_orig.pt", map_location="cpu", weights_only=False)
    z = d["logits"].float()
    labels = z.argmax(1)
    K = z.shape[1]
    counts = torch.bincount(labels, minlength=K)
    classes = [int(c) for c in torch.nonzero(counts).flatten()]

    sources = {"orig_T1": F.softmax(z, -1), "orig_T2": F.softmax(z / 2, -1)}
    for s in ("s1", "s2", "s3", "s4"):
        t = torch.load(TDIR / f"{s}.pt", map_location="cpu", weights_only=False)
        assert torch.equal(t["labels"], labels)
        sources[f"{s}_mean"] = t["probs_mean"].float()
    if (TDIR / f"{a.a1}.pt").exists():
        sources["a1"] = torch.load(TDIR / f"{a.a1}.pt", map_location="cpu", weights_only=False)["probs_mean"].float()
    if a.ckpt or a.orig_mild:
        lg = gpu_logits([c.split("=", 1) for c in a.ckpt], a.orig_mild)
        for k, v in lg.items():
            sources[k] = F.softmax(v, -1)

    all_rows, summary = [], {}
    for name, P in sources.items():
        rows, loss = per_class(name, P, labels, counts, classes)
        all_rows += rows
        # between-class vs within-class share of the loss variance
        cm = torch.zeros(K).index_add_(0, labels, loss) / counts.clamp_min(1)
        between = ((cm[labels] - loss.mean()) ** 2).mean().item()
        total = loss.var(unbiased=False).item()
        ru = torch.tensor([r["runner_up"] for r in rows])
        summary[name] = {
            "acc": (P.argmax(1) == labels).float().mean().item(),
            "loss_mean": loss.mean().item(), "loss_std": loss.std().item(),
            "between_class_var_share": between / max(total, 1e-12),
            "runner_up_is_forget_class": (counts[ru] > 0).float().mean().item(),
            "runner_up_adjacent_idx(|d|<=3)": ((ru - torch.tensor(classes)).abs() <= 3).float().mean().item(),
            "corr_classloss_vs_count": torch.corrcoef(torch.stack(
                [torch.tensor([r["loss_mean"] for r in rows]),
                 torch.tensor([float(r["n"]) for r in rows])]))[0, 1].item(),
        }
    # agreement of the class-level runner-up between sources (is orig's dark knowledge = drifted class?)
    by = {}
    for r in all_rows:
        by.setdefault(r["source"], {})[r["cls"]] = r["runner_up"]
    ref = "orig_T2"
    for name in sources:
        summary[name][f"runner_up_agrees_with_{ref}"] = sum(by[name][c] == by[ref][c] for c in classes) / len(classes)

    with open(OUT / "per_class.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(all_rows[0]))
        w.writeheader()
        w.writerows(all_rows)
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))

    lines = []
    for name in sources:
        lines.append(f"\n=== {name} ===  " + "  ".join(f"{k}={v:.3f}" for k, v in summary[name].items()))
        lines.append(f"{'cls':>4} {'n':>4} {'acc':>5} {'Lmean':>6} {'Lstd':>6} {'Lmed':>6} {'Lp90':>6} {'Lmax':>6}"
                     f" | {'p_true':>6} | {'2nd':>4} {'p2nd':>7} {'n2nd':>4} {'cons':>5} | {'err->':>5} {'frac':>4}")
        for r in sorted([r for r in all_rows if r["source"] == name], key=lambda r: -r["loss_mean"]):
            lines.append(f"{r['cls']:>4} {r['n']:>4} {r['acc']:5.2f} {r['loss_mean']:6.3f} {r['loss_std']:6.3f}"
                         f" {r['loss_med']:6.3f} {r['loss_p90']:6.3f} {r['loss_max']:6.2f} | {r['p_true_mean']:6.3f} |"
                         f" {r['runner_up']:>4} {r['runner_up_p']:7.4f} {r['runner_up_n_forget']:>4}"
                         f" {r['runner_up_consistency']:5.2f} | {r['err_to']:>5} {r['err_to_frac']:4.2f}")
    txt = "\n".join(lines)
    (OUT / "report.txt").write_text(txt)
    print(txt)


if __name__ == "__main__":
    main()
