#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=00:35:00
#SBATCH --job-name=wm_wamft
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/wam_%j.out
# dc-gpu-devel: OUTSIDE the cispahack reservation. Submit from the team folder; after start check:
#   scontrol show job <id> | grep Reservation   (must be empty)
# WAM-ft (stack/wam_ft.py): wm-U-Net 5-fold fine-tuning + per-cell message-decoding head (WAM eq. 5), arms n/d/c.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|ffmpeg|state_dict|Model loaded|ERROR:0" | sed -u "s/^/[$1] /"; }
CUDA_VISIBLE_DEVICES=0 $PY wam_ft.py --method pixelseal  --init wmunet  --arms n,d,c 2>&1 | tagged gpu0 &
CUDA_VISIBLE_DEVICES=1 $PY wam_ft.py --method trustmark  --init wmunet  --arms n,d,c 2>&1 | tagged gpu1 &
CUDA_VISIBLE_DEVICES=2 $PY wam_ft.py --method stegastamp --init wmunetH --enc_lr 3e-5 --arms n,d,c 2>&1 | tagged gpu2 &
CUDA_VISIBLE_DEVICES=3 $PY wam_ft.py --method pixelseal  --init wmunet2 --arms n,d --suffix 2 2>&1 | tagged gpu3 &
wait
echo done
