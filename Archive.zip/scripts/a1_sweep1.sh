#!/bin/bash
# A1 sweep 1: margin targets (build_targets_margin.py) + distill with clean_frac. 2 runs per GPU, sequential.
# Axes: target loss mean (0.8/1.2/1.6), loss std (1.6/2.4), wrong-class source (clean/blend/aug), trainer strength.
P=".venv/bin/python scripts/distill.py --epochs 10 --clean_frac 0.5 --eval_every 135"
S="--lr 3e-5 --alpha 0.3"
T=output/targets
run() { $P --run "$1" --target "$T/$2.pt" "${@:3}" > "output/$1.log" 2>&1; }
(CUDA_VISIBLE_DEVICES=0; export CUDA_VISIBLE_DEVICES
 run a1s1_m1.2_s2.4_w0.5   a1_m1.2_s2.4_T1.5_w0.5 $S
 run a1s1_m0.8_s2.4_w0.5   a1_m0.8_s2.4_T1.5_w0.5 $S) &
(CUDA_VISIBLE_DEVICES=1; export CUDA_VISIBLE_DEVICES
 run a1s1_m1.6_s2.4_w0.5   a1_m1.6_s2.4_T1.5_w0.5 $S
 run a1s1_m1.2_s1.6_w0.5   a1_m1.2_s1.6_T1.5_w0.5 $S) &
(CUDA_VISIBLE_DEVICES=2; export CUDA_VISIBLE_DEVICES
 run a1s1_m1.2_s2.4_w0     a1_m1.2_s2.4_T1.5_w0 $S
 run a1s1_m1.2_s2.4_w1     a1_m1.2_s2.4_T1.5_w1 $S) &
(CUDA_VISIBLE_DEVICES=3; export CUDA_VISIBLE_DEVICES
 run a1s1_m1.2_s2.4_w0.5_weak   a1_m1.2_s2.4_T1.5_w0.5 --lr 1e-5 --alpha 1.0
 run a1s1_m1.2_s2.4_w0.5_strong a1_m1.2_s2.4_T1.5_w0.5 --lr 1e-4 --alpha 0.3) &
wait
