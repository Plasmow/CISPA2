"""U-Net predicting the 128x128 watermark grid (stride 4) from a 512x512 image.

Hooks for later fusion:
  - aux_ch  : extra 128x128 maps (heatmaps, per-position maps, ...) concatenated at the last decoder stage
  - glob_dim: per-image vector (method one-hot, whole-image score, ...) broadcast at the bottleneck
  - highpass: adds x - blur(x) (amplified) as 3 extra input channels (watermarks are mostly high-frequency)
  - in_extra: extra full-resolution (512x512) input channels, e.g. residual products hp(x).hp(r)
"""
import numpy as np
import timm
import torch
import torch.nn as nn
import torch.nn.functional as F

MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def gaussian_blur(x, sigma):
    r = int(np.ceil(3 * sigma)); k = torch.arange(-r, r + 1, device=x.device, dtype=x.dtype)
    k = torch.exp(-k ** 2 / (2 * sigma ** 2)); k = k / k.sum(); C = x.shape[1]
    x = F.conv2d(F.pad(x, (r, r, 0, 0), mode="reflect"), k.view(1, 1, 1, -1).repeat(C, 1, 1, 1), groups=C)
    return F.conv2d(F.pad(x, (0, 0, r, r), mode="reflect"), k.view(1, 1, -1, 1).repeat(C, 1, 1, 1), groups=C)


class ConvBlock(nn.Sequential):
    def __init__(self, cin, cout):
        super().__init__(nn.Conv2d(cin, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
                         nn.Conv2d(cout, cout, 3, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class Up(nn.Module):
    def __init__(self, cin, cskip, cout):
        super().__init__()
        self.block = ConvBlock(cin + cskip, cout)

    def forward(self, x, skip):
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.block(torch.cat([x, skip], 1))


class UNet128(nn.Module):
    def __init__(self, encoder="resnet34.a1_in1k", pretrained=True, highpass=False, glob_dim=0, aux_ch=0,
                 in_extra=0, dec=(256, 128, 64)):
        super().__init__()
        self.highpass, self.glob_dim, self.aux_ch, self.in_extra = highpass, glob_dim, aux_ch, in_extra
        in_ch = (6 if highpass else 3) + in_extra
        self.enc = timm.create_model(encoder, pretrained=pretrained, features_only=True, in_chans=in_ch)
        ch = self.enc.feature_info.channels()                     # strides 2, 4, 8, 16, 32
        self.up16 = Up(ch[4] + glob_dim, ch[3], dec[0])
        self.up8 = Up(dec[0], ch[2], dec[1])
        self.up4 = Up(dec[1], ch[1] + ch[0] + aux_ch, dec[2])      # stride-2 features pooled into the stride-4 skip
        self.head = nn.Sequential(ConvBlock(dec[2], dec[2] // 2), nn.Conv2d(dec[2] // 2, 1, 1))

    def forward(self, x, glob=None, aux=None, extra=None):
        """x [B,3,512,512] in [0,1]; glob [B,glob_dim]; aux [B,aux_ch,128,128]; extra [B,in_extra,512,512]
        -> logits [B,128,128]."""
        z = (x - MEAN.to(x)) / STD.to(x)
        if self.highpass:
            z = torch.cat([z, (x - gaussian_blur(x, 1.5)) * 20], 1)
        if self.in_extra:
            z = torch.cat([z, extra.to(z)], 1)
        f = self.enc(z)
        b = f[4]
        if self.glob_dim:
            b = torch.cat([b, glob[:, :, None, None].expand(-1, -1, *b.shape[-2:]).to(b)], 1)
        y = self.up16(b, f[3]); y = self.up8(y, f[2])
        s4 = [f[1], F.avg_pool2d(f[0], 2)]
        if self.aux_ch:
            s4.append(F.interpolate(aux.to(f[1]), size=f[1].shape[-2:], mode="bilinear", align_corners=False))
        y = self.up4(y, torch.cat(s4, 1))
        return self.head(y)[:, 0]


def miou_loss(logits, y, eps=1.0):
    """1 - soft per-image mIoU over classes {0,1} (differentiable surrogate of the official metric)."""
    p = torch.sigmoid(logits.float()); y = y.float()
    i1 = (p * y).sum((1, 2)); u1 = (p + y - p * y).sum((1, 2))
    q, z = 1 - p, 1 - y
    i0 = (q * z).sum((1, 2)); u0 = (q + z - q * z).sum((1, 2))
    return (1 - ((i1 + eps) / (u1 + eps) + (i0 + eps) / (u0 + eps)) / 2).mean()
