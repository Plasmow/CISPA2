#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --reservation=cispahack
#SBATCH --time=02:30:00
#SBATCH --job-name=wm_unet
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/unet_%j.out
# Submit FROM THE TEAM FOLDER (scratch) so the team job check (%Z) sees it:
#   cd /p/scratch/training2666/ayadi1/automateam2 && sbatch /p/project1/training2666/debbah2/wmloc_unet/run_unet.sh
# Code/outputs live in project1 because the scratch group quota is full.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
VARS=(rgb rgb_glob rgb_hp_glob effb3_hp_glob)
for k in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=$k $PY train_unet.py --variant ${VARS[$k]} --epochs 60 2>&1 | grep --line-buffered -v -i -E "warn|Unexpected keys" | sed -u "s/^/[gpu$k] /" &
done
wait
$PY eval_unet.py 2>&1 | grep -v -i warn
echo done
