| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['headsyn2', 'headsyn'] | 0.5609 | 0.5692 | 0.5526 |
| pixelseal | fusion top3 ['headsyn2', 'headsyn', 'headmulti'] | 0.5680 | 0.5826 | 0.5534 |
| pixelseal | fusion all ['headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5749 | 0.5845 | 0.5654 |
| pixelseal | fusion all + rule switch | 0.5749 | 0.5845 | 0.5654 |
| pixelseal | fusion all + rule expected_area | 0.5791 | 0.5916 | 0.5667 |
| pixelseal | fusion all + rule otsu_in_regime | 0.5769 | 0.5853 | 0.5685 |
| pixelseal | fusion all + rule regressed_area | 0.5535 | 0.5693 | 0.5377 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6150 | 0.6290 | 0.6009 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.5762 | 0.5902 | 0.5623 |
| pixelseal | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<256 / F:drop<256 | **0.5807** | 0.5945 | 0.5668 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.5833 | 0.5969 | 0.5697 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6042 | 0.5969 | 0.6115 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6147 | 0.5969 | 0.6326 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6162 | 0.5969 | 0.6356 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6180 | 0.5969 | 0.6390 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6063 | 0.5969 | 0.6158 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6025 | 0.5969 | 0.6080 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6180** | 0.5969 | 0.6390 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['headsyn2', 'headsyn'] | 0.5549 | 0.5727 | 0.5371 |
| trustmark | fusion top3 ['headsyn2', 'headsyn', 'headmulti'] | 0.5574 | 0.5810 | 0.5338 |
| trustmark | fusion all ['headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5697 | 0.5802 | 0.5592 |
| trustmark | fusion all + rule switch | 0.5697 | 0.5802 | 0.5592 |
| trustmark | fusion all + rule expected_area | 0.5788 | 0.5870 | 0.5706 |
| trustmark | fusion all + rule otsu_in_regime | 0.5744 | 0.5804 | 0.5684 |
| trustmark | fusion all + rule regressed_area | 0.5582 | 0.5650 | 0.5513 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6162 | 0.6222 | 0.6103 |
| trustmark | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.5788 | 0.5870 | 0.5706 |
| trustmark | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<64 / F:drop<16+box>=0.7 | **0.5774** | 0.5856 | 0.5693 |
| trustmark | + rect override none (boxes for 85 train images) | 0.5806 | 0.5878 | 0.5734 |
| trustmark | + rect override rect>=0.7 (boxes for 85 train images) | 0.6174 | 0.5878 | 0.6471 |
| trustmark | + rect override rect>=0.75 (boxes for 85 train images) | 0.6355 | 0.5878 | 0.6832 |
| trustmark | + rect override rect>=0.8 (boxes for 85 train images) | 0.6416 | 0.5878 | 0.6954 |
| trustmark | + rect override rect>=0.85 (boxes for 85 train images) | 0.6436 | 0.5878 | 0.6994 |
| trustmark | + rect override rect>=0.9 (boxes for 85 train images) | 0.6436 | 0.5878 | 0.6994 |
| trustmark | + rect override rect>=0.95 (boxes for 85 train images) | 0.6436 | 0.5878 | 0.6994 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6355** | 0.5878 | 0.6832 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot', 'headsyn2', 'headmulti', 'remark'] | 0.6861 | 0.7246 | 0.6477 |
| stegastamp | fusion all + rule switch | 0.6861 | 0.7246 | 0.6477 |
| stegastamp | fusion all + rule expected_area | 0.6937 | 0.7278 | 0.6596 |
| stegastamp | fusion all + rule otsu_in_regime | 0.6898 | 0.7294 | 0.6501 |
| stegastamp | fusion all + rule regressed_area | 0.6766 | 0.7099 | 0.6432 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7251 | 0.7602 | 0.6899 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.6937 | 0.7278 | 0.6596 |
| stegastamp | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<64 / F:largest | **0.6935** | 0.7292 | 0.6579 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<256",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.618,
  "cv_T": 0.5969,
  "cv_F": 0.639,
  "test_frac_pred_1": 0.496
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<64",
  "post_F": "drop<16+box>=0.7",
  "rect": "rect>=0.85",
  "cv": 0.6355,
  "cv_T": 0.5878,
  "cv_F": 0.6832,
  "test_frac_pred_1": 0.501
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "none",
  "cv": 0.6935,
  "cv_T": 0.7292,
  "cv_F": 0.6579,
  "test_frac_pred_1": 0.484
 },
 "expected_cv_mIoU": 0.649,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v3d.pt",
 "size_MB": 15.96
}
```
