#!/bin/bash
.venv/bin/python scripts/build_twin_targets.py --strengths 0.625,0.875 > output/twin_targets2.log 2>&1
COMMON="--epochs 10 --clean_frac 0.5 --eval_every 54"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON "$@" > output/$name.log 2>&1 & }
run 0 tw2_s0.875_lr3e-5  --target output/targets/tw0.875.pt --lr 3e-5
run 1 tw2_s0.875_lr1e-4  --target output/targets/tw0.875.pt --lr 1e-4
run 2 tw2_s0.625_lr1e-4  --target output/targets/tw0.625.pt --lr 1e-4
run 3 tw2_s0.875_lr1e-4_tau1.5 --target output/targets/tw0.875.pt --lr 1e-4 --tau 1.5
wait
