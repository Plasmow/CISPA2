"""Classifier-independent semantic distance for the twins: DINOv2 CLS embeddings of every forget image and every
twin (output/twins/*.npz). Used by adaptive_twins.py to gate twins by 'same object?' instead of by the original
classifier's confidence (which is circular: that classifier is the one memorising x).

Writes output/twins/dino.pt: {'src': [N,D], 's<tag>': [N,k,D]} (L2-normalised, fp16).
Run on the login-node GPU (inference only):  .venv/bin/python scripts/dino_embed.py
"""
import glob, sys, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

OUT = ROOT / "output" / "twins" / "dino.pt"
MODEL = "facebook/dinov2-base"


@torch.no_grad()
def main():
    from transformers import AutoModel
    dev = "cuda"
    m = AutoModel.from_pretrained(MODEL).to(dev).half().eval()
    mean = torch.tensor([0.485, 0.456, 0.406], device=dev)[:, None, None]
    std = torch.tensor([0.229, 0.224, 0.225], device=dev)[:, None, None]

    def emb(u8):  # u8 [B,224,224,3] uint8 numpy/torch
        x = torch.as_tensor(u8).to(dev).permute(0, 3, 1, 2).float() / 255.0
        x = ((x - mean) / std).half()
        o = m(pixel_values=x)
        cls = o.last_hidden_state[:, 0]
        patch = o.last_hidden_state[:, 1:].mean(1)
        return F.normalize(torch.cat([cls, patch], 1).float(), dim=1).half().cpu()

    def run(arr, bs=256):
        return torch.cat([emb(arr[i:i + bs]) for i in range(0, len(arr), bs)])

    res = torch.load(OUT) if OUT.exists() else {}
    if "src" not in res:
        imgs = tt.load_forget_images(ROOT / "forget_images.npz")
        res["src"] = run(imgs.numpy() if hasattr(imgs, "numpy") else imgs)
        print("src", res["src"].shape, flush=True)
    tags = sorted({Path(f).name.split("_sh")[0] for f in glob.glob(str(ROOT / "output/twins/s*_sh*.npz")) if ".tmp" not in f})
    for tag in tags:
        if tag in res:
            continue
        t0 = time.time(); idx, E = [], []
        for f in sorted(glob.glob(str(ROOT / f"output/twins/{tag}_sh*.npz"))):
            if ".tmp" in f:
                continue
            with np.load(f) as d:
                im = d["images"]; idx.append(d["idx"])
            n, k = im.shape[:2]
            E.append(run(im.reshape(n * k, 224, 224, 3)).reshape(n, k, -1))
        idx = np.concatenate(idx); E = torch.cat(E)[np.argsort(idx)]
        res[tag] = E
        torch.save(res, OUT)
        print(f"{tag} {tuple(E.shape)} {time.time() - t0:.0f}s", flush=True)
    torch.save(res, OUT)


if __name__ == "__main__":
    main()
