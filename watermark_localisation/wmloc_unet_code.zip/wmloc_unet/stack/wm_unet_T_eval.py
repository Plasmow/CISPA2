"""Effect of new map sources on the v3 fusion, per method and per sub-type (Agent B). Read-only: nothing is written.

For each method, starting from the fusion sources of a version (default submission_v8.json), compare
  base               : the version's sources
  base + <tag>       : each new source alone
  base + all new     : all new sources of the method
with v3.py's own functions and folds: OOF fusion (oof_fusion), then the version's rule AND the emiou rule (rule_emiou),
post-processing chosen in CV (v3 steps 3-4). Before rectangles and SAM. Sub-types: T / F-rect / F-seg (typo_stats).

    python wm_unet_T_eval.py --tags wmunetT wmunetTo wmunetT0
"""
import argparse
import json

import numpy as np

from v3 import (ROOT, HERE, TASK, METHODS, load_split, folds, g_of, load_sources, fuse_feats, oof_fusion, rule_preds,
                post_scores, cv_select, cv_eval)
from rule_emiou import emiou_rule


def pipeline_scores(L, g, gt, rule):
    pred = np.zeros(gt.shape, bool); typT = np.zeros(len(L), bool)
    for f in folds(len(L), 5, 0):
        tr = np.setdiff1d(np.arange(len(L)), f); out, p = rule_preds(L, g, gt, tr)
        m = emiou_rule(L, g, gt, tr, "none", p)[0] if rule == "emiou_none" else out[rule]
        pred[f] = m[f]; typT[f] = (g > p["tg"])[f]
    P = post_scores(pred, gt, typT)
    sT, _ = cv_select({k[1]: v for k, v in P.items() if k[0] == "T"}, typT); sF, _ = cv_select({k[1]: v for k, v in P.items() if k[0] == "F"}, ~typT)
    s = np.zeros(len(L)); s[typT] = sT; s[~typT] = sF
    return s


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--tags", nargs="+", required=True); ap.add_argument("--base", default="submission_v8")
    ap.add_argument("--methods", nargs="+", default=list(METHODS))
    ap.add_argument("--combos", nargs="*", default=[], help="extra variants: comma-separated tag sets added together to the base")
    ap.add_argument("--no_singles", action="store_true", help="skip the base + <tag> variants"); a = ap.parse_args()
    rep = json.loads((ROOT / "submissions" / f"{a.base}.json").read_text())
    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}
    typo = {r["name"]: r for r in json.loads((TASK / "loc" / "cache" / "typo_stats.json").read_text())}
    subt = lambda n: "T" if typo[n]["full"] else ("F-rect" if typo[n]["fill_bbox"] >= 0.99 else "F-seg")
    print("| method | sources | switch CV of map | rule | all | T | F-rect | F-seg |\n|---|---|---|---|---|---|---|---|", flush=True)
    for meth in a.methods:
        cfg = rep[meth]; base = cfg["sources"] or [cfg["map"]]
        new = [t for t in a.tags if (HERE / "maps" / f"{t}_train_{meth}.npz").exists() and (HERE / "maps" / f"{t}_test_{meth}.npz").exists()]
        n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
        g = g_of("train", n_tr, meta_tr); gt = np.stack([tr_all.m128[n] for n in n_tr]).astype(bool); st = np.array([subt(n) for n in n_tr])
        allsrc = base + new
        runs = [s for s in allsrc if (ROOT / "runs" / s / "oof_all.npz").exists()]
        extras = [s for s in allsrc if s != "head" and (HERE / "maps" / f"{s}_train_{meth}.npz").exists()]
        S = load_sources(meth, n_tr, n_te, runs, extras)
        variants = [("base", base)] + ([] if a.no_singles else [(f"base + {t}", base + [t]) for t in new])
        variants += [(f"base + {c}", base + c.split(",")) for c in a.combos if all(t in new for t in c.split(","))]
        for t in new:                                                   # the new source alone, for reference
            s = cv_eval(S[t][0], gt, g, "switch")
            print(f"| {meth} | {t} alone | {s.mean():.4f} | switch | {s.mean():.4f} | {s[st == 'T'].mean():.4f} | {s[st == 'F-rect'].mean():.4f} | {s[st == 'F-seg'].mean():.4f} |", flush=True)
        for name, srcs in variants:
            L = oof_fusion(fuse_feats([S[k][0] for k in srcs], g), gt); sw = cv_eval(L, gt, g, "switch").mean()
            for rule in (cfg["rule"], "emiou_none"):
                s = pipeline_scores(L, g, gt, rule)
                print(f"| {meth} | {name} | {sw:.4f} | {rule} | {s.mean():.4f} | {s[st == 'T'].mean():.4f} | {s[st == 'F-rect'].mean():.4f} | {s[st == 'F-seg'].mean():.4f} |", flush=True)


if __name__ == "__main__":
    main()
