#!/bin/bash
# Wait until the team has no job (running or pending), submit the T job from the team folder, wait for it, run the post-processing.
T=/p/scratch/training2666/ayadi1/automateam2
while squeue -r -h -o "%Z" | grep -q "^$T"; do sleep 30; done
cd $T && J=$(sbatch --parsable /p/project1/training2666/debbah2/wmloc_unet/run_unetT_devel.sh) || exit 1
echo "submitted $J $(date +%H:%M)"; sleep 60; scontrol show job $J | grep -o "Reservation=[^ ]*"
while squeue -h -j $J 2>/dev/null | grep -q .; do sleep 30; done
echo "job $J finished $(date +%H:%M)"; tail -30 /p/project1/training2666/debbah2/wmloc_unet/logs/unetT_$J.out
/p/project1/training2666/debbah2/wmloc_unet/stack/post_unetT.sh
