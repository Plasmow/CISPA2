#!/bin/bash
# A1 + Task-1 class-similarity prior (build_targets_margin.py --n_prior), strong trainer.
# Compare against a1s1_m1.2_s2.4_w0.5_strong (same target without the prior, same trainer).
#SBATCH --job-name=a1p-sweep1
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --time=00:30:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
P=".venv/bin/python scripts/distill.py --epochs 10 --clean_frac 0.5 --eval_every 135"
S="--lr 1e-4 --alpha 0.3"
T=output/targets
run() { $P --run "$1" --target "$T/$2.pt" "${@:3}" > "output/$1.log" 2>&1; }
(CUDA_VISIBLE_DEVICES=0; export CUDA_VISIBLE_DEVICES
 run a1p_m1.2_s2.4_w0.5_p0.2_strong a1_m1.2_s2.4_T1.5_w0.5_p0.2 $S) &
(CUDA_VISIBLE_DEVICES=1; export CUDA_VISIBLE_DEVICES
 run a1p_m1.2_s2.4_w0.5_p0.4_strong a1_m1.2_s2.4_T1.5_w0.5_p0.4 $S) &
wait
echo "done!"
