"""Pixel attribution of the official decoders with the KNOWN message (no training -> trivially out-of-fold).

conf(x) = mean over bits of logit * (2 msg - 1), through the exact wrapper preprocessing (PixelSeal: bilinear AA 256 +
det; TrustMark: bilinear AA 245, *2-1, ResNet-50; StegaStamp: bicubic AA 400, torch port of the ONNX decoder).
g = d conf / d x at 512, h = x - Gaussian_1(x) (per channel). Maps on the 128 grid (8 px windows, then 4x4 pooling):
  ga = sum_c g*h (input x gradient on the high-pass)     gn = ga / sqrt(sum g^2 * sum h^2) (local correlation)
  gm = log sum |g| (saliency)                            gd = ga for PixelSeal's detection channel (others: = ga)
Per-image z-score, clip +-8 -> maps/{ga,gn,gm,gd}_{split}_<m>.npz.
  python grad_maps.py train [methods...]      then   python noise_maps.py --pilot ga gn gm gd
"""
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT, METHODS  # noqa: E402
from noise_maps import HERE, pool, zimg  # noqa: E402

TAGS = ("ga", "gn", "gm", "gd")


def conf_fns(meth):
    if meth == "stegastamp":
        from stega_torch import StegaDecoder
        net = StegaDecoder().eval()
        f = lambda x: net(F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1))
        return f, None
    wm = load_watermark(meth, KIT / "models", "cpu")
    if meth == "pixelseal":
        det = wm.det
        out = lambda x: det(F.interpolate(x, size=(256, 256), mode="bilinear", align_corners=False, antialias=True))
        return (lambda x: out(x)[:, 1:]), (lambda x: out(x)[:, 0])
    net = wm.net
    return (lambda x: net(F.interpolate(x, size=(245, 245), mode="bilinear", align_corners=False, antialias=True) * 2 - 1)), None


def grad(fn, x, sgn):
    x = x.clone().requires_grad_(True)
    v = fn(x); s = (v * sgn).mean() if v.dim() == 2 else v.mean()
    s.backward(); return x.grad[0].numpy().astype(np.float64)


def maps(g, x):
    h = x - np.stack([ndi.gaussian_filter(c, 1.0) for c in x])
    u = lambda a: pool(ndi.uniform_filter(a, 8), 4)
    ga = u((g * h).sum(0)); gn = ga / np.sqrt(u((g ** 2).sum(0)) * u((h ** 2).sum(0)) + 1e-30)
    return ga, gn, np.log(u(np.abs(g).sum(0)) + 1e-30)


def main():
    torch.set_num_threads(8); split = sys.argv[1]; meths = sys.argv[2:] or METHODS; ds = load_split(split)
    for meth in meths:
        fn, fd = conf_fns(meth); idx = [i for i, m in enumerate(ds.meta) if m["method"] == meth]; out = []; t0 = time.time()
        for k, i in enumerate(idx):
            it = ds[i]; x = torch.from_numpy(np.asarray(it["image"], np.float32) / 255).permute(2, 0, 1)[None]
            sgn = torch.as_tensor(np.asarray(it["message"], np.float32) * 2 - 1)[None]
            g = grad(fn, x, sgn); xn = x[0].numpy().astype(np.float64); ga, gn, gm = maps(g, xn)
            gd = maps(grad(fd, x, sgn), xn)[0] if fd else ga
            out.append(np.stack([zimg(m) for m in (ga, gn, gm, gd)]).astype(np.float16))
            if k % 40 == 0:
                print(meth, k, f"{(time.time() - t0) / (k + 1):.2f}s/img", flush=True)
        M = np.stack(out); names = np.array([ds.meta[i]["image_name"] for i in idx])
        for j, t in enumerate(TAGS):
            np.savez(HERE / "maps" / f"{t}_{split}_{meth}.npz", names=names, logit128=M[:, j])


if __name__ == "__main__":
    main()
