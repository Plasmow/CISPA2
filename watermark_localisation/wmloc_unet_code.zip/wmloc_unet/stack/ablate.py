"""Backward elimination of fusion sources, per method (CPU). Uses v3.py's own functions.

Start from every source available for the method (the v3d set). Each round, try removing each remaining source,
re-fit the out-of-fold fusion and score it (5-fold CV, 'switch' rule, same as v3's fusion selection). Remove the
source whose absence costs least, as long as the score stays >= score(all sources) - TOL (so the total loss is
bounded by TOL). Stops when every removal would cost more. Writes maps/select_<method>.json.

    python ablate.py pixelseal
"""
import json
import sys
import time

import numpy as np

from v3 import HERE, load_split, load_sources, fuse_feats, oof_fusion, g_of, cv_eval

RUNS = ["effb3_hp_glob", "effb3_hp_glob_stack", "rgb_hp_glob_synth8k"]
EXTRAS = ["headmulti", "remark", "headsyn", "headsyn2"]
TOL = 0.001


def main():
    meth = sys.argv[1]; t0 = time.time()
    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}
    n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
    g_tr = g_of("train", n_tr, meta_tr); gt = np.stack([tr_all.m128[n] for n in n_tr]).astype(bool)
    S = load_sources(meth, n_tr, n_te, RUNS, EXTRAS)

    def score(keys):
        L = S[keys[0]][0] if len(keys) == 1 else oof_fusion(fuse_feats([S[k][0] for k in keys], g_tr), gt)
        return float(cv_eval(L, gt, g_tr, "switch").mean())

    singles = {k: score([k]) for k in S}
    print(f"[{meth}] single sources: " + ", ".join(f"{k}={v:.4f}" for k, v in sorted(singles.items(), key=lambda kv: -kv[1])), flush=True)
    cur = sorted(S, key=lambda k: -singles[k]); s_all = score(cur); hist = [(list(cur), s_all)]
    print(f"[{meth}] all {len(cur)} sources: {s_all:.4f}", flush=True)
    while len(cur) > 1:
        trials = {k: score([c for c in cur if c != k]) for k in cur}
        k_rm = max(trials, key=trials.get)
        print(f"[{meth}] round with {len(cur)}: " + ", ".join(f"-{k}={v:.4f}" for k, v in sorted(trials.items(), key=lambda kv: -kv[1]))
              + f"  ({time.time() - t0:.0f}s)", flush=True)
        if trials[k_rm] < s_all - TOL:
            break
        cur.remove(k_rm); hist.append((list(cur), trials[k_rm]))
    print(f"[{meth}] KEPT {len(cur)}/{len(S)}: {cur} -> {hist[-1][1]:.4f} (all: {s_all:.4f})", flush=True)
    (HERE / "maps" / f"select_{meth}.json").write_text(json.dumps(dict(selected=cur, score=hist[-1][1], score_all=s_all,
                                                                       singles=singles, history=hist), indent=1))


if __name__ == "__main__":
    main()
