"""A1 targets: control the true-class probability and the wrong-class distribution SEPARATELY.

Why: the loss part of the forget score only looks at the true-class probability (mean/std of CE over the set), while
the prediction part (KL(p_gold || p_sub) at T=2) looks at the whole distribution, i.e. at WHICH wrong classes get mass.
So per image we set
    q(x) = t(x) * onehot(y)  +  (1 - t(x)) * r(x)
  t(x) = exp(-L(x)):  per-image losses L are quantiles of a heavy-tailed (Gamma) distribution with the requested
         mean/std (= our guess of the gold models' loss mean/std); the hardest images get the largest losses.
         Difficulty = mean over aug-average targets (build_targets.py) of -log p_true, optionally + a class term.
  r(x):  distribution over the WRONG classes = (1-w) * softmax(orig clean logits / wrong_T, true class removed)
                                             +    w  * aug-average distribution with the true class removed.
         The original's ranking of the wrong classes is the "dark knowledge" about natural confusions.
         --n_prior v (optional): r(x) <- (1-v) * r(x) + v * S[y], where S is a class-similarity prior measured on
         images the model never saw (Task-1 watermark images, output/outside_task1/logits.pt, 3 views):
           S[a,b] = sum_i p_i[a] p_i[b] / m[b]^lift   (p_i = softmax(logits/n_T), m = mean p, diagonal removed,
                                                       rows normalised).
         The lift divides out "sink" classes (97/99/81...) that absorb mass on those out-of-distribution images.
         Agreement of S's top-3 with the original's runner-up on forget images: 26% raw, 43% with lift=1 (T=2).

CPU only (uses cached original logits from output/diag_orig.pt and the aug-average targets in output/targets/).
Writes output/targets/<name>.pt in the same format as build_targets.py (probs_mean == probs_geo == q), so it plugs
into distill.py unchanged:   python scripts/distill.py --run X --target output/targets/<name>.pt

Usage (from unlearning/; comma lists build every combination):
  python scripts/build_targets_margin.py --loss_mean 0.8,1.2,1.6 --loss_std 2.4 --wrong_T 1.5 --wrong_aug 0.5
"""
import argparse
import itertools
import json
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
TDIR = ROOT / "output" / "targets"


def floats(s):
    return [float(v) for v in str(s).split(",")]


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loss_mean", default="1.2", help="target mean CE on the forget set (guess of gold mean)")
    ap.add_argument("--loss_std", default="2.4", help="target std of CE on the forget set (guess of gold std)")
    ap.add_argument("--loss_cap", type=float, default=12.0, help="max per-image loss (p_true >= exp(-cap))")
    ap.add_argument("--wrong_T", default="1.5", help="temperature on the original's clean logits for r(x)")
    ap.add_argument("--wrong_aug", default="0.5", help="weight of the aug-average wrong-class distribution in r(x)")
    ap.add_argument("--diff", default="s2,s3", help="aug-average target files used for difficulty (and r_aug: first)")
    ap.add_argument("--class_w", default="0", help="difficulty += class_w * z(log #forget images of the class)")
    ap.add_argument("--rank_noise", default="0", help="difficulty += rank_noise * N(0,1) (difficulty is z-scored)")
    ap.add_argument("--n_prior", default="0", help="weight of the Task-1 class-similarity prior S[y] in r(x)")
    ap.add_argument("--n_T", type=float, default=2.0, help="softmax temperature for the Task-1 prior")
    ap.add_argument("--n_lift", type=float, default=1.0, help="divide S columns by class marginal^lift (sinks)")
    ap.add_argument("--n_topk", type=int, default=5, help="keep only the top-k classes of each prior row (0 = all); "
                    "full rows are ~uniform (entropy 4.3 nats), top-5 matches the original's wrong-class entropy")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tag", default="", help="suffix for the output names")
    return ap.parse_args()


def gamma_quantiles(n, mean, std, cap, seed, n_samples=2_000_000, iters=30):
    """n sorted losses = quantiles of Gamma(mean', std') capped at `cap`, with mean'/std' adjusted so that the CAPPED
    distribution has the requested mean/std."""
    m, s = mean, std
    for _ in range(iters):
        k, rate = (m / s) ** 2, m / s ** 2
        torch.manual_seed(seed)  # same seed every iteration -> smooth fixed-point iteration
        x = torch.distributions.Gamma(torch.tensor(k, dtype=torch.float64),
                                      torch.tensor(rate, dtype=torch.float64)).sample((n_samples,)).clamp_max(cap)
        dm, ds = mean - x.mean().item(), std - x.std().item()
        if abs(dm) < 1e-3 and abs(ds) < 1e-3:
            break
        m, s = max(m + dm, 1e-3), max(s + ds, 1e-3)
    xs = x.sort().values
    idx = ((torch.arange(n, dtype=torch.float64) + 0.5) / n * n_samples).long()
    return xs[idx].float()


def zscore(v):
    return (v - v.mean()) / v.std().clamp_min(1e-8)


def stats(q, labels, clean_logits):
    loss = -q.clamp_min(1e-12).log().gather(1, labels[:, None])[:, 0]
    wrong = q.argmax(1) != labels
    qT = F.softmax(q.clamp_min(1e-12).log() / 2, -1)
    oT = F.log_softmax(clean_logits / 2, -1)
    top2 = clean_logits.topk(2, 1).indices[:, 1]
    return {
        "acc": 1 - wrong.float().mean().item(),
        "loss_mean": loss.mean().item(), "loss_std": loss.std().item(),
        "maxp": q.max(1).values.mean().item(),
        "ent_T2": (-(qT * qT.clamp_min(1e-12).log()).sum(1)).mean().item(),
        "kl_T2_to_orig": (qT * (qT.clamp_min(1e-12).log() - oT)).sum(1).mean().item(),
        "wrong_is_clean_top2": (q.argmax(1)[wrong] == top2[wrong]).float().mean().item() if wrong.any() else float("nan"),
    }


def task1_prior(C, T, lift, topk=0):
    """[C, C] row-stochastic class-similarity matrix from the original's outputs on the Task-1 images."""
    d = torch.load(ROOT / "output" / "outside_task1" / "logits.pt", map_location="cpu", weights_only=False)
    P = torch.cat([F.softmax(d[k].float() / T, -1) for k in ("logits_full", "logits_crop", "logits_flip")])
    assert P.shape[1] == C
    S = (P.T @ P) / P.mean(0)[None, :].pow(lift)
    S.fill_diagonal_(0)
    if topk > 0:
        idx = S.topk(topk, 1).indices
        S = torch.zeros_like(S).scatter_(1, idx, S.gather(1, idx))
    return S / S.sum(1, keepdim=True)


def main():
    a = parse()
    TDIR.mkdir(parents=True, exist_ok=True)
    d = torch.load(ROOT / "output" / "diag_orig.pt", map_location="cpu", weights_only=False)
    z, labels = d["logits"].float(), d["labels"]
    N, C = z.shape
    assert torch.equal(labels, z.argmax(1))
    onehot = F.one_hot(labels, C).float()

    srcs = [s.strip() for s in a.diff.split(",") if s.strip()]
    aug = {s: torch.load(TDIR / f"{s}.pt", map_location="cpu")["probs_mean"].float() for s in srcs}
    for s, p in aug.items():
        assert torch.equal(torch.load(TDIR / f"{s}.pt", map_location="cpu")["labels"], labels), s
    diff0 = torch.stack([-p.gather(1, labels[:, None])[:, 0].clamp_min(1e-8).log() for p in aug.values()]).mean(0)
    counts = torch.bincount(labels, minlength=C).float()
    cls_term = zscore(counts[labels].log())

    # r_aug: aug-average distribution of the first source with the true class removed
    pa = aug[srcs[0]] * (1 - onehot)
    r_aug = pa / pa.sum(1, keepdim=True).clamp_min(1e-12)
    n_priors = floats(a.n_prior)
    r_n = task1_prior(C, a.n_T, a.n_lift, a.n_topk)[labels] if any(v > 0 for v in n_priors) else None

    summary_path = TDIR / "summary_a1.json"
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    combos = itertools.product(floats(a.loss_mean), floats(a.loss_std), floats(a.wrong_T), floats(a.wrong_aug),
                               floats(a.class_w), floats(a.rank_noise), n_priors)
    for m, s, wT, wa, cw, rn, npw in combos:
        diff = zscore(diff0) + cw * cls_term
        if rn > 0:
            gen = torch.Generator().manual_seed(a.seed + 1)
            diff = zscore(diff) + rn * torch.randn(N, generator=gen)
        losses = gamma_quantiles(N, m, s, a.loss_cap, a.seed)
        L = torch.empty(N)
        L[diff.argsort()] = losses  # easiest image -> smallest loss
        t = (-L).exp().clamp(1e-12, 1 - 1e-7)

        r_clean = F.softmax(z.masked_fill(onehot.bool(), float("-inf")) / wT, -1)
        r = (1 - wa) * r_clean + wa * r_aug
        if npw > 0:
            r = (1 - npw) * r + npw * r_n
        q = t[:, None] * onehot + (1 - t[:, None]) * r
        q = q / q.sum(1, keepdim=True)

        name = f"a1_m{m:g}_s{s:g}_T{wT:g}_w{wa:g}" + (f"_c{cw:g}" if cw else "") + (f"_n{rn:g}" if rn else "") \
            + (f"_p{npw:g}" + (f"_pT{a.n_T:g}" if a.n_T != 2 else "") + (f"_pl{a.n_lift:g}" if a.n_lift != 1 else "")
               + (f"_pk{a.n_topk}" if a.n_topk != 5 else "") if npw else "") + a.tag
        st = stats(q, labels, z)
        params = dict(loss_mean=m, loss_std=s, loss_cap=a.loss_cap, wrong_T=wT, wrong_aug=wa, class_w=cw,
                      rank_noise=rn, diff=a.diff, seed=a.seed, n_prior=npw, n_T=a.n_T, n_lift=a.n_lift, n_topk=a.n_topk)
        torch.save({"probs_mean": q, "probs_geo": q, "labels": labels, "level": params, "k": 0,
                    "stats": {"mean": st, "geo": st}, "target_loss": L}, TDIR / f"{name}.pt")
        summary[name] = {"params": params, "stats": st}
        print(f"{name:42s} acc {st['acc']:.3f} loss {st['loss_mean']:.3f}±{st['loss_std']:.3f} "
              f"maxp {st['maxp']:.3f} entT2 {st['ent_T2']:.3f} KL(q||orig)T2 {st['kl_T2_to_orig']:.3f} "
              f"wrong=top2 {st['wrong_is_clean_top2']:.2f}", flush=True)
    summary_path.write_text(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
