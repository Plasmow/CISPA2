"""Go / no-go test of the optimised alpha map (PixelSeal, TrustMark; CPU; 20 train images per method).

r = embed(x, m) - x (float). Find alpha in [0,1] (64x64 grid, bilinear to 512) minimising
    conf(x - alpha * r)^2 + lam * mean(alpha) + mu * TV(alpha)
with conf = mean over bits of the decoder logit oriented toward the known message. Removing the pattern where it is
present drives conf to 0 with little alpha; the map alpha is then the localisation. Caveat being tested: removing r
from a clean area adds an inverted watermark, which also lowers conf, so the problem may be ill-posed.
Reports AUC of alpha (128x128) against the GT inside each image type.
"""
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "heat")); sys.path.insert(0, str(TASK / "loc"))
from common import load_split, load_watermark, KIT, auc  # noqa: E402
from residual import residual_float  # noqa: E402
from attribution import _conf_fn  # noqa: E402

torch.set_num_threads(48)


def alpha_map(wm, f, img, msg, steps=60, lam=0.05, mu=0.5):
    x = torch.from_numpy(np.asarray(img)).permute(2, 0, 1)[None].float() / 255
    r = residual_float(wm, img, msg, "cpu")[None] / 255
    sgn = torch.as_tensor(np.asarray(msg, np.float32) * 2 - 1)
    with torch.no_grad():
        c0 = (f(x).float() * sgn).mean().item()
    a = torch.full((1, 1, 64, 64), -2.0, requires_grad=True); opt = torch.optim.Adam([a], lr=0.15)
    for _ in range(steps):
        al = torch.sigmoid(a); A = F.interpolate(al, size=(512, 512), mode="bilinear", align_corners=False)
        conf = (f(x - A * r).float() * sgn).mean()
        tv = (al[..., 1:, :] - al[..., :-1, :]).abs().mean() + (al[..., :, 1:] - al[..., :, :-1]).abs().mean()
        loss = conf ** 2 / max(c0 ** 2, 1e-2) + lam * al.mean() + mu * tv
        opt.zero_grad(); loss.backward(); opt.step()
    al = torch.sigmoid(a).detach()
    return F.interpolate(al, size=(128, 128), mode="bilinear", align_corners=False)[0, 0].numpy(), c0, conf.item()


def main():
    ds = load_split("train"); rng = np.random.RandomState(0)
    for meth in ("pixelseal", "trustmark"):
        wm = load_watermark(meth, KIT / "models", "cpu"); f = _conf_fn(wm)
        for p in (wm.det.parameters() if meth == "pixelseal" else wm.net.parameters()):
            p.requires_grad_(False)
        it_t = [i for i, m in enumerate(ds.meta) if m["method"] == meth and m["full_watermark"]]
        it_f = [i for i, m in enumerate(ds.meta) if m["method"] == meth and not m["full_watermark"]]
        A, G, Fl, t = [], [], [], time.time()
        for i in list(rng.permutation(it_t)[:10]) + list(rng.permutation(it_f)[:10]):
            it = ds[i]; al, c0, c1 = alpha_map(wm, f, it["image"], it["message"])
            A.append(al); G.append(it["mask128"]); Fl.append(it["full_watermark"])
            print(f"  {meth} full={it['full_watermark']} conf {c0:.2f} -> {c1:.2f} | alpha mean in GT={al[it['mask128'] > 0].mean() if it['mask128'].any() else float('nan'):.3f} "
                  f"out={al[it['mask128'] == 0].mean() if (it['mask128'] == 0).any() else float('nan'):.3f}", flush=True)
        A = np.stack(A); G = np.stack(G).astype(bool); Fl = np.array(Fl)
        print(f"{meth}: {(time.time() - t) / len(A):.1f}s/img | alpha AUC type T={auc(A[Fl], G[Fl]):.3f}  type F={auc(A[~Fl], G[~Fl]):.3f}", flush=True)


if __name__ == "__main__":
    main()
