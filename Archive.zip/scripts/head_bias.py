"""Head-bias surgery: test the "130-cap classes were removed entirely" hypothesis without any training.

For each delta, subtract delta from head.bias of the removed classes, so the model (almost) never predicts them; the
remaining mass goes to the original's own runner-up classes (DELETE-style masked dark knowledge, arXiv 2503.23751).
Optionally add a prior shift log((N - n_forget) / N) to the partially forgotten classes (label-shift correction,
assuming N training images per class).

Logits are W h + b, so a bias change shifts the cached logits exactly: the forget-set stats printed here are what the
edited model gives on the clean forget images (up to fp16 noise).

Usage (from unlearning/, CPU only):
  python scripts/head_bias.py --delta 16,20
  python scripts/head_bias.py --delta 18 --prior_shift --class_size 130
Writes output/headbias/hb_d<delta>[_prior].pt
"""
import argparse
import json
from pathlib import Path

import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "output" / "headbias"
REMOVED = [0, 6, 7, 8, 29, 30, 31, 33, 38]  # classes with 129-130 forget images


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--delta", default="16,20", help="comma list of bias shifts for the removed classes")
    ap.add_argument("--classes", default=",".join(map(str, REMOVED)), help="removed classes")
    ap.add_argument("--prior_shift", action="store_true", help="also shift partial classes by log((N-n)/N)")
    ap.add_argument("--class_size", type=float, default=130.0, help="assumed training images per class (N)")
    a = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    sd0 = torch.load(ROOT / "model.pt", map_location="cpu", weights_only=True)
    d = torch.load(ROOT / "output" / "diag_orig.pt", map_location="cpu", weights_only=False)
    z, y = d["logits"].float(), d["labels"]
    C = z.shape[1]
    removed = torch.tensor([int(c) for c in a.classes.split(",")])
    counts = torch.bincount(y, minlength=C).float()
    m = torch.isin(y, removed)

    for delta in [float(v) for v in a.delta.split(",")]:
        shift = torch.zeros(C)
        if a.prior_shift:
            partial = (counts > 0) & ~torch.isin(torch.arange(C), removed)
            frac = ((a.class_size - counts[partial]) / a.class_size).clamp_min(1e-3)
            shift[partial] = frac.log()
        shift[removed] = -delta

        sd = {k: v.clone() for k, v in sd0.items()}
        sd["head.bias"] = (sd["head.bias"].float() + shift).float()

        zz = z + shift
        L = F.cross_entropy(zz, y, reduction="none")
        stats = {
            "delta": delta, "prior_shift": a.prior_shift, "class_size": a.class_size,
            "acc_all": (zz.argmax(1) == y).float().mean().item(),
            "acc_removed": (zz[m].argmax(1) == y[m]).float().mean().item(),
            "acc_partial": (zz[~m].argmax(1) == y[~m]).float().mean().item(),
            "loss_mean": L.mean().item(), "loss_std": L.std().item(),
            "loss_mean_removed": L[m].mean().item(), "loss_std_removed": L[m].std().item(),
            "loss_mean_partial": L[~m].mean().item(), "loss_std_partial": L[~m].std().item(),
        }
        name = f"hb_d{delta:g}" + (f"_prior{a.class_size:g}" if a.prior_shift else "")
        path = OUT / f"{name}.pt"
        torch.save(sd, path)
        (OUT / f"{name}.json").write_text(json.dumps(stats, indent=1))
        print(f"{path}: " + " ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}" for k, v in stats.items()))


if __name__ == "__main__":
    main()
