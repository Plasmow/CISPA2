"""Learned head maps (PixelSeal, TrustMark) for stacking and submission.
Head = logistic regression per position on frozen detector features (best configs of step 1b):
  PixelSeal : ConvNeXt stage-2 features 16x16 + per-position conf (upsampled) + whole-image score g + position, wd 1e-3
  TrustMark : ResNet layer2 features 31x31 + g + position, wd 1e-2
Train: out-of-fold logits (5 folds, the head never saw the image). Test: mean of the 5 fold heads' logits.
Output: stack/maps/head_<split>_<method>.npz  names, logit128 [N,128,128] float16 (bilinear upsampling)."""
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

LOC = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
sys.path.insert(0, str(LOC))
from common import load_split, CACHE, folds  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels, pos_feats, fit_logreg, predict_logreg  # noqa: E402

HERE = Path(__file__).resolve().parent
CFG = {"pixelseal": ("b", 1e-3, True), "trustmark": ("a", 1e-2, False)}


def features(meth, split, names, msg, g):
    d = np.load(CACHE / f"perpos_{meth}_{split}.npz"); dm = np.load(CACHE / f"mid_{meth}_{split}.npz")
    assert d["names"].tolist() == names and dm["names"].tolist() == names
    key, _, with_conf = CFG[meth]; f = dm[key].astype(np.float32); N, hw = len(names), f.shape[-1]
    parts = [f, np.broadcast_to(g[:, None, None, None], (N, 1, hw, hw)), pos_feats(N, hw, hw)]
    if with_conf:
        conf = (d["pp"].astype(np.float32) * msg[:, :, None, None]).mean(1, keepdims=True)
        parts.append(F.interpolate(torch.as_tensor(conf), size=(hw, hw), mode="bilinear", align_corners=False).numpy())
    return np.concatenate(parts, 1)


def split_info(meth, split):
    ds = load_split(split, [meth]); names = [m["image_name"] for m in ds.meta]
    msg = np.array([[int(c) for c in m["message"]] for m in ds.meta], np.float32) * 2 - 1
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item(); lut = dict(zip(gl[meth]["names"], gl[meth]["logits"]))
    g = np.array([(lut[n] * msg[i]).mean() for i, n in enumerate(names)])
    return ds, names, msg, g


def flat(X):
    N, D, h, w = X.shape
    return X.transpose(0, 2, 3, 1).reshape(N, h * w, D)


def main():
    (HERE / "maps").mkdir(exist_ok=True)
    for meth, (_, wd, _) in CFG.items():
        ds, names, msg, g = split_info(meth, "train"); _, tnames, tmsg, tg = split_info(meth, "test")
        X = features(meth, "train", names, msg, g); Xt = features(meth, "test", tnames, tmsg, tg)
        N, D, h, w = X.shape; Y = soft_labels(np.stack([ds.m128[n] for n in names]), (h, w)).reshape(N, -1)
        Xf, Xtf = flat(X), flat(Xt)
        oof = np.zeros((N, h * w), np.float32); test = np.zeros((len(tnames), h * w), np.float32)
        for f in folds(N, 5, 0):
            tr = np.setdiff1d(np.arange(N), f)
            m = fit_logreg(Xf[tr].reshape(-1, D), Y[tr].reshape(-1), wd)
            oof[f] = predict_logreg(m, Xf[f].reshape(-1, D)).reshape(len(f), -1)
            test += predict_logreg(m, Xtf.reshape(-1, D)).reshape(len(tnames), -1) / 5
        o128, t128 = to128(oof.reshape(N, h, w)), to128(test.reshape(-1, h, w))
        gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([m["full_watermark"] for m in ds.meta])
        s = cv_eval(o128, gt, g, "switch", seed=1)
        print(f"{meth}: OOF head CV mIoU={s.mean():.4f} T={s[full].mean():.4f} F={s[~full].mean():.4f} | "
              f"test logit mean={t128.mean():.3f} vs train OOF mean={o128.mean():.3f}", flush=True)
        np.savez(HERE / "maps" / f"head_train_{meth}.npz", names=np.array(names), logit128=o128.astype(np.float16))
        np.savez(HERE / "maps" / f"head_test_{meth}.npz", names=np.array(tnames), logit128=t128.astype(np.float16))


if __name__ == "__main__":
    main()
