"""Altered-view gap analysis (2026-11-22 10:10).
1) orig on unseen look-alikes (twins): loss w.r.t. the forget label on clean twin vs augmented twin
   -> how a never-trained model's loss changes under alteration (gold proxy).
2) a checkpoint: loss stats + LDS/PS per view (clean vs several alteration families).
Usage: python scripts/aug_gap.py [ckpt ...]
"""
import sys
import numpy as np
import torch
import torch.nn.functional as F

import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

teacher, imgs = C.load_all()
N = len(imgs)
y = None


def logits(model, x01_fn, src, bs=200):
    out = []
    with torch.no_grad():
        for i in range(0, len(src), bs):
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                out.append(model(C.norm(x01_fn(C.u8_to01(src[i:i + bs]), i))).float())
    return torch.cat(out)


def gen(seed):
    return torch.Generator(device=C.DEVICE).manual_seed(seed)


def jpeg_like(x, g):
    H = x.shape[-1]
    return F.interpolate(F.interpolate(x, size=int(H * 0.6), mode="bilinear", antialias=True, align_corners=False),
                         size=H, mode="bilinear", align_corners=False).clamp(0, 1)


FAM = {
    "clean": lambda x, i: x,
    "mild": None,  # EvalSets-style, seeded per batch below
    "flip": lambda x, i: x.flip(-1),
    "crop80": lambda x, i: C.augment(x, gen(10 + i), scale=(0.8, 1.0), rot_deg=0, flip=False, bright=0, contrast=0, noise=0),
    "crop50": lambda x, i: C.augment(x, gen(20 + i), scale=(0.35, 0.6), rot_deg=0, flip=False, bright=0, contrast=0, noise=0),
    "rot15": lambda x, i: C.augment(x, gen(30 + i), scale=(1.0, 1.0), rot_deg=15, flip=False, bright=0, contrast=0, noise=0),
    "color": lambda x, i: C.augment(x, gen(40 + i), scale=(1.0, 1.0), rot_deg=0, flip=False, bright=0.3, contrast=0.3, noise=0),
    "noise": lambda x, i: C.augment(x, gen(50 + i), scale=(1.0, 1.0), rot_deg=0, flip=False, bright=0, contrast=0, noise=0.08),
    "lowres": lambda x, i: jpeg_like(x, None),
}
FAM["mild"] = lambda x, i: C.augment(x, gen(60 + i), scale=(0.6, 1.0), rot_deg=10, bright=0.2, contrast=0.2, noise=0.05)

zc = logits(teacher, FAM["clean"], imgs)
y = zc.argmax(1)


def st(z, yy):
    l = F.cross_entropy(z, yy, reduction="none")
    return f"loss {l.mean():.2f}±{l.std():.2f} acc {(z.argmax(1) == yy).float().mean():.3f}"


print("=== 1) orig on twins (unseen look-alikes), label = forget label")
for s in ["0.3", "0.5", "0.625", "0.875"]:
    import glob
    fs = sorted(f for f in glob.glob(str(C.ROOT / f"output/twins/s{s}_sh*.npz")) if ".tmp" not in f)
    ii = np.concatenate([np.load(f)["idx"] for f in fs])
    im = np.concatenate([np.load(f)["images"][:, 0] for f in fs])  # first twin per image
    tw = torch.from_numpy(im[np.argsort(ii)]).to(C.DEVICE)
    row = []
    for fam in ["clean", "mild", "flip", "crop80", "crop50", "color", "noise", "lowres"]:
        row.append(f"{fam}: {st(logits(teacher, FAM[fam], tw), y)}")
    print(f"s{s}: " + " | ".join(row), flush=True)
    del tw

# gold hypotheses for PS (T=2): tail (p_true .3, orig tail) and tw (s0.625 twins mean)
oh = F.one_hot(y, 100).float()
zz = zc.clone(); zz[torch.arange(N, device=C.DEVICE), y] = -1e4
g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3
g_tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
G = {"tail": g_tail, "tw": g_tw, "blend": 0.5 * (g_tail + g_tw)}


def klm(g, z):
    return (g * (g.clamp_min(1e-12).log() - F.log_softmax(z / 2, -1))).sum(1).mean().item()


zo = {fam: logits(teacher, FAM[fam], imgs) for fam in FAM}
print("=== orig on forget views:", " | ".join(f"{f}: {st(zo[f], y)}" for f in zo), flush=True)
for ck in sys.argv[1:]:
    m = C.tt.build_model()
    m.load_state_dict(torch.load(ck, map_location="cpu", weights_only=True), strict=True)
    m = m.to(C.DEVICE).eval()
    print(f"=== {ck}")
    for fam in FAM:
        z = logits(m, FAM[fam], imgs)
        l = F.cross_entropy(z, y, reduction="none")
        lo = F.cross_entropy(zo[fam], y, reduction="none")
        lds = {}
        for mu, sd in [(5, 7), (4, 6), (6, 8)]:
            d = abs(l.mean().item() - mu) + abs(l.std().item() - sd)
            do = abs(lo.mean().item() - mu) + abs(lo.std().item() - sd)
            lds[f"{mu}/{sd}"] = round(1 - min(max(d / do, 0), 1), 3)
        ps = {h: round(1 - min(max(klm(g, z) / klm(g, zo[fam]), 0), 1), 3) for h, g in G.items()}
        print(f"  {fam:7s} {st(z, y)} | LDS {lds} | PS {ps}", flush=True)
