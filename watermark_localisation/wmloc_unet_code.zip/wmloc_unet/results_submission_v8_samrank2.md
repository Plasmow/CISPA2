eligible images: 192 (F-rect 68, F-seg 124, F-empty 0)

| variant | all (n=192) | pixelseal | trustmark | stegastamp | F-rect | F-seg | effect on mean CV |
|---|---|---|---|---|---|
| ref | 0.6886 | 0.6626 | 0.6899 | 0.7111 | 0.5101 | 0.7865 | +0.0241 |
| dec | 0.6849 | 0.6596 | 0.6939 | 0.7009 | 0.5055 | 0.7833 | +0.0227 |
| emiou | 0.6881 | 0.6530 | 0.7204 | 0.6952 | 0.4971 | 0.7929 | +0.0239 |
| mix | 0.6796 | 0.6494 | 0.6891 | 0.6995 | 0.5016 | 0.7771 | +0.0207 |
| lin | 0.6865 | 0.6440 | 0.7040 | 0.7115 | 0.4997 | 0.7889 | +0.0233 |
| per-method (nested) | 0.6921 | 0.6527 | 0.7204 | 0.7061 | 0.5038 | 0.7954 | +0.0254 |
| base (no SAM) | 0.6246 | 0.6096 | 0.6039 | 0.6540 | 0.5114 | 0.6867 | +0.0000 |
| oracle decision (snap_sam segment) | 0.7064 | 0.6854 | 0.7054 | 0.7261 | 0.5162 | 0.8107 | +0.0308 |

per-method picks per outer fold: pi:dec tr:emiou st:lin pi:ref tr:emiou st:lin pi:ref tr:emiou st:ref pi:dec tr:emiou st:lin pi:ref tr:emiou st:ref
