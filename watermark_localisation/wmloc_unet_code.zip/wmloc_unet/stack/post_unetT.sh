#!/bin/bash
# After the T job: fusion v18 with the new runs, SAM stage, upload if expected CV after SAM >= 0.7217 (v12a_sam 0.7187 + 0.003).
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack; export OMP_NUM_THREADS=8
E="headmulti remark headsyn headsyn2 wmunet wmunet0 wmunetF wmunetF0 wmunetH wmunetH0 wmunet2 wmunet20"
R="effb3_hp_glob effb3_hp_glob_stack rgb_hp_glob_synth8k loc_effv2s_hp_glob_stack loc_r50_hp_glob_stack loc_regy032_hp_glob_stack"
NEW=$(for v in effb3_hp_glob_stack_Tft effb3_hp_glob_stack_Tft9 effb3_hp_glob_Tft effb3_hp_glob_stack_Tft60; do [ -f ../runs/$v/oof_all.npz ] && echo -n "$v "; done)
echo "new runs: $NEW"; [ -z "$NEW" ] && { echo "no new run"; exit 1; }
WMLOC_NO_RECT3=1 $PY v3.py --rect --rules_plus --runs $R $NEW --extras $E --out ../submissions/submission_v18_T.pt --baseline_cv 9 2>&1 | tail -40
$PY sam_stage.py ../submissions/submission_v18_T.pt 2>&1 | tail -3
CV=$($PY -c "import json;print(json.load(open('../sam/submission_v18_T/report.json'))['expected_cv_after'])")
echo "v18_T expected CV after SAM = $CV (v12a_sam 0.7187)"
F=../submissions/submission_v18_T_sam.pt; [ -f $F ] || F=../submissions/submission_v18_T.pt
if $PY -c "import sys;sys.exit(0 if $CV>=0.7217 else 1)"; then
  echo "UPLOAD $F"; cd /p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/starter_kit && $PY -c "from submission_template import submit; submit('$(readlink -f /p/project1/training2666/debbah2/wmloc_unet/stack/$F)')"
else echo "NO UPLOAD (gain < 0.003)"; fi
