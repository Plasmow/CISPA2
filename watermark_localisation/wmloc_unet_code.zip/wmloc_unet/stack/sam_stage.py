"""SAM snapping stage for a v3.py submission (CPU only, a few minutes). Run it after every new version:

    cd stack && python sam_stage.py ../submissions/submission_vX.pt          # reads ../submissions/submission_vX.json

1. Replays the version described by submission_vX.json with v3.py's own functions (read-only import, no shared file
   written, in particular NOT maps/fused_*): fused map per method (OOF on train, refit on whole train for test),
   decision rule, post-processing, decoder rectangles, with the same folds as v3.py. The replay is checked against the
   json CV scores and against the submitted test masks.
2. Exports what the teammate's loc/snap_sam.py needs to ../sam/<stem>/ (3 large files):
     probs_train_oof.pt  {"image_names", "probs" [510,128,128] float32}  sigmoid of the OOF fused map, BEFORE the rule
     masks_train_oof.pt  {"image_names", "masks" [510,128,128] bool}     FINAL OOF masks (rule + post + rectangles)
     probs_test.pt       {"image_names", "probs" [1020,128,128] float32} same version, test split
3. Runs stack/snap_sam_local.py (copy of the teammate's loc/snap_sam.py whose rectangle exclusion uses v3.load_rect,
   i.e. loc/cache/rect_* + stack/maps/rect2_*, for the 3 methods) on the ORIGINAL submission file, with the rectangle
   threshold of each method read from the version's .json (9 = no rectangle): masks already replaced by a rectangle
   are never snapped. Keeps ../submissions/<stem>_sam.pt only if the CV gain is positive.
   Report: ../sam/<stem>/report.json and snap_sam.log. Nothing is uploaded.

Versions made before the rect2 boxes (<= v4b) must be replayed with WMLOC_NO_RECT2=1 (read by v3.load_rect, passed on
to snap_sam_local.py):   WMLOC_NO_RECT2=1 python sam_stage.py ../submissions/submission_v4b.pt
"""
import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

import numpy as np
import torch

from v3 import (TASK, HERE, ROOT, METHODS, load_split, folds, miou_batch, load_rect, g_of, load_sources, fuse_feats,
                oof_fusion, fit_fusion, apply_fusion, post_scores, cv_select, cv_choice, POST_T, POST_F)

from v3 import rule_preds_any as rule_preds                          # = rule_preds unless WMLOC_RULES_PLUS=1 (versions >= v9)
RECT_THRS = (0.7, 0.75, 0.8, 0.85, 0.9, 0.95)                             # same grid as v3.py --rect
VENV_PY = TASK / ".venv" / "bin" / "python"


def sig(L):
    return (1 / (1 + np.exp(-np.clip(L, -30, 30)))).astype(np.float32)


def apply_post(m, typT, post_T, post_F):
    return np.stack([POST_T[post_T](m[i]) if typT[i] else POST_F[post_F](m[i]) for i in range(len(m))])


def replay(meth, cfg, tr_all, te_all, meta_tr, meta_te):
    """Rebuild one method of a v3.py version. -> dict with OOF probs/masks (train), probs/masks (test), checks."""
    n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
    g_tr, g_te = g_of("train", n_tr, meta_tr), g_of("test", n_te, meta_te); N = len(n_tr)
    gt = np.stack([tr_all.m128[n] for n in n_tr]).astype(bool)
    srcs = cfg["sources"] or [cfg["map"]]
    runs = [s for s in srcs if (ROOT / "runs" / s / "oof_all.npz").exists()]
    extras = [s for s in srcs if s != "head" and (HERE / "maps" / f"{s}_train_{meth}.npz").exists()]
    S = load_sources(meth, n_tr, n_te, runs, extras)
    # 1. map right before the decision rule
    if cfg["sources"] is None:                                            # a single source won
        Lb, L_te = S[cfg["map"]]
    else:
        Ftr = fuse_feats([S[k][0] for k in srcs], g_tr); Lb = oof_fusion(Ftr, gt)
        L_te = apply_fusion(fit_fusion(Ftr, gt, np.arange(N)), fuse_feats([S[k][1] for k in srcs], g_te)); del Ftr
    del S
    # 2. rule (whole-train choice, thresholds per fold) + post-processing (chosen per fold), exactly as v3.py
    rule = cfg["rule"]; pred = np.zeros(gt.shape, bool); typT = np.zeros(N, bool)
    for f in folds(N, 5, 0):
        trn = np.setdiff1d(np.arange(N), f); pr, p = rule_preds(Lb, g_tr, gt, trn)
        pred[f] = pr[rule][f]; typT[f] = g_tr[f] > p["tg"]
    P = post_scores(pred, gt, typT)
    PT = {k[1]: v for k, v in P.items() if k[0] == "T"}; PF = {k[1]: v for k, v in P.items() if k[0] == "F"}
    sT, postT = cv_select(PT, typT); sF, postF = cv_select(PF, ~typT)
    s_post = np.zeros(N); s_post[typT] = sT; s_post[~typT] = sF
    cT, cF = cv_choice(PT, typT), cv_choice(PF, ~typT)
    oof = np.stack([POST_T[cT[i]](pred[i]) if typT[i] else POST_F[cF[i]](pred[i]) for i in range(N)])
    assert np.allclose(miou_batch(oof, gt), s_post), "OOF masks do not reproduce the post-processing CV scores"
    rect_choice = "none"
    if load_rect(meth, "test"):                                           # v3.py --rect branch (boxes exist for test)
        B = load_rect(meth, "train"); final = apply_post(pred, typT, postT, postF); alts = {"none": final}
        for thr in RECT_THRS:
            alt = final.copy()
            for i, n in enumerate(n_tr):
                if not typT[i] and n in B and B[n][1] >= thr:
                    alt[i] = B[n][0]
            alts[f"rect>={thr}"] = alt
        opts = {k: miou_batch(v, gt) for k, v in alts.items()}
        s_rect, choice = cv_select(opts, np.ones(N, bool)); ch = cv_choice(opts, np.ones(N, bool))
        oof_rect = np.stack([alts[ch[i]][i] for i in range(N)])
        assert np.allclose(miou_batch(oof_rect, gt), s_rect), "OOF masks do not reproduce the rectangle CV scores"
        # built with --rect? certain if the json names a rectangle threshold, otherwise the replayed CV closest to the json
        if cfg.get("rect", "none") != "none" or abs(s_rect.mean() - cfg["cv"]) < abs(s_post.mean() - cfg["cv"]):
            oof, s_post, rect_choice = oof_rect, s_rect, choice
    checks = dict(cv_json=cfg["cv"], cv_replay=round(float(s_post.mean()), 4),
                  choices_json=[cfg["post_T"], cfg["post_F"], cfg.get("rect", "none")], choices_replay=[postT, postF, rect_choice])
    # 3. test, with the version's own choices (whole-train refit, as v3.py)
    preds_te, p = rule_preds(np.concatenate([Lb, L_te]), np.concatenate([g_tr, g_te]),
                             np.concatenate([gt, np.zeros((len(n_te),) + gt.shape[1:], bool)]), np.arange(N))
    tT = g_te > p["tg"]; m_te = apply_post(preds_te[rule][N:], tT, cfg["post_T"], cfg["post_F"])
    rect = cfg.get("rect", "none"); rect_thr = float(rect.split(">=")[1]) if rect != "none" else None
    if rect_thr is not None:
        Bt = load_rect(meth, "test")
        for i, n in enumerate(n_te):
            if not tT[i] and n in Bt and Bt[n][1] >= rect_thr:
                m_te[i] = Bt[n][0]
    return dict(n_tr=n_tr, n_te=n_te, p_tr=sig(Lb), p_te=sig(L_te), oof=oof, m_te=m_te, rect_thr=rect_thr, checks=checks)


def parse_snap(log):
    num = r"([+-]?[\d.]+|inf)"
    m = re.search(rf"base {num} \| always snap {num} \| CV-tuned snap {num} \(gain {num}\) \| s = {num}, snaps (\d+)%", log)
    out = dict(zip(["base", "always_snap", "cv_snap", "gain", "s", "snap_pct"], map(float, m.groups()))) if m else {}
    m = re.search(rf"regime-F images eligible \(excluding (\d+) rectangle images\)", log)
    if m:
        out["n_rect_excluded"] = int(m.group(1))
    m = re.search(rf"over these (\d+) train images: {num}", log)
    if m:
        out["effect_overall"] = float(m.group(2))
    out["per_method"] = {mm: dict(n=int(n), base=float(b), always_snap=float(a_), cv_snap=float(c))
                         for mm, n, b, a_, c in re.findall(rf"^\s+(\w+)\s+n=\s*(\d+)\s+base {num}\s+always snap {num}\s+CV snap {num}", log, re.M)}
    m = re.search(r"test: (\d+) masks snapped to SAM segments \((\d+) regime-F images had no candidates\)", log)
    if m:
        out["test_snapped"], out["test_no_cands"] = int(m.group(1)), int(m.group(2))
    out["disabled"] = "stage disabled" in log
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("submission", help="v3.py submission .pt (its .json next to it describes the version)")
    ap.add_argument("--json", default=None, help="version report (default: <submission>.json)")
    ap.add_argument("--max_cv_dev", type=float, default=0.003, help="abort if a replayed method CV deviates more")
    ap.add_argument("--min_test_agree", type=float, default=0.995, help="abort if replayed test masks agree less (pixels)")
    a = ap.parse_args()
    base = Path(a.submission).resolve(); rep = json.loads(Path(a.json or base.with_suffix(".json")).read_text())
    if rep.get("rules_plus"):
        os.environ["WMLOC_RULES_PLUS"] = "1"                           # the version chose among Agent B's rules too
    if not rep.get("rect3"):
        os.environ["WMLOC_NO_RECT3"] = "1"                             # versions made without the rect3 boxes (<= v9)
    out_dir = ROOT / "sam" / base.stem; out_dir.mkdir(parents=True, exist_ok=True)
    out_sam = base.with_name(base.stem + "_sam.pt")
    sub = torch.load(base, weights_only=True); sub_masks = dict(zip(sub["image_names"], sub["masks"].numpy().astype(bool)))
    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}; meta_te = {m["image_name"]: m for m in te_all.meta}
    P_tr, M_tr, P_te, R, rect_thr = {}, {}, {}, {}, {}
    for meth in METHODS:
        r = replay(meth, rep[meth], tr_all, te_all, meta_tr, meta_te)
        agree = float(np.mean([(r["m_te"][i] == sub_masks[n]).mean() for i, n in enumerate(r["n_te"])]))
        r["checks"]["test_pixel_agreement_with_submission"] = round(agree, 5)
        print(f"{meth}: replay {r['checks']}", flush=True)
        if abs(r["checks"]["cv_replay"] - r["checks"]["cv_json"]) > a.max_cv_dev or agree < a.min_test_agree:
            sys.exit(f"{meth}: replay does not match the version (see above); nothing exported")
        P_tr.update(zip(r["n_tr"], r["p_tr"])); M_tr.update(zip(r["n_tr"], r["oof"])); P_te.update(zip(r["n_te"], r["p_te"]))
        R[meth] = r["checks"]; rect_thr[meth] = r["rect_thr"]
    n_tr_all = [m["image_name"] for m in tr_all.meta]; n_te_all = list(sub["image_names"])
    assert len(n_tr_all) == 510 and len(n_te_all) == 1020
    f_oof, f_msk, f_te = out_dir / "probs_train_oof.pt", out_dir / "masks_train_oof.pt", out_dir / "probs_test.pt"
    torch.save({"image_names": n_tr_all, "probs": torch.from_numpy(np.stack([P_tr[n] for n in n_tr_all]))}, f_oof)
    torch.save({"image_names": n_tr_all, "masks": torch.from_numpy(np.stack([M_tr[n] for n in n_tr_all])).bool()}, f_msk)
    torch.save({"image_names": n_te_all, "probs": torch.from_numpy(np.stack([P_te[n] for n in n_te_all]))}, f_te)
    # snap: images whose rectangle passes this version's threshold are left alone (9 = no rectangle for that method)
    thr_of = {m: rect_thr[m] if rect_thr[m] is not None else 9 for m in METHODS}
    thr = ",".join(f"{m}={thr_of[m]}" for m in METHODS)
    rect_excluded = {m: {sp: sum(acc >= thr_of[m] for _, acc in load_rect(m, sp).values()) for sp in ("train", "test")} for m in METHODS}
    cmd = [str(VENV_PY), str(HERE / "snap_sam_local.py"), "--oof", str(f_oof), "--oof-masks", str(f_msk), "--test", str(f_te),
           "--base", str(base), "--out", str(out_sam), "--rect-thr", thr]
    env = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "PYTHONDONTWRITEBYTECODE": "1"}
    no_rect2 = env.get("WMLOC_NO_RECT2", "")
    pr = subprocess.run(cmd, cwd=HERE, env=env, capture_output=True, text=True)
    log = pr.stdout + ("\n[stderr]\n" + pr.stderr if pr.stderr.strip() else "")
    (out_dir / "snap_sam.log").write_text(f"cd stack && WMLOC_NO_RECT2={no_rect2} " + " ".join(cmd) + "\n\n" + log); print(log, flush=True)
    snap = parse_snap(log) if pr.returncode == 0 else {"error": f"snap_sam exit code {pr.returncode}"}
    keep = pr.returncode == 0 and not snap.get("disabled", True) and snap.get("gain", 0) > 0
    if not keep and out_sam.exists():
        out_sam.unlink()                                                  # no CV gain: the base submission stays the candidate
    # expected per-method CV after snapping (snap_sam's base on the eligible images = these OOF masks)
    n_meth = {m: sum(meta_tr[n]["method"] == m for n in n_tr_all) for m in METHODS}
    after = {m: round(rep[m]["cv"] + (pm["n"] * (pm["cv_snap"] - pm["base"]) / n_meth[m] if keep and m in snap.get("per_method", {}) else 0), 4)
             for m in METHODS for pm in [snap.get("per_method", {}).get(m, {"n": 0, "cv_snap": 0, "base": 0})]}
    report = dict(version=base.stem, base_submission=str(base), sam_submission=str(out_sam) if keep else None, kept=keep,
                  rect_thr_for_snap=thr, WMLOC_NO_RECT2=no_rect2, rect_images_excluded=rect_excluded, replay=R, snap=snap, cv_before={m: rep[m]["cv"] for m in METHODS}, cv_after=after,
                  expected_cv_before=rep["expected_cv_mIoU"], expected_cv_after=round(float(np.mean(list(after.values()))), 4))
    (out_dir / "report.json").write_text(json.dumps(report, indent=1)); print(json.dumps(report, indent=1))
    print(f"\nSAM stage {'KEPT' if keep else 'NOT kept (no CV gain)'}: expected CV {report['expected_cv_before']} -> "
          f"{report['expected_cv_after']}" + (f"  -> {out_sam}" if keep else f"; candidate stays {base}"))


if __name__ == "__main__":
    main()
