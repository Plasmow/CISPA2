| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | fusion selected ['headsyn', 'headmulti', 'effb3_hp_glob'] | 0.5747 | 0.5839 | 0.5655 |
| pixelseal | fusion selected + rule switch | 0.5747 | 0.5839 | 0.5655 |
| pixelseal | fusion selected + rule expected_area | 0.5763 | 0.5889 | 0.5638 |
| pixelseal | fusion selected + rule otsu_in_regime | 0.5762 | 0.5842 | 0.5681 |
| pixelseal | fusion selected + rule regressed_area | 0.5507 | 0.5653 | 0.5361 |
| pixelseal | fusion selected + ORACLE per-image threshold (upper bound) | 0.6109 | 0.6237 | 0.5982 |
| pixelseal | fusion selected + CV-selected rule (whole-train choice: expected_area) | 0.5746 | 0.5881 | 0.5612 |
| pixelseal | **v2 pipeline**: fusion selected + expected_area + post T:fill_holes<256 / F:drop<256 | **0.5773** | 0.5861 | 0.5686 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.5805 | 0.5917 | 0.5692 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6021 | 0.5917 | 0.6125 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6119 | 0.5917 | 0.6322 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6133 | 0.5917 | 0.6349 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6148 | 0.5917 | 0.6380 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6034 | 0.5917 | 0.6151 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.5995 | 0.5917 | 0.6074 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6133** | 0.5917 | 0.6349 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | fusion selected ['headsyn2', 'headmulti', 'effb3_hp_glob'] | 0.5729 | 0.5867 | 0.5591 |
| trustmark | fusion selected + rule switch | 0.5729 | 0.5867 | 0.5591 |
| trustmark | fusion selected + rule expected_area | 0.5770 | 0.5902 | 0.5639 |
| trustmark | fusion selected + rule otsu_in_regime | 0.5763 | 0.5857 | 0.5670 |
| trustmark | fusion selected + rule regressed_area | 0.5544 | 0.5661 | 0.5427 |
| trustmark | fusion selected + ORACLE per-image threshold (upper bound) | 0.6129 | 0.6236 | 0.6022 |
| trustmark | fusion selected + CV-selected rule (whole-train choice: expected_area) | 0.5750 | 0.5879 | 0.5621 |
| trustmark | **v2 pipeline**: fusion selected + expected_area + post T:fill_holes<64 / F:largest | **0.5772** | 0.5903 | 0.5641 |
| trustmark | + rect override none (boxes for 85 train images) | 0.5804 | 0.5903 | 0.5705 |
| trustmark | + rect override rect>=0.7 (boxes for 85 train images) | 0.6209 | 0.5903 | 0.6515 |
| trustmark | + rect override rect>=0.75 (boxes for 85 train images) | 0.6417 | 0.5903 | 0.6930 |
| trustmark | + rect override rect>=0.8 (boxes for 85 train images) | 0.6478 | 0.5903 | 0.7052 |
| trustmark | + rect override rect>=0.85 (boxes for 85 train images) | 0.6505 | 0.5903 | 0.7106 |
| trustmark | + rect override rect>=0.9 (boxes for 85 train images) | 0.6505 | 0.5903 | 0.7106 |
| trustmark | + rect override rect>=0.95 (boxes for 85 train images) | 0.6505 | 0.5903 | 0.7106 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6417** | 0.5903 | 0.6930 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | fusion selected ['effb3_hp_glob_stack', 'rgb_hp_glob_synth8k', 'synth_zeroshot', 'headsyn2', 'headmulti'] | 0.6853 | 0.7229 | 0.6478 |
| stegastamp | fusion selected + rule switch | 0.6853 | 0.7229 | 0.6478 |
| stegastamp | fusion selected + rule expected_area | 0.6947 | 0.7283 | 0.6610 |
| stegastamp | fusion selected + rule otsu_in_regime | 0.6886 | 0.7272 | 0.6500 |
| stegastamp | fusion selected + rule regressed_area | 0.6791 | 0.7104 | 0.6477 |
| stegastamp | fusion selected + ORACLE per-image threshold (upper bound) | 0.7239 | 0.7584 | 0.6894 |
| stegastamp | fusion selected + CV-selected rule (whole-train choice: expected_area) | 0.6947 | 0.7283 | 0.6610 |
| stegastamp | **v2 pipeline**: fusion selected + expected_area + post T:fill_holes<64 / F:largest | **0.6954** | 0.7322 | 0.6585 |

```json
{
 "pixelseal": {
  "map": "fusion selected",
  "sources": [
   "headsyn",
   "headmulti",
   "effb3_hp_glob"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<256",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.6133,
  "cv_T": 0.5917,
  "cv_F": 0.6349,
  "test_frac_pred_1": 0.498
 },
 "trustmark": {
  "map": "fusion selected",
  "sources": [
   "headsyn2",
   "headmulti",
   "effb3_hp_glob"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6417,
  "cv_T": 0.5903,
  "cv_F": 0.693,
  "test_frac_pred_1": 0.494
 },
 "stegastamp": {
  "map": "fusion selected",
  "sources": [
   "effb3_hp_glob_stack",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot",
   "headsyn2",
   "headmulti"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "none",
  "cv": 0.6954,
  "cv_T": 0.7322,
  "cv_F": 0.6585,
  "test_frac_pred_1": 0.484
 },
 "expected_cv_mIoU": 0.6501,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v3s.pt",
 "size_MB": 15.96
}
```
