"""Sliding-window heatmaps.

score_windows(): decodes every window of every size once (batched on GPU) and returns the per-window score
                 (signed confidence: mean over bits of the logit oriented toward the expected bit; 0 = chance).
aggregate():     heat[cell] = sum_w weight_w(cell) * score_w / sum_w weight_w(cell), on the 128x128 grid,
                 weight = 2D gaussian centred on the window (sigma = sf * window) or uniform.
fuse():          z-score each scale's heat per image, then average.

Modes per method (from the separability test): PixelSeal keep_blur8, TrustMark / StegaStamp keep_gray.
"""
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from windows import make_inputs, background, decode_logits  # noqa: E402

MODE = {"pixelseal": "keep_blur8", "trustmark": "keep_gray", "stegastamp": "keep_gray"}
SIZES = (96, 128, 192, 256)
STRIDE = 32


def positions(w, s=STRIDE, H=512):
    p = list(range(0, H - w + 1, s))
    if p[-1] != H - w:
        p.append(H - w)
    return p


@torch.no_grad()
def score_windows(wm, img_uint8, msg, method, sizes=SIZES, stride=STRIDE, dev="cuda"):
    """-> {w: [ny, nx] float32 signed-confidence scores}."""
    x = torch.from_numpy(np.asarray(img_uint8)).permute(2, 0, 1).float().div(255).to(dev)
    sgn = torch.as_tensor(np.asarray(msg, np.float32) * 2 - 1)
    bg = background(x, MODE[method]); out = {}
    for w in sizes:
        ps = positions(w, stride); boxes = [(y, xx, w, w) for y in ps for xx in ps]
        L = []
        for b in range(0, len(boxes), 64):
            L.append(decode_logits(wm, make_inputs(x, boxes[b:b + 64], MODE[method], bg)))
        out[w] = ((torch.cat(L) * sgn).mean(1)).reshape(len(ps), len(ps)).numpy()
    return out


def _weights(w, ps, sf, dev):
    """[n_windows, 128, 128] weights on the 128 grid (cell centres)."""
    c = (torch.arange(128, device=dev, dtype=torch.float32) + 0.5) * 4
    P = torch.tensor(ps, device=dev, dtype=torch.float32)
    inside = (c[None] >= P[:, None]) & (c[None] < P[:, None] + w)                     # [np, 128]
    if sf is None:
        g = inside.float()
    else:
        g = torch.exp(-((c[None] - (P[:, None] + w / 2)) ** 2) / (2 * (sf * w) ** 2)) * inside
    return (g[:, None, :, None] * g[None, :, None, :]).reshape(len(ps) ** 2, 128, 128)  # separable


def aggregate(scores, sf=0.25, dev="cpu"):
    """scores {w: [ny,nx]} -> {w: [128,128]} weighted heat per scale. sf=None -> uniform."""
    out = {}
    for w, s in scores.items():
        Wt = _weights(w, positions(w), sf, dev)
        s = torch.as_tensor(s, device=dev).reshape(-1, 1, 1)
        out[w] = ((Wt * s).sum(0) / Wt.sum(0).clamp(min=1e-8)).cpu().numpy()
    return out


def zscore(h):
    return (h - h.mean()) / (h.std() + 1e-6)


def fuse(heats, sizes):
    return np.mean([zscore(heats[w]) for w in sizes], 0)
