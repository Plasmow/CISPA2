"""Test context-preserving maps. A) gradient attribution (PixelSeal, TrustMark), all 170 train images/method:
cell AUC within type, within-image Spearman with the true watermarked fraction, CV mIoU (switch).
B) occlusion (3 methods), 30 images/method (15 T + 15 F), sizes 64/96/128, fill gray / window-mean:
response curve, within-image Spearman, CV mIoU on the same 30 images vs the keep-window heat."""
import sys, time
import numpy as np, torch, torch.nn.functional as F
from scipy.stats import spearmanr
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT, CACHE, auc
from evalkit import cv_eval
from heatmap import positions, aggregate, zscore
from attribution import occlusion_scores, grad_maps
from pathlib import Path
HERE = Path(__file__).parent
ds = load_split("train"); gl = np.load(CACHE / "global_train.npy", allow_pickle=True).item()
def gval(meth, it):
    lut = dict(zip(gl[meth]["names"], gl[meth]["logits"])); return float((lut[it["image_name"]] * (it["message"] * 2. - 1)).mean())
def soft128(mask): return F.avg_pool2d(torch.from_numpy(mask).float()[None, None], 4)[0, 0].numpy()
def wspear(maps, soft, sel):
    return np.nanmean([spearmanr(maps[i].ravel(), soft[i].ravel())[0] for i in np.where(sel)[0] if soft[i].std() > 0])
def report(tag, h, gt, soft, g, full):
    s = cv_eval(h, gt, g, "switch")
    print(f"  {tag:34s} AUC T={auc(h[full],gt[full]):.3f} F={auc(h[~full],gt[~full]):.3f} | Spearman T={wspear(h,soft,full):.2f} "
          f"F={wspear(h,soft,~full):.2f} | mIoU={s.mean():.4f} T={s[full].mean():.4f} F={s[~full].mean():.4f}", flush=True)

print("=== A) gradient attribution (170 imgs/method)")
for meth in ("pixelseal", "trustmark"):
    wm = load_watermark(meth, KIT / "models", "cuda"); idx = [i for i, m in enumerate(ds.meta) if m["method"] == meth]
    M, gt, soft, g, full = {}, [], [], [], []; t = time.time()
    for i in idx:
        it = ds[i]; maps, _ = grad_maps(wm, it["image"], it["message"])
        for k, v in maps.items(): M.setdefault(k, []).append(v)
        gt.append(it["mask128"]); soft.append(soft128(it["mask"])); g.append(gval(meth, it)); full.append(it["full_watermark"])
    gt = np.stack(gt).astype(bool); soft = np.stack(soft); g = np.array(g); full = np.array(full)
    print(f" {meth} ({(time.time()-t)/len(idx)*1000:.0f} ms/img)  [ref: head 0.533/0.516, keep-window heat 0.469/0.458]")
    for k, v in M.items(): report(k, np.stack(v), gt, soft, g, full)
    np.savez(HERE / "cache" / f"grad_train_{meth}.npz", names=np.array([ds.meta[i]["image_name"] for i in idx]), **{k: np.stack(v) for k, v in M.items()})

print("\n=== B) occlusion (30 imgs/method)")
rng = np.random.RandomState(0); bins = [0, .05, .25, .5, .75, .95, 1.01]
for meth in ("pixelseal", "trustmark", "stegastamp"):
    wm = load_watermark(meth, KIT / "models", "cuda")
    it_t = [i for i, m in enumerate(ds.meta) if m["method"] == meth and m["full_watermark"]]
    it_f = [i for i, m in enumerate(ds.meta) if m["method"] == meth and not m["full_watermark"]]
    pick = list(rng.permutation(it_t)[:15]) + list(rng.permutation(it_f)[:15])
    keep = np.load(HERE / "cache" / f"scores_train_{meth}.npz"); kidx = {n: j for j, n in enumerate(keep["names"])}
    items = [ds[i] for i in pick]
    gt = np.stack([it["mask128"] for it in items]).astype(bool); soft = np.stack([soft128(it["mask"]) for it in items])
    g = np.array([gval(meth, it) for it in items]); full = np.array([it["full_watermark"] for it in items])
    masks = torch.from_numpy(np.stack([it["mask"] for it in items]).astype(np.float32))[:, None]
    print(f" {meth}")
    # reference on the same 30 images: keep-window heat (cached), fused z-mean of all 4 sizes, sf=1/6
    ref = np.stack([np.mean([zscore(aggregate({w: keep[f"s{w}"][kidx[it['image_name']]]}, 1/6)[w]) for w in (96, 128, 192, 256)], 0) for it in items])
    report("REF keep-window heat (fused)", ref, gt, soft, g, full)
    for fill in ("gray", "mean"):
        t = time.time(); S = [occlusion_scores(wm, it["image"], it["message"], fill=fill)[0] for it in items]
        dt = (time.time() - t) / len(items); H = {}
        for w in (64, 96, 128):
            P = torch.tensor(positions(w)); frac = F.avg_pool2d(masks, w, stride=1)[:, 0][:, P][:, :, P].numpy()
            s = np.stack([S[j][w] for j in range(len(items))])
            for typ, sel in (("T", full), ("F", ~full)):
                f_, s_ = frac[sel].ravel(), s[sel].ravel()
                curve = " ".join(f"{s_[(f_>=a)&(f_<b)].mean():6.3f}" if ((f_>=a)&(f_<b)).any() else "   n/a" for a, b in zip(bins[:-1], bins[1:]))
                rho = np.nanmean([spearmanr(frac[i].ravel(), s[i].ravel())[0] for i in np.where(sel)[0] if frac[i].std() > 0])
                print(f"    occl {fill} w={w:3d} {typ}: drop by wm fraction [0-5,5-25,25-50,50-75,75-95,95-100%] = {curve} | window Spearman={rho:.2f}")
            H[w] = np.stack([zscore(aggregate({w: S[j][w]}, 1/6)[w]) for j in range(len(items))])
            report(f"occl {fill} w={w} heat", H[w], gt, soft, g, full)
        report(f"occl {fill} fused (64,96,128)  [{dt:.1f}s/img]", np.mean([H[w] for w in H], 0), gt, soft, g, full)
