"""Unseen twins: img2img variants of each forget image (same object, same style, new pixels), plus the original
model's logits on them.

Idea: gold never trained on forget image x. The original model never trained on a twin v of x. So the original's
prediction on twins of x is a proxy for gold's prediction on x (per-image soft target, natural wrong classes,
heavy-tailed loss). Strength = how far a twin is from its source (sd-turbo img2img, guidance 0).

One process per GPU (shard), launched by scripts/twins_job.sh. Writes, per strength s and shard i:
  output/twins/s<s>_sh<i>.npz : idx [n], images uint8 [n, k, 224, 224, 3], logits float32 [n, k, 100]
Merge + build targets on CPU with scripts/build_twin_targets.py.
"""
import argparse
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import task_template as tt  # noqa: E402

OUT = ROOT / "output" / "twins"


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shard", type=int, default=0)
    ap.add_argument("--nshards", type=int, default=1)
    ap.add_argument("--strengths", default="0.5,0.3,0.7", help="order = generation priority")
    ap.add_argument("--k", type=int, default=4, help="twins per image per strength")
    ap.add_argument("--steps", type=int, default=4, help="img2img steps; effective steps = int(steps * strength)")
    ap.add_argument("--bs", type=int, default=8, help="source images per pipe call (x k twins)")
    ap.add_argument("--res", type=int, default=512, help="diffusion resolution (224 -> res -> 224)")
    ap.add_argument("--prompt", default="a high quality cinematic photograph")
    ap.add_argument("--limit", type=int, default=0, help="debug: only the first N images of the shard")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tag", default="", help="file tag: output/twins/s<s><tag>_sh<i>.npz (new seeds -> new files)")
    return ap.parse_args()


@torch.no_grad()
def main():
    a = parse()
    OUT.mkdir(parents=True, exist_ok=True)
    from diffusers import AutoPipelineForImage2Image

    pipe = AutoPipelineForImage2Image.from_pretrained(
        "stabilityai/sd-turbo", torch_dtype=torch.float16, variant="fp16").to("cuda")
    pipe.set_progress_bar_config(disable=True)
    model = tt.load_model(ROOT / "model.pt")

    imgs = tt.load_forget_images(ROOT / "forget_images.npz")
    idx = np.array_split(np.arange(len(imgs)), a.nshards)[a.shard]
    if a.limit:
        idx = idx[:a.limit]

    for s in [float(v) for v in a.strengths.split(",")]:
        path = OUT / f"s{s:g}{a.tag}_sh{a.shard}.npz"
        if path.exists():
            print(f"skip {path} (exists)", flush=True)
            continue
        t0 = time.time()
        out_img = np.zeros((len(idx), a.k, 224, 224, 3), np.uint8)
        out_log = np.zeros((len(idx), a.k, tt.NUM_CLASSES), np.float32)
        for b in range(0, len(idx), a.bs):
            ib = idx[b:b + a.bs]
            x = imgs[ib].to("cuda").permute(0, 3, 1, 2).float() / 255.0                 # [B,3,224,224] in [0,1]
            x = F.interpolate(x, size=a.res, mode="bicubic", align_corners=False).clamp(0, 1)
            x = x.repeat_interleave(a.k, 0).half()                                       # [B*k,3,res,res]
            gens = [torch.Generator("cuda").manual_seed(a.seed * 10_000_000 + int(i) * 100 + j + int(s * 1000))
                    for i in ib for j in range(a.k)]
            y = pipe(prompt=[a.prompt] * len(x), image=x, strength=s, num_inference_steps=a.steps,
                     guidance_scale=0.0, generator=gens, output_type="pt").images               # [B*k,3,res,res] [0,1]
            y = F.interpolate(y.float(), size=224, mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
            u8 = (y * 255).round().to(torch.uint8).permute(0, 2, 3, 1)                   # [B*k,224,224,3]
            logits = tt.predict(model, u8, batch_size=len(u8))                           # server-like fp16 forward
            out_img[b:b + len(ib)] = u8.cpu().numpy().reshape(len(ib), a.k, 224, 224, 3)
            out_log[b:b + len(ib)] = logits.numpy().reshape(len(ib), a.k, -1)
            if b == 0 or (b // a.bs) % 20 == 0:
                print(f"[sh{a.shard} s={s:g}] {b + len(ib)}/{len(idx)}  {time.time() - t0:.0f}s", flush=True)
        tmp = path.with_name(path.stem + ".tmp.npz")
        np.savez(tmp, idx=idx, images=out_img, logits=out_log)
        os.replace(tmp, path)
        print(f"wrote {path} in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
