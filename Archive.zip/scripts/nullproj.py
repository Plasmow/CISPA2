"""Null-space projection of an unlearning update (post-hoc, no training).

For every nn.Linear in the ViT (qkv, attn.proj, fc1, fc2, head), with homogeneous input x~ = [x, 1]:
  C = E[x~ x~^T] over tokens of GENERIC images (unseen twins s0.875 + s0.625(seed0) + task-1 outside), via the
      ORIGINAL model's activations.   C = V diag(e) V^T.
  Delta = [W_unl - W_orig, b_unl - b_orig]           (out x in+1)
  Delta' = Delta V diag(lam / (lam + e/mean(e))) V^T  -> damp the update along input directions generic data uses,
                                                        keep it along directions only (memorised) forget inputs use.
Other params (norms, LayerScale, embeddings): --other keep|orig.
Evaluates each lam with the local metrics (drift t875/t625/proxy, loss stats, PS) and saves the chosen one.
Usage: python scripts/nullproj.py --ckpt output/X/ckpt.pt --name NP --lams 0.01,0.1,1 [--save LAM]
"""
import argparse, glob, json, sys
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--ckpt", required=True)
ap.add_argument("--name", required=True)
ap.add_argument("--lams", default="0.003,0.01,0.03,0.1,0.3,1")
ap.add_argument("--other", default="keep", choices=["keep", "orig"])
ap.add_argument("--n_gen", type=int, default=3000, help="generic images for the covariances")
ap.add_argument("--save", default="", help="comma list of lams to save as checkpoints")
a = ap.parse_args()
import os
from pathlib import Path
OUT = Path(os.environ.get("NP_OUT", str(C.ROOT / "output" / "nullproj"))); OUT.mkdir(parents=True, exist_ok=True)
dev = C.DEVICE

teacher, imgs = C.load_all()
ev = C.Evaluator(teacher, imgs); y = ev.labels; N = len(y)

def load_imgs(pat, sl):
    files = sorted(f for f in glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
    return torch.from_numpy(np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in files])[sl])
g = torch.Generator().manual_seed(0)
t875 = load_imgs("output/twins/s0.875_sh*.npz", slice(0, -1000))          # held-out last 1000 excluded
t625 = load_imgs("output/twins/s0.625_sh*.npz", slice(None))              # seed-0 twins (metrics use seed-1 'b')
out_ = torch.from_numpy(np.load(C.ROOT / "output/outside_task1/images_224.npz")["images"])
n1, n2 = int(a.n_gen * 0.5), int(a.n_gen * 0.35)
gen = torch.cat([t875[torch.randperm(len(t875), generator=g)[:n1]], t625[torch.randperm(len(t625), generator=g)[:n2]],
                 out_[torch.randperm(len(out_), generator=g)[:a.n_gen - n1 - n2]]])
print(f"generic images: {len(gen)}", flush=True)

# ---- covariances of linear-layer inputs (orig activations)
lin = \
      {n: m for n, m in teacher.named_modules() if isinstance(m, nn.Linear)}
cov = {n: torch.zeros(m.in_features + 1, m.in_features + 1, device=dev, dtype=torch.float64) for n, m in lin.items()}
cnt = {n: 0 for n in lin}
def hook(name):
    def f(mod, inp, outp):
        x = inp[0].detach().reshape(-1, inp[0].shape[-1]).double()
        x = torch.cat([x, torch.ones(len(x), 1, device=dev, dtype=torch.float64)], 1)
        cov[name] += x.T @ x; cnt[name] += len(x)
    return f
hs = [m.register_forward_hook(hook(n)) for n, m in lin.items()]
teacher.eval()
with torch.no_grad():
    for i in range(0, len(gen), 64):
        teacher(C.norm(C.u8_to01(gen[i:i + 64].to(dev))))
for h in hs:
    h.remove()
eig = {}
for n in lin:
    c = cov[n] / cnt[n]
    e, V = torch.linalg.eigh(c)
    e = e.clamp_min(0)
    eig[n] = (e / e.mean(), V)
print("covariances done", flush=True)

sd_o = {k: v.float() for k, v in teacher.state_dict().items()}
sd_u = torch.load(C.ROOT / a.ckpt, map_location=dev, weights_only=True)

def project(lam):
    sd = {}
    for k in sd_o:
        sd[k] = sd_u[k].clone() if a.other == "keep" else sd_o[k].clone()
    for n, m in lin.items():
        W, b = f"{n}.weight", f"{n}.bias"
        D = torch.cat([(sd_u[W] - sd_o[W]).double(), (sd_u[b] - sd_o[b]).double()[:, None]], 1)
        e, V = eig[n]
        Dp = (D @ V) * (lam / (lam + e))[None, :] @ V.T
        sd[W] = (sd_o[W].double() + Dp[:, :-1]).float()
        sd[b] = (sd_o[b].double() + Dp[:, -1]).float()
    return sd

HO = {"tw875": load_imgs("output/twins/s0.875_sh*.npz", slice(-1000, None)).to(dev),
      "tw625": load_imgs("output/twins/s0.625b_sh*.npz", slice(-1000, None)).to(dev)}
def logits(m, u8):
    m.eval()
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        return torch.cat([m(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])
HOt = {k: logits(teacher, u) for k, u in HO.items()}
oh = F.one_hot(y, 100).float()
g_tw = F.softmax(load_twins("0.625").to(dev) / 2, -1).mean(1)
zz = ev.t_clean.clone(); zz[torch.arange(N, device=dev), y] = -1e4
g_bl = 0.5 * g_tw + 0.5 * (F.softmax(zz / 2, -1) * 0.7 + oh * 0.3)
klm = lambda gg, lq: (gg * (gg.clamp_min(1e-12).log() - lq)).sum(1).mean().item()  # noqa: E731
D_bl = {v: klm(g_bl, F.log_softmax(t / 2, -1)) for v, t in (("clean", ev.t_clean), ("mild", ev.t_mild))}

model = C.tt.build_model().to(dev)
saves = [float(s) for s in a.save.split(",") if s]
for lam in [float(v) for v in a.lams.split(",")] + [float("inf")]:
    sd = sd_u if lam == float("inf") else project(lam)
    model.load_state_dict(sd)
    c, m_, p = (ev.sets.logits(model, k) for k in ("clean", "mild", "proxy"))
    r = {"lam": lam, "ckpt": a.ckpt, "other": a.other}
    r.update({f"clean_{k}": v for k, v in C.forget_stats(c, y).items()})
    r.update({f"mild_{k}": v for k, v in C.forget_stats(m_, y).items()})
    r["proxy_kl"] = C.kl_T(ev.t_proxy, p).mean().item()
    for k, u in HO.items():
        r[f"{k}_kl"] = C.kl_T(HOt[k], logits(model, u)).mean().item()
    r["PS_blend"] = float(np.mean([1 - np.clip(klm(g_bl, F.log_softmax(t / 2, -1)) / D_bl[v], 0, 1)
                                   for v, t in (("clean", c), ("mild", m_))]))
    r["retain_fit"] = 1 / (1 + 2.3 * r["tw875_kl"] + 0.32 * r["tw625_kl"])
    with open(OUT / f"{a.name}.jsonl", "a") as f:
        f.write(json.dumps(r) + "\n")
    print(f"lam {lam:8.3g}: clean {r['clean_loss_mean']:.2f}±{r['clean_loss_std']:.2f} mild {r['mild_loss_mean']:.2f}±"
          f"{r['mild_loss_std']:.2f} | t875 {r['tw875_kl']:.3f} t625 {r['tw625_kl']:.3f} pKL {r['proxy_kl']:.3f} | "
          f"PS_bl {r['PS_blend']:.3f} | retain_fit {r['retain_fit']:.3f}", flush=True)
    if lam in saves:
        C.save_state_dict(model, OUT / f"{a.name}_lam{lam:g}.pt")
        print("  saved", OUT / f"{a.name}_lam{lam:g}.pt", flush=True)
