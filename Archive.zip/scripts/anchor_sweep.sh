#!/bin/bash
# Distillation with retain anchors that are NOT built from the forget images (Task-1 outside images + img2img twins).
# Target: a1_m2_s3_T1.5_w1_tw (loss 2.0±3.0, maxp 0.77) = the leaderboard-verified SCRUB-C@240 operating point.
# an_out90 (done, Task-1 anchors only) reached 1.03±1.23: mean closer, but the heavy tail (std 3.0) is not reached.
# Run: sbatch --job-name=anchor scripts/run4.sh scripts/anchor_sweep.sh
T=output/targets/a1_m2_s3_T1.5_w1_tw.pt
OUT="--outside output/outside_task1/images_224.npz"
TWP="output/twins/s0.875_sh*.npz"  # quoted below so the shell does not expand it
COMMON="--target $T --epochs 10 --clean_frac 0.5 --eval_every 54 --lr 1e-4 --twin_frac 0"
run() { local gpu=$1; local name=$2; shift 2
  CUDA_VISIBLE_DEVICES=$gpu .venv/bin/python scripts/distill.py --run $name $COMMON "$@" > output/$name.log 2>&1 & }

# wave 1: anchors (Task-1 + twins), plus a first tail-weighting probe on the free GPU
run 0 an_out90_tw_tw1  $OUT --outside_frac 0.5 --outside_minconf 0.9 --proxy_twins "$TWP" --twin_frac 0.5 --tail_w 1
run 1 an_out90_tw      $OUT --outside_frac 0.5 --outside_minconf 0.9 --proxy_twins "$TWP" --twin_frac 0.5
run 2 an_out90_tw_a3   $OUT --outside_frac 0.5 --outside_minconf 0.9 --proxy_twins "$TWP" --twin_frac 0.5 --alpha 3
run 3 an_outall_tw     $OUT --outside_frac 0.5 --outside_minconf 0.0 --proxy_twins "$TWP" --twin_frac 0.5
wait

# wave 2: reach the heavy tail (target std 3.0): weight hard images, fit longer / harder, more exact-image steps
run 0 an_tail2           $OUT --outside_frac 0.5 --proxy_twins "$TWP" --twin_frac 0.5 --tail_w 2
run 1 an_tail1_e20_lr2e-4 $OUT --outside_frac 0.5 --proxy_twins "$TWP" --twin_frac 0.5 --tail_w 1 --epochs 20 --lr 2e-4
run 2 an_cf0.8_e20       $OUT --outside_frac 0.5 --proxy_twins "$TWP" --twin_frac 0.5 --clean_frac 0.8 --epochs 20
run 3 an_tail1_cf0.8_e20 $OUT --outside_frac 0.5 --proxy_twins "$TWP" --twin_frac 0.5 --tail_w 1 --clean_frac 0.8 --epochs 20
wait
