| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['headsyn', 'headmulti'] | 0.5652 | 0.5800 | 0.5505 |
| pixelseal | fusion top3 ['headsyn', 'headmulti', 'head'] | 0.5650 | 0.5798 | 0.5502 |
| pixelseal | fusion all ['headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5739 | 0.5844 | 0.5634 |
| pixelseal | fusion all + rule switch | 0.5739 | 0.5844 | 0.5634 |
| pixelseal | fusion all + rule expected_area | 0.5753 | 0.5880 | 0.5626 |
| pixelseal | fusion all + rule otsu_in_regime | 0.5758 | 0.5851 | 0.5666 |
| pixelseal | fusion all + rule regressed_area | 0.5509 | 0.5650 | 0.5369 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6104 | 0.6231 | 0.5977 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: otsu_in_regime) | 0.5746 | 0.5860 | 0.5633 |
| pixelseal | **v2 pipeline**: fusion all + otsu_in_regime + post T:fill_holes<64 / F:drop<64 | **0.5744** | 0.5812 | 0.5676 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['headsyn', 'headmulti'] | 0.5441 | 0.5664 | 0.5218 |
| trustmark | fusion top3 ['headsyn', 'headmulti', 'head'] | 0.5439 | 0.5664 | 0.5213 |
| trustmark | fusion all ['headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5609 | 0.5691 | 0.5527 |
| trustmark | fusion all + rule switch | 0.5609 | 0.5691 | 0.5527 |
| trustmark | fusion all + rule expected_area | 0.5703 | 0.5745 | 0.5661 |
| trustmark | fusion all + rule otsu_in_regime | 0.5651 | 0.5701 | 0.5600 |
| trustmark | fusion all + rule regressed_area | 0.5498 | 0.5516 | 0.5479 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6091 | 0.6109 | 0.6072 |
| trustmark | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.5703 | 0.5745 | 0.5661 |
| trustmark | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<256 / F:largest | **0.5711** | 0.5726 | 0.5695 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot', 'headmulti', 'remark'] | 0.6838 | 0.7182 | 0.6494 |
| stegastamp | fusion all + rule switch | 0.6838 | 0.7182 | 0.6494 |
| stegastamp | fusion all + rule expected_area | 0.6849 | 0.7143 | 0.6554 |
| stegastamp | fusion all + rule otsu_in_regime | 0.6890 | 0.7235 | 0.6545 |
| stegastamp | fusion all + rule regressed_area | 0.6689 | 0.6978 | 0.6400 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7206 | 0.7503 | 0.6909 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: otsu_in_regime) | 0.6890 | 0.7235 | 0.6545 |
| stegastamp | **v2 pipeline**: fusion all + otsu_in_regime + post T:fill_holes<4 / F:largest | **0.6881** | 0.7203 | 0.6559 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "otsu_in_regime",
  "post_T": "fill_holes<64",
  "post_F": "drop<64",
  "cv": 0.5744,
  "cv_T": 0.5812,
  "cv_F": 0.5676,
  "test_frac_pred_1": 0.477
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<256",
  "post_F": "largest",
  "cv": 0.5711,
  "cv_T": 0.5726,
  "cv_F": 0.5695,
  "test_frac_pred_1": 0.491
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot",
   "headmulti",
   "remark"
  ],
  "rule": "otsu_in_regime",
  "post_T": "fill_holes<4",
  "post_F": "largest",
  "cv": 0.6881,
  "cv_T": 0.7203,
  "cv_F": 0.6559,
  "test_frac_pred_1": 0.485
 },
 "expected_cv_mIoU": 0.6112,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v3b.pt",
 "size_MB": 15.96
}
```
