"""Routing: tune the thresholding rule and the post-processing separately for each kind of image (CPU only).

The v3/v4 pipeline tunes one rule for all images and one post-processing per type, although part of the type-F
images is overridden by the rectangle anyway. Here every image is routed to a group that is known at test time:
  F_rect  : predicted type F and a searched box with bit acc >= RECT_THR      -> the box (as in v3 --rect)
  F_other : predicted type F, no reliable box (objects, missed rectangles)     -> rule + post tuned on this group only
  T_blobs : predicted type T, the predicted holes are >= 3 small pieces        -> rule + post tuned on this group only
  T_region: predicted type T, 1-2 larger holes (irregular zones)               -> rule + post tuned on this group only
The fused map is the same as v3 (best of single sources / top2 / top3 / all by CV). Every choice is made by nested
5-fold CV restricted to the group; the reported score is out-of-fold.

    python route.py --extras headmulti remark headsyn headsyn2 wmunet wmunet0 wmunetF wmunetF0 --out ../submissions/submission_v5_route.pt
"""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

from v3 import (HERE, ROOT, METHODS, UNET_RUNS, load_split, load_sources, fuse_feats, fit_fusion, apply_fusion, oof_fusion,
                cv_eval, rule_preds, miou_batch, POST_T, POST_F, cv_select, load_rect, g_of, folds)

RECT_THR = 0.85


def t_subgroup(pred):
    """True = 'blobs' (>= 3 predicted hole pieces, holes < 8% of the image), from the predicted mask only."""
    out = np.zeros(len(pred), bool)
    for i, m in enumerate(pred):
        hole = ~m; n = ndi.label(hole)[1]
        out[i] = n >= 3 and hole.mean() < 0.08
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", default=list(UNET_RUNS))
    ap.add_argument("--extras", nargs="*", default=["headmulti", "remark", "headsyn", "headsyn2", "wmunet", "wmunet0", "wmunetF", "wmunetF0"])
    ap.add_argument("--out", default=str(ROOT / "submissions" / "submission_v5_route.pt")); a = ap.parse_args()
    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}; meta_te = {m["image_name"]: m for m in te_all.meta}
    final, report, lines = {}, {}, []
    for meth in METHODS:
        n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
        g_tr, g_te = g_of("train", n_tr, meta_tr), g_of("test", n_te, meta_te)
        gt = np.stack([tr_all.m128[n] for n in n_tr]).astype(bool); full = np.array([meta_tr[n]["full_watermark"] for n in n_tr]); N = len(n_tr)
        # ---- fused map, chosen exactly as in v3
        S = load_sources(meth, n_tr, n_te, a.runs, a.extras); cands = {}
        for k, (L, Lt) in S.items():
            cands[k] = (cv_eval(L, gt, g_tr, "switch").mean(), L, Lt, None)
        ranked = sorted(S, key=lambda k: -cands[k][0])
        for name, srcs in (("fusion top2", ranked[:2]), ("fusion top3", ranked[:3]), ("fusion all", ranked)):
            L = oof_fusion(fuse_feats([S[k][0] for k in srcs], g_tr), gt); cands[name] = (cv_eval(L, gt, g_tr, "switch").mean(), L, None, srcs)
        best = max(cands, key=lambda k: cands[k][0]); _, Lb, Lt, srcs = cands[best]
        if srcs is not None:
            Lt = apply_fusion(fit_fusion(fuse_feats([S[k][0] for k in srcs], g_tr), gt, np.arange(N)), fuse_feats([S[k][1] for k in srcs], g_te))
        # ---- out-of-fold binary predictions of every rule, and the predicted type
        R = {}; typT = np.zeros(N, bool)
        for f in folds(N, 5, 0):
            tr = np.setdiff1d(np.arange(N), f); pr, p = rule_preds(Lb, g_tr, gt, tr)
            for r, m in pr.items():
                R.setdefault(r, np.zeros(gt.shape, bool))[f] = m[f]
            typT[f] = g_tr[f] > p["tg"]
        B = load_rect(meth, "train"); Bt = load_rect(meth, "test"); use_rect = len(Bt) > 0
        f_rect = np.array([use_rect and (not typT[i]) and n_tr[i] in B and B[n_tr[i]][1] >= RECT_THR for i in range(N)])
        f_other = ~typT & ~f_rect
        # ---- rule per group (T, F_other), nested CV restricted to the group
        sc = {r: miou_batch(m, gt) for r, m in R.items()}
        sT, ruleT = cv_select(sc, typT); sF, ruleF = cv_select(sc, f_other) if f_other.any() else (np.array([]), "switch")
        base = np.where(typT[:, None, None], R[ruleT], R[ruleF])
        # ---- T sub-groups from the predicted holes, post-processing per group
        tb = typT & t_subgroup(base); trg = typT & ~tb
        def post_scores(names_fns, mask):
            return {k: np.array([miou_batch(fn(base[i])[None], gt[i][None])[0] if mask[i] else np.nan for i in range(N)]) for k, fn in names_fns.items()}
        s_tb, post_tb = cv_select(post_scores(POST_T, tb), tb) if tb.any() else (np.array([]), "none")
        s_tr, post_tr = cv_select(post_scores(POST_T, trg), trg) if trg.any() else (np.array([]), "none")
        s_fo, post_fo = cv_select(post_scores(POST_F, f_other), f_other) if f_other.any() else (np.array([]), "none")
        s = np.zeros(N); s[tb] = s_tb; s[trg] = s_tr; s[f_other] = s_fo
        if f_rect.any():
            s[f_rect] = miou_batch(np.stack([B[n_tr[i]][0] for i in np.where(f_rect)[0]]), gt[f_rect])
        lines.append(f"| {meth} | {best} | T: rule {ruleT}, blobs n={tb.sum()} post {post_tb}, regions n={trg.sum()} post {post_tr} | "
                     f"F: rect n={f_rect.sum()}, other n={f_other.sum()} rule {ruleF} post {post_fo} | **{s.mean():.4f}** | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
        print(lines[-1], flush=True)
        # ---- test
        pr_te, p = rule_preds(np.concatenate([Lb, Lt]), np.concatenate([g_tr, g_te]), np.concatenate([gt, np.zeros((len(n_te),) + gt.shape[1:], bool)]), np.arange(N))
        tT = g_te > p["tg"]; base_te = np.where(tT[:, None, None], pr_te[ruleT][N:], pr_te[ruleF][N:]); tb_te = tT & t_subgroup(base_te)
        out = []
        for i, n in enumerate(n_te):
            if not tT[i] and use_rect and n in Bt and Bt[n][1] >= RECT_THR:
                out.append(Bt[n][0])
            elif tT[i]:
                out.append(POST_T[post_tb if tb_te[i] else post_tr](base_te[i]))
            else:
                out.append(POST_F[post_fo](base_te[i]))
        final.update(zip(n_te, out))
        report[meth] = dict(map=best, sources=srcs, cv=round(float(s.mean()), 4), rule_T=ruleT, rule_F=ruleF, post_T_blobs=post_tb,
                            post_T_regions=post_tr, post_F_other=post_fo, train_groups=dict(T_blobs=int(tb.sum()), T_regions=int(trg.sum()),
                            F_rect=int(f_rect.sum()), F_other=int(f_other.sum())), test_frac_pred_1=round(float(np.mean(out)), 3))
    names = [m["image_name"] for m in te_all.meta]; masks = np.stack([final[n] for n in names]).astype(bool)
    assert len(names) == len(set(names)) == 1020 and masks.shape == (1020, 128, 128)
    out_p = Path(a.out); torch.save({"image_names": names, "masks": torch.from_numpy(masks)}, out_p)
    re = torch.load(out_p, weights_only=True); assert re["image_names"] == names and re["masks"].dtype == torch.bool
    report["expected_cv_mIoU"] = round(float(np.mean([report[m]["cv"] for m in METHODS])), 4); report["size_MB"] = round(os.path.getsize(out_p) / 2 ** 20, 2)
    hdr = ["| method | map | T routing | F routing | mIoU (CV) | type T | type F |", "|---|---|---|---|---|---|---|"]
    (ROOT / f"results_{out_p.stem}.md").write_text("\n".join(hdr + lines) + "\n\n```json\n" + json.dumps(report, indent=1) + "\n```\n")
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
