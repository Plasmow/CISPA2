#!/bin/bash
# Run gen_twins.py on all 4 GPUs of the node (one shard per GPU).
# Usage: sbatch --job-name=twins --time=00:50:00 scripts/run4.sh scripts/twins_job.sh [extra gen_twins args]
export HF_HOME=/p/scratch/training2666/ayadi1/automateam2/.cache
export HUGGINGFACE_HUB_CACHE=/p/scratch/training2666/ayadi1/automateam2/.cache/hub
export HF_HUB_OFFLINE=1
for i in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=$i .venv/bin/python scripts/gen_twins.py --shard $i --nshards 4 "$@" \
    > output/twins_sh$i.log 2>&1 &
done
wait
bash scripts/twin_distill_sweep.sh
