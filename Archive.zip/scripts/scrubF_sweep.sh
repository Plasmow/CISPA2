#!/bin/bash
# SCRUB-F sweep: KL cap only (no A1 target), longer max phase (msteps 12 of 14 epochs = 648 max steps).
# Per-image caps 24/28/32/40, one cap32 at lr 5e-5, and batch-mean caps 16/24/32 (keep some per-image spread).
#SBATCH --job-name=scrubF
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --time=00:45:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
P=".venv/bin/python scripts/scrub.py --lr 3e-5 --kd_T 4 --epochs 14 --msteps 12 --min_per_max 1 --eval_every 30 --save_min 180 --save_max 756"
run() { $P --run "$1" "${@:2}" > "output/$1.log" 2>&1; }
(export CUDA_VISIBLE_DEVICES=0
 run scrubF_cap24 --cap 24
 run scrubF_cap32_lr5e-5 --cap 32 --lr 5e-5) &
(export CUDA_VISIBLE_DEVICES=1
 run scrubF_cap32 --cap 32
 run scrubF_capB16 --cap 16 --cap_mode batch) &
(export CUDA_VISIBLE_DEVICES=2
 run scrubF_cap40 --cap 40
 run scrubF_capB24 --cap 24 --cap_mode batch) &
(export CUDA_VISIBLE_DEVICES=3
 run scrubF_cap28 --cap 28
 run scrubF_capB32 --cap 32 --cap_mode batch) &
wait
echo "done!"
