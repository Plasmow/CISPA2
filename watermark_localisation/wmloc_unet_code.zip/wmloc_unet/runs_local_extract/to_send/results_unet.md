Baselines (CV): whole-image score threshold = 0.4512 | regime oracle = 0.4547

| variant | mIoU@0.5 | pixelseal | trustmark | stegastamp | full=T | full=F | CV thr/method | CV switch/method |
|---|---|---|---|---|---|---|---|---|
| effb3_hp_glob_stack | **0.5528** | 0.5042 | 0.4997 | 0.6544 | 0.5666 | 0.5390 | 0.5550 | 0.5560 |
