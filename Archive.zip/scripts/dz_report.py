"""Summarise dz runs: per run, the eval rows with local stats and predicted scores (fitted leaderboard model).
Usage: python scripts/dz_report.py [run_glob=dz*] [--all]"""
import glob, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
pat = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "dz*"
show_all = "--all" in sys.argv
for d in sorted(glob.glob(str(ROOT / "output" / pat))):
    p = Path(d) / "log.jsonl"
    if not p.exists():
        continue
    L = [json.loads(l) for l in p.read_text().splitlines()]
    if not L or "pred_5" not in L[0]:
        continue
    ck = {int(c.stem.split("_")[1]) for c in Path(d).glob("ckpt_*.pt")}
    print(f"== {Path(d).name}  ({len(L)} evals, ckpts {sorted(ck)})")
    rows = L if show_all else [r for r in L if r["step"] in ck or r is L[-1]]
    for r in rows:
        print(f"  {r['step']:5d} clean {r['clean_acc']:.2f} {r['clean_loss_mean']:5.2f}±{r['clean_loss_std']:5.2f} "
              f"mild {r['mild_loss_mean']:5.2f}±{r['mild_loss_std']:5.2f} KLt {r['kl_target_T2']:.3f} "
              f"pKL {r['proxy_kl']:.3f} oKL {r.get('out_kl', 0):.3f} t875 {r.get('tw875_kl', 0):.3f} t625 {r.get('tw625_kl', 0):.3f} PS {r['PS_blend']:.3f}/{r['PS_tw']:.3f}/{r['PS_tail']:.3f} "
              f"pred@5 {r['pred_5']:.3f} @6 {r['pred_6']:.3f}" + (f" | tw12 {r['PS_tw12']:.3f} NEW pred2@7 {r['pred2_7']:.3f} @6.5 {r['pred2_6.5']:.3f} @6 {r['pred2_6']:.3f}" if 'pred2_7' in r else ""))
