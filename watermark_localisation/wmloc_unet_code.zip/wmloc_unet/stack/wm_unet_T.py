"""wm-U-Net specialised for TYPE T (fully watermarked image, minority class = random blob holes). Agent B.

Same network and freezing schedule as wm_unet.py (imported, not modified); what changes:
  1. T-oriented synthetic pre-training: only full-watermark edits ("hole": clean content restored in a region,
     "addition": content of another clean image pasted), with LEAK-FREE hole shapes: smooth random blobs whose area and
     number of large components follow the marginal distributions of the real train T holes (loc/cache/typo_stats.json).
     No real mask shape is used (wm_unet.py's generator reuses the train GT masks, which would leak validation shapes
     into a T-specialised model). Short schedule (default 4000 steps).
     Optional --init <tag>: start from an existing wm_unet synthetic checkpoint (maps/<tag>_<method>_synthetic.pt)
     and only run the T-oriented synthetic phase on top of it.
  2. 5-fold fine-tuning on the real train images, SAME folds as wm_unet.py / every other source (folds(N, 5, 0) in
     load_split order), two variants from the same pre-trained state:
       <tag>   : all images, per-image loss weight --wT on T images (default 3)
       <tag>o  : T images only (epochs scaled to keep the number of steps)
  3. Per fold and overall, T-only scores (mIoU@0, switch rule CV, per-image oracle threshold) against wmunet.
Outputs (never overwrites an existing file; aborts at start if one exists):
  maps/<tag>0_{train,test}_<m>.npz (synthetic only), maps/<tag>_{...}.npz, maps/<tag>o_{...}.npz  (names, logit128 f16)
  maps/<tag>_<m>_synthetic.pt (pre-trained state, f16),  runs/wmunetT/<tag>_<m>.json (log)

    python wm_unet_T.py --method pixelseal --tag wmunetT
    python wm_unet_T.py --method trustmark --tag wmunetTi --init wmunet --steps 1500 --freeze_steps 0 --lr 1e-4
"""
import argparse
import copy
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage
from scipy.ndimage import gaussian_filter
from torch.utils.data import DataLoader, IterableDataset, get_worker_info

from wm_unet import (HERE, ROOT, TASK, CH, WMUNet, StegaUNet, load_real, predict, set_encoder_trainable, zero_shot_report,
                     load_watermark, KIT, folds, cv_eval, miou_batch)
from generator import SynthGenerator

TYPO = TASK / "loc" / "cache" / "typo_stats.json"
RUNS = ROOT / "runs" / "wmunetT"


class TMaskBank:
    """Leak-free T hole shapes: thresholded smooth noise (optionally roughened), area drawn from the empirical
    distribution of real T hole areas, k largest components kept with k drawn from the real 'big_cc' counts."""

    def __init__(self):
        rows = [r for r in json.loads(TYPO.read_text()) if r["full"]]
        self.area = np.sort([r["area"] for r in rows]); self.k = np.array([max(1, int(r["big_cc"])) for r in rows])

    def sample(self, rng, kind=None, H=512):
        import cv2
        a = float(np.clip(np.interp(rng.rand(), np.linspace(0, 1, len(self.area)), self.area) * np.exp(rng.normal(0, 0.15)), 0.003, 0.5))
        k = int(self.k[rng.randint(len(self.k))])
        n = gaussian_filter(rng.randn(H // 8, H // 8), sigma=rng.uniform(10, 60) / 8, mode="wrap")
        n = cv2.resize(n.astype(np.float32), (H, H), interpolation=cv2.INTER_CUBIC); n /= n.std() + 1e-6
        if rng.rand() < 0.5:                                            # irregular contour
            f = gaussian_filter(rng.randn(H // 4, H // 4), sigma=rng.uniform(1, 3), mode="wrap")
            f = cv2.resize(f.astype(np.float32), (H, H), interpolation=cv2.INTER_CUBIC); n += rng.uniform(0.1, 0.4) * f / (f.std() + 1e-6)
        q = a; m = n > np.quantile(n, 1 - q)
        for _ in range(4):                                              # keep k components, re-aim the area
            lab, nc = ndimage.label(m)
            if nc > k:
                s = ndimage.sum(m, lab, range(1, nc + 1)); m = np.isin(lab, np.argsort(-s)[:k] + 1)
            r = m.mean() / a
            if 0.75 < r < 1.33 or q >= 0.6:
                break
            q = min(0.6, q / max(r, 1e-3)); m = n > np.quantile(n, 1 - q)
        if rng.rand() < 0.5:
            m = m[:, ::-1]
        return np.ascontiguousarray(m)


class TSynthGenerator(SynthGenerator):
    def __init__(self, meth, seed, p_hole=0.6):
        self.realistic = True
        self.files = {meth: sorted((ROOT / "synth" / "bank" / meth).glob("*.npz"))}; self.methods = [meth]
        self.edits, self.p = ["hole", "addition"], np.array([p_hole, 1 - p_hole])
        self.masks = TMaskBank(); self.rng = np.random.RandomState(seed)


class TStream(IterableDataset):
    def __init__(self, meth, seed):
        self.meth, self.seed = meth, seed

    def __iter__(self):
        wi = get_worker_info(); g = TSynthGenerator(self.meth, self.seed + (wi.id if wi else 0))
        while True:
            s = g.sample()
            yield (torch.from_numpy(s["image"]).permute(2, 0, 1), torch.from_numpy(s["mask128"].astype(np.float32)),
                   torch.from_numpy(s["message"].astype(np.float32)))


def per_image_loss(lg, y, eps=1.0):
    """BCE + (1 - soft 2-class mIoU), per image (same surrogate as unet.miou_loss)."""
    bce = F.binary_cross_entropy_with_logits(lg, y, reduction="none").mean((1, 2))
    p = torch.sigmoid(lg.float()); i1 = (p * y).sum((1, 2)); u1 = (p + y - p * y).sum((1, 2))
    q, z = 1 - p, 1 - y; i0 = (q * z).sum((1, 2)); u0 = (q + z - q * z).sum((1, 2))
    return bce + 1 - ((i1 + eps) / (u1 + eps) + (i0 + eps) / (u0 + eps)) / 2


def oracle_T(L, gt):
    th = np.quantile(L.reshape(len(L), -1), np.linspace(0, 1, 41), axis=1).T; best = np.zeros(len(L))
    for j in range(th.shape[1]):
        best = np.maximum(best, miou_batch(L > th[:, j, None, None], gt))
    return best


def scores(L, real, idx=None):
    """T-only and F-only scores of a train map (switch rule fitted in CV on all images of the method)."""
    gt, fl = real["gt"], real["full"]; s = cv_eval(L, gt, real["g"], "switch", seed=1); o = oracle_T(L, gt); m0 = miou_batch(L > 0, gt)
    r = lambda v, k: round(float(v[k].mean()), 4)
    return dict(T_miou0=r(m0, fl), T_switch=r(s, fl), T_oracle=r(o, fl), F_switch=r(s, ~fl), all_switch=round(float(s.mean()), 4))


def load_ref(meth, names, tag):
    p = HERE / "maps" / f"{tag}_train_{meth}.npz"
    if not p.exists():
        return None
    z = np.load(p); d = dict(zip(z["names"].tolist(), z["logit128"].astype(np.float32)))
    return np.stack([d[n] for n in names]) if all(n in d for n in names) else None


def finetune(model, pre_state, real, test, a, dev, variant, refs, t0):
    """5-fold fine-tuning, folds(N, 5, 0) as every other source. variant 'w': T weighted, 'o': T images only."""
    meth = a.method; N = len(real["names"]); full = real["full"]
    oof = np.zeros((N, 128, 128), np.float32); tmean = np.zeros((len(test["names"]), 128, 128), np.float32); per_fold = []
    for k, f in enumerate(folds(N, 5, 0)):
        model.load_state_dict(pre_state); tr = np.setdiff1d(np.arange(N), f)
        epochs = a.ft_epochs
        if variant == "o":
            epochs = int(round(a.ft_epochs * len(tr) / max(1, full[tr].sum()))); tr = tr[full[tr]]
        set_encoder_trainable(model, a.freeze_steps >= 0)
        groups = [{"params": [p for n, p in model.named_parameters() if not n.startswith("enc.")], "lr": a.ft_lr}]
        if a.freeze_steps >= 0:
            groups.append({"params": list(model.enc.parameters()), "lr": a.enc_lr / 2})
        opt = torch.optim.AdamW(groups, weight_decay=1e-4); rng = np.random.RandomState(k + 100 * a.seed)
        wv = torch.tensor(np.where(full, a.wT if variant == "w" else 1.0, 1.0), dtype=torch.float32)
        for ep in range(epochs):
            perm = rng.permutation(tr)
            for b in range(0, len(perm), 8):
                ii = perm[b:b + 8]
                x = real["imgs"][ii].to(dev).float() / 255; y = torch.from_numpy(real["gt"][ii].astype(np.float32)).to(dev)
                li = per_image_loss(model(x, real["msgs"][ii].to(dev) * 2 - 1), y); w = wv[ii].to(dev)
                loss = (li * w).sum() / w.sum()
                opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
        oof[f] = predict(model, real, f, dev); tmean += predict(model, test, np.arange(len(test["names"])), dev) / 5
        Tf = f[full[f]]; row = dict(fold=k, n_T=int(len(Tf)), new_T_miou0=round(float(miou_batch(oof[Tf] > 0, real["gt"][Tf]).mean()), 4))
        for rt, R in refs.items():
            row[f"{rt}_T_miou0"] = round(float(miou_batch(R[Tf] > 0, real["gt"][Tf]).mean()), 4)
        per_fold.append(row)
        print(f"[{meth}:{variant}] fold {k}: {json.dumps(row)} ({time.time() - t0:.0f}s)", flush=True)
    return oof, tmean, per_fold


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--method", required=True, choices=list(CH)); ap.add_argument("--tag", default="wmunetT")
    ap.add_argument("--init", default=None, help="start from maps/<init>_<method>_synthetic.pt (wm_unet checkpoint)")
    ap.add_argument("--steps", type=int, default=4000); ap.add_argument("--bs", type=int, default=16)
    ap.add_argument("--freeze_steps", type=int, default=2000, help="encoder frozen for these steps; -1 = always frozen")
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--enc_lr", type=float, default=1e-5)
    ap.add_argument("--workers", type=int, default=14); ap.add_argument("--eval_every", type=int, default=2000)
    ap.add_argument("--ft_epochs", type=int, default=15); ap.add_argument("--ft_lr", type=float, default=1e-4)
    ap.add_argument("--wT", type=float, default=3.0); ap.add_argument("--variants", default="w,o")
    ap.add_argument("--seed", type=int, default=0); ap.add_argument("--maps_dir", default=str(HERE / "maps"))
    ap.add_argument("--max_real", type=int, default=None); ap.add_argument("--dev", default="cuda")
    a = ap.parse_args(); dev = a.dev; meth = a.method; t0 = time.time(); MD = Path(a.maps_dir)
    variants = [v for v in a.variants.split(",") if v]; suffix = {"w": "", "o": "o"}
    outs = [MD / f"{a.tag}0_{s}_{meth}.npz" for s in ("train", "test")] + [MD / f"{a.tag}{suffix[v]}_{s}_{meth}.npz" for v in variants for s in ("train", "test")]
    outs += [MD / f"{a.tag}_{meth}_synthetic.pt", RUNS / f"{a.tag}_{meth}.json"]
    clash = [str(p) for p in outs if p.exists()]
    if clash:
        raise SystemExit(f"refusing to overwrite existing files: {clash}")
    RUNS.mkdir(parents=True, exist_ok=True); torch.manual_seed(a.seed)
    torch.backends.cuda.matmul.allow_tf32 = False; torch.backends.cudnn.allow_tf32 = False   # encoder at full fp32
    if meth == "stegastamp":
        model = StegaUNet().to(dev)
    else:
        wm = load_watermark(meth, KIT / "models", dev); model = WMUNet(meth, wm).to(dev); del wm
    if a.init:
        sd = torch.load(HERE / "maps" / f"{a.init}_{meth}_synthetic.pt", map_location=dev, weights_only=True)
        model.load_state_dict({k: v.float() for k, v in sd.items()}); print(f"[{meth}] init from {a.init} synthetic checkpoint", flush=True)
    real = load_real(meth, "train", a.max_real); test = load_real(meth, "test", a.max_real)
    refs = {t: R for t in ("wmunet", "wmunetH", "wmunet2") if (R := load_ref(meth, real["names"], t)) is not None}
    log = {"args": vars(a), "evals": [], "ref": {t: scores(R, real) for t, R in refs.items()}}
    print(f"[{meth}] reference maps (T-only scores): {json.dumps(log['ref'])}", flush=True)
    # ---- 1. T-oriented synthetic phase
    set_encoder_trainable(model, False)
    dec_params = [p for n, p in model.named_parameters() if not n.startswith("enc.")]
    opt = torch.optim.AdamW(dec_params, lr=a.lr, weight_decay=1e-4); opt_enc = None
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, a.lr, total_steps=a.steps, pct_start=0.05)
    dl = DataLoader(TStream(meth, 9000 + 1000 * a.seed), batch_size=a.bs, num_workers=a.workers, pin_memory=True,
                    persistent_workers=a.workers > 0)
    run = None
    for step, (x, y, msg) in enumerate(dl, 1):
        if a.freeze_steps >= 0 and step == a.freeze_steps + 1:
            set_encoder_trainable(model, True); opt_enc = torch.optim.AdamW(model.enc.parameters(), lr=a.enc_lr, weight_decay=0)
            print(f"[{meth}] step {step}: encoder unfrozen (lr {a.enc_lr})", flush=True)
        x = x.to(dev, non_blocking=True).float() / 255; y = y.to(dev); sgn = msg.to(dev) * 2 - 1
        loss = per_image_loss(model(x, sgn), y).mean()
        opt.zero_grad(set_to_none=True)
        if opt_enc:
            opt_enc.zero_grad(set_to_none=True)
        loss.backward(); opt.step(); sched.step()
        if opt_enc:
            opt_enc.step()
        run = loss.item() if run is None else 0.98 * run + 0.02 * loss.item()
        if step % 100 == 0:
            print(f"[{meth}] step {step}/{a.steps} loss {run:.4f} {(time.time() - t0) / step:.2f}s/step", flush=True)
        if step % a.eval_every == 0 or step == a.steps:
            L, _ = zero_shot_report(model, real, dev, f"T-synthetic step {step}"); r = dict(tag=f"T-synthetic step {step}", **scores(L, real))
            log["evals"].append(r); print(f"[{meth}] ZERO-SHOT on real train: {json.dumps(r)}", flush=True)
        if step >= a.steps:
            break
    del dl
    pre_state = copy.deepcopy(model.state_dict())
    L0 = predict(model, real, np.arange(len(real["names"])), dev); T0 = predict(model, test, np.arange(len(test["names"])), dev)
    np.savez(MD / f"{a.tag}0_train_{meth}.npz", names=np.array(real["names"]), logit128=L0.astype(np.float16))
    np.savez(MD / f"{a.tag}0_test_{meth}.npz", names=np.array(test["names"]), logit128=T0.astype(np.float16))
    torch.save({k: v.half() for k, v in pre_state.items()}, MD / f"{a.tag}_{meth}_synthetic.pt")
    log["evals"].append(dict(tag=f"{a.tag}0 (synthetic only)", **scores(L0, real)))
    # ---- 2. 5-fold fine-tuning variants
    for v in variants:
        oof, tmean, per_fold = finetune(model, pre_state, real, test, a, dev, v, refs, t0)
        name = f"{a.tag}{suffix[v]}"
        np.savez(MD / f"{name}_train_{meth}.npz", names=np.array(real["names"]), logit128=oof.astype(np.float16))
        np.savez(MD / f"{name}_test_{meth}.npz", names=np.array(test["names"]), logit128=tmean.astype(np.float16))
        r = dict(tag=f"{name} (fine-tuned, OOF)", **scores(oof, real), per_fold=per_fold); log["evals"].append(r)
        print(f"[{meth}] {name}: {json.dumps({k: v_ for k, v_ in r.items() if k != 'per_fold'})}  vs ref {json.dumps(log['ref'])}", flush=True)
    (RUNS / f"{a.tag}_{meth}.json").write_text(json.dumps(log, indent=1))
    print(f"[{meth}] done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
