#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=00:40:00
#SBATCH --job-name=wm_vae_export
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/vae_export_%j.out
# Agent A, VAE step 2. dc-gpu-devel: OUTSIDE the cispahack reservation, account training2666 allowed, 2 h max.
# Submit from the team folder; after start:  scontrol show job <id> | grep Reservation   (must be empty)
#
# VAE reconstruction residual maps (stack/vae_rec.py --export) for the 1530 images (train + test, 3 methods), for the
# best VAE x variant of the pilot (and the 2nd best combination if any). Per-image z-score, clip +-8, float16.
# Writes only stack/maps/<tag>_{train,test}_<method>.npz. Weights are read offline from /p/project1/training2666/debbah2/hf.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=8
export HF_HOME=/p/project1/training2666/debbah2/hf HF_HUB_CACHE=/p/project1/training2666/debbah2/hf/hub HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
tagged() { grep --line-buffered -v -i -E "warn|accelerate|pip install" | sed -u "s/^/[$1] /"; }
# combination 1 (filled from the pilot) and optional combination 2
VAE1=__VAE1__; VAR1=__VAR1__
VAE2=__VAE2__; VAR2=__VAR2__
CUDA_VISIBLE_DEVICES=0 $PY vae_rec.py --export --vaes $VAE1 --variant $VAR1 --tag vaerec --dev cuda --bs 8 2>&1 | tagged gpu0 &
if [ "$VAE2" != "none" ]; then
  CUDA_VISIBLE_DEVICES=1 $PY vae_rec.py --export --vaes $VAE2 --variant $VAR2 --tag vaerec2 --dev cuda --bs 8 2>&1 | tagged gpu1 &
fi
wait
echo done
