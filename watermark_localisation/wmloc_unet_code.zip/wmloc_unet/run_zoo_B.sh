#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --reservation=cispahack
#SBATCH --time=00:28:00
#SBATCH --job-name=wm_zooB
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/zooB_%j.out
# Encoder zoo of "stack" U-Nets (train_unet.py, 40 epochs), 2 processes per GPU, folds split across processes.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=8
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant zrx50_hp_glob_stack --folds 0 1 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zrx50_hp_glob_stack f0 1] /' &
CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant zregy040_hp_glob_stack --folds 2 3 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zregy040_hp_glob_stack f2 3] /' &
CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant zrx50_hp_glob_stack --folds 2 3 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zrx50_hp_glob_stack f2 3] /' &
CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant zrx50_hp_glob_stack --folds 4 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zrx50_hp_glob_stack f4] /' &
CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant zr2n50_hp_glob_stack --folds 0 1 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zr2n50_hp_glob_stack f0 1] /' &
CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant zr2n50_hp_glob_stack --folds 4 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zr2n50_hp_glob_stack f4] /' &
CUDA_VISIBLE_DEVICES=3 $PY train_unet.py --variant zr2n50_hp_glob_stack --folds 2 3 --epochs 40 2>&1 | grep --line-buffered -v -i -E 'warn|Unexpected keys' | sed -u 's/^/[zr2n50_hp_glob_stack f2 3] /' &
wait; echo done
