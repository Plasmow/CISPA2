#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --partition=dc-gpu-devel
#SBATCH --time=01:40:00
#SBATCH --job-name=wm_unet_more
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/unet_more_%j.out
# Submit FROM THE TEAM FOLDER, then check that no reservation was attached (cispahack is "magnetic"):
#   cd /p/scratch/training2666/ayadi1/automateam2 && sbatch /p/project1/training2666/debbah2/wmloc_unet/run_unet_more_devel.sh
#   scontrol show job <id> | grep Reservation      # must be empty
# 8 new encoder families for the "stack" U-Net (train_unet_more.py), 2 per GPU, most promising first.
# Each variant is collected (oof_all.npz / test_mean.npz) as soon as its 5 folds are done.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
A=(effv2m_hp_glob_stack regy040_hp_glob_stack hrw18_hp_glob_stack effb4_hp_glob_stack)
B=(r2n50_hp_glob_stack serx50_hp_glob_stack regzd8_hp_glob_stack rx50_hp_glob_stack)
for k in 0 1 2 3; do
  ( for v in ${A[$k]} ${B[$k]}; do
      CUDA_VISIBLE_DEVICES=$k OMP_NUM_THREADS=8 $PY train_unet_more.py --variant $v --epochs 60 &&
      $PY train_unet_more.py --collect $v
    done ) 2>&1 | grep --line-buffered -v -i -E "warn|Unexpected keys" | sed -u "s/^/[gpu$k] /" &
done
wait
echo done
