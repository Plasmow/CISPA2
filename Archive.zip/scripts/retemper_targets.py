"""Variant of a dz target file: keep the per-image true-class mass t (T=2) but re-temper the wrong-class shape:
rest <- rest^(1/tau) (normalised). tau>1 broader, tau<1 sharper. Writes output/targets/<out>.pt
Usage: python scripts/retemper_targets.py dz_b_m5s7 1.5 dz_b_m5s7_rt1.5"""
import sys
import torch, torch.nn.functional as F
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
src, tau, out = sys.argv[1], float(sys.argv[2]), sys.argv[3]
d = torch.load(ROOT / "output" / "targets" / f"{src}.pt")
q, y, t = d["q2"].double(), d["labels"], d["t"].double()
oh = F.one_hot(y, 100).double()
rest = q * (1 - oh); rest = rest / rest.sum(1, keepdim=True)
rest = rest.clamp_min(1e-30) ** (1 / tau); rest = rest * (1 - oh); rest = rest / rest.sum(1, keepdim=True)
q2 = rest * (1 - t[:, None]) + oh * t[:, None]
z1 = 2 * q2.clamp_min(1e-30).log(); z1 = z1 - z1.mean(1, keepdim=True)
l = -(F.log_softmax(z1, -1) * oh).sum(1)
ent = -(rest * rest.clamp_min(1e-30).log()).sum(1).mean()
st = dict(d["stats"]); st.update(rest_tau=tau, loss_mean=l.mean().item(), loss_std=l.std().item())
torch.save({"logits": z1.float(), "q2": q2.float(), "labels": y, "t": t.float(), "stats": st}, ROOT / "output" / "targets" / f"{out}.pt")
print(f"{out}: loss {l.mean():.2f}±{l.std():.2f}, rest entropy {ent:.2f}")
