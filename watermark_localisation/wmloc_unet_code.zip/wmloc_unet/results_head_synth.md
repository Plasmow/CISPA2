| method | head | AUC type T | AUC type F | mIoU (CV switch) | type T | type F |
|---|---|---|---|---|---|---|
| pixelseal | synthetic logistic | 0.864 | 0.812 | 0.5364 | 0.5299 | 0.5430 |
| pixelseal | synthetic conv | 0.893 | 0.826 | 0.5614 | 0.5748 | 0.5480 |
| pixelseal | **kept: conv** | | | **0.5614** | | |
| trustmark | synthetic logistic | 0.862 | 0.792 | 0.5188 | 0.5180 | 0.5197 |
| trustmark | synthetic conv | 0.895 | 0.832 | 0.5502 | 0.5654 | 0.5351 |
| trustmark | **kept: conv** | | | **0.5502** | | |
