"""Evaluate weight-space combinations of dz checkpoints with the local predicted-score model:
  soup  = mean of the given checkpoints' weights
  cand(lam) = orig + lam * (soup - orig)
Logs local stats + pred_<mu> (same fitted model as dz.py) to output/soups/<name>.jsonl; saves --save_best candidate.
Usage: python scripts/soup_eval.py --name S --ckpts a.pt,b.pt --lams 0.8,0.9,1.0,1.1 [--save_best]
"""
import argparse, glob, json, sys
from pathlib import Path
import numpy as np, torch, torch.nn.functional as F
import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True)
ap.add_argument("--ckpts", required=True)
ap.add_argument("--lams", default="1.0")
ap.add_argument("--save_best", action="store_true")
a = ap.parse_args()
OUT = C.ROOT / "output" / "soups"; OUT.mkdir(exist_ok=True)
RIDGE = [(5.0, 7.0), (6.0, 6.0), (6.5, 5.5), (7.0, 5.0)]

teacher, imgs = C.load_all()
ev = C.Evaluator(teacher, imgs); y = ev.labels; N = len(y)
oh = F.one_hot(y, 100).float()
g_tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
g12 = F.softmax(torch.cat([load_twins("0.625"), load_twins("0.625b")], 1).to(C.DEVICE) / 2, -1).mean(1)
zz = ev.t_clean.clone(); zz[torch.arange(N, device=C.DEVICE), y] = -1e4
g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3
HYP = {"blend": 0.5 * g_tw + 0.5 * g_tail, "blend12": 0.5 * g12 + 0.5 * g_tail, "tw12": g12, "tw4": g_tw}
klm = lambda g, lq: (g * (g.clamp_min(1e-12).log() - lq)).sum(1).mean().item()  # noqa: E731
lq_o = {"clean": F.log_softmax(ev.t_clean / 2, -1), "mild": F.log_softmax(ev.t_mild / 2, -1)}
Dn = {h: {v: klm(g, lq_o[v]) for v in lq_o} for h, g in HYP.items()}
lo = {v: F.cross_entropy(t, y, reduction="none") for v, t in (("clean", ev.t_clean), ("mild", ev.t_mild))}
LSo = {v: (lo[v].mean().item(), lo[v].std().item()) for v in lo}
# held-out drift sets (same as dz.py: last 1000 of each)
def load_imgs(pat):
    files = sorted(f for f in glob.glob(str(C.ROOT / pat)) if ".tmp" not in f)
    return torch.from_numpy(np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in files])[-1000:]).to(C.DEVICE)
def logits(m, u8):
    m.eval()
    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
        return torch.cat([m(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])
HO = {k: load_imgs(p) for k, p in (("tw875", "output/twins/s0.875_sh*.npz"), ("tw625", "output/twins/s0.625b_sh*.npz"))}
HOt = {k: logits(teacher, u) for k, u in HO.items()}

sd_o = {k: v.float() for k, v in teacher.state_dict().items()}
sds = [torch.load(C.ROOT / p, map_location=C.DEVICE, weights_only=True) for p in a.ckpts.split(",")]
soup = {k: sum(sd[k].float() for sd in sds) / len(sds) for k in sd_o}
model = C.tt.build_model().to(C.DEVICE)
best = (-1, None)
for lam in [float(v) for v in a.lams.split(",")]:
    model.load_state_dict({k: sd_o[k] + lam * (soup[k] - sd_o[k]) for k in sd_o})
    c, m, p = (ev.sets.logits(model, k) for k in ("clean", "mild", "proxy"))
    r = {"name": a.name, "lam": lam, "ckpts": a.ckpts}
    r.update({f"clean_{k}": v for k, v in C.forget_stats(c, y).items()})
    r.update({f"mild_{k}": v for k, v in C.forget_stats(m, y).items()})
    r["proxy_kl"] = C.kl_T(ev.t_proxy, p).mean().item()
    for k, u in HO.items():
        r[f"{k}_kl"] = C.kl_T(HOt[k], logits(model, u)).mean().item()
    sub = {"clean": c, "mild": m}
    for h, g in HYP.items():
        r[f"PS_{h}"] = float(np.mean([1 - np.clip(klm(g, F.log_softmax(sub[v] / 2, -1)) / Dn[h][v], 0, 1) for v in sub]))
    ls = {v: F.cross_entropy(sub[v], y, reduction="none") for v in sub}
    ls = {v: (ls[v].mean().item(), ls[v].std().item()) for v in ls}
    for mu, sdv in RIDGE:
        l_ = np.mean([1 - np.clip((abs(ls[v][0] - mu) + abs(ls[v][1] - sdv)) /
                                  (abs(LSo[v][0] - mu) + abs(LSo[v][1] - sdv)), 0, 1) for v in sub])
        r[f"LDS_{mu:g}"] = float(l_)
        r[f"pred_{mu:g}"] = float(l_ * r["PS_blend12"] / (1 + r["proxy_kl"]))
        r[f"pred2_{mu:g}"] = float(l_ * 0.5 * (r["PS_tw4"] + r["PS_tw12"]) / (1 + r["proxy_kl"]))
    with open(OUT / f"{a.name}.jsonl", "a") as f:
        f.write(json.dumps(r) + "\n")
    print(f"lam {lam:.2f}: clean {r['clean_loss_mean']:.2f}±{r['clean_loss_std']:.2f} mild {r['mild_loss_mean']:.2f}±"
          f"{r['mild_loss_std']:.2f} | pKL {r['proxy_kl']:.3f} t875 {r['tw875_kl']:.3f} t625 {r['tw625_kl']:.3f} | PS b/b12 "
          f"{r['PS_blend']:.3f}/{r['PS_blend12']:.3f} tw4/tw12 {r['PS_tw4']:.3f}/{r['PS_tw12']:.3f} | NEW pred2@7 {r['pred2_7']:.3f} @6.5 {r['pred2_6.5']:.3f} @6 {r['pred2_6']:.3f}",
          flush=True)
    if r["pred2_7"] > best[0]:
        best = (r["pred2_7"], lam)
if a.save_best:
    lam = best[1]
    model.load_state_dict({k: sd_o[k] + lam * (soup[k] - sd_o[k]) for k in sd_o})
    C.save_state_dict(model, OUT / f"{a.name}_lam{lam:g}.pt")
    print("saved", OUT / f"{a.name}_lam{lam:g}.pt")
