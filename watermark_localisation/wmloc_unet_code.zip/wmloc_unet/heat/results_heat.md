| method | config | mIoU | full=T | full=F |
|---|---|---|---|---|
| pixelseal | baseline: whole-image score only | **0.4482** | 0.4469 | 0.4496 |
| pixelseal | heat 96 gauss sf=0.167 | **0.4482** | 0.4469 | 0.4496 |
| pixelseal | heat 128 gauss sf=0.167 | **0.4481** | 0.4418 | 0.4545 |
| pixelseal | heat 192 gauss sf=0.167 | **0.4605** | 0.4542 | 0.4668 |
| pixelseal | heat 256 gauss sf=0.167 | **0.4645** | 0.4543 | 0.4747 |
| pixelseal | heat fused z-mean (96, 128, 192, 256) gauss sf=0.167 | **0.4604** | 0.4581 | 0.4627 |
| pixelseal | heat fused z-mean (128, 192, 256) gauss sf=0.167 | **0.4635** | 0.4573 | 0.4697 |
| pixelseal | heat fused z-mean (192, 256) gauss sf=0.167 | **0.4687** | 0.4613 | 0.4760 |
| pixelseal | heat 96 gauss sf=0.25 | **0.4482** | 0.4469 | 0.4496 |
| pixelseal | heat 128 gauss sf=0.25 | **0.4482** | 0.4427 | 0.4537 |
| pixelseal | heat 192 gauss sf=0.25 | **0.4621** | 0.4557 | 0.4685 |
| pixelseal | heat 256 gauss sf=0.25 | **0.4619** | 0.4524 | 0.4714 |
| pixelseal | heat fused z-mean (96, 128, 192, 256) gauss sf=0.25 | **0.4605** | 0.4568 | 0.4641 |
| pixelseal | heat fused z-mean (128, 192, 256) gauss sf=0.25 | **0.4622** | 0.4575 | 0.4669 |
| pixelseal | heat fused z-mean (192, 256) gauss sf=0.25 | **0.4681** | 0.4595 | 0.4767 |
| pixelseal | heat 96 gauss sf=0.5 | **0.4482** | 0.4468 | 0.4496 |
| pixelseal | heat 128 gauss sf=0.5 | **0.4479** | 0.4423 | 0.4534 |
| pixelseal | heat 192 gauss sf=0.5 | **0.4614** | 0.4530 | 0.4698 |
| pixelseal | heat 256 gauss sf=0.5 | **0.4603** | 0.4515 | 0.4690 |
| pixelseal | heat fused z-mean (96, 128, 192, 256) gauss sf=0.5 | **0.4563** | 0.4551 | 0.4575 |
| pixelseal | heat fused z-mean (128, 192, 256) gauss sf=0.5 | **0.4615** | 0.4577 | 0.4653 |
| pixelseal | heat fused z-mean (192, 256) gauss sf=0.5 | **0.4680** | 0.4567 | 0.4793 |
| pixelseal | heat 96 uniform | **0.4482** | 0.4468 | 0.4496 |
| pixelseal | heat 128 uniform | **0.4477** | 0.4422 | 0.4532 |
| pixelseal | heat 192 uniform | **0.4604** | 0.4523 | 0.4684 |
| pixelseal | heat 256 uniform | **0.4552** | 0.4499 | 0.4606 |
| pixelseal | heat fused z-mean (96, 128, 192, 256) uniform | **0.4561** | 0.4547 | 0.4576 |
| pixelseal | heat fused z-mean (128, 192, 256) uniform | **0.4608** | 0.4558 | 0.4658 |
| pixelseal | heat fused z-mean (192, 256) uniform | **0.4662** | 0.4569 | 0.4756 |
| pixelseal | HEAD alone (16x16) | **0.5325** | 0.5323 | 0.5327 |
| pixelseal | HEAD + heat (early: heat channels in the head) | **0.5346** | 0.5340 | 0.5352 |
| pixelseal | HEAD + heat (late: logistic on head + heat + g) | **0.5247** | 0.5176 | 0.5319 |
| trustmark | baseline: whole-image score only | **0.4481** | 0.4487 | 0.4475 |
| trustmark | heat 96 gauss sf=0.167 | **0.4541** | 0.4496 | 0.4585 |
| trustmark | heat 128 gauss sf=0.167 | **0.4566** | 0.4501 | 0.4631 |
| trustmark | heat 192 gauss sf=0.167 | **0.4560** | 0.4502 | 0.4618 |
| trustmark | heat 256 gauss sf=0.167 | **0.4545** | 0.4461 | 0.4630 |
| trustmark | heat fused z-mean (96, 128, 192, 256) gauss sf=0.167 | **0.4560** | 0.4451 | 0.4669 |
| trustmark | heat fused z-mean (128, 192, 256) gauss sf=0.167 | **0.4584** | 0.4445 | 0.4724 |
| trustmark | heat fused z-mean (192, 256) gauss sf=0.167 | **0.4542** | 0.4429 | 0.4655 |
| trustmark | heat 96 gauss sf=0.25 | **0.4544** | 0.4497 | 0.4591 |
| trustmark | heat 128 gauss sf=0.25 | **0.4579** | 0.4499 | 0.4658 |
| trustmark | heat 192 gauss sf=0.25 | **0.4576** | 0.4502 | 0.4650 |
| trustmark | heat 256 gauss sf=0.25 | **0.4539** | 0.4466 | 0.4612 |
| trustmark | heat fused z-mean (96, 128, 192, 256) gauss sf=0.25 | **0.4561** | 0.4439 | 0.4684 |
| trustmark | heat fused z-mean (128, 192, 256) gauss sf=0.25 | **0.4568** | 0.4431 | 0.4705 |
| trustmark | heat fused z-mean (192, 256) gauss sf=0.25 | **0.4559** | 0.4402 | 0.4716 |
| trustmark | heat 96 gauss sf=0.5 | **0.4537** | 0.4500 | 0.4574 |
| trustmark | heat 128 gauss sf=0.5 | **0.4569** | 0.4498 | 0.4639 |
| trustmark | heat 192 gauss sf=0.5 | **0.4590** | 0.4502 | 0.4677 |
| trustmark | heat 256 gauss sf=0.5 | **0.4531** | 0.4435 | 0.4627 |
| trustmark | heat fused z-mean (96, 128, 192, 256) gauss sf=0.5 | **0.4554** | 0.4432 | 0.4677 |
| trustmark | heat fused z-mean (128, 192, 256) gauss sf=0.5 | **0.4548** | 0.4434 | 0.4662 |
| trustmark | heat fused z-mean (192, 256) gauss sf=0.5 | **0.4564** | 0.4401 | 0.4726 |
| trustmark | heat 96 uniform | **0.4538** | 0.4501 | 0.4575 |
| trustmark | heat 128 uniform | **0.4551** | 0.4498 | 0.4605 |
| trustmark | heat 192 uniform | **0.4592** | 0.4499 | 0.4685 |
| trustmark | heat 256 uniform | **0.4523** | 0.4456 | 0.4591 |
| trustmark | heat fused z-mean (96, 128, 192, 256) uniform | **0.4539** | 0.4439 | 0.4639 |
| trustmark | heat fused z-mean (128, 192, 256) uniform | **0.4570** | 0.4430 | 0.4709 |
| trustmark | heat fused z-mean (192, 256) uniform | **0.4545** | 0.4400 | 0.4690 |
| trustmark | HEAD alone (31x31) | **0.5156** | 0.5208 | 0.5104 |
| trustmark | HEAD + heat (early: heat channels in the head) | **0.5178** | 0.5231 | 0.5126 |
| trustmark | HEAD + heat (late: logistic on head + heat + g) | **0.5079** | 0.5102 | 0.5055 |
| stegastamp | baseline: whole-image score only | **0.4574** | 0.4554 | 0.4594 |
| stegastamp | heat 96 gauss sf=0.167 | **0.4840** | 0.4920 | 0.4760 |
| stegastamp | heat 128 gauss sf=0.167 | **0.4893** | 0.4944 | 0.4843 |
| stegastamp | heat 192 gauss sf=0.167 | **0.4786** | 0.4815 | 0.4757 |
| stegastamp | heat 256 gauss sf=0.167 | **0.4690** | 0.4767 | 0.4613 |
| stegastamp | heat fused z-mean (96, 128, 192, 256) gauss sf=0.167 | **0.4902** | 0.4935 | 0.4869 |
| stegastamp | heat fused z-mean (128, 192, 256) gauss sf=0.167 | **0.4842** | 0.4858 | 0.4826 |
| stegastamp | heat fused z-mean (192, 256) gauss sf=0.167 | **0.4762** | 0.4790 | 0.4734 |
| stegastamp | heat 96 gauss sf=0.25 | **0.4853** | 0.4939 | 0.4766 |
| stegastamp | heat 128 gauss sf=0.25 | **0.4892** | 0.4930 | 0.4853 |
| stegastamp | heat 192 gauss sf=0.25 | **0.4814** | 0.4863 | 0.4765 |
| stegastamp | heat 256 gauss sf=0.25 | **0.4704** | 0.4778 | 0.4630 |
| stegastamp | heat fused z-mean (96, 128, 192, 256) gauss sf=0.25 | **0.4863** | 0.4881 | 0.4844 |
| stegastamp | heat fused z-mean (128, 192, 256) gauss sf=0.25 | **0.4820** | 0.4826 | 0.4814 |
| stegastamp | heat fused z-mean (192, 256) gauss sf=0.25 | **0.4728** | 0.4746 | 0.4711 |
| stegastamp | heat 96 gauss sf=0.5 | **0.4863** | 0.4953 | 0.4773 |
| stegastamp | heat 128 gauss sf=0.5 | **0.4876** | 0.4919 | 0.4833 |
| stegastamp | heat 192 gauss sf=0.5 | **0.4762** | 0.4779 | 0.4746 |
| stegastamp | heat 256 gauss sf=0.5 | **0.4663** | 0.4706 | 0.4621 |
| stegastamp | heat fused z-mean (96, 128, 192, 256) gauss sf=0.5 | **0.4857** | 0.4889 | 0.4825 |
| stegastamp | heat fused z-mean (128, 192, 256) gauss sf=0.5 | **0.4814** | 0.4861 | 0.4766 |
| stegastamp | heat fused z-mean (192, 256) gauss sf=0.5 | **0.4717** | 0.4792 | 0.4642 |
| stegastamp | heat 96 uniform | **0.4862** | 0.4954 | 0.4769 |
| stegastamp | heat 128 uniform | **0.4852** | 0.4887 | 0.4818 |
| stegastamp | heat 192 uniform | **0.4738** | 0.4765 | 0.4711 |
| stegastamp | heat 256 uniform | **0.4648** | 0.4680 | 0.4615 |
| stegastamp | heat fused z-mean (96, 128, 192, 256) uniform | **0.4838** | 0.4873 | 0.4803 |
| stegastamp | heat fused z-mean (128, 192, 256) uniform | **0.4784** | 0.4816 | 0.4752 |
| stegastamp | heat fused z-mean (192, 256) uniform | **0.4716** | 0.4809 | 0.4623 |
| stegastamp | heat + g (logistic per cell) | **0.4747** | 0.4663 | 0.4832 |
