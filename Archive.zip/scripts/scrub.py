"""SCRUB+R (Kurmanji et al., NeurIPS 2023) adapted to the no-retain-data setting.

Teacher = frozen original model, student = copy being unlearned.
  max-step : maximise KL(teacher || student) on augmented forget images         (push away from the original)
  min-step : minimise alpha * KL(teacher || student) on proxy-retain inputs       (stay close to the original)
             (+ gamma * CE w.r.t. teacher argmax on the proxy inputs, 0 by default since mixups are ambiguous)
The first `msteps` epochs interleave max- and min-steps, the remaining epochs only do min-steps (as in the paper).
"R" = rewinding: we save checkpoints along the trajectory and choose among them afterwards (by leaderboard score,
since we have no validation set), using the logged local metrics as a guide.

Usage (from unlearning/):  python scripts/scrub.py --run scrub_v1 [--lr 1e-5 --epochs 6 --msteps 3 ...]
"""
import argparse
import copy
import json
import time

import torch
import torch.nn.functional as F

import common as C


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--lr", type=float, default=1e-5)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--msteps", type=int, default=3, help="epochs with max-steps")
    ap.add_argument("--bs_f", type=int, default=64, help="forget batch size")
    ap.add_argument("--bs_r", type=int, default=128, help="proxy-retain batch size")
    ap.add_argument("--min_per_max", type=int, default=2, help="min-steps per max-step")
    ap.add_argument("--kd_T", type=float, default=4.0, help="distillation temperature (paper uses 4)")
    ap.add_argument("--alpha", type=float, default=1.0)
    ap.add_argument("--gamma", type=float, default=0.0)
    ap.add_argument("--max_w", type=float, default=1.0, help="weight of the max-step loss")
    ap.add_argument("--train_from_block", type=int, default=0, help="freeze patch embed + blocks below this")
    ap.add_argument("--eval_every", type=int, default=20, help="evaluate + checkpoint every N max/min iterations")
    ap.add_argument("--save", type=int, default=1)
    ap.add_argument("--fine_from", type=int, default=-1, help="also evaluate/save every --fine_every steps from here...")
    ap.add_argument("--fine_to", type=int, default=-1, help="...up to here (inclusive)")
    ap.add_argument("--fine_every", type=int, default=4)
    ap.add_argument("--save_min", type=int, default=0, help="only save checkpoints with step >= this")
    ap.add_argument("--save_max", type=int, default=10**9, help="only save checkpoints with step <= this")
    ap.add_argument("--cap", type=float, default=0.0,
                    help="per-image cap on the max-step KL (T^2-scaled, same units as kl_forget_train); 0 = off")
    ap.add_argument("--cap_mode", default="sample", choices=["sample", "batch"],
                    help="sample: cap each image's KL; batch: stop the push once the batch-mean KL passes the cap")
    ap.add_argument("--target", default="", help="A1 soft-target file; adds lam * CE(q, student) to the max step")
    ap.add_argument("--agg", default="mean", help="which probs_<agg> of the target file to use")
    ap.add_argument("--lam", type=float, default=0.0, help="weight of the soft-target term in the max step")
    ap.add_argument("--outside", default="", help="npz of outside images (key 'images') used as extra retain anchors "
                                                  "in the min step, e.g. output/outside_task1/images_224.npz")
    ap.add_argument("--outside_minconf", type=float, default=0.9, help="keep outside images with teacher maxp > this")
    ap.add_argument("--outside_n", type=int, default=0, help="outside images ADDED to each min-step batch (on top of bs_r)")
    ap.add_argument("--seed", type=int, default=0)
    return ap.parse_args()


def kd_loss(t_logits, s_logits, T):
    """KL(teacher || student) at temperature T, scaled by T^2 (standard KD)."""
    return F.kl_div(F.log_softmax(s_logits / T, -1), F.log_softmax(t_logits / T, -1),
                    reduction="batchmean", log_target=True) * T * T


def kd_per_sample(t_logits, s_logits, T):
    """Per-image KL(teacher || student) at temperature T, scaled by T^2."""
    lt = F.log_softmax(t_logits / T, -1)
    return (lt.exp() * (lt - F.log_softmax(s_logits / T, -1))).sum(1) * T * T


def main():
    a = parse()
    torch.manual_seed(a.seed)
    out = C.ROOT / "output" / a.run
    out.mkdir(parents=True, exist_ok=True)
    (out / "args.json").write_text(json.dumps(vars(a), indent=1))
    log = out / "log.jsonl"
    log.unlink(missing_ok=True)

    teacher, imgs = C.load_all()
    for p in teacher.parameters():
        p.requires_grad_(False)
    student = copy.deepcopy(teacher)
    ev = C.Evaluator(teacher, imgs)
    N = len(imgs)
    q = None
    if a.target and a.lam > 0:
        q = torch.load(a.target, map_location="cpu")[f"probs_{a.agg}"].to(C.DEVICE).clamp_min(1e-8)
        q = q / q.sum(1, keepdim=True)

    out_u8 = out_t = None
    if a.outside and a.outside_n > 0:
        import numpy as np
        ou = torch.from_numpy(np.load(C.ROOT / a.outside)["images"]).to(C.DEVICE)
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            tl_o = torch.cat([teacher(C.norm(C.u8_to01(ou[i:i + 128]))).float() for i in range(0, len(ou), 128)])
        conf, lab = tl_o.softmax(1).max(1)
        keep = (conf > a.outside_minconf).nonzero()[:, 0]
        out_u8, out_t = ou[keep], tl_o[keep]
        print(f"outside anchors: {len(keep)}/{len(ou)} with maxp>{a.outside_minconf} covering "
              f"{lab[keep].unique().numel()} classes, {a.outside_n} added per min-step batch", flush=True)

    @torch.no_grad()
    def outside_drift():
        """KL(orig || student) at T=2 and argmax agreement on the (clean) outside anchors."""
        if out_u8 is None:
            return {}
        student.eval()
        with torch.autocast(device_type="cuda", dtype=torch.float16):
            s = torch.cat([student(C.norm(C.u8_to01(out_u8[i:i + 128]))).float() for i in range(0, len(out_u8), 128)])
        lt, ls = F.log_softmax(out_t / 2, -1), F.log_softmax(s / 2, -1)
        return {"out_kl": round((lt.exp() * (lt - ls)).sum(1).mean().item(), 4),
                "out_agree": round((s.argmax(1) == out_t.argmax(1)).float().mean().item(), 4)}

    # trainable parameters
    params = []
    for n, p in student.named_parameters():
        trainable = True
        if a.train_from_block > 0:
            if n.startswith(("patch_embed", "cls_token", "pos_embed")):
                trainable = False
            elif n.startswith("blocks."):
                trainable = int(n.split(".")[1]) >= a.train_from_block
        p.requires_grad_(trainable)
        if trainable:
            params.append(p)
    print(f"trainable params: {sum(p.numel() for p in params) / 1e6:.1f}M", flush=True)
    opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
    g = torch.Generator(device=C.DEVICE).manual_seed(a.seed)

    def evaluate(step, epoch, extra):
        r = ev(student)
        r.update(outside_drift())
        r.update(step=step, epoch=epoch, t=round(time.time() - t0, 1), **extra)
        C.log_jsonl(log, r)
        print(f"[{step:5d} ep{epoch}] clean acc {r['clean_acc']:.3f} loss {r['clean_loss_mean']:.3f}±{r['clean_loss_std']:.3f} "
              f"| mild acc {r['mild_acc']:.3f} loss {r['mild_loss_mean']:.3f}±{r['mild_loss_std']:.3f} "
              f"| proxy KL {r['proxy_kl']:.4f} agree {r['proxy_agree']:.3f} | wrong=top2 {r['wrong_is_teacher_top2']:.2f}"
              + (f" | out KL {r['out_kl']:.4f} agree {r['out_agree']:.3f}" if "out_kl" in r else "")
              + f" | {extra}", flush=True)
        if a.save and a.save_min <= step <= a.save_max:
            C.save_state_dict(student, out / f"ckpt_{step:05d}.pt")
        student.train()

    t0 = time.time()
    step = 0
    evaluate(step, 0, {})
    iters_per_epoch = N // a.bs_f
    for epoch in range(a.epochs):
        student.train()
        perm = torch.randperm(N, generator=g, device=C.DEVICE)
        do_max = epoch < a.msteps
        lmax = lmin = 0.0
        for it in range(iters_per_epoch):
            # ---- max step on forget
            if do_max:
                idx = perm[it * a.bs_f:(it + 1) * a.bs_f]
                x = C.norm(C.augment(C.u8_to01(imgs[idx]), g))
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    with torch.no_grad():
                        tl = teacher(x).float()
                    sl = student(x).float()
                kl_i = kd_per_sample(tl, sl, a.kd_T)
                lmax_raw = kl_i.mean()
                if a.cap > 0 and a.cap_mode == "sample":
                    kl_i = kl_i.clamp(max=a.cap)          # images past the cap get no more push
                kl_m = kl_i.mean()
                if a.cap > 0 and a.cap_mode == "batch":
                    kl_m = kl_m.clamp(max=a.cap)          # whole batch past the cap gets no more push
                loss = -a.max_w * kl_m
                if q is not None:
                    loss = loss - (a.lam * (q[idx] * F.log_softmax(sl, -1)).sum(1).mean())  # + lam * CE(q, student)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                opt.step()
                lmax = lmax_raw.item()
            # ---- min steps on proxy retain
            for _ in range(a.min_per_max):
                ia = torch.randint(0, N, (a.bs_r,), generator=g, device=C.DEVICE)
                ib = torch.randint(0, N, (a.bs_r,), generator=g, device=C.DEVICE)
                x = C.mix_proxy(C.augment(C.u8_to01(imgs[ia]), g), C.augment(C.u8_to01(imgs[ib]), g), g)
                if out_u8 is not None:  # extra retain anchors: real images of (mostly) non-forget content
                    io_ = torch.randint(0, len(out_u8), (a.outside_n,), generator=g, device=C.DEVICE)
                    x = torch.cat([x, C.augment(C.u8_to01(out_u8[io_]), g, scale=(0.7, 1.0), noise=0.02)])
                x = C.norm(x)
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    with torch.no_grad():
                        tl = teacher(x).float()
                    sl = student(x).float()
                loss = a.alpha * kd_loss(tl, sl, a.kd_T)
                if a.gamma > 0:
                    loss = loss + a.gamma * F.cross_entropy(sl, tl.argmax(1))
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(params, 1.0)
                opt.step()
                lmin = loss.item()
            step += 1
            fine = a.fine_from <= step <= a.fine_to and (step - a.fine_from) % a.fine_every == 0
            if step % a.eval_every == 0 or fine:
                evaluate(step, epoch, {"kl_forget_train": round(lmax, 4), "kl_proxy_train": round(lmin, 4)})
    if step % a.eval_every != 0:
        evaluate(step, a.epochs - 1, {})
    print(f"done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
