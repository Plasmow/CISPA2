| VAE | variante | méthode | AUC T (médiane) | AUC F (médiane) | AUC T v12a seul | AUC T logistique [v12a, VAE] (CV 2 plis) | gain T |
|---|---|---|---|---|---|---|---|
| sd-mse | v1 | pixelseal | 0.559 | 0.567 | 0.925 | 0.920 | -0.005 |
| sd-mse | v2 | pixelseal | 0.558 | 0.534 | 0.925 | 0.924 | -0.006 |
| sd-mse | v1 | trustmark | 0.486 | 0.572 | 0.919 | 0.917 | -0.008 |
| sd-mse | v2 | trustmark | 0.505 | 0.563 | 0.919 | 0.918 | -0.004 |
| sd-mse | v1 | stegastamp | 0.627 | 0.650 | 0.989 | 0.989 | -0.001 |
| sd-mse | v2 | stegastamp | 0.660 | 0.692 | 0.989 | 0.989 | -0.001 |
| sdxl | v1 | pixelseal | 0.538 | 0.558 | 0.925 | 0.923 | -0.006 |
| sdxl | v2 | pixelseal | 0.549 | 0.531 | 0.925 | 0.922 | -0.007 |
| sdxl | v1 | trustmark | 0.479 | 0.585 | 0.919 | 0.918 | -0.005 |
| sdxl | v2 | trustmark | 0.508 | 0.569 | 0.919 | 0.918 | -0.004 |
| sdxl | v1 | stegastamp | 0.610 | 0.630 | 0.989 | 0.989 | -0.001 |
| sdxl | v2 | stegastamp | 0.668 | 0.679 | 0.989 | 0.989 | -0.001 |
