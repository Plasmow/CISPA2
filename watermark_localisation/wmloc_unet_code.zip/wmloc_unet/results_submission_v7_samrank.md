| images | n | base (version) | snap_sam (CV) | learned choice (CV) | oracle | kept base |
|---|---|---|---|---|---|---|
| all | 192 | 0.6246 | 0.6887 | **0.6786** | 0.8099 | 19% |
| pixelseal | 65 | 0.6096 | 0.6626 | **0.6659** | 0.7868 | 8% |
| trustmark | 55 | 0.6039 | 0.6899 | **0.6743** | 0.8455 | 9% |
| stegastamp | 72 | 0.6540 | 0.7114 | **0.6934** | 0.8036 | 38% |

Effect on the whole train score: snap_sam +0.0241, learned +0.0203

CV per method: snap_sam {'pixelseal': 0.6714, 'trustmark': 0.7027, 'stegastamp': 0.7458} (mean 0.7066) | learned {'pixelseal': 0.6726, 'trustmark': 0.6977, 'stegastamp': 0.7382} (mean 0.7028)
