| images | n | base (version) | snap_sam (CV) | learned choice (CV) | oracle | kept base |
|---|---|---|---|---|---|---|
| all | 192 | 0.6246 | 0.6887 | **0.6852** | 0.7412 | 27% |
| pixelseal | 65 | 0.6096 | 0.6626 | **0.6704** | 0.7291 | 29% |
| trustmark | 55 | 0.6039 | 0.6899 | **0.6734** | 0.7340 | 20% |
| stegastamp | 72 | 0.6540 | 0.7114 | **0.7075** | 0.7576 | 31% |

Effect on the whole train score: snap_sam +0.0241, learned +0.0228

CV per method: snap_sam {'pixelseal': 0.6714, 'trustmark': 0.7027, 'stegastamp': 0.7458} (mean 0.7066) | learned {'pixelseal': 0.6743, 'trustmark': 0.6974, 'stegastamp': 0.7442} (mean 0.7053)
