"""Assemble the stacked 128x128 input maps for the combined U-Net, in metadata order of each split:
  ch0 head      : learned head logit (train out-of-fold, test = mean of fold heads); 0 for StegaStamp
  ch1 perpos    : detector per-position signed confidence (8x8 -> 128 bilinear); 0 for StegaStamp
  ch2 heat      : sliding-window heatmap, per-scale z-score then mean (gauss sf=1/6), best scale set per method
Output: stack/maps/stack_<split>.npz  names, aux [N,3,128,128] float16."""
import sys
from pathlib import Path

import numpy as np

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "heat"))
from common import load_split, CACHE  # noqa: E402
from evalkit import to128  # noqa: E402
from heatmap import aggregate, zscore  # noqa: E402

HERE = Path(__file__).resolve().parent; HEAT = HERE.parent / "heat" / "cache"
COMBO = {"pixelseal": (192, 256), "trustmark": (128, 192, 256), "stegastamp": (96, 128, 192, 256)}   # from eval_heat


def main():
    for split in ("train", "test"):
        ds = load_split(split); names = [m["image_name"] for m in ds.meta]; pos = {n: i for i, n in enumerate(names)}
        aux = np.zeros((len(names), 3, 128, 128), np.float32)
        for meth in ("pixelseal", "trustmark", "stegastamp"):
            sub = [m for m in ds.meta if m["method"] == meth]; nn = [m["image_name"] for m in sub]; ii = [pos[n] for n in nn]
            if meth != "stegastamp":
                h = np.load(HERE / "maps" / f"head_{split}_{meth}.npz"); assert h["names"].tolist() == nn
                aux[ii, 0] = h["logit128"].astype(np.float32)
                d = np.load(CACHE / f"perpos_{meth}_{split}.npz"); assert d["names"].tolist() == nn
                sgn = np.array([[int(c) for c in m["message"]] for m in sub], np.float32) * 2 - 1
                aux[ii, 1] = to128((d["pp"].astype(np.float32) * sgn[:, :, None, None]).mean(1))
            z = np.load(HEAT / f"scores_{split}_{meth}.npz"); assert z["names"].tolist() == nn
            aux[ii, 2] = np.stack([np.mean([zscore(aggregate({w: z[f"s{w}"][j]}, 1 / 6)[w]) for w in COMBO[meth]], 0)
                                   for j in range(len(nn))])
            print(split, meth, "done", flush=True)
        np.savez(HERE / "maps" / f"stack_{split}.npz", names=np.array(names), aux=aux.astype(np.float16))
        print("wrote", split, aux.shape, "channel means", aux.mean((0, 2, 3)).round(3), flush=True)


if __name__ == "__main__":
    main()
