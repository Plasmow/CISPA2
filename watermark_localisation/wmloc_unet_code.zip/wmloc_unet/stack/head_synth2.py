"""Synthetic-trained conv heads, round 2 (CPU only): more samples, more epochs (cosine LR), and StegaStamp too.

Same idea as head_synth.py (heads on frozen decoder layers, trained only on realistic synthetic edits, evaluated on the
real train images they never saw), with:
  PixelSeal : 16x16 [stage1 (pooled), stage2, per-position confidence, g, position]       8000 samples
  TrustMark : 31x31 [layer2, layer3 (upsampled), per-position confidence, g, position]     3000 samples
  StegaStamp: 25x25 [conv6, conv7 (upsampled), feature-space occlusion, g, position]       6000 samples
Output: stack/maps/headsyn2_{train,test}_<method>.npz  (extra source for the fusion, see v3.py).

    python head_synth2.py --methods pixelseal stegastamp trustmark
"""
import argparse
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import onnxruntime as ort
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]; HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(ROOT / "synth")); sys.path.insert(0, str(TASK / "loc"))
from common import load_watermark, load_split, KIT, auc  # noqa: E402
from evalkit import to128, cv_eval  # noqa: E402
from heads import soft_labels  # noqa: E402
from head_multi import layers, build, info  # noqa: E402
from head_synth import _gen, decoder_layers, ConvHead, predict_conv  # noqa: E402
from head_stega import dense_weights, MODEL, OUTS, g_of  # noqa: E402

torch.set_num_threads(32)
CFG = {"pixelseal": (16, ["s1", "s2", "conf"], 8000), "trustmark": (31, ["l2", "l3", "conf"], 3000),
       "stegastamp": (25, ["c6", "c7", "occ"], 6000)}


def stega_layers(imgs, msgs, bs=32):
    so = ort.SessionOptions(); so.intra_op_num_threads = 32
    sess = ort.InferenceSession(str(MODEL), so, providers=["CPUExecutionProvider"]); (W1, b1), (W2, b2) = dense_weights()
    c6, c7, occ, g = [], [], [], []
    for b in range(0, len(imgs), bs):
        x = torch.from_numpy(imgs[b:b + bs]).permute(0, 3, 1, 2).float() / 255
        x = F.interpolate(x, size=(400, 400), mode="bicubic", align_corners=False, antialias=True).clamp(0, 1)
        r = sess.run(OUTS, {"image": x.permute(0, 2, 3, 1).numpy(), "secret": np.zeros((len(x), 100), np.float32)})
        f7 = r[2]; sg = msgs[b:b + bs] * 2 - 1
        contrib = np.einsum("bchw,hwcj->bhwj", f7, W1.reshape(13, 13, 128, -1)); pre = contrib.sum((1, 2)) + b1
        base = ((np.maximum(pre, 0) @ W2 + b2) * sg).mean(1)
        drop = base[:, None, None] - ((np.maximum(pre[:, None, None] - contrib, 0) @ W2 + b2) * sg[:, None, None]).mean(-1)
        c6.append(r[1].astype(np.float16)); c7.append(f7.astype(np.float16)); occ.append(drop[:, None].astype(np.float32)); g.append((r[3] * sg).mean(1))
    return {"c6": np.concatenate(c6), "c7": np.concatenate(c7), "occ": np.concatenate(occ)}, np.concatenate(g)


def real_inputs(meth, keys, hw):
    if meth != "stegastamp":
        ds, names, msg, g = info(meth, "train"); _, tnames, tmsg, tg = info(meth, "test")
        return ds, names, g, build(layers(meth, "train", names, msg), keys, hw, g), build(layers(meth, "test", tnames, tmsg), keys, hw, tg), tnames
    out = []
    for split in ("train", "test"):
        z = np.load(HERE / "maps" / f"stega_feats_{split}.npz"); names = z["names"].tolist(); g = g_of(split, names, load_split(split, ["stegastamp"]))
        out.append((names, g, build({"c6": z["c6"], "c7": z["c7"], "occ": z["occ"][:, None]}, keys, hw, g)))
    return load_split("train", ["stegastamp"]), out[0][0], out[0][1], out[0][2], out[1][2], out[1][0]


def train_conv(X, Y, hw, epochs, bs=32):
    N, _, D = X.shape; Xt = torch.from_numpy(X).view(N, hw, hw, D).permute(0, 3, 1, 2); Yt = torch.from_numpy(Y).view(N, hw, hw)
    torch.manual_seed(0); m = ConvHead(D); opt = torch.optim.Adam(m.parameters(), 1e-3, weight_decay=1e-4)
    steps = epochs * int(np.ceil(N / bs)); sched = torch.optim.lr_scheduler.OneCycleLR(opt, 2e-3, total_steps=steps, pct_start=0.1)
    for ep in range(epochs):
        perm = torch.randperm(N); tot = 0
        for b in range(0, N, bs):
            i = perm[b:b + bs]; loss = F.binary_cross_entropy_with_logits(m(Xt[i]), Yt[i])
            opt.zero_grad(); loss.backward(); opt.step(); sched.step(); tot += loss.item() * len(i)
        print(f"    epoch {ep + 1}/{epochs}: loss {tot / N:.4f}", flush=True)
    return m


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--methods", nargs="+", default=list(CFG)); ap.add_argument("--epochs", type=int, default=12)
    a = ap.parse_args(); lines = []
    for meth in a.methods:
        hw, keys, n_syn = CFG[meth]; t = time.time()
        with Pool(24) as pool:
            chunks = pool.map(_gen, [(meth, 5000 + k, n_syn // 24 + 1) for k in range(24)])
        S = [s for c in chunks for s in c][:n_syn]
        imgs = np.stack([s[0] for s in S]); gts = np.stack([s[1] for s in S]); msgs = np.stack([s[2] for s in S]); del S, chunks
        print(f"{meth}: {len(imgs)} synthetic samples in {time.time() - t:.0f}s", flush=True); t = time.time()
        if meth == "stegastamp":
            Ls, gs = stega_layers(imgs, msgs)
        else:
            Ls, gs = decoder_layers(load_watermark(meth, KIT / "models", "cpu"), meth, imgs, msgs)
        del imgs; print(f"{meth}: decoder layers in {time.time() - t:.0f}s", flush=True)
        Xs = build(Ls, keys, hw, gs); del Ls; Ys = soft_labels(gts, (hw, hw)).reshape(len(gts), -1).astype(np.float32)
        ds, names, g, Xr, Xt, tnames = real_inputs(meth, keys, hw)
        gt = np.stack([ds.m128[n] for n in names]).astype(bool); full = np.array([ds.meta[i]["full_watermark"] for i in range(len(ds.meta))])
        assert [m["image_name"] for m in ds.meta] == names
        D = Xs.shape[-1]; mu = Xs.reshape(-1, D).mean(0); sd = Xs.reshape(-1, D).std(0) + 1e-4
        st = lambda X: ((X - mu) / sd).astype(np.float32)  # noqa: E731
        conv = train_conv(st(Xs), Ys, hw, a.epochs); del Xs
        o = to128(predict_conv(conv, st(Xr), hw)); te = to128(predict_conv(conv, st(Xt), hw))
        s = cv_eval(o, gt, g, "switch", seed=1)
        lines.append(f"| {meth} | synthetic conv, {n_syn} samples, {a.epochs} epochs | {auc(o[full], gt[full]):.3f} | {auc(o[~full], gt[~full]):.3f} | "
                     f"{s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |"); print(lines[-1], flush=True)
        np.savez(HERE / "maps" / f"headsyn2_train_{meth}.npz", names=np.array(names), logit128=o.astype(np.float16))
        np.savez(HERE / "maps" / f"headsyn2_test_{meth}.npz", names=np.array(tnames), logit128=te.astype(np.float16))
        torch.save(conv.state_dict(), HERE / "maps" / f"headsyn2_{meth}.pt")
    hdr = ["| method | head | AUC type T | AUC type F | mIoU (CV switch) | type T | type F |", "|---|---|---|---|---|---|---|"]
    with open(ROOT / "results_head_synth2.md", "a") as fh:
        fh.write("\n".join(hdr + lines) + "\n")


if __name__ == "__main__":
    main()
