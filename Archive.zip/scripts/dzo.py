"""[dzo 2026-11-22 10:20] + --reassign_every K: every K steps, re-sort the designed per-image true-class mass t
WITHIN each class so that images with the lowest current student margin get the smallest t (1-D optimal transport of
the fixed per-class target multiset). Loss distribution and expected PS (uniform gold) are unchanged; the model picks
the images that are cheapest to push into the heavy tail -> less drift.
DZMT = dzm.py + --t2i txt2img retain anchors (scripts/gen_t2i.py), drift metrics t2i_kl / t2iU_kl.
DZM = dzr.py + --mem: 'memorised-like' retain anchors (generated images on which orig shows a training-style margin,
gap>8: output/mem_anchors.npz) with a held-out memorised drift metric mem_kl (last --mem_ho images, never trained on).
DZR = dz.py + (#2) extra twin anchor sets (--twins2 comma list) for retain repair + (#4) altered-view targets
(--aug_mix: KL target of an augmented forget view mixes in the teacher on a same-augmented s0.625 twin; --mg_aug_w /
--aug_shift: margin term on augmented views, so their loss does not fall below the clean loss).

DZ: designed-target distillation (built from the leaderboard-fitted gold model, see lbfit*.py / design_targets.py).

forget (clean + augmented copies of each forget image i):
    kl_w * T^2 * KL(q2_i || softmax(s/2))          match gold's (soft, averaged) T=2 distribution
  + mg_w * huber(margin(s) - margin_t_i)            match the designed T=1 loss (heavy tail -> gold's loss mean/std)
    margin(z) = z_y - logsumexp_{j!=y} z_j  (T=1 loss = softplus(-margin))
retain: alpha * T^2 * KL(orig || student) at T=2 on anchors (task-1 outside images, s0.875 twins, forget mixups).

Every eval: local metrics + predicted leaderboard score under the fitted model (blend/tw/tail hypotheses, several
gold (mu, sigma) on the mu+sigma~12 ridge, retain = 1/(1+proxy_kl)).
Usage: python scripts/dz.py --run NAME --target output/targets/dz_X.pt [--lr 2e-4 --epochs 20]
"""
import argparse, copy, glob, json, sys, time
import numpy as np
import torch
import torch.nn.functional as F

import common as C
sys.path.insert(0, str(C.ROOT / "scripts"))
from lbfit_lib import load_twins  # noqa: E402

RIDGE = [(3.0, 9.0), (4.0, 8.0), (5.0, 7.0), (6.0, 6.0), (6.5, 5.5), (7.0, 5.0)]


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--target", required=True)
    ap.add_argument("--init", default="")
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--bs_f", type=int, default=64)
    ap.add_argument("--bs_r", type=int, default=128)
    ap.add_argument("--clean_frac", type=float, default=0.5)
    ap.add_argument("--kl_w", type=float, default=1.0)
    ap.add_argument("--mg_w", type=float, default=0.1)
    ap.add_argument("--alpha", type=float, default=1.0)
    ap.add_argument("--outside", default="output/outside_task1/images_224.npz")
    ap.add_argument("--outside_minconf", type=float, default=0.9)
    ap.add_argument("--outside_frac", type=float, default=0.4)
    ap.add_argument("--twins", default="output/twins/s0.875_sh*.npz")
    ap.add_argument("--twin_frac", type=float, default=0.4, help="rest of the retain batch = forget mixups")
    ap.add_argument("--twins2", default="", help="second anchor set, e.g. output/twins/s0.625b_sh*.npz (sub-population)")
    ap.add_argument("--twin2_frac", type=float, default=0.0)
    ap.add_argument("--mem", default="output/mem_anchors.npz")
    ap.add_argument("--t2i", default="output/t2i/t2i_sh*.npz")
    ap.add_argument("--t2i_frac", type=float, default=0.0)
    ap.add_argument("--t2i_ho", type=int, default=2000)
    ap.add_argument("--aug_extra", type=float, default=0.0, help="prob of each extra op (strong zoom, blur, saturation/gray, low-res) on augmented forget views")
    ap.add_argument("--mem_frac", type=float, default=0.0)
    ap.add_argument("--mem_ho", type=int, default=600)
    ap.add_argument("--holdout_tw2", default="output/twins/s0.625b_sh*.npz", help="drift metric set (last 1000 held out)")
    ap.add_argument("--train_from_block", type=int, default=0)
    ap.add_argument("--warmup", type=int, default=30)
    ap.add_argument("--eval_every", type=int, default=108)
    ap.add_argument("--save_from", type=int, default=0)
    ap.add_argument("--keep", type=int, default=4, help="keep the last K checkpoints (+ best predicted)")
    ap.add_argument("--amp", default="bf16", choices=["bf16", "fp16"])
    ap.add_argument("--max_steps", type=int, default=0, help="debug: stop after this many steps")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--aug_mix", type=float, default=0.0, help="#4: weight of teacher(same-aug twin) in aug-view KL target")
    ap.add_argument("--aug_twins", default="output/twins/s0.625_sh*.npz")
    ap.add_argument("--mg_aug_w", type=float, default=1.0, help="#4: margin-loss weight on augmented views (clean = 1)")
    ap.add_argument("--aug_shift", type=float, default=0.0, help="#4: lower the margin target of aug views by this")
    ap.add_argument("--reassign_every", type=int, default=0, help="re-sort t within class every K steps (0=off)")
    ap.add_argument("--l2sp", type=float, default=0.0, help="decoupled decay toward the ORIGINAL weights: p -= lr*l2sp*(p-p_orig)")
    return ap.parse_args()


def extra_aug(x, g, p):
    """Extra alteration families on [0,1] images: strong zoom (25-50% area crop), Gaussian blur, saturation/grayscale,
    low-res round trip (compression-like). Each applied independently with probability p."""
    B, dev = x.shape[0], x.device
    u = lambda *s_: torch.rand(*s_, generator=g, device=dev)  # noqa: E731
    x = x.clone()
    m = u(B) < p
    if m.any():
        x[m] = C.augment(x[m], g, scale=(0.25, 0.5), rot_deg=0.0, flip=False, bright=0, contrast=0, noise=0)
    m = u(B) < p
    if m.any():
        sig = 0.5 + u(1).item() * 1.5
        k = int(2 * round(3 * sig) + 1)
        ax = torch.arange(k, device=dev, dtype=x.dtype) - k // 2
        w = torch.exp(-ax ** 2 / (2 * sig ** 2)); w = w / w.sum()
        xm = F.conv2d(F.pad(x[m], (k // 2, k // 2, 0, 0), mode="reflect"), w.view(1, 1, 1, k).repeat(3, 1, 1, 1), groups=3)
        xm = F.conv2d(F.pad(xm, (0, 0, k // 2, k // 2), mode="reflect"), w.view(1, 1, k, 1).repeat(3, 1, 1, 1), groups=3)
        x[m] = xm.to(x.dtype)
    m = u(B) < p
    if m.any():
        xm = x[m]
        gray = (0.299 * xm[:, 0] + 0.587 * xm[:, 1] + 0.114 * xm[:, 2]).unsqueeze(1)
        x[m] = gray + (xm - gray) * (u(xm.shape[0], 1, 1, 1) * 1.5)
    m = u(B) < p
    if m.any():
        H = x.shape[-1]
        r = int(H * (0.35 + 0.4 * u(1).item()))
        x[m] = F.interpolate(F.interpolate(x[m], size=r, mode="bilinear", antialias=True, align_corners=False),
                             size=H, mode="bilinear", align_corners=False)
    return x.clamp(0, 1)


def margin(z, y):
    zy = z.gather(1, y[:, None])[:, 0]
    zo = z.scatter(1, y[:, None], float("-inf"))
    return zy - torch.logsumexp(zo, 1)


def main():
    a = parse()
    torch.manual_seed(a.seed)
    import os
    from pathlib import Path
    link = C.ROOT / "output" / a.run
    if os.environ.get("DZ_OUT"):  # scratch is at its (shared) inode limit: write elsewhere, symlink back
        out = Path(os.environ["DZ_OUT"]) / a.run
        out.mkdir(parents=True, exist_ok=True)
        if not link.exists():
            try:
                link.symlink_to(out)
            except OSError as e:
                print("symlink failed:", e, flush=True)
    else:
        out = link
        out.mkdir(parents=True, exist_ok=True)
    (out / "args.json").write_text(json.dumps(vars(a), indent=1))
    log = out / "log.jsonl"
    log.unlink(missing_ok=True)
    adt = torch.bfloat16 if a.amp == "bf16" else torch.float16

    teacher, imgs = C.load_all()
    for p in teacher.parameters():
        p.requires_grad_(False)
    student = copy.deepcopy(teacher)
    if a.init:
        student.load_state_dict(torch.load(a.init, map_location=C.DEVICE, weights_only=True), strict=True)
    ev = C.Evaluator(teacher, imgs)
    N = len(imgs)
    y = ev.labels

    tg = torch.load(C.ROOT / a.target, map_location="cpu")
    assert torch.equal(tg["labels"].to(C.DEVICE), y), "target labels != orig argmax"
    zt = tg["logits"].float().to(C.DEVICE)
    q2 = F.softmax(zt / 2, -1)
    mt = margin(zt, y)
    t_des = tg["t"].float().to(C.DEVICE)
    oh_ = F.one_hot(y, 100).float()
    rest_ = q2 * (1 - oh_); rest_ = rest_ / rest_.sum(1, keepdim=True)
    cls_idx = [(y == c).nonzero()[:, 0] for c in y.unique()]
    t_sorted_c = [t_des[ii].sort().values for ii in cls_idx]
    t_cur = t_des.clone()

    def set_targets(tv):
        qn = rest_ * (1 - tv[:, None]) + oh_ * tv[:, None]
        zn = 2 * qn.clamp_min(1e-30).log(); zn = zn - zn.mean(1, keepdim=True)
        q2.copy_(F.softmax(zn / 2, -1)); mt.copy_(margin(zn, y)); zt.copy_(zn)

    set_targets(t_cur)
    print(f"rebuilt targets from t: max |dq2| vs file {(F.softmax(zt / 2, -1) - F.softmax(tg['logits'].float().to(C.DEVICE) / 2, -1)).abs().max():.2e}", flush=True)

    def reassign(model, step):
        c_ = ev.sets.logits(model, "clean")
        m_ = margin(c_, y)
        tn = torch.empty_like(t_cur)
        for ii, ts in zip(cls_idx, t_sorted_c):
            tn[ii[m_[ii].argsort()]] = ts
        tail_old, tail_new = t_cur < 1e-3, tn < 1e-3
        ch = (tail_old != tail_new).float().sum().item() / max(1, int(tail_new.sum()))
        t_cur.copy_(tn); set_targets(t_cur)
        print(f"[reassign {step}] tail-set change {ch:.3f}  corr(t,new) n/a", flush=True)
        return ch
    print("target:", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in tg["stats"].items()}, flush=True)

    # ---- fitted leaderboard model pieces
    oh = F.one_hot(y, 100).float()
    g_tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
    zz = ev.t_clean.clone(); zz[torch.arange(N, device=C.DEVICE), y] = -1e4
    g_tail = F.softmax(zz / 2, -1) * 0.7 + oh * 0.3
    g12 = F.softmax(torch.cat([load_twins("0.625"), load_twins("0.625b")], 1).to(C.DEVICE) / 2, -1).mean(1)
    HYP = {"blend": 0.5 * g_tw + 0.5 * g_tail, "tw": g_tw, "tail": g_tail, "tw12": g12}

    def klm(g, lq):
        return (g * (g.clamp_min(1e-12).log() - lq)).sum(1).mean().item()

    lq_o = {"clean": F.log_softmax(ev.t_clean / 2, -1), "mild": F.log_softmax(ev.t_mild / 2, -1)}
    Dn = {h: {v: klm(g, lq_o[v]) for v in lq_o} for h, g in HYP.items()}
    lo = {v: F.cross_entropy(t, y, reduction="none") for v, t in (("clean", ev.t_clean), ("mild", ev.t_mild))}
    LSo = {v: (lo[v].mean().item(), lo[v].std().item()) for v in lo}

    def predicted(c_logits, m_logits, proxy_kl):
        sub = {"clean": c_logits, "mild": m_logits}
        r = {}
        for h, g in HYP.items():
            r[f"PS_{h}"] = float(np.mean([1 - np.clip(klm(g, F.log_softmax(sub[v] / 2, -1)) / Dn[h][v], 0, 1)
                                          for v in sub]))
        ls = {v: F.cross_entropy(sub[v], y, reduction="none") for v in sub}
        ls = {v: (ls[v].mean().item(), ls[v].std().item()) for v in ls}
        for mu, sd in RIDGE:
            l_ = np.mean([1 - np.clip((abs(ls[v][0] - mu) + abs(ls[v][1] - sd)) /
                                      (abs(LSo[v][0] - mu) + abs(LSo[v][1] - sd)), 0, 1) for v in sub])
            r[f"LDS_{mu:g}"] = float(l_)
            r[f"pred_{mu:g}"] = float(l_ * r["PS_blend"] / (1 + proxy_kl))
            r[f"pred2_{mu:g}"] = float(l_ * 0.5 * (r["PS_tw"] + r["PS_tw12"]) / (1 + proxy_kl))
        return r

    # ---- anchors
    out_tr = out_ho = out_ho_t = None
    if a.outside and a.outside_frac > 0:
        ou = torch.from_numpy(np.load(C.ROOT / a.outside)["images"]).to(C.DEVICE)
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            tl = torch.cat([teacher(C.norm(C.u8_to01(ou[i:i + 128]))).float() for i in range(0, len(ou), 128)])
        keep = (tl.softmax(1).max(1).values > a.outside_minconf).nonzero()[:, 0]
        keep = keep[torch.randperm(len(keep), generator=torch.Generator().manual_seed(0)).to(C.DEVICE)]
        nho = len(keep) // 5
        out_ho, out_tr, out_ho_t = ou[keep[:nho]], ou[keep[nho:]], tl[keep[:nho]]
        print(f"outside anchors: {len(out_tr)} train / {len(out_ho)} held out", flush=True)
    def load_imgs(pat):
        files = sorted(f for pp in pat.split(",") for f in glob.glob(str(C.ROOT / pp)) if ".tmp" not in f)
        arr = [np.load(f)["images"] for f in files]
        return torch.from_numpy(np.concatenate([x.reshape(-1, *x.shape[-3:]) for x in arr])).to(C.DEVICE)

    def tlogits(u8):
        with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16):
            return torch.cat([teacher(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])

    # held-out drift sets: last 1000 s0.875 twins (generic in-distribution) and last 1000 of holdout_tw2 (sub-population)
    HO = {}
    twins = None
    if a.twins:
        allt = load_imgs(a.twins)
        HO["tw875"] = (allt[-1000:], tlogits(allt[-1000:]))
        twins = allt[:-1000] if a.twin_frac > 0 else None
        print(f"twin anchors: {0 if twins is None else len(twins)} (+1000 held out)", flush=True)
    memset = None
    if a.mem:
        mu8 = torch.from_numpy(np.load(C.ROOT / a.mem)["images"]).to(C.DEVICE)
        HO["mem"] = (mu8[-a.mem_ho:], tlogits(mu8[-a.mem_ho:]))
        if a.mem_frac > 0:
            memset = mu8[:-a.mem_ho]
            print(f"memorised-like anchors: {len(memset)} (+{a.mem_ho} held out)", flush=True)
    twins2 = None
    if a.holdout_tw2:
        t2 = load_imgs(a.holdout_tw2)
        HO["tw625"] = (t2[-1000:], tlogits(t2[-1000:]))
    if a.twins2 and a.twin2_frac > 0:
        twins2 = load_imgs(a.twins2)
        if a.holdout_tw2 in a.twins2.split(","):
            twins2 = twins2[:-1000]
        print(f"twin2 anchors: {len(twins2)}", flush=True)

    t2i = None
    if a.t2i:
        ti = load_imgs(a.t2i)
        tl_ = tlogits(ti[-a.t2i_ho:])
        HO["t2i"] = (ti[-a.t2i_ho:], tl_)
        fc = torch.zeros(100, dtype=torch.bool, device=C.DEVICE); fc[y.unique()] = True
        un = ~fc[tl_.argmax(1)]
        HO["t2iU"] = (ti[-a.t2i_ho:][un], tl_[un])
        print(f"t2i: {len(ti) - a.t2i_ho} train / {a.t2i_ho} held out ({int(un.sum())} unseen-class)", flush=True)
        if a.t2i_frac > 0:
            t2i = ti[:-a.t2i_ho]

    atw = None
    if a.aug_mix > 0:
        fs = sorted(f for f in glob.glob(str(C.ROOT / a.aug_twins)) if ".tmp" not in f)
        ii = np.concatenate([np.load(f)["idx"] for f in fs])
        im = np.concatenate([np.load(f)["images"] for f in fs])
        atw = torch.from_numpy(im[np.argsort(ii)]).to(C.DEVICE)   # [N, k, 224, 224, 3]
        assert len(atw) == N
        print(f"aug twins: {tuple(atw.shape)}", flush=True)

    params = []
    for n, p in student.named_parameters():
        tr = True
        if a.train_from_block > 0:
            if n.startswith(("patch_embed", "cls_token", "pos_embed")):
                tr = False
            elif n.startswith("blocks."):
                tr = int(n.split(".")[1]) >= a.train_from_block
        p.requires_grad_(tr)
        if tr:
            params.append(p)
    opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
    p_orig = [tp.detach().clone() for (n_, tp) in teacher.named_parameters() if dict(student.named_parameters())[n_].requires_grad] if a.l2sp > 0 else None
    iters = a.epochs * (N // a.bs_f)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / a.warmup) * 0.5 * (1 + np.cos(np.pi * min(s, iters) / iters)))
    scaler = torch.amp.GradScaler(enabled=a.amp == "fp16")
    g = torch.Generator(device=C.DEVICE).manual_seed(a.seed)
    best = {"pred": -1, "step": -1}

    @torch.no_grad()
    def outside_drift():
        r = {}
        student.eval()
        sets = dict(HO)
        if out_ho is not None:
            sets["out"] = (out_ho, out_ho_t)
        for name, (u8, tl_) in sets.items():
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                s = torch.cat([student(C.norm(C.u8_to01(u8[i:i + 128]))).float() for i in range(0, len(u8), 128)])
            lt, ls = F.log_softmax(tl_ / 2, -1), F.log_softmax(s / 2, -1)
            r[f"{name}_kl"] = (lt.exp() * (lt - ls)).sum(1).mean().item()
            r[f"{name}_agree"] = (s.argmax(1) == tl_.argmax(1)).float().mean().item()
        return r

    def evaluate(step, extra):
        c = ev.sets.logits(student, "clean")
        m = ev.sets.logits(student, "mild")
        p = ev.sets.logits(student, "proxy")
        r = {f"clean_{k}": v for k, v in C.forget_stats(c, y).items()}
        r.update({f"mild_{k}": v for k, v in C.forget_stats(m, y).items()})
        r["proxy_kl"] = C.kl_T(ev.t_proxy, p).mean().item()
        # fixed extra-altered view of every forget image (each op p=0.5): loss level vs clean (gold: >= clean)
        gx = torch.Generator(device=C.DEVICE).manual_seed(777)
        xv = []
        with torch.no_grad():
            for i in range(0, N, 256):
                xin = C.norm(extra_aug(C.augment(C.u8_to01(imgs[i:i + 256]), gx), gx, 0.5))
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    xv.append(student(xin).float())
        xv = torch.cat(xv)
        lx = F.cross_entropy(xv, y, reduction="none")
        r["xv_loss_mean"], r["xv_loss_std"], r["xv_acc"] = lx.mean().item(), lx.std().item(), (xv.argmax(1) == y).float().mean().item()
        r.update(outside_drift())
        r["kl_target_T2"] = (q2 * (q2.clamp_min(1e-12).log() - F.log_softmax(c / 2, -1))).sum(1).mean().item()
        r["margin_mae"] = (margin(c, y) - mt).abs().mean().item()
        r.update(predicted(c, m, r["proxy_kl"]))
        r.update(step=step, t=round(time.time() - t0, 1), **extra)
        C.log_jsonl(log, r)
        print(f"[{step:5d}] clean {r['clean_acc']:.3f} {r['clean_loss_mean']:.2f}±{r['clean_loss_std']:.2f} | mild "
              f"{r['mild_acc']:.3f} {r['mild_loss_mean']:.2f}±{r['mild_loss_std']:.2f} | KLt {r['kl_target_T2']:.3f} "
              f"mMAE {r['margin_mae']:.2f} | pKL {r['proxy_kl']:.3f} oKL {r.get('out_kl', 0):.3f} t875 {r.get('tw875_kl', 0):.3f} "
              f"t625 {r.get('tw625_kl', 0):.3f} MEM {r.get('mem_kl', 0):.3f} XV {r['xv_loss_mean']:.2f}±{r['xv_loss_std']:.2f} t2i {r.get('t2i_kl', 0):.3f} t2iU {r.get('t2iU_kl', 0):.3f} | PS b/tw/tl "
              f"{r['PS_blend']:.3f}/{r['PS_tw']:.3f}/{r['PS_tail']:.3f} | pred@3 {r['pred_3']:.3f} @4 {r['pred_4']:.3f}"
              f" @5 {r['pred_5']:.3f} @6 {r['pred_6']:.3f} | NEW tw12 {r['PS_tw12']:.3f} pred2@7 {r['pred2_7']:.3f} @6 {r['pred2_6']:.3f} | {extra}", flush=True)
        key = r["pred2_7"]
        if step >= a.save_from:
            C.save_state_dict(student, out / f"ckpt_{step:05d}.pt")
            if key > best["pred"]:
                best.update(pred=key, step=step)
            ck = sorted(out.glob("ckpt_*.pt"))
            for old in ck[:-a.keep]:
                if old.name != f"ckpt_{best['step']:05d}.pt":
                    old.unlink(missing_ok=True)
        student.train()

    t0 = time.time()
    evaluate(0, {})
    step = 0
    for epoch in range(a.epochs):
        student.train()
        perm = torch.randperm(N, generator=g, device=C.DEVICE)
        for it in range(N // a.bs_f):
            if a.reassign_every and step % a.reassign_every == 0:
                reassign(student, step); student.train()
            idx = perm[it * a.bs_f:(it + 1) * a.bs_f]
            x01 = C.u8_to01(imgs[idx])
            gs = g.get_state()
            xa = C.augment(x01, g)
            nc = int(round(a.clean_frac * len(idx)))
            xa[:nc] = x01[:nc]
            if a.aug_extra > 0:
                xa = torch.cat([xa[:nc], extra_aug(xa[nc:], g, a.aug_extra)])
            qa = None
            if atw is not None:   # same augmentation params applied to a random twin of each image
                g2 = torch.Generator(device=C.DEVICE); g2.set_state(gs)
                kk = torch.randint(0, atw.shape[1], (len(idx),), generator=g, device=C.DEVICE)
                xt = C.augment(C.u8_to01(atw[idx, kk]), g2)
                with torch.no_grad(), torch.autocast(device_type="cuda", dtype=adt):
                    qa = F.softmax(teacher(C.norm(xt[nc:])).float() / 2, -1)
            parts = []
            no = int(round(a.outside_frac * a.bs_r)) if out_tr is not None else 0
            nt = min(int(round(a.twin_frac * a.bs_r)), a.bs_r - no) if twins is not None else 0
            if no:
                io_ = torch.randint(0, len(out_tr), (no,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(out_tr[io_]), g, scale=(0.7, 1.0), noise=0.02))
            if nt:
                it_ = torch.randint(0, len(twins), (nt,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(twins[it_]), g, scale=(0.7, 1.0), noise=0.02))
            nt2 = min(int(round(a.twin2_frac * a.bs_r)), a.bs_r - no - nt) if twins2 is not None else 0
            if nt2:
                i2 = torch.randint(0, len(twins2), (nt2,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(twins2[i2]), g, scale=(0.7, 1.0), noise=0.02))
            nmm = min(int(round(a.mem_frac * a.bs_r)), a.bs_r - no - nt - nt2) if memset is not None else 0
            if nmm:
                im_ = torch.randint(0, len(memset), (nmm,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(memset[im_]), g, scale=(0.7, 1.0), noise=0.02))
            nt3 = min(int(round(a.t2i_frac * a.bs_r)), a.bs_r - no - nt - nt2 - nmm) if t2i is not None else 0
            if nt3:
                i3 = torch.randint(0, len(t2i), (nt3,), generator=g, device=C.DEVICE)
                parts.append(C.augment(C.u8_to01(t2i[i3]), g, scale=(0.7, 1.0), noise=0.02))
            nm = a.bs_r - no - nt - nt2 - nmm - nt3
            if nm > 0:
                ia = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                ib = torch.randint(0, N, (nm,), generator=g, device=C.DEVICE)
                parts.append(C.mix_proxy(C.augment(C.u8_to01(imgs[ia]), g), C.augment(C.u8_to01(imgs[ib]), g), g))
            xr = C.norm(torch.cat(parts))
            xf = C.norm(xa)
            with torch.autocast(device_type="cuda", dtype=adt):
                with torch.no_grad():
                    tr = teacher(xr).float()
                s = student(torch.cat([xf, xr])).float()
            sf, sr = s[:len(xf)], s[len(xf):]
            qt = q2[idx].clone()
            if qa is not None:
                qt[nc:] = (1 - a.aug_mix) * qt[nc:] + a.aug_mix * qa
            lf_kl = (qt * (qt.clamp_min(1e-12).log() - F.log_softmax(sf / 2, -1))).sum(1).mean() * 4
            wm = torch.ones(len(idx), device=C.DEVICE); wm[nc:] = a.mg_aug_w
            mtt = mt[idx].clone(); mtt[nc:] -= a.aug_shift
            lf_mg = (F.huber_loss(margin(sf, y[idx]), mtt, delta=2.0, reduction="none") * wm).sum() / wm.sum()
            lr_ = F.kl_div(F.log_softmax(sr / 2, -1), F.log_softmax(tr / 2, -1), reduction="batchmean",
                           log_target=True) * 4
            loss = a.kl_w * lf_kl + a.mg_w * lf_mg + a.alpha * lr_
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            scaler.step(opt)
            if p_orig is not None:
                with torch.no_grad():
                    lr_now = opt.param_groups[0]['lr']
                    for p_, p0_ in zip(params, p_orig):
                        p_.add_(p_ - p0_, alpha=-lr_now * a.l2sp)
            scaler.update()
            sched.step()
            step += 1
            if step % a.eval_every == 0 or step == a.max_steps:
                evaluate(step, {"ep": epoch, "kl": round(lf_kl.item(), 3), "mg": round(lf_mg.item(), 3),
                                "ret": round(lr_.item(), 4)})
            if a.max_steps and step >= a.max_steps:
                print(f"debug stop at {step} ({time.time() - t0:.0f}s)")
                return
    if step % a.eval_every:
        evaluate(step, {"ep": a.epochs - 1})
    print(f"done in {time.time() - t0:.0f}s; best predicted {best}", flush=True)


if __name__ == "__main__":
    main()
