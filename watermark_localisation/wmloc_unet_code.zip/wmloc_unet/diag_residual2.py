"""Message-differential residual: Delta = r(x,m) - r(x,m_bar) (complement) or r(x,m) - mean_k r(x,m_k) (random msgs).
Controlled test (x1 = x0 + w1) then dataset AUC on 40 train images/method."""
import sys
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT, auc
from residual import residual_float, hp, local_maps

def beta(a, b): return float((a * b).sum() / ((b * b).sum() + 1e-9))
def deltas(wm, x, m, rng, K=4):
    r = residual_float(wm, x, m)
    d_c = r - residual_float(wm, x, 1 - np.asarray(m))
    d_r = r - torch.stack([residual_float(wm, x, rng.randint(0, 2, wm.nbits)) for _ in range(K)]).mean(0)
    return {"raw": r, "comp": d_c, "rand4": d_r}
ds = load_split("train"); rng = np.random.RandomState(1)
for meth in ("pixelseal", "trustmark", "stegastamp"):
    wm = load_watermark(meth, KIT / "models", "cuda"); rows = {}
    for i in [i for i, m in enumerate(ds.meta) if m["method"] == meth][:6]:
        x0 = ds[i]["image"]; m1 = rng.randint(0, 2, wm.nbits)
        x1 = (torch.from_numpy(x0).permute(2, 0, 1).float().cuda() + residual_float(wm, x0, m1)).clamp(0, 255).round()
        x1u = x1.byte().permute(1, 2, 0).cpu().numpy(); X0 = torch.from_numpy(x0).permute(2, 0, 1).float().cuda()
        D1, D0 = deltas(wm, x1u, m1, rng), deltas(wm, x0, m1, rng)
        for k in D1: rows.setdefault(k, []).append([beta(hp(x1), hp(D1[k])), beta(hp(X0), hp(D0[k]))])
    print(meth, " | ".join(f"{k}: beta wm={np.mean(v,0)[0]:.3f} clean={np.mean(v,0)[1]:.3f}" for k, v in rows.items()), flush=True)
    # dataset AUC
    idx_t = [i for i, m in enumerate(ds.meta) if m["method"] == meth and m["full_watermark"]]
    idx_f = [i for i, m in enumerate(ds.meta) if m["method"] == meth and not m["full_watermark"]]
    M, G, Fl = {}, [], []
    for i in list(rng.permutation(idx_t)[:20]) + list(rng.permutation(idx_f)[:20]):
        it = ds[i]; X = torch.from_numpy(it["image"]).permute(2, 0, 1).float().cuda()
        for k, d in deltas(wm, it["image"], it["message"], rng).items():
            if k == "raw": continue
            for kk, v in local_maps(hp(X), hp(d), (8, 16, 32)).items(): M.setdefault(f"{k}:{kk}", []).append(v.cpu().numpy())
        G.append(it["mask128"]); Fl.append(it["full_watermark"])
    G = np.stack(G).astype(bool); Fl = np.array(Fl)
    for k, v in M.items():
        v = np.stack(v)
        print(f"   {k:14s} AUC all={auc(v,G):.3f} full=T={auc(v[Fl],G[Fl]):.3f} full=F={auc(v[~Fl],G[~Fl]):.3f} | in={v[G].mean():.3f} out={v[~G].mean():.3f}", flush=True)
