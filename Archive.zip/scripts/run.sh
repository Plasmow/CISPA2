#!/bin/bash
# Generic GPU job: sbatch scripts/run.sh scripts/scrub.py --run NAME [args...]
#SBATCH --job-name=unl
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=16
#SBATCH --time=01:00:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
srun .venv/bin/python "$@"
echo "done!"
