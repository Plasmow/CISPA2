| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source zregy040_hp_glob_stack | 0.5171 | 0.5159 | 0.5183 |
| pixelseal | source zrx50_hp_glob_stack | 0.5069 | 0.5085 | 0.5052 |
| pixelseal | source zr2n50_hp_glob_stack | 0.5223 | 0.5175 | 0.5272 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wmunet20'] | 0.6125 | 0.6218 | 0.6032 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'zr2n50_hp_glob_stack', 'zregy040_hp_glob_stack', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6169 | 0.6291 | 0.6048 |
| pixelseal | fusion all + rule switch | 0.6169 | 0.6291 | 0.6048 |
| pixelseal | fusion all + rule expected_area | 0.6172 | 0.6312 | 0.6031 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6185 | 0.6300 | 0.6070 |
| pixelseal | fusion all + rule regressed_area | 0.5940 | 0.6104 | 0.5776 |
| pixelseal | fusion all + rule emiou_none | 0.6230 | 0.6342 | 0.6119 |
| pixelseal | fusion all + rule emiouT|switch | 0.6191 | 0.6344 | 0.6038 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6192 | 0.6340 | 0.6045 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6201 | 0.6342 | 0.6060 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6074 | 0.6322 | 0.5826 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6520 | 0.6604 | 0.6436 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6230 | 0.6342 | 0.6119 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:largest | **0.6242** | 0.6336 | 0.6147 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6255 | 0.6336 | 0.6174 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6395 | 0.6336 | 0.6454 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6513 | 0.6336 | 0.6690 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6529 | 0.6336 | 0.6722 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6546 | 0.6336 | 0.6756 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6447 | 0.6336 | 0.6558 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6424 | 0.6336 | 0.6513 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6546** | 0.6336 | 0.6756 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source zregy040_hp_glob_stack | 0.5310 | 0.4989 | 0.5632 |
| trustmark | source zrx50_hp_glob_stack | 0.5027 | 0.5014 | 0.5040 |
| trustmark | source zr2n50_hp_glob_stack | 0.5187 | 0.5122 | 0.5253 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunet0'] | 0.6078 | 0.6110 | 0.6046 |
| trustmark | fusion top3 ['wmunet', 'wmunet0', 'wmunetF0'] | 0.6099 | 0.6152 | 0.6047 |
| trustmark | fusion all ['wmunet', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'zregy040_hp_glob_stack', 'headmulti', 'zr2n50_hp_glob_stack', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'zrx50_hp_glob_stack', 'loc_r50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6136 | 0.6116 | 0.6157 |
| trustmark | fusion all + rule switch | 0.6136 | 0.6116 | 0.6157 |
| trustmark | fusion all + rule expected_area | 0.6245 | 0.6251 | 0.6239 |
| trustmark | fusion all + rule otsu_in_regime | 0.6167 | 0.6114 | 0.6220 |
| trustmark | fusion all + rule regressed_area | 0.6065 | 0.6116 | 0.6014 |
| trustmark | fusion all + rule emiou_none | 0.6289 | 0.6284 | 0.6295 |
| trustmark | fusion all + rule emiouT|switch | 0.6223 | 0.6274 | 0.6172 |
| trustmark | fusion all + rule emiouT|expected_area | 0.6262 | 0.6283 | 0.6240 |
| trustmark | fusion all + rule emiouT|otsu_in_regime | 0.6240 | 0.6272 | 0.6207 |
| trustmark | fusion all + rule emiouT|regressed_area | 0.6156 | 0.6272 | 0.6040 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6556 | 0.6546 | 0.6566 |
| trustmark | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6289 | 0.6284 | 0.6295 |
| trustmark | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:drop<16 | **0.6295** | 0.6303 | 0.6288 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6307 | 0.6315 | 0.6298 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6519 | 0.6315 | 0.6722 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6761 | 0.6315 | 0.7208 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6832 | 0.6315 | 0.7350 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6865 | 0.6315 | 0.7415 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6865 | 0.6315 | 0.7415 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6865 | 0.6315 | 0.7415 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6761** | 0.6315 | 0.7208 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source zregy040_hp_glob_stack | 0.7245 | 0.7618 | 0.6872 |
| stegastamp | source zrx50_hp_glob_stack | 0.6326 | 0.6485 | 0.6166 |
| stegastamp | source zr2n50_hp_glob_stack | 0.6583 | 0.6886 | 0.6279 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | fusion top2 ['zregy040_hp_glob_stack', 'loc_effv2s_hp_glob_stack'] | 0.7322 | 0.7759 | 0.6885 |
| stegastamp | fusion top3 ['zregy040_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack'] | 0.7367 | 0.7748 | 0.6986 |
| stegastamp | fusion all ['zregy040_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'zr2n50_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'zrx50_hp_glob_stack', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7579 | 0.8043 | 0.7114 |
| stegastamp | fusion all + rule switch | 0.7579 | 0.8043 | 0.7114 |
| stegastamp | fusion all + rule expected_area | 0.7513 | 0.7869 | 0.7157 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7640 | 0.8096 | 0.7184 |
| stegastamp | fusion all + rule regressed_area | 0.7332 | 0.7610 | 0.7055 |
| stegastamp | fusion all + rule emiou_none | 0.7682 | 0.8053 | 0.7311 |
| stegastamp | fusion all + rule emiouT|switch | 0.7571 | 0.8035 | 0.7106 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7607 | 0.8053 | 0.7162 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7615 | 0.8049 | 0.7182 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7558 | 0.8053 | 0.7062 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7687 | 0.7980 | 0.7395 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7682 | 0.8053 | 0.7311 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<16 | **0.7643** | 0.7998 | 0.7288 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7686 | 0.8055 | 0.7317 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7208 | 0.7991 | 0.6426 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7671 | 0.7991 | 0.7351 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7756 | 0.7991 | 0.7521 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7792 | 0.7991 | 0.7594 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7825 | 0.8055 | 0.7594 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7825 | 0.8055 | 0.7594 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7792** | 0.7991 | 0.7594 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "zr2n50_hp_glob_stack",
   "zregy040_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6546,
  "cv_T": 0.6336,
  "cv_F": 0.6756,
  "test_frac_pred_1": 0.491
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunet0",
   "wmunetF0",
   "wmunetF",
   "headsyn2",
   "headsyn",
   "zregy040_hp_glob_stack",
   "headmulti",
   "zr2n50_hp_glob_stack",
   "head",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "zrx50_hp_glob_stack",
   "loc_r50_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "drop<16",
  "rect": "rect>=0.85",
  "cv": 0.6761,
  "cv_T": 0.6315,
  "cv_F": 0.7208,
  "test_frac_pred_1": 0.498
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "zregy040_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "zr2n50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "zrx50_hp_glob_stack",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<16",
  "rect": "rect>=0.9",
  "cv": 0.7792,
  "cv_T": 0.7991,
  "cv_F": 0.7594,
  "test_frac_pred_1": 0.495
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.7033,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v19a.pt",
 "size_MB": 15.96
}
```
