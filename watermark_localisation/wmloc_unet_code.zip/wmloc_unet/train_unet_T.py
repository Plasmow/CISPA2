"""T-only fine-tuning of an existing stack U-Net with a hole-focused loss (BCE + Lovasz hinge + Tversky on holes).
Same strat folds as train_unet.py; fold k starts from runs/<init_run>/fold<k>/model.pt (trained without fold k -> OOF stays clean).
Trains only on the T images of the 4 training folds; predicts every val / test image as usual.
    python train_unet_T.py --variant effb3_hp_glob_stack --tag Tft --epochs 30 --lr 1e-4 --lr_enc 3e-5
"""
import inspect, os, sys
import torch, torch.nn.functional as F
import train_unet as T

TW = float(os.environ.get("T_TV_BETA", "0.7"))


def lovasz_grad(gs):
    p = len(gs); gts = gs.sum(); inter = gts - gs.cumsum(0); union = gts + (1 - gs).cumsum(0)
    j = 1. - inter / union
    if p > 1: j[1:p] = j[1:p] - j[:-1]
    return j


def lovasz_hinge(lg, y):
    out = []
    for l, t in zip(lg.reshape(len(lg), -1), y.reshape(len(y), -1)):
        s = 2. * t - 1.; e = 1. - l * s; es, perm = torch.sort(e, descending=True)
        out.append(torch.dot(F.relu(es), lovasz_grad(t[perm])))
    return torch.stack(out).mean()


def hole_loss(lg, y):
    lg = lg.float(); ph = 1 - torch.sigmoid(lg); h = 1 - y                    # hole = class 0
    tp = (ph * h).sum((-2, -1)); fp = (ph * (1 - h)).sum((-2, -1)); fn = ((1 - ph) * h).sum((-2, -1))
    tv = 1 - (tp + 1) / (tp + (1 - TW) * fp + TW * fn + 1)
    return F.binary_cross_entropy_with_logits(lg, y) + lovasz_hinge(lg, y) + tv.mean()


src = inspect.getsource(T.train_fold)
src = src.replace("itr = np.where(folds != fold)[0]", "itr = np.where((folds != fold) & tr['full'].astype(bool))[0]")
src = src.replace("args.init:", "args.init.replace('{k}', str(fold)):").replace("torch.load(args.init,", "torch.load(args.init.replace('{k}', str(fold)),")
src = src.replace("F.binary_cross_entropy_with_logits(lg.float(), y) + miou_loss(lg, y)", "hole_loss(lg, y)")
assert "hole_loss" in src and "tr['full']" in src
ns = dict(vars(T)); ns["hole_loss"] = hole_loss; exec(src, ns); T.train_fold = ns["train_fold"]

if __name__ == "__main__":
    T.main()
