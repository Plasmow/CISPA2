"""Missed decoder rectangles, PixelSeal / TrustMark: search by PAIRS OF EDGES around many seeds (GPU).

Seeds per image (deduplicated, IoU > 0.9):
  - every box already found for it: loc/cache/rect_<m>_<split>_* (teammate, read-only) and stack/maps/rect2_* ;
  - the map seeds of rect_seeded.py (maximum-sum rectangles of the fused logit - b, boxes of the largest blobs) ;
  - the bounding box of the largest component, and of the whole foreground, of the masks of earlier versions
    (test: submissions v3 ... v9 ; train: OOF masks of v4b, v7, v9 in sam/<stem>/masks_train_oof.pt).
For each seed, alternate (2D grid on (x0, x1) at +-HALF px, step STEP, y fixed) and (2D grid on (y0, y1), x fixed), ROUNDS
times; PixelSeal then gets a greedy 1 px pass (its bit acc decays with the offset, TrustMark is flat up to ~8 px: see the
tolerance study in COORD.md). Key = bit acc + 1e-3 * confidence. Crops resized like the official wrapper (bilinear antialias,
PixelSeal 256 / TrustMark 245). Aspect ratio <= 16:1 (2:1 for TrustMark), side >= 8 px.
Images: predicted type F (fused-map g <= tg + 0.1) with NO box >= the version's threshold yet; those whose best box is
0.6-0.85 first.

    python rect_pairs.py trustmark test 0 4 [--dev cuda] [--nmax N] [--names a,b]
Writes stack/maps/rect3_<method>_<split>_<shard>.npz (names, boxes y0,y1,x0,x1 in px 512, acc, conf, src, seed_acc).
v3.load_rect reads rect3_* too (best acc per image) ; WMLOC_NO_RECT3=1 ignores them (to replay versions <= v9).
"""
import argparse
import glob
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import ndimage as ndi

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
LOC = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
sys.path.insert(0, str(LOC)); sys.path.insert(0, str(HERE))
from common import load_split, load_watermark, KIT, CACHE  # noqa: E402
from shapes2 import max_rect  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("method", choices=["pixelseal", "trustmark"]); ap.add_argument("split"); ap.add_argument("shard", type=int); ap.add_argument("nshards", type=int)
ap.add_argument("--dev", default="cuda"); ap.add_argument("--nmax", type=int, default=10 ** 9); ap.add_argument("--names", default=None)
ap.add_argument("--half", type=int, default=24); ap.add_argument("--step", type=int, default=2); ap.add_argument("--rounds", type=int, default=3)
ap.add_argument("--maxseeds", type=int, default=12, help="seeds kept per image (best initial key first)")
ap.add_argument("--version", default="submission_v9", help="version whose rectangle thresholds define 'already found'")
a = ap.parse_args()
dev = a.dev
if dev == "cuda":
    torch.backends.cuda.matmul.allow_tf32 = True; torch.backends.cudnn.allow_tf32 = True
RES_ = {"pixelseal": 256, "trustmark": 245}[a.method]
MAXAR = 2.0 if a.method == "trustmark" else 16.0
BS = {"pixelseal": 256, "trustmark": 384}[a.method]
FINAL1 = a.method == "pixelseal"
MINSIDE = 8

ds = load_split(a.split, [a.method]); wm = load_watermark(a.method, KIT / "models", dev)


def crops_resized(x, boxes):
    out = torch.empty(len(boxes), 3, RES_, RES_, device=dev)
    for i, (y0, y1, x0, x1) in enumerate(boxes):
        out[i] = F.interpolate(x[None, :, y0:y1, x0:x1], size=(RES_, RES_), mode="bilinear", align_corners=False, antialias=True)[0]
    return out.clamp_(0, 1)


@torch.no_grad()
def score(x, boxes, sgn):
    accs, confs = [], []
    for b in range(0, len(boxes), BS):
        s = wm.logits(crops_resized(x, boxes[b:b + BS])).float().to(dev) * sgn
        accs.append((s > 0).float().mean(1).cpu()); confs.append(s.mean(1).cpu())
    return torch.cat(accs).numpy(), torch.cat(confs).numpy()


def valid(b):
    y0, y1, x0, x1 = b; h, w = y1 - y0, x1 - x0
    return 0 <= y0 and y1 <= 512 and 0 <= x0 and x1 <= 512 and h >= MINSIDE and w >= MINSIDE and max(h, w) / min(h, w) <= MAXAR


def box_iou(p, q):
    ih = max(0, min(p[1], q[1]) - max(p[0], q[0])); iw = max(0, min(p[3], q[3]) - max(p[2], q[2])); inter = ih * iw
    return inter / max((p[1] - p[0]) * (p[3] - p[2]) + (q[1] - q[0]) * (q[3] - q[2]) - inter, 1)


def clip_box(b):
    y0, y1, x0, x1 = [int(v) for v in b]
    y0, x0 = max(0, y0), max(0, x0); y1, x1 = min(512, max(y1, y0 + MINSIDE)), min(512, max(x1, x0 + MINSIDE))
    return (y0, y1, x0, x1)


def bbox128(m, largest=True):
    if not m.any():
        return None
    if largest:
        lab, k = ndi.label(m); sz = ndi.sum(np.ones_like(lab), lab, range(1, k + 1)); m = lab == 1 + int(np.argmax(sz))
    ys, xs = np.where(m); return clip_box((4 * ys.min(), 4 * ys.max() + 4, 4 * xs.min(), 4 * xs.max() + 4))


def map_seeds(L):
    out = []
    for b in (-1.0, 0.0, 1.0, 2.0):
        v, y0, y1, x0, x1 = max_rect(L.astype(np.float64) - b)
        if v > 0:
            out.append(clip_box((4 * y0, 4 * y1, 4 * x0, 4 * x1)))
    for t in (0.3, 0.5):
        lab, k = ndi.label(L > np.log(t / (1 - t)))
        if k:
            sz = ndi.sum(np.ones_like(lab), lab, range(1, k + 1))
            for c in np.argsort(-sz)[:3]:
                ys, xs = np.where(lab == c + 1); out.append(clip_box((4 * ys.min(), 4 * ys.max() + 4, 4 * xs.min(), 4 * xs.max() + 4)))
    return out


# ---- existing boxes (raw coordinates) and the version's threshold
found = {}                                                     # name -> list of (box, acc)
for f in glob.glob(str(CACHE / f"rect_{a.method}_{a.split}_*.npz")) + glob.glob(str(HERE / "maps" / f"rect2_{a.method}_{a.split}_*.npz")):
    d = np.load(f)
    for n, b, acc in zip(d["names"], d["boxes"], d["acc"]):
        found.setdefault(str(n), []).append((clip_box(b), float(acc)))
cfg = json.loads((ROOT / "submissions" / f"{a.version}.json").read_text())[a.method]
THR = float(cfg["rect"].split(">=")[1]) if cfg.get("rect", "none") != "none" else 0.85

# ---- masks of earlier versions (seeds)
masks_by_name = {}
if a.split == "test":
    for v in ("v3", "v3a", "v3b", "v3c", "v3d", "v4_wmunet", "v4b", "v7", "v8", "v9"):
        p = ROOT / "submissions" / f"submission_{v}.pt"
        if p.exists():
            d = torch.load(p, weights_only=True)
            for n, m in zip(d["image_names"], d["masks"].numpy()):
                masks_by_name.setdefault(n, []).append(m.astype(bool))
else:
    for v in ("submission_v4b", "submission_v7", "submission_v9"):
        p = ROOT / "sam" / v / "masks_train_oof.pt"
        if p.exists():
            d = torch.load(p, weights_only=True)
            for n, m in zip(d["image_names"], d["masks"].numpy()):
                masks_by_name.setdefault(n, []).append(m.astype(bool))

# ---- images: predicted F, nothing found above THR ; best existing box 0.6-0.85 first
zt = np.load(HERE / "maps" / f"fused_{a.split}_{a.method}.npz"); fnames = zt["names"].tolist(); FL = zt["logit128"].astype(np.float32); FG = zt["g"]
ztr = np.load(HERE / "maps" / f"fused_train_{a.method}.npz")
from evalkit import fit_switch  # noqa: E402
tr_ds = load_split("train", [a.method]) if a.split != "train" else ds
gt_tr = np.stack([tr_ds.m128[n] for n in ztr["names"].tolist()]).astype(bool)
tg = fit_switch(ztr["logit128"].astype(np.float32), gt_tr, ztr["g"], np.arange(len(gt_tr)))["tg"]
pos = {n: i for i, n in enumerate(fnames)}
best_acc = {n: max(acc for _, acc in found.get(n, [((0, 8, 0, 8), -1.0)])) for n in fnames}
if a.names:
    want = set(a.names.split(",")); idx = [i for i, m in enumerate(ds.meta) if m["image_name"] in want]
else:
    idx = [i for i, m in enumerate(ds.meta) if FG[pos[m["image_name"]]] <= tg + 0.1 and best_acc[m["image_name"]] < THR]
    idx.sort(key=lambda i: (not (0.6 <= best_acc[ds.meta[i]["image_name"]] < THR), ds.meta[i]["image_name"]))
idx = idx[:a.nmax][a.shard::a.nshards]
print(f"{a.method} {a.split} shard {a.shard}: {len(idx)} images (thr {THR}, tg {tg:.3f})", flush=True)


def grid2(b, axis):
    """2D grid on the two edges of one axis (axis 0: y0,y1 ; axis 1: x0,x1), the other axis fixed."""
    i0, i1 = (0, 1) if axis == 0 else (2, 3); out = []
    r = range(-a.half, a.half + 1, a.step)
    for d0 in r:
        for d1 in r:
            c = list(b); c[i0] += d0; c[i1] += d1; c = tuple(c)
            if valid(c):
                out.append(c)
    return out


def search(x, sgn, seeds):
    cur = list(seeds); A, C = score(x, cur, sgn); key = list(A + 1e-3 * C); acc = list(A); conf = list(C)
    for _ in range(a.rounds):
        moved = False
        for axis in (1, 0):
            cands, owner = [], []
            for si, b in enumerate(cur):
                g = grid2(b, axis); cands += g; owner += [si] * len(g)
            if not cands:
                continue
            ca, cc = score(x, cands, sgn); kk = ca + 1e-3 * cc; owner = np.array(owner)
            for si in range(len(cur)):
                js = np.where(owner == si)[0]
                if len(js) == 0:
                    continue
                j = js[np.argmax(kk[js])]
                if kk[j] > key[si] + 1e-9:
                    cur[si], key[si], acc[si], conf[si] = cands[j], kk[j], ca[j], cc[j]; moved = True
        if not moved:
            break
    if FINAL1:                                                  # greedy 1 px pass on every edge
        for si in range(len(cur)):
            while True:
                cands = []
                for e in range(4):
                    for d in (-1, 1):
                        c = list(cur[si]); c[e] += d; c = tuple(c)
                        if valid(c):
                            cands.append(c)
                ca, cc = score(x, cands, sgn); kk = ca + 1e-3 * cc; j = int(np.argmax(kk))
                if kk[j] > key[si] + 1e-9:
                    cur[si], key[si], acc[si], conf[si] = cands[j], kk[j], ca[j], cc[j]
                else:
                    break
    return [(cur[i], float(acc[i]), float(conf[i])) for i in range(len(cur))]


rec = {k: [] for k in ("names", "boxes", "acc", "conf", "src", "seed_acc")}
out_path = HERE / "maps" / f"rect3_{a.method}_{a.split}_{a.shard}.npz"
t0 = time.time()
for k, i in enumerate(idx):
    it = ds[i]; n = it["image_name"]
    x = torch.from_numpy(np.array(it["image"])).permute(2, 0, 1).float().div(255).to(dev)
    sgn = torch.as_tensor(it["message"].astype(np.float32) * 2 - 1, device=dev)
    cand = [(b, "found") for b, _ in found.get(n, [])] + [(b, "map") for b in map_seeds(FL[pos[n]])]
    for m in masks_by_name.get(n, []):
        for largest in (True, False):
            b = bbox128(m, largest)
            if b is not None:
                cand.append((b, "masks"))
    seeds, src = [], []
    for b, s in cand:
        if valid(b) and all(box_iou(b, u) < 0.9 for u in seeds):
            seeds.append(b); src.append(s)
    if not seeds:
        seeds, src = [(128, 384, 128, 384)], ["center"]
    A0, C0 = score(x, seeds, sgn); order = np.argsort(-(A0 + 1e-3 * C0))[:a.maxseeds]
    seeds = [seeds[j] for j in order]; src = [src[j] for j in order]; seed_acc = float(A0.max())
    res = search(x, sgn, seeds)
    j = max(range(len(res)), key=lambda q: (res[q][1], res[q][2]))
    for kk_, v in (("names", n), ("boxes", res[j][0]), ("acc", res[j][1]), ("conf", res[j][2]), ("src", src[j]), ("seed_acc", seed_acc)):
        rec[kk_].append(v)
    print(f"[{a.method} {a.split} {a.shard}] {k + 1}/{len(idx)} {n} prev_best={best_acc[n]:.3f} seed={seed_acc:.3f} -> acc={res[j][1]:.3f} "
          f"box={res[j][0]} src={src[j]} seeds={len(seeds)} {(time.time() - t0) / (k + 1):.1f}s/img", flush=True)
    if (k + 1) % 5 == 0 or k + 1 == len(idx):
        np.savez(out_path, **{kk_: np.array(vv) for kk_, vv in rec.items()})
if not idx:
    np.savez(out_path, **{kk_: np.array(vv) for kk_, vv in rec.items()})
print("done", flush=True)
