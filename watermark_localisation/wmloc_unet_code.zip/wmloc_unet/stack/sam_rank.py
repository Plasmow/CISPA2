"""Learned choice of the SAM segment (CPU only): replaces the hand-made rule of snap_sam (softIoU x contrast, threshold s).

For every regime-F image without a decoder rectangle (same eligibility as snap_sam_local.py: whole-image bit acc < 0.8,
no rectangle above the version's thresholds, SAM candidates available), the candidates are the ~100 SAM segments
(loc/cache/sam_cands, read-only) + the current mask of the version ("base"). Each candidate gets label-free features
computed from the fused probability map of the version (OOF on train): area, mean probability inside / in a ring,
contrast, soft IoU, snap_sam score and its rank, share of the map mass captured, IoU with the base mask and with P>0.5,
expected mIoU under P, bounding-box fill, number of components, + image features (bit acc, method, base area, map stats).
A listwise MLP (stack/shapes2.Sel, ensemble of seeds) is trained to put the highest score on the candidate with the
best true mIoU; "keep base" is a candidate, so the snap/no-snap decision is learned too. Score = 5-fold CV over images.

    python sam_rank.py ../submissions/submission_v7.pt [TOPK]   # needs ../sam/submission_v7/{probs_train_oof,masks_train_oof,probs_test}.pt
Writes ../submissions/<stem>_samrank.pt (only if the CV beats snap_sam's) and ../results_<stem>_samrank.md. No upload.
"""
import glob
import json
import sys
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

from v3 import HERE, ROOT, METHODS, load_rect, folds, miou_batch
from common import CACHE, DATA
from shapes2 import Sel

N = 128 * 128
SAMD = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc/cache/sam_cands")


def global_acc(split):
    g = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item()
    md = {m["image_name"]: m for m in json.loads((DATA / split / "metadata.json").read_text())}
    return ({n: float(((l > 0) == np.array([int(c) for c in md[n]["message"]])).mean()) for d in g.values() for n, l in zip(d["names"], d["logits"])},
            {n: m["method"] for n, m in md.items()})


def load_cands(split):
    out = {}
    for f in glob.glob(str(SAMD / f"sam_{split}*.npz")):
        d = np.load(f, allow_pickle=True)
        for n, c in zip(d["names"], d["cands"]):
            out[str(n)] = np.unpackbits(c, axis=1)[:, :N].astype(bool) if len(c) else np.zeros((0, N), bool)
    return out


def feats(P, B, C, gacc, meth):
    """P [N] prob, B [N] base mask, C [K,N] candidates -> X [K+1, F] (row 0 = base), masks [K+1, N]."""
    M = np.vstack([B[None], C]); K = len(M); Mf = M.astype(np.float32)
    area = Mf.sum(1); sP = P.sum(); std = P.std() + 1e-6
    inside = (Mf @ P) / (area + 1e-6)
    R = np.stack([ndi.binary_dilation(m.reshape(128, 128), iterations=4).ravel() & ~m for m in M]).astype(np.float32)
    ring = (R @ P) / (R.sum(1) + 1e-6)
    pn = (P - P.min()) / (P.max() - P.min() + 1e-6); inter = Mf @ pn
    soft = inter / (area + pn.sum() - inter + 1e-6); sc = soft * np.clip((inside - ring) / std, 0, None)
    rank = np.argsort(np.argsort(-sc[1:])); rank = np.r_[0, rank] / max(K - 1, 1)
    p1 = Mf @ P; q1 = sP - p1; e1 = p1 / (area + q1 + 1e-6)
    Q = 1 - P; p0 = (1 - Mf) @ Q; q0 = Mf @ Q; e0 = p0 / ((N - area) + q0 + 1e-6); emiou = (e1 + e0) / 2
    Bf = B.astype(np.float32); ib = (Mf @ Bf) / (area + Bf.sum() - Mf @ Bf + 1e-6)
    H = (P > 0.5).astype(np.float32); ih = (Mf @ H) / (area + H.sum() - Mf @ H + 1e-6)
    M3 = M.reshape(K, 128, 128); rows = M3.any(2); cols = M3.any(1)
    def span(a):
        has = a.any(1); first = np.argmax(a, 1); last = a.shape[1] - 1 - np.argmax(a[:, ::-1], 1)
        return np.where(has, last - first + 1, 0)
    fill = area / np.maximum(span(rows) * span(cols), 1)
    ncomp = np.array([ndi.label(m)[1] for m in M3])
    border = (M3[:, 0].any(1) | M3[:, -1].any(1) | M3[:, :, 0].any(1) | M3[:, :, -1].any(1)).astype(np.float32)
    oh = np.zeros(3); oh[METHODS.index(meth)] = 1
    img = np.r_[gacc, oh, B.mean(), P.mean(), P.max(), std, (P > 0.5).mean()]
    X = np.c_[area / N, np.log(area + 1), inside, ring, inside - ring, (inside - ring) / std, soft, sc, sc - sc[1:].max(initial=0), rank,
              p1 / (sP + 1e-6), ib, ih, emiou, e1, e0, fill, np.log1p(ncomp), border, np.r_[1.0, np.zeros(K - 1)],
              np.broadcast_to(img, (K, len(img)))]
    return X.astype(np.float32), M


TOPK = int(sys.argv[2]) if len(sys.argv) > 2 else 0          # >0: keep only base + the TOPK best segments by snap_sam's score


def restrict(X, M):
    if not TOPK or len(X) <= TOPK + 1:
        return X, M
    keep = np.r_[0, 1 + np.argsort(-X[1:, 7])[:TOPK]]
    return X[keep], M[keep]


def snap_choice(X):
    """snap_sam's own choice among the SAM candidates (column 7 = score, rows 1..)."""
    return 1 + int(np.argmax(X[1:, 7])), float(X[1:, 7].max())


def main():
    sub = Path(sys.argv[1]).resolve(); stem = sub.stem; cfg = json.loads(sub.with_suffix(".json").read_text())
    sd = ROOT / "sam" / stem
    thr = {m: float(cfg[m]["rect"].split(">=")[1]) if cfg[m].get("rect", "none") != "none" else 9.0 for m in METHODS}
    def rect_names(split):
        return {n for m in METHODS for n, (_, acc) in load_rect(m, split).items() if acc >= thr[m]}
    def load_pt(p, key):
        d = torch.load(p, weights_only=True); return {n: np.asarray(x).ravel() for n, x in zip(d["image_names"], d[key].numpy())}
    # ---- train
    gacc, meth_of = global_acc("train"); rects = rect_names("train"); cands = load_cands("train")
    probs = load_pt(sd / "probs_train_oof.pt", "probs"); base = {n: v.astype(bool) for n, v in load_pt(sd / "masks_train_oof.pt", "masks").items()}
    z = np.load(DATA / "train" / "masks_128.npz"); gt = {n: m.astype(bool) for n, m in zip(z["names"].tolist(), z["masks"])}
    names = [n for n in probs if gacc[n] < 0.8 and n not in rects and n in cands and len(cands[n])]
    print(f"train: {len(names)} eligible images (excluded as rectangle: {len(rects & set(probs))})", flush=True)
    data, ys = [], []
    for n in names:
        X, M = restrict(*feats(probs[n].astype(np.float32), base[n], cands[n], gacc[n], meth_of[n]))
        data.append((list(range(len(M))), M, X)); ys.append(miou_batch(M.reshape(-1, 128, 128), np.broadcast_to(gt[n], (len(M), 128, 128))))
    n_img = len(names); meths = np.array([meth_of[n] for n in names])
    sb = np.array([y[0] for y in ys]); orc = np.array([y.max() for y in ys])
    # snap_sam reference: CV-tuned threshold on its own score (same folds as snap_sam_local: seed 0)
    sj = [snap_choice(d[2]) for d in data]; ss = np.array([ys[i][j] for i, (j, _) in enumerate(sj)]); conf = np.array([c for _, c in sj])
    def best_s(idx):
        cand_s = np.r_[np.inf, np.unique(np.quantile(conf[idx], np.linspace(0, 1, 41)))]
        return cand_s[int(np.argmax([np.where(conf[idx] >= t, ss[idx], sb[idx]).mean() for t in cand_s]))]
    ref = np.zeros(n_img)
    for f in folds(n_img, 5, 0):
        t = best_s(np.setdiff1d(np.arange(n_img), f)); ref[f] = np.where(conf[f] >= t, ss[f], sb[f])
    # learned ranker, ensemble of seeds
    SEEDS = (0, 1, 2, 3, 4)
    cv = np.zeros(n_img); picked_base = np.zeros(n_img, bool)
    for f in folds(n_img, 5, 0):
        trn = np.setdiff1d(np.arange(n_img), f); models = [Sel(data, ys, trn, epochs=300, seed=s) for s in SEEDS]
        for i in f:
            sc = np.mean([m.predict(data[i][2]) for m in models], 0); j = int(np.argmax(sc)); cv[i] = ys[i][j]; picked_base[i] = j == 0
    lines = [f"| all | {n_img} | {sb.mean():.4f} | {ref.mean():.4f} | **{cv.mean():.4f}** | {orc.mean():.4f} | {picked_base.mean():.0%} |"]
    for m in METHODS:
        k = meths == m
        lines.append(f"| {m} | {k.sum()} | {sb[k].mean():.4f} | {ref[k].mean():.4f} | **{cv[k].mean():.4f}** | {orc[k].mean():.4f} | {picked_base[k].mean():.0%} |")
    n_all = len(probs); gain_ref = (ref.sum() - sb.sum()) / n_all; gain_cv = (cv.sum() - sb.sum()) / n_all
    hdr = ["| images | n | base (version) | snap_sam (CV) | learned choice (CV) | oracle | kept base |", "|---|---|---|---|---|---|---|"]
    txt = "\n".join(hdr + lines) + f"\n\nEffect on the whole train score: snap_sam {gain_ref:+.4f}, learned {gain_cv:+.4f}\n"
    print(txt, flush=True)
    # per-method CV after, for the report (version CV + gain on its images)
    after = {m: round(cfg[m]["cv"] + float((cv[meths == m].sum() - sb[meths == m].sum()) / 170), 4) for m in METHODS}
    after_ref = {m: round(cfg[m]["cv"] + float((ref[meths == m].sum() - sb[meths == m].sum()) / 170), 4) for m in METHODS}
    txt += f"\nCV per method: snap_sam {after_ref} (mean {np.mean(list(after_ref.values())):.4f}) | learned {after} (mean {np.mean(list(after.values())):.4f})\n"
    print(txt.splitlines()[-1], flush=True)
    (ROOT / f"results_{stem}_samrank{TOPK or ''}.md").write_text(txt)
    if gain_cv <= gain_ref:
        print("learned choice does not beat snap_sam -> no file written"); return
    # ---- test
    models = [Sel(data, ys, np.arange(n_img), epochs=300, seed=s) for s in SEEDS]
    gacc_t, meth_t = global_acc("test"); rects_t = rect_names("test"); cands_t = load_cands("test")
    probs_t = load_pt(sd / "probs_test.pt", "probs"); d = torch.load(sub, weights_only=True)
    out_names = list(d["image_names"]); Mout = d["masks"].numpy().astype(bool).copy(); used = 0
    for i, n in enumerate(out_names):
        if gacc_t[n] < 0.8 and n not in rects_t and n in cands_t and len(cands_t[n]) and n in probs_t:
            X, M = restrict(*feats(probs_t[n].astype(np.float32), Mout[i].ravel(), cands_t[n], gacc_t[n], meth_t[n]))
            j = int(np.argmax(np.mean([m.predict(X) for m in models], 0)))
            if j:
                Mout[i] = M[j].reshape(128, 128); used += 1
    out = ROOT / "submissions" / f"{stem}_samrank{TOPK or ''}.pt"
    torch.save({"image_names": out_names, "masks": torch.from_numpy(Mout)}, out)
    print(f"test: {used} masks replaced by the chosen SAM segment -> {out}")


if __name__ == "__main__":
    main()
