"""Which images end up in the heavy tail? Compare ckpts' tail sets (loss>10) vs random design and twin p_true."""
import sys, torch, torch.nn.functional as F
import common as C
from lbfit_lib import load_twins
teacher, imgs = C.load_all(); ev = C.Evaluator(teacher, imgs); y = ev.labels
tw = F.softmax(load_twins("0.625").to(C.DEVICE) / 2, -1).mean(1)
ptw = tw.gather(1, y[:, None])[:, 0]
g = torch.Generator(device=C.DEVICE).manual_seed(5)
zo50 = ev.sets.logits(teacher, "mild")
lo50 = F.cross_entropy(zo50, y, reduction="none")
sets = {}
for ck in sys.argv[1:]:
    m = C.tt.build_model(); m.load_state_dict(torch.load(ck, map_location="cpu", weights_only=True)); m = m.to(C.DEVICE).eval()
    l = F.cross_entropy(ev.sets.logits(m, "clean"), y, reduction="none")
    tail = l > 10
    sets[ck] = tail
    def rk(v):
        return v.argsort().argsort().float()
    sp = lambda a, b: torch.corrcoef(torch.stack([rk(a), rk(b)]))[0, 1].item()
    print(f"{ck}: tail frac {tail.float().mean():.3f} | twin p_true tail {ptw[tail].mean():.3f} vs rest {ptw[~tail].mean():.3f} | "
          f"orig mild-loss tail {lo50[tail].mean():.3f} vs rest {lo50[~tail].mean():.3f} | spearman(loss, twin p_true) {sp(l, ptw):.3f}", flush=True)
ks = list(sets)
for i in range(len(ks)):
    for j in range(i + 1, len(ks)):
        a, b = sets[ks[i]], sets[ks[j]]
        print(f"overlap {ks[i][-30:]} vs {ks[j][-30:]}: jaccard {(a & b).sum().item() / max(1, (a | b).sum().item()):.3f}")
