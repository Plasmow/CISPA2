"""Compare gold hypotheses g on the leaderboard history, with the retain model validated on the DZ family:
retain = 1 / (1 + a*t875 + b*t625) (drift on held-out generic / sub-population twins), LDS(mu, sigma), PS(g).
Fits (mu, sigma, a, b) by grid; reports RMSE on all subs and on the DZ family (score > 0.2).
Usage: python scripts/lbfit_g.py [extra hypothesis files output/targets/g_eu_*.pt ...]"""
import glob, sys
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "scripts")
from lbfit_lib import *

subs = [s for s in load_subs() if (LB / "drift" / f"{s['key']}.pt").exists()]
orig = torch.load(LB / "orig.pt"); y = orig["clean"].float().argmax(1); N = len(y)
od = torch.load(LB / "drift" / "orig.pt")
klT = lambda a, b: (F.softmax(a.float() / 2, -1) * (F.log_softmax(a.float() / 2, -1) - F.log_softmax(b.float() / 2, -1))).sum(1).mean().item()  # noqa
Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
Dr = {s["key"]: torch.load(LB / "drift" / f"{s['key']}.pt") for s in subs}
t875 = np.array([klT(od["tw875"], Dr[s["key"]]["tw875"]) for s in subs])
t625 = np.array([klT(od["tw625"], Dr[s["key"]]["tw625"]) for s in subs])
score = np.array([s["score"] for s in subs]); dzf = score > 0.2
LS = {k: {v: loss_stats_from_logits(Z[k][v], y) for v in ("clean", "mild")} for k in Z}
LSo = {v: loss_stats_from_logits(orig[v], y) for v in ("clean", "mild")}
LQ = {k: {v: F.log_softmax(Z[k][v].float() / T, -1) for v in ("clean", "mild")} for k in Z}
LQo = {v: F.log_softmax(orig[v].float() / T, -1) for v in ("clean", "mild")}
oh = F.one_hot(y, 100).float()
tw4 = F.softmax(load_twins("0.625") / T, -1).mean(1)
z = orig["clean"].float().clone(); z[torch.arange(N), y] = -1e4
tail = F.softmax(z / T, -1) * 0.7 + oh * 0.3
HYP = {"tw4": tw4, "tail": tail, "blend": 0.5 * tw4 + 0.5 * tail}
# per-image p_true signals with the orig-tail wrong-class shape (mean p_true kept at ~0.3)
rest = F.softmax(z / T, -1)
def tail_with(pt):
    pt = pt.clamp(0.01, 0.95)
    return rest * (1 - pt[:, None]) + oh * pt[:, None]
def rescale(sig, mean=0.3):  # map a signal to p_true with mean ~0.3 by a logit shift
    lo, hi = -10.0, 10.0
    for _ in range(50):
        mid = (lo + hi) / 2
        if torch.sigmoid(sig + mid).mean() > mean: hi = mid
        else: lo = mid
    return torch.sigmoid(sig + (lo + hi) / 2)
tw_pt = tw4.gather(1, y[:, None])[:, 0]
zs = orig["clean"].float().sort(1, descending=True).values
gap = zs[:, 0] - zs[:, 1]                                  # orig margin (memorised, but residual info)
r2 = F.softmax(orig["clean"].float() / 2, -1).sort(1, descending=True).values[:, 1]  # runner-up mass at T=2
mild_pt = F.softmax(orig["mild"].float(), -1).gather(1, y[:, None])[:, 0]           # robustness under aug
for nm, sig in (("twlogit", torch.logit(tw_pt.clamp(1e-3, 1 - 1e-3))), ("gap", (gap - gap.mean()) / gap.std()),
                ("negrunner", -(r2.log() - r2.log().mean()) / r2.log().std()),
                ("mildpt", torch.logit(mild_pt.clamp(1e-4, 1 - 1e-4)) / 4)):
    for sc in (0.5, 1.0, 2.0):
        HYP[f"tail_pt:{nm}x{sc}"] = tail_with(rescale(sig * sc))
HYP["tail_pt:random"] = tail_with(rescale(torch.randn(N, generator=torch.Generator().manual_seed(0)) * 1.0))
for f in sys.argv[1:]:
    d = torch.load(f); assert torch.equal(d["labels"], y)
    ge = d["probs_T2"].float(); n = Path(f).stem
    HYP[n] = ge
    HYP[n + "+blend"] = 0.5 * ge + 0.5 * HYP["blend"]
    HYP[n + "+tail"] = 0.5 * ge + 0.5 * tail
MUS = np.arange(3, 8.01, 0.5); SDS = np.arange(3, 10.01, 0.5)
AS = [0, 1, 2, 3]; BS = [0, 0.15, 0.3, 0.5]
LDS = {(mu, sd): np.array([np.mean([lds(*LS[s['key']][v], *LSo[v], mu, sd) for v in ("clean", "mild")]) for s in subs])
       for mu in MUS for sd in SDS}
print(f"{len(subs)} subs ({dzf.sum()} DZ-family)")
print(f"{'hypothesis':28s} rmse_all rmse_dz  mu   sd   a   b  | p_true ent")
for hn, g in HYP.items():
    ps = np.array([np.mean([1 - np.clip(kl_mean(g, LQ[s['key']][v]) / kl_mean(g, LQo[v]), 0, 1) for v in ("clean", "mild")]) for s in subs])
    best = None
    for (mu, sd), l in LDS.items():
        for a_ in AS:
            for b_ in BS:
                pred = l * ps / (1 + a_ * t875 + b_ * t625)
                e = np.sqrt(((pred - score) ** 2).mean()); ed = np.sqrt(((pred[dzf] - score[dzf]) ** 2).mean())
                key = e + ed
                if best is None or key < best[0]:
                    best = (key, e, ed, mu, sd, a_, b_)
    _, e, ed, mu, sd, a_, b_ = best
    ent = -(g * g.clamp_min(1e-12).log()).sum(1).mean().item()
    print(f"{hn:28s} {e:.4f}   {ed:.4f}  {mu:4.1f} {sd:4.1f} {a_:3.0f} {b_:4.2f} | {g.gather(1, y[:, None]).mean():.3f} {ent:.2f}")
