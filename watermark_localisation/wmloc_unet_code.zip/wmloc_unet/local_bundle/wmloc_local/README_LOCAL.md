# Entraînement local du U-Net « tout connecté »

Contexte : voir le bilan « Localisation de watermark — bilan de l'architecture » (sections *Les briques une par une*
et *Prêt mais pas encore lancé*). Ce dossier contient tout ce qu'il faut pour entraîner, en validation croisée
5-fold sur le train, le U-Net qui reçoit en plus de l'image trois cartes 128×128 précalculées sur le cluster :

| canal | contenu | méthodes |
|---|---|---|
| 0 | sortie (logit) de la tête apprise ; train = hors fold, test = moyenne des 5 têtes | PixelSeal, TrustMark (0 pour StegaStamp) |
| 1 | confiance per-position du décodeur (grille 8×8 agrandie) | PixelSeal, TrustMark (0 pour StegaStamp) |
| 2 | heatmap par fenêtres glissantes, z-score par image | les 3 |

Le score global du décodeur (5 nombres par image) est lu dans `loc/cache/global_*.npy`. Aucun modèle de watermark
n'est nécessaire ici.

## Installation

Python 3.10+ avec CUDA :

```bash
pip install torch torchvision timm numpy scipy pillow
```

Les poids ImageNet d'EfficientNet-B3 sont téléchargés automatiquement par timm au premier lancement.

## Données

```bash
mkdir -p release && unzip -q train.zip -d release && unzip -q test.zip -d release
ls release/train/images | wc -l   # 510
ls release/test/images | wc -l    # 1020
```

## Lancement

Depuis ce dossier :

```bash
export WMLOC_TASK=$PWD
python train_unet.py --variant effb3_hp_glob_stack --epochs 60 --bs 8 2>&1 | tee train_stack.log
python eval_unet.py
```

- Testé sur le cluster : batch 8 = ~4 Go de mémoire GPU (une RTX 4060 de 8 Go suffit). En cas de manque de mémoire, `--bs 4`.
- Durée estimée sur RTX 4060 : ~15–20 min par fold, ~1h30 pour les 5 folds.
- Le log affiche le mIoU de validation toutes les 10 époques, puis une ligne `final val mIoU@0.5 TTA` par fold.
- Option si le temps le permet : `--variant rgb_glob_stack` (ResNet34, plus rapide).
- Test rapide avant le vrai lancement : `python train_unet.py --variant effb3_hp_glob_stack --folds 0 --epochs 2 --max_train 50 --out_root runs_smoke`.

## Ce qu'il faut renvoyer

Après `eval_unet.py`, pour chaque variante entraînée, ces deux fichiers suffisent (~150 Mo au total) :

```
runs/effb3_hp_glob_stack/oof_all.npz     # prédictions hors fold sur le train (510 x 128 x 128)
runs/effb3_hp_glob_stack/test_mean.npz   # prédictions test, moyenne des 5 folds (1020 x 128 x 128)
results_unet.md                          # tableau des scores
train_stack.log
```

Ils seront copiés dans `wmloc_unet/runs/<variante>/` sur le cluster ; `stack/make_submission.py` les compare aux
autres sources, méthode par méthode, et refait la soumission.

## Points de comparaison (validation croisée, mIoU officiel)

| méthode | meilleur actuel | source |
|---|---|---|
| PixelSeal | 0.532 | tête apprise |
| TrustMark | 0.517 | tête apprise |
| StegaStamp | 0.640 | U-Net effb3_hp_glob (sans cartes) |
| moyenne | 0.563 | soumission actuelle, 0.5674 au leaderboard public |
