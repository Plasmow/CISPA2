| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source loc_effv2s_hp_glob_stack | 0.5065 | 0.5012 | 0.5119 |
| pixelseal | source loc_r50_hp_glob_stack | 0.5117 | 0.5129 | 0.5104 |
| pixelseal | source loc_regy032_hp_glob_stack | 0.5056 | 0.5040 | 0.5071 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source wamc | 0.6072 | 0.6192 | 0.5952 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunet2', 'wmunet'] | 0.6077 | 0.6201 | 0.5953 |
| pixelseal | fusion top3 ['wmunet2', 'wmunet', 'wamc'] | 0.6079 | 0.6206 | 0.5953 |
| pixelseal | fusion all ['wmunet2', 'wmunet', 'wamc', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_r50_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6149 | 0.6273 | 0.6025 |
| pixelseal | fusion all + rule switch | 0.6149 | 0.6273 | 0.6025 |
| pixelseal | fusion all + rule expected_area | 0.6137 | 0.6294 | 0.5979 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6162 | 0.6283 | 0.6041 |
| pixelseal | fusion all + rule regressed_area | 0.5940 | 0.6105 | 0.5775 |
| pixelseal | fusion all + rule emiou_none | 0.6199 | 0.6326 | 0.6072 |
| pixelseal | fusion all + rule emiouT|switch | 0.6173 | 0.6330 | 0.6017 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6158 | 0.6324 | 0.5993 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6180 | 0.6328 | 0.6031 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6063 | 0.6314 | 0.5813 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6481 | 0.6591 | 0.6370 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6199 | 0.6326 | 0.6072 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:drop<256 | **0.6154** | 0.6300 | 0.6008 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6209 | 0.6345 | 0.6073 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6369 | 0.6345 | 0.6394 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6498 | 0.6345 | 0.6651 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6514 | 0.6345 | 0.6684 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6531 | 0.6345 | 0.6718 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6421 | 0.6345 | 0.6498 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6384 | 0.6345 | 0.6423 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6531** | 0.6345 | 0.6718 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source loc_effv2s_hp_glob_stack | 0.4957 | 0.4822 | 0.5092 |
| trustmark | source loc_r50_hp_glob_stack | 0.4990 | 0.4910 | 0.5070 |
| trustmark | source loc_regy032_hp_glob_stack | 0.5070 | 0.4893 | 0.5246 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source wamc | 0.6048 | 0.6106 | 0.5991 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wamc'] | 0.6045 | 0.6098 | 0.5992 |
| trustmark | fusion top3 ['wmunet', 'wamc', 'wmunet0'] | 0.6074 | 0.6104 | 0.6044 |
| trustmark | fusion all ['wmunet', 'wamc', 'wmunet0', 'wmunetF0', 'wmunetF', 'headsyn2', 'headsyn', 'headmulti', 'head', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'loc_r50_hp_glob_stack', 'loc_effv2s_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6037 | 0.6067 | 0.6007 |
| trustmark | fusion top3 + rule switch | 0.6074 | 0.6104 | 0.6044 |
| trustmark | fusion top3 + rule expected_area | 0.6114 | 0.6193 | 0.6035 |
| trustmark | fusion top3 + rule otsu_in_regime | 0.6086 | 0.6104 | 0.6067 |
| trustmark | fusion top3 + rule regressed_area | 0.5936 | 0.6098 | 0.5774 |
| trustmark | fusion top3 + rule emiou_none | 0.6164 | 0.6229 | 0.6099 |
| trustmark | fusion top3 + rule emiouT|switch | 0.6145 | 0.6232 | 0.6058 |
| trustmark | fusion top3 + rule emiouT|expected_area | 0.6131 | 0.6223 | 0.6039 |
| trustmark | fusion top3 + rule emiouT|otsu_in_regime | 0.6147 | 0.6232 | 0.6062 |
| trustmark | fusion top3 + rule emiouT|regressed_area | 0.6009 | 0.6201 | 0.5817 |
| trustmark | fusion top3 + ORACLE per-image threshold (upper bound) | 0.6404 | 0.6479 | 0.6329 |
| trustmark | fusion top3 + CV-selected rule (whole-train choice: emiou_none) | 0.6164 | 0.6229 | 0.6099 |
| trustmark | **v2 pipeline**: fusion top3 + emiou_none + post T:close_holes5 / F:largest | **0.6193** | 0.6229 | 0.6157 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6193 | 0.6229 | 0.6157 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6493 | 0.6229 | 0.6757 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6758 | 0.6229 | 0.7287 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6830 | 0.6229 | 0.7432 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6862 | 0.6229 | 0.7495 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6862 | 0.6229 | 0.7495 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6862 | 0.6229 | 0.7495 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6758** | 0.6229 | 0.7287 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source loc_effv2s_hp_glob_stack | 0.6833 | 0.7417 | 0.6249 |
| stegastamp | source loc_r50_hp_glob_stack | 0.6280 | 0.6427 | 0.6133 |
| stegastamp | source loc_regy032_hp_glob_stack | 0.6802 | 0.7271 | 0.6334 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | source wamc | 0.6043 | 0.6333 | 0.5753 |
| stegastamp | fusion top2 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack'] | 0.7072 | 0.7546 | 0.6598 |
| stegastamp | fusion top3 ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack'] | 0.7050 | 0.7542 | 0.6557 |
| stegastamp | fusion all ['loc_effv2s_hp_glob_stack', 'loc_regy032_hp_glob_stack', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'loc_r50_hp_glob_stack', 'wmunetH0', 'wamc', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.7289 | 0.7891 | 0.6687 |
| stegastamp | fusion all + rule switch | 0.7289 | 0.7891 | 0.6687 |
| stegastamp | fusion all + rule expected_area | 0.7325 | 0.7745 | 0.6905 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7360 | 0.7947 | 0.6772 |
| stegastamp | fusion all + rule regressed_area | 0.7172 | 0.7496 | 0.6847 |
| stegastamp | fusion all + rule emiou_none | 0.7463 | 0.7888 | 0.7038 |
| stegastamp | fusion all + rule emiouT|switch | 0.7271 | 0.7865 | 0.6678 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7399 | 0.7888 | 0.6910 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7327 | 0.7885 | 0.6769 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7371 | 0.7890 | 0.6852 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7569 | 0.7912 | 0.7226 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7463 | 0.7888 | 0.7038 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<16 | **0.7459** | 0.7901 | 0.7017 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7475 | 0.7901 | 0.7048 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.7060 | 0.7841 | 0.6279 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7470 | 0.7841 | 0.7098 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7549 | 0.7841 | 0.7256 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7586 | 0.7841 | 0.7330 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7616 | 0.7901 | 0.7330 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7616 | 0.7901 | 0.7330 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7586** | 0.7841 | 0.7330 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunet2",
   "wmunet",
   "wamc",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "loc_r50_hp_glob_stack",
   "effb3_hp_glob_stack",
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "drop<256",
  "rect": "rect>=0.85",
  "cv": 0.6531,
  "cv_T": 0.6345,
  "cv_F": 0.6718,
  "test_frac_pred_1": 0.491
 },
 "trustmark": {
  "map": "fusion top3",
  "sources": [
   "wmunet",
   "wamc",
   "wmunet0"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes5",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6758,
  "cv_T": 0.6229,
  "cv_F": 0.7287,
  "test_frac_pred_1": 0.496
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "loc_effv2s_hp_glob_stack",
   "loc_regy032_hp_glob_stack",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "loc_r50_hp_glob_stack",
   "wmunetH0",
   "wamc",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<16",
  "rect": "rect>=0.9",
  "cv": 0.7586,
  "cv_T": 0.7841,
  "cv_F": 0.733,
  "test_frac_pred_1": 0.493
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.6958,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v18_wamc.pt",
 "size_MB": 15.96
}
```
