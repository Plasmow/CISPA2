# Bilan d'architecture : localisation de watermark (état au 22/11, 08:00)

Destinataire : une IA qui reprend le projet. Tous les chemins sont absolus. Ce document décrit l'état réel des fichiers.
Le suivi au fil de l'eau entre les agents est dans `W/COORD.md` (section A : intégration, rectangles, SAM ;
section B : type T et cartes).

## 0. En bref

- **Meilleure soumission : `submission_v12a_sam.pt`**, score public **0.7192** (soumission n° 3521).
  Les précédentes : 0.7131 (v9_sam), 0.7101 (v8_sam), 0.7094 (v7_sam), 0.6873 (v4_wmunet).
  Le classement final se fait sur une partie cachée du test.
- Le CV attendu de v12a_sam est **0.7187** (CV par image sur le train, toutes les étapes en validation croisée).
  Les gains de CV se sont retrouvés au leaderboard : +0.0038 de CV pour +0.0030 au leaderboard (v9),
  +0.0083 de CV pour +0.0061 (v12a).
- **Fin du hackathon vers 12:00 le 22/11.** La réservation cispahack se termine à 14:00.
- Pipeline, de bout en bout :
  **sources (cartes 128×128)** → **fusion par régression logistique** → **règle de seuil (dont « mIoU attendu maximal »)**
  → **post-traitement par type** → **rectangles du décodeur** → **recalage SAM** → soumission.
- **Règle d'intégration en vigueur** : une piste n'entre que si la CV moyenne finale (après SAM) gagne au moins +0.003,
  lue par méthode et par sous-type (T, F-rect, F-seg). Aucun envoi sans le « oui » explicite de debbah2.

## 1. Tâche et données

- Images 512×512. Chacune est tatouée par **PixelSeal, TrustMark ou StegaStamp** sur une sous-région, puis éditée
  (outpainting, suppression, ajout ou transplantation d'objets).
- **Prédiction** : un masque binaire 128×128 (1 = tatoué). La grille officielle est `downsample_mask` de `wmloc.utils`.
- **Métrique** : mIoU par image sur les 2 classes, moyennée sur les images.
- **Taille des jeux** : train 510 images (170 par méthode), test 1020.
  La méthode et le message (100 bits) sont connus, aussi pour le test.
- **Données** : `/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/{release,starter_kit}`.
  Chargement : `loc/common.py:load_split(split, methods)` renvoie un `LocalisationDataset`. Les attributs utiles sont
  `.meta` (image_name, method, message, full_watermark) et `.m128` (masques 128). Un item contient `image`, `mask` (512) et `message`.
- **Deux régimes** :
  - **type T** (`full_watermark`) : environ 90 % tatoué ; la classe minoritaire, ce sont les **trous**.
  - **type F** : environ 9 % tatoué.
- **Sous-types**, d'après `loc/cache/typo_stats.json` de la coéquipière ; par méthode, 85 T, 43 F-rect, 42 F-seg :
  - **T** : blobs aléatoires ou zones irrégulières.
  - **F-rect** : `fill_bbox ≥ 0.99`, un rectangle issu d'un outpainting.
  - **F-seg** : un objet net, sans doute issu de SAM.
- **g = confiance signée globale** : `mean(logits_décodeur × (2·msg − 1))` sur l'image entière, lue dans
  `loc/cache/global_{split}.npy` (voir `v3.g_of`). g sépare T et F avec une AUC d'environ 0.999.
  Le type prédit est `g > tg`, où tg est réglé sur le train.

## 2. Emplacements

- **Code et résultats** : `/p/project1/training2666/debbah2/wmloc_unet/` (noté `W/`). Le quota d'inodes de /p/scratch est plein, on y écrit peu.
  - `W/stack/` : fusion, têtes, rectangles, SAM. Cartes dans `W/stack/maps/`.
  - `W/runs/<variante>/` : U-Nets image (`oof_all.npz`, `test_mean.npz`).
    `W/runs/loc_*` : U-Nets entraînés sur la machine de debbah2 (section 3).
  - `W/synth/` : générateur synthétique et banque d'images.
  - `W/submissions/` : `submission_vX.pt` et `.json` (config, CV, champs `rules_plus` et `rect3`).
  - `W/sam/<stem>/` : exports et rapport de l'étape SAM.
  - `W/logs/` : journaux.
  - Rapports : `W/results_*.md`. Coordination : `W/COORD.md`.
- **Fichiers de l'agent B** (A ne les modifie pas) :
  - `W/stack/rule_emiou.py` : règle du mIoU attendu.
  - `W/stack/wm_unet_T.py`, `W/stack/wm_unet_T_eval.py`, `W/stack/wm_unet_T_pl.py`.
  - Cartes `wmunetT*` et `plwmunetT*` dans `W/stack/maps/`, scripts dans `W/runs/wmunetT/`.
- **Dossier de la coéquipière (LECTURE SEULE)** :
  `/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc/` et `loc/cache/`.
  On y trouve `rect_search.py`, `ss_local_search.py`, `snap_sam.py`, `README_rect_sam.md`, `cache/rect_*.npz`
  (dont `rect_stegastamp_test_local.npz`), `cache/sam_cands/`, `cache/global_*.npy` et `cache/typo_stats.json`.
- **Python** : `/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python`
  (torch, timm, scipy, onnxruntime ; ni sklearn ni skimage).
- **Format d'une carte source** : `W/stack/maps/<source>_{train,test}_<méthode>.npz`, avec `names`
  et `logit128` [N,128,128] float16. Sur le train, les cartes sont **OOF** : chaque image est prédite par un modèle qui ne l'a pas vue.
  Les runs U-Net (`W/runs/<v>/`) ont `names` et `prob` [N,128,128].

## 3. Sources (cartes de logits 128×128)

| Source | Fichier qui la produit | Principe |
|---|---|---|
| `effb3_hp_glob`, `rgb_hp_glob_synth8k` | `W/train_unet.py`, `W/unet.py`, `W/eval_unet.py` | U-Net 128 sur l'image (EfficientNet-B3 ou ResNet). Entrées : RGB + passe-haut ×20, et un vecteur global de 5 valeurs (méthode en one-hot, conf/5, acc×2) injecté au goulot. Perte BCE + mIoU, 5 plis, TTA par retournements. |
| `effb3_hp_glob_stack` | idem | Même U-Net ; le décodeur reçoit en plus les cartes empilées (logit de la tête, confiance par position du détecteur, heatmap). |
| **`loc_effv2s_hp_glob_stack`, `loc_r50_hp_glob_stack`, `loc_regy032_hp_glob_stack`** | `train_unet.py`, sur la machine de debbah2 (RTX 4060) | Variantes « stack » avec d'autres encodeurs : EfficientNetV2-S, ResNet-50, RegNetY-032. Seules, 0.536 à 0.562 de mIoU@0.5, mais **environ 0.68 sur StegaStamp** ; apport décisif dans la fusion StegaStamp (v12a). `loc_effb3_hp_glob_stack` est un nouvel entraînement presque identique au run du cluster (corrélation 0.994), inutile. |
| `synth_zeroshot` | `W/synth/train_synth.py` | ResNet34 U-Net entraîné uniquement sur des éditions synthétiques réalistes (`W/synth/generator.py`, banque COCO). |
| `head` | `stack/head_maps.py` | Régression logistique par position sur les features gelées du décodeur (PixelSeal ConvNeXt stage 2, TrustMark ResNet layer 2). |
| `headmulti` | `stack/head_multi.py`, `stack/head_stega.py` | Hypercolonnes multi-couches (PixelSeal, TrustMark). Pour StegaStamp : occlusion exacte dans l'espace des features (contribution de chaque position à la couche dense). |
| `headsyn`, `headsyn2` | `stack/head_synth.py`, `stack/head_synth2.py` | Têtes convolutionnelles sur les features gelées du décodeur, entraînées sur des données synthétiques. |
| `remark` | `stack/remark_maps.py` | StegaStamp seulement : corrélation entre le résidu de re-marquage et l'image. |
| **`wmunet`**, `wmunetF`, `wmunetH`, `wmunet2`, et leurs versions `…0` | `stack/wm_unet.py` | **U-Net dont l'encodeur est le décodeur du watermark** (détails ci-dessous). Ce sont les sources les plus fortes pour PixelSeal et TrustMark. |
| `wmunetTi`, `wmunetTio`, `wmunetTi2`, … (agent B) | `stack/wm_unet_T.py` | wm-U-Net spécialisé T : départ du checkpoint synthétique, puis pré-entraînement sur des trous T synthétiques. **Pas dans la version** : +0.0026 (v11b), puis +0.0002 une fois SAM appliqué sur v12. |

**Détail de wm_unet.py** :
- **Encodeur** : copie du décodeur officiel, en fp32 et BatchNorm gelée. PixelSeal : ConvNeXt, entrée 256 bilinéaire.
  TrustMark : ResNet-50, entrée 245, ×2−1. StegaStamp : `stack/stega_torch.py`, portage PyTorch exact du graphe ONNX
  (écart sur les logits de 6e-5), STN compris (échelle 398 = W−2). Pour StegaStamp, le décodeur du U-Net travaille dans
  le repère redressé par le STN, puis la sortie est ramenée sur les 128×128 cases de l'image par l'affine inverse.
- **Goulot** : carte de confiance par position du décodeur + g.
- **Décodeur** : skips depuis les étages de l'encodeur, plus un « stem » pleine résolution (image + passe-haut, stride 4).
- **Entraînement** :
  1. Données synthétiques seules (cartes `<tag>0_*`, utilisées comme source zéro-shot).
  2. Fine-tuning en 5 plis sur le train réel (cartes `<tag>_*`, OOF).
- **Tags** :
  - `wmunet` : encodeur gelé pendant 2000 pas, puis lr 1e-5.
  - `wmunetF` : encodeur toujours gelé.
  - `wmunetH` (StegaStamp) : gel 1000 pas, puis lr 3e-5.
  - `wmunet2` : PixelSeal, seconde graine.
- **Seul**, il atteint environ 0.61 de CV sur PixelSeal et TrustMark.

## 4. Fusion, règle de seuil, post-traitement (`W/stack/v3.py`)

Toutes les décisions sont prises par validation croisée à 5 plis sur les cartes OOF, imbriquée quand c'est nécessaire.
Le modèle final est réentraîné sur tout le train et appliqué au test.

1. **Fusion** (`fuse_feats`, `fit_fusion`, `oof_fusion`)
   - Par case, les features sont `[clip(logit_s, ±8) pour chaque source s, g/5, (g/5)·logit_s]`.
   - Régression logistique entraînée sur une case sur deux.
   - Candidats : chaque source seule, top 2, top 3, toutes ; le meilleur est choisi en CV avec la règle `switch`.
   - Sources : les runs passés par `--runs` (U-Nets de `W/runs/`) + les `--extras` (cartes de `W/stack/maps/`).
2. **Règles de seuil** (`rule_preds_any`)
   - `switch` : type par `g > tg`, puis un seuil par type (t_hi / t_lo).
   - `expected_area` : on garde les k cases les plus probables, avec k = Σp.
   - `otsu_in_regime`.
   - `regressed_area`, inférieure aux autres.
   - **Avec `--rules_plus`** (depuis v9) : les règles de B (`rule_emiou.rule_preds_plus`).
     - `emiou_none` : pour chaque image, on garde le k (masque des k cases les plus probables) qui maximise le mIoU souple
       attendu sous P = sigmoïde(carte fusionnée), sans paramètre appris.
     - Les hybrides `emiouT_none|<règle>`.
     - L'option écrit `"rules_plus": true` dans le .json.
   - Choix final de la règle en CV. Depuis v9, `emiou_none` est choisie pour les 3 méthodes.
3. **Post-traitement par type prédit** (`POST_T`, `POST_F`), choisi en CV
   - T : boucher les trous de moins de s cases, ou `close_holes3` / `close_holes5` (ouverture des trous).
   - F : `drop<s` (retirer les petits blobs), `largest`, fermeture + remplissage, boîte si la forme est presque un rectangle.
4. **Rectangles du décodeur** (`--rect`, détail en section 5)
   - Pour une image prédite F, si la meilleure boîte a une bit acc ≥ seuil, le masque devient la boîte.
   - Seuil choisi en CV parmi 0.7 à 0.95.

**Configuration de v12a** (`W/submissions/submission_v12a.json`) :

| Méthode | Carte | Règle | Post T / F | Rectangle | CV avant SAM | CV après SAM |
|---|---|---|---|---|---|---|
| PixelSeal | fusion de 17 sources | emiou_none | fill_holes<64 / drop<16+box>=0.85 | acc ≥ 0.85 | 0.6525 | 0.6729 |
| TrustMark | fusion top 3 (wmunet, wmunet0, wmunetF0) | emiou_none | close_holes5 / largest | acc ≥ 0.85 | 0.6778 | 0.7022 |
| StegaStamp | fusion de 16 sources | emiou_none | close_holes3 / drop<16 | acc ≥ 0.9 | 0.7594 | 0.7810 |
| **Moyenne** | | | | | 0.6966 | **0.7187** |

## 5. Rectangles du décodeur

- **Principe** : les images F-rect viennent d'un outpainting autour de l'image tatouée.
  On **recadre exactement le rectangle** et on le redimensionne comme le fait le wrapper officiel :
  StegaStamp 400 bicubique antialias, PixelSeal 256 bilinéaire, TrustMark 245 bilinéaire.
  Le décodeur relit alors le message connu, avec une bit acc proche de 1.
- **Tolérance au décalage d'un bord** (boîtes déjà trouvées, train ; détail dans COORD.md) :
  - StegaStamp : ±2 à 4 px.
  - TrustMark : acc ≈ 1 jusqu'à 8 px, 0.95 à 16 px.
  - PixelSeal : 0.95 → 0.90 à 8 px ; agrandir la boîte coûte plus que la réduire.
- Recadrer la boîte englobante d'un **objet transplanté ne se décode jamais** (0 sur 83).
- **Sources de boîtes, toutes lues par `v3.load_rect(meth, split)`, qui garde la meilleure acc par image** :

| Fichier | Auteur, script | Contenu | Interrupteur |
|---|---|---|---|
| `loc/cache/rect_{m}_{split}_*.npz` | coéquipière, `rect_search.py` (grille de 32 px à l'aveugle + affinage glouton) | PixelSeal et TrustMark, train et test ; StegaStamp, 24 images du train | — |
| `loc/cache/rect_stegastamp_test_local.npz` | coéquipière, `ss_local_search.py` (±8 px au pas de 4 autour du plus grand blob des masques v3 à v7, puis 2 et 1 px) | StegaStamp test, 159 images, 24 boîtes ≥ 0.9 | — (motif `rect_*_test_*`) |
| `W/stack/maps/rect2_{m}_{split}_{0,1}.npz` | A, `rect_seeded.py` (graines de la carte : sous-rectangle de somme maximale du logit fusionné, boîtes des blobs ; + grille de 32 px ; affinage 16 → 1 px) | StegaStamp et TrustMark, train et test | `WMLOC_NO_RECT2=1` (rejouer ≤ v4b) |
| `W/stack/maps/rect3_{m}_{split}_{0..3}.npz` | A, `rect_pairs.py` (grilles 2D par paires de bords à ±24 px au pas de 2, nombreuses graines) | PixelSeal et TrustMark, train et test. **REJETÉ** (v10) | `WMLOC_NO_RECT3=1` ; v3.py écrit `"rect3"` dans le .json |

- **Résultats** :
  - StegaStamp : rect2 fait passer les rectangles retrouvés sur le train de 3 à 15 (mIoU 0.96) ; sur le test, 0 → 36 images,
    puis 42 avec le fichier local de la coéquipière (v8).
  - TrustMark : 32 boîtes sur le train, 65 à 66 sur le test.
  - PixelSeal : 20 sur le train, 40 sur le test.
  - rect3 (v10) : seulement 12 nouvelles boîtes ≥ 0.85, souvent presque toute l'image ; CV −0.0004 (PixelSeal −0.002).
    **Les versions ≥ v11 sont construites avec `WMLOC_NO_RECT3=1`.**
- **Limites** :
  - Il reste des rectangles manqués : ni la carte ni les graines ne s'en approchent assez, surtout pour les petits (~45 px).
  - Les recadrages PixelSeal se décodent mal : acc d'environ 0.56 sur les rectangles manqués du train.

## 6. Recalage sur un segment SAM (`W/stack/sam_stage.py`)

- **Candidats** : environ 100 segments SAM ViT-L par image, sur la grille 128.
  - Fichiers : `loc/cache/sam_cands/sam_train.npz` et `sam_test_{0,1}.npz`.
  - Couverture : 510 images du train et 507 images F du test.
  - Ils sont **déjà calculés et ne doivent pas être regénérés**.
- **`sam_stage.py <submission_vX.pt>`** (CPU, environ 2 min) :
  1. **Rejoue la version** à partir de son `.json`, avec les fonctions de v3.py et sans rien écrire dans `maps/`.
     - Il lit `rules_plus` (règles de B) et `rect3` (sinon il pose `WMLOC_NO_RECT3=1`).
     - Il retrouve les runs U-Net à partir des noms de sources présents dans `W/runs/`.
     - Contrôles : `cv_json == cv_replay`, et masques de test identiques à 100 % à ceux de la soumission.
  2. **Exporte** dans `W/sam/<stem>/` :
     - `probs_train_oof.pt` (sigmoïde de la carte fusionnée OOF, avant la règle) ;
     - `masks_train_oof.pt` (masques OOF finaux, règle + post + rectangles) ;
     - `probs_test.pt`.
  3. **Lance `W/stack/snap_sam_local.py`**, copie de `loc/snap_sam.py` dont l'exclusion des images « rectangle » passe par
     `v3.load_rect` pour les 3 méthodes, avec les seuils du `.json`.
     - Images concernées : régime F (acc globale < 0.8) **sans rectangle**.
     - Le script choisit le segment qui maximise (IoU souple avec la carte) × (contraste dedans / anneau autour).
     - Le masque n'est remplacé que si ce score dépasse un seuil `s`, réglé en CV, commun aux 3 méthodes
       (0.176 pour v12a). Changer les cartes d'une méthode déplace donc légèrement le score SAM des autres.
  4. **Garde `<stem>_sam.pt` seulement si le gain en CV est positif.** Rapport dans `W/sam/<stem>/report.json` et `snap_sam.log`.
- **Effet** : environ +0.022 à +0.024 de CV par version, presque entièrement sur F-seg.
  Pour v12a : 0.6966 → 0.7187, avec 252 segments appliqués sur le test.

## 7. Historique des versions

| Version | Contenu ajouté | CV après SAM (ou finale) | Leaderboard public |
|---|---|---|---|
| v1 | têtes simples + règle switch | 0.563 | 0.5674 |
| v2 | fusion + règles + post-traitement | — | 0.6136 |
| v3a / v3b | sources supplémentaires (têtes multi-couches, synthétiques, remark) | — | 0.6166 / 0.6287 |
| v3c | + rectangles de la coéquipière | — | 0.663 |
| v3d | + headsyn2 | — | 0.6676 |
| v4_wmunet | + U-Net à encodeur = décodeur (PixelSeal, TrustMark) | 0.671 | 0.6873 |
| v4b | + wm-U-Net StegaStamp + 2e graine PixelSeal | 0.677 (≈ 0.699 avec SAM) | non envoyée |
| v7_sam | v4b + rectangles rect2 + SAM | 0.7066 | 0.7094 |
| v8_sam | + boîtes StegaStamp test de la coéquipière (CV identique, 14 images du test changent) | 0.7066 | 0.7101 |
| v9_sam | + règle du mIoU attendu de B (`--rules_plus`) | 0.7104 | 0.7131 |
| v10 | + rect3 | 0.6874 avant SAM (v9 : 0.6878) | **rejetée** |
| v11a / v11b | v9 + `wmunetTi` (/ + `wmunetTio`) de B | v11b_sam 0.7130 (+0.0026) | non envoyée (sous le seuil) |
| **v12a_sam** | **v9 + U-Nets locaux effv2s, r50, regy032** | **0.7187** | **0.7192** (meilleure) |
| v12b / v12c | v12a + effb3 local / + cartes T de B | v12c_sam 0.7189 | non envoyées (pas de gain) |

D'autres fichiers existent mais n'ont pas été envoyés : v3s (11 sources au lieu de 23, même CV), v5_route (+0.002), v6_shapes (+0.002).

## 8. Ce qui n'a pas marché (à ne pas refaire)

- **Heatmap à fenêtre glissante avec le décodeur** : signal faible, car le décodeur a besoin de contexte, et la résolution est limitée.
- **Attribution par gradient ; carte « alpha »** : AUC de 0.45 à 0.50.
- **Rectangles cherchés dans les cartes seules** (`guided_rect.py`, `rectfit` de shapes2) : jamais choisis.
  Les rectangles n'apparaissent utilement qu'avec le décodeur.
- **Recherche de rectangles par paires de bords, PixelSeal et TrustMark** (`rect_pairs.py`, rect3) : rendement très faible.
  TrustMark tolère 8 px, donc ses rectangles manqués ne relèvent pas d'un manque de précision mais de graines absentes.
- **Règle `regressed_area`** : surapprend.
- **Re-marquage** : n'aide que sur StegaStamp, et faiblement.
- **Entraînements synthétiques longs** : peu de gain.
- **Routage par sous-groupe** (`route.py`) : +0.002.
- **Sélection structurée par familles de formes** (`shapes.py`, `shapes2.py`, avec un sélecteur MLP appris) :
  - gain d'environ +0.002 en moyenne ;
  - le plafond oracle n'est que d'environ +0.03 ;
  - **le facteur limitant est la qualité de la carte**, pas la mise en forme du masque.
- **Bandes de bord en type T** : elles n'existent pas (0 sur 255).
- **Choix appris du segment SAM** (`sam_rank.py`, `sam_rank2.py`), évalué strictement hors pli sur 192 images éligibles.
  La règle actuelle (snap_sam) vaut +0.0241, et aucune variante ne la bat :

  | Variante | Effet sur la CV moyenne |
  |---|---|
  | règle actuelle (snap_sam) | **+0.0241** |
  | MLP listwise, tous les segments | +0.0203 |
  | MLP listwise, top 5 + base | +0.0228 |
  | décision logistique (même segment) | +0.0227 |
  | segment de mIoU attendu maximal | +0.0239 |
  | classeur linéaire, top 10 + base | +0.0233 |
  | choix de la variante par méthode (imbriqué) | +0.0254, soit seulement +0.0013 |

  - Même une décision parfaite « recaler ou non » ne vaut que +0.007 de plus.
  - L'oracle sur les 5 meilleurs segments de la règle vaut 0.741, contre 0.810 sur tous les segments : le bon segment est
    souvent hors du top 5 de la règle.
- **Décoder chaque segment SAM** (`seg_decode.py`, pilote sur 25 images F-seg par méthode ; détail dans COORD.md)
  - Principe : segment gardé, reste rempli (gris, flou ou couleur moyenne), décodage à 512.
  - **L'aire seule sépare mieux** les bons segments des mauvais (AUC 0.83 à 0.92) que tout score décodé (0.5 à 0.84).
  - Le top-1 du décodeur préfère les segments trop grands : −0.11 à −0.21 de mIoU par rapport à la règle actuelle.
  - Abandonné pour les 3 méthodes.

## 9. Commandes

```bash
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet/stack
E="headmulti remark headsyn headsyn2 wmunet wmunet0 wmunetF wmunetF0 wmunetH wmunetH0 wmunet2 wmunet20"
R="effb3_hp_glob effb3_hp_glob_stack rgb_hp_glob_synth8k loc_effv2s_hp_glob_stack loc_r50_hp_glob_stack loc_regy032_hp_glob_stack"

# version complète = v12a (CPU, ~5 min) : fusion + règles (+ mIoU attendu) + post + rectangles (sans rect3)
WMLOC_NO_RECT3=1 $PY v3.py --rect --rules_plus --runs $R --extras $E \
   --out ../submissions/submission_vX.pt --baseline_cv 9           # sans --submit : rien n'est envoyé
# (--dump réécrit maps/fused_*, utilisé par rect_seeded.py, rect_pairs.py et shapes2.py : à éviter sans raison)

# étape SAM (CPU, ~2 min) : lit rules_plus / rect3 dans le .json, rejoue, garde <stem>_sam.pt si la CV gagne
$PY sam_stage.py ../submissions/submission_vX.pt

# ajouter une source : la mettre dans W/runs/<nom>/ (runs U-Net) ou W/stack/maps/<tag>_{train,test}_<m>.npz (extras),
# puis l'ajouter à --runs ou --extras ; comparer la CV après SAM à celle de v12a_sam (0.7187), seuil +0.003.
```

**Envoi au leaderboard : UNIQUEMENT avec le « oui » explicite de debbah2.**
- Commande : depuis `starter_kit/`, `$PY -c "from submission_template import submit; submit('<chemin>.pt')"`.
- **Ne jamais exécuter `submission_template.py` tel quel** : il envoie automatiquement.
- Il faut environ 144 s entre deux envois de l'équipe (sinon erreur 429 : attendre le délai indiqué, puis renvoyer).

## 10. Règles du cluster (JURECA)

- **Réservation `cispahack`** :
  - **un seul job à la fois pour toute l'équipe**, en cours et en attente confondus ;
  - vérifier avant tout sbatch :
    `squeue -r --reservation=cispahack -h -o "%u|%T|%Z" | grep /p/scratch/training2666/ayadi1/automateam2` ;
  - **la réservation est « magnétique »** : un job du compte training2666 sur dc-gpu y atterrit **même sans `--reservation`** ;
  - un coéquipier y a souvent déjà un job ; nos agents n'y soumettent jamais.
- **Partition `dc-gpu-devel`** (utilisée pour nos jobs GPU) :
  - 12 nœuds hors réservation, compte autorisé ;
  - 2 h maximum, 2 jobs en cours et 4 soumis par utilisateur ;
  - **un slot par agent** (A et B) ;
  - soumettre depuis le dossier d'équipe, puis vérifier `scontrol show job <id> | grep Reservation` (doit être vide).
- **Soumission d'un job** : seulement avec l'accord de debbah2. Le filtre de permissions peut bloquer le `sbatch` de
  l'agent même après cet accord ; dans ce cas, debbah2 soumet le script lui-même.
- **GPU des nœuds de login** : partagés et déconseillés. CPU du nœud de login : 8 threads au plus pour les pilotes.
- **Quota d'inodes plein sur /p/scratch** : peu de gros fichiers, et seulement sous /p/project1/training2666/debbah2/.
- **Données personnelles** : ne transmettre à aucun service externe l'adresse e-mail ni aucune information personnelle.

## 11. Marge restante, mesurée sur les masques OOF de v7 (avant SAM)

Gain possible sur le score global, par catégorie d'image (par méthode : 85 T, 43 F-rect, 42 F-seg) :

| Catégorie | Score v7 | Plafond si on choisit le meilleur segment SAM | Plafond parfait (mIoU = 1) |
|---|---|---|---|
| T (trous) | 0.664 | +0.000 (les trous ne sont pas des segments SAM) | **+0.168** |
| F-rect | 0.706 | +0.010 | +0.074 |
| F-seg | 0.696 | +0.062 (SAM en a déjà pris environ +0.024) | +0.075 |

- Depuis v7 :
  - la règle du mIoU attendu a apporté T +0.007 et F-seg +0.008 ;
  - les U-Nets locaux ont apporté T +0.012, F-rect +0.006 et F-seg +0.006, tout sur StegaStamp.
- **Un +0.1 sûr n'existe pas.**
  - Le levier principal reste **la qualité des cartes**, surtout pour les trous du type T.
  - La diversité d'architectures est ce qui a le plus aidé en dernier : v12a, +0.029 sur StegaStamp.

## 12. Pistes restantes (gain estimé)

- **Nouvelles graines ou architectures des U-Nets « stack »** sur la machine de debbah2 (effv2s, regy032 surtout) :
  c'est ce qui a donné le dernier gain, sur StegaStamp. Il suffit de déposer `oof_all.npz` et `test_mean.npz` dans
  `W/runs/loc_<nom>/`, puis de l'ajouter à `--runs`.
- **Sources par méthode** : v3.py utilise les mêmes `--runs` et `--extras` pour les 3 méthodes. Les U-Nets locaux coûtent
  −0.002 à PixelSeal ; un jeu de sources par méthode les éviterait. Gain d'environ +0.001, à valider en CV imbriquée.
- **Cartes de B** (`wmunetTi2`, `plwmunetT*`) : à tester sur la base v12a, sans les inclure par défaut.
- **Réduire de 2 px les boîtes StegaStamp avant la conversion en 128** : environ +0.001 au total.
- **Choix appris du segment SAM pour TrustMark seulement** (variante « mIoU attendu ») : environ +0.003, choisi après coup ; non retenu.
