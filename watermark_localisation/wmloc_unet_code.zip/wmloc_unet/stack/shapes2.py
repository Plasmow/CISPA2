"""Shape-pooled decoding of the fused map (CPU only).

Instead of deciding cell by cell, score WHOLE shape hypotheses and pick one per image:
  - "sliding rectangles": every axis-aligned rectangle is scored by the sum of (logit - b) it covers (exact maximum-sum
    sub-rectangle, all positions and sizes); for type F the region, for type T a rectangular hole;
  - the shape families of shapes.py (thresholds x {raw, largest, fill, drop small, close, open}), the decoder box, all-0/1.
Then a LEARNED selector (small listwise MLP, trained with the ground truth on the other folds) predicts the mIoU of every
candidate from label-free features (expected mIoU under the map, area, components, rectangularity, family, box bit acc,
type confidence) and keeps the best one per image. Reported score is out-of-fold; the test masks use a selector refit on
the whole train split.

    python shapes2.py --out ../submissions/submission_v6_shapes.pt
"""
import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

from v3 import HERE, ROOT, METHODS, load_split, miou_batch, load_rect, folds
from shapes import candidates, expected_miou, comps
from evalkit import fit_switch

RECT_THR = 0.85
FAMS = ["all0", "all1", "raw", "largest", "largest+fill", "drop<16", "drop<64", "fill", "close3+fill", "open3",
        "box", "box-holes", "box+largest", "rectfit"]


def max_rect(S):
    """Maximum-sum axis-aligned sub-rectangle of S [H,W] -> (value, y0, y1, x0, x1) inclusive-exclusive."""
    H, W = S.shape
    Cr = np.vstack([np.zeros((1, W)), np.cumsum(S, 0)])                         # [H+1, W]
    band = Cr[None, 1:, :] - Cr[:H, None, :]                                    # [y0, y1, W] = rows y0..y1
    P = np.concatenate([np.zeros((H, H, 1)), np.cumsum(band, 2)], 2)            # [y0, y1, W+1]
    run_min = np.minimum.accumulate(P, 2)
    gain = P[:, :, 1:] - run_min[:, :, :-1]                                     # best rect ending at x1 (exclusive x1+1)
    tri = np.triu(np.ones((H, H), bool))                                        # y1 >= y0
    gain = np.where(tri[:, :, None], gain, -np.inf)
    k = int(np.argmax(gain)); y0, y1, x1 = np.unravel_index(k, gain.shape)
    x0 = int(np.argmin(P[y0, y1, :x1 + 1]))
    return float(gain[y0, y1, x1]), int(y0), int(y1) + 1, x0, int(x1) + 1


def rect_candidates(L, typeT):
    out = {}
    for b in (0.0, 1.0, 2.0):
        S = (L - b) if not typeT else (-L - b)
        v, y0, y1, x0, x1 = max_rect(S.astype(np.float64))
        if v <= 0:
            continue
        m = np.zeros(L.shape, bool); m[y0:y1, x0:x1] = True
        out[f"rectfit{b}"] = ~m if typeT else m
    return out


def fam_of(k):
    k = k.split(":")[-1]
    if k.startswith("box-holes"):
        return "box-holes"
    if k.startswith("rectfit"):
        return "rectfit"
    return k


def feats(L, P, M, typeT, g, box_acc, key):
    n = M.size; a = M.mean(); minority = ~M if typeT else M
    lab, sz = comps(minority)
    nb = len(sz); big = sz.max() / n if nb else 0.0
    if minority.any():
        ys, xs = np.where(minority); bb = (ys.max() - ys.min() + 1) * (xs.max() - xs.min() + 1); rectness = minority.sum() / bb
    else:
        rectness = 0.0
    e = [expected_miou(1 / (1 + np.exp(-L / T)), M) for T in (0.5, 1.0, 2.0)]
    lin = L[M].mean() if M.any() else 0.0; lout = L[~M].mean() if (~M).any() else 0.0
    t = float(key.split(":")[0][1:]) if key.startswith("t") and ":" in key else -1.0
    f = [*e, a, minority.mean(), nb, np.log1p(nb), big, rectness, lin, lout, lin - lout, float(typeT), g, box_acc, t,
         (P > 0.5).mean(), P.mean(), np.abs(P - 0.5).mean()]
    oh = [0.0] * len(FAMS); oh[FAMS.index(fam_of(key))] = 1.0
    return f + oh


def build(L_all, g, typT, names, B):
    """-> per image: keys, masks [K,128,128], features [K,F]."""
    out = []
    for i in range(len(L_all)):
        L = L_all[i].astype(np.float64); P = 1 / (1 + np.exp(-L))
        has = names[i] in B and B[names[i]][1] >= RECT_THR
        box = B[names[i]][0] if has else None; acc = B[names[i]][1] if names[i] in B else -1.0
        C = candidates(P, bool(typT[i]), box); C.update(rect_candidates(L, bool(typT[i])))
        keys = list(C); masks = np.stack([C[k] for k in keys])
        X = np.array([feats(L, P, masks[j], bool(typT[i]), g[i], acc, keys[j]) for j in range(len(keys))], np.float32)
        out.append((keys, masks, X))
    return out


class Sel:
    """Listwise selector: small MLP scoring every candidate of an image; trained with a softmax cross-entropy towards
    the candidates' true mIoU (sharpened), so it learns to rank the candidates of the same image."""
    def __init__(self, data, ys, idx, epochs=400, seed=0):
        torch.manual_seed(seed)
        X = np.concatenate([data[i][2] for i in idx]); self.mu = X.mean(0); self.sd = X.std(0) + 1e-6
        K = max(len(data[i][0]) for i in idx); F_ = X.shape[1]
        Xp = np.zeros((len(idx), K, F_), np.float32); Yp = np.full((len(idx), K), -1e9, np.float32); Mk = np.zeros((len(idx), K), bool)
        for r, i in enumerate(idx):
            k = len(data[i][0]); Xp[r, :k] = (data[i][2] - self.mu) / self.sd; Yp[r, :k] = ys[i]; Mk[r, :k] = True
        Xp, Yp, Mk = map(torch.from_numpy, (Xp, Yp, Mk))
        tgt = torch.softmax(torch.where(Mk, Yp / 0.02, torch.tensor(-1e9)), 1)
        self.net = torch.nn.Sequential(torch.nn.Linear(F_, 64), torch.nn.ReLU(), torch.nn.Linear(64, 64), torch.nn.ReLU(), torch.nn.Linear(64, 1))
        opt = torch.optim.Adam(self.net.parameters(), 3e-3, weight_decay=1e-4)
        for ep in range(epochs):
            s = self.net(Xp).squeeze(-1).masked_fill(~Mk, -1e9)
            loss = -(tgt * torch.log_softmax(s, 1)).sum(1).mean(); opt.zero_grad(); loss.backward(); opt.step()

    def predict(self, X):
        with torch.no_grad():
            return self.net(torch.from_numpy(((X - self.mu) / self.sd).astype(np.float32))).squeeze(-1).numpy()


def fit_sel(data, ys, idx):
    return Sel(data, ys, idx)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--maps", default="fused")
    ap.add_argument("--out", default=str(ROOT / "submissions" / "submission_v6_shapes.pt")); a = ap.parse_args()
    tr, te = load_split("train"), load_split("test"); meta_tr = {m["image_name"]: m for m in tr.meta}
    lines, final, report = [], {}, {}
    for meth in METHODS:
        z = np.load(HERE / "maps" / f"{a.maps}_train_{meth}.npz"); names = z["names"].tolist(); L = z["logit128"].astype(np.float32); g = z["g"]
        zt = np.load(HERE / "maps" / f"{a.maps}_test_{meth}.npz"); names_t = zt["names"].tolist(); Lt = zt["logit128"].astype(np.float32); gt_ = zt["g"]
        gt = np.stack([tr.m128[n] for n in names]).astype(bool); full = np.array([meta_tr[n]["full_watermark"] for n in names]); N = len(L)
        tg = fit_switch(L, gt, g, np.arange(N))["tg"]; typT = g > tg; typT_t = gt_ > tg
        has_test_boxes = bool(load_rect(meth, "test"))
        B = load_rect(meth, "train") if has_test_boxes else {}; Bt = load_rect(meth, "test") if has_test_boxes else {}
        data = build(L, g, typT, names, B)
        ys = [miou_batch(m, np.broadcast_to(gt[i], m.shape)) for i, (_, m, _) in enumerate(data)]
        oracle = np.array([y.max() for y in ys])
        # baseline: rect override then expected-mIoU (T=1) choice
        base = np.array([ys[i][int(np.argmax(data[i][2][:, 1]))] for i in range(N)])
        cv = np.zeros(N); picks = [None] * N
        for f in folds(N, 5, 7):
            trn = np.setdiff1d(np.arange(N), f); model = fit_sel(data, ys, trn)
            for i in f:
                j = int(np.argmax(model.predict(data[i][2]))); cv[i] = ys[i][j]; picks[i] = fam_of(data[i][0][j])
        from collections import Counter
        fam = Counter(picks).most_common(6)
        lines.append(f"| {meth} | {base.mean():.4f} | **{cv.mean():.4f}** | {cv[full].mean():.4f} | {cv[~full].mean():.4f} | {oracle.mean():.4f} | {fam} |")
        print(lines[-1], flush=True)
        # test
        model = fit_sel(data, ys, np.arange(N)); dt = build(Lt, gt_, typT_t, names_t, Bt)
        out = [dt[i][1][int(np.argmax(model.predict(dt[i][2])))] for i in range(len(dt))]
        final.update(zip(names_t, out))
        report[meth] = dict(cv=round(float(cv.mean()), 4), cv_T=round(float(cv[full].mean()), 4), cv_F=round(float(cv[~full].mean()), 4),
                            expected_miou_choice=round(float(base.mean()), 4), oracle=round(float(oracle.mean()), 4),
                            test_frac_pred_1=round(float(np.mean(out)), 3))
    names = [m["image_name"] for m in te.meta]; masks = np.stack([final[n] for n in names]).astype(bool)
    assert len(names) == len(set(names)) == 1020 and masks.shape == (1020, 128, 128)
    out_p = Path(a.out); torch.save({"image_names": names, "masks": torch.from_numpy(masks)}, out_p)
    report["expected_cv_mIoU"] = round(float(np.mean([report[m]["cv"] for m in METHODS])), 4); report["size_MB"] = round(os.path.getsize(out_p) / 2 ** 20, 2)
    hdr = ["| method | expected-mIoU choice | **learned selector (CV)** | type T | type F | oracle | most chosen |", "|---|---|---|---|---|---|---|"]
    (ROOT / f"results_{out_p.stem}.md").write_text("\n".join(hdr + lines) + "\n\n```json\n" + json.dumps(report, indent=1) + "\n```\n")
    (Path(a.out).with_suffix(".json")).write_text(json.dumps(report, indent=1))
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
