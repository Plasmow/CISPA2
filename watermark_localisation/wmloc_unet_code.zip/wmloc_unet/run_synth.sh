#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --time=02:00:00
#SBATCH --job-name=wm_synth
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/synth_%j.out
# General JURECA queue (NO cispahack reservation): allowed by the organisers, does not count toward the team's
# one-node limit. Submit from the team folder:
#   cd /p/scratch/training2666/ayadi1/automateam2 && sbatch /p/project1/training2666/debbah2/wmloc_unet/run_synth.sh
#
# GPU0: long synthetic pre-training, ResNet34 (40k steps)        -> 5-fold fine-tune on real (rgb_hp_glob)
# GPU1: 5-fold fine-tune on real from the existing 8k-step synthetic ResNet34
# GPU2: long synthetic pre-training, EfficientNet-B3 (40k steps) -> 5-fold fine-tune on real (effb3_hp_glob)
# GPU3: "everything connected" U-Net (effb3_hp_glob_stack), same run as on the local PC, faster here
# Then: CV evaluation of every run, and a candidate submission file (NOT uploaded).
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
R=/p/project1/training2666/debbah2/wmloc_unet; cd $R
EFF=efficientnet_b3.ra2_in1k
tagged() { grep --line-buffered -v -i -E "warn|Unexpected keys|ffmpeg" | sed -u "s/^/[$1] /"; }

( CUDA_VISIBLE_DEVICES=0 $PY synth/train_synth.py --name r34_hp_40k --steps 40000 --eval_every 5000 --workers 14 &&
  CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant rgb_hp_glob --epochs 60 --init synth/runs_synth/r34_hp_40k/model.pt --tag synth40k ) 2>&1 | tagged gpu0 &
( CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant rgb_hp_glob --epochs 60 --init synth/runs_synth/r34_hp/model.pt --tag synth8k ) 2>&1 | tagged gpu1 &
( CUDA_VISIBLE_DEVICES=2 $PY synth/train_synth.py --name effb3_hp_40k --encoder $EFF --steps 40000 --eval_every 5000 --workers 14 &&
  CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant effb3_hp_glob --epochs 60 --init synth/runs_synth/effb3_hp_40k/model.pt --tag synth40k ) 2>&1 | tagged gpu2 &
( CUDA_VISIBLE_DEVICES=3 $PY train_unet.py --variant effb3_hp_glob_stack --epochs 60 ) 2>&1 | tagged gpu3 &
wait

$PY eval_unet.py 2>&1 | grep -v -i warn
cd stack && $PY make_submission.py --out ../submissions/submission_v2.pt \
  --extra rgb_hp_glob_synth40k rgb_hp_glob_synth8k effb3_hp_glob_synth40k effb3_hp_glob_stack 2>&1 | grep -v -i warn
echo done
