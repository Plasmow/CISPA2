| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['head', 'effb3_hp_glob_stack'] | 0.5370 | 0.5358 | 0.5383 |
| pixelseal | fusion top3 ['head', 'effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.5367 | 0.5350 | 0.5384 |
| pixelseal | fusion all ['head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5360 | 0.5371 | 0.5350 |
| pixelseal | fusion top2 + rule switch | 0.5370 | 0.5358 | 0.5383 |
| pixelseal | fusion top2 + rule expected_area | 0.5395 | 0.5450 | 0.5340 |
| pixelseal | fusion top2 + rule otsu_in_regime | 0.5406 | 0.5431 | 0.5380 |
| pixelseal | fusion top2 + ORACLE per-image threshold (upper bound) | 0.5739 | 0.5833 | 0.5645 |
| pixelseal | fusion top2 + CV-selected rule (whole-train choice: otsu_in_regime) | 0.5389 | 0.5403 | 0.5375 |
| pixelseal | **v2 pipeline**: fusion top2 + otsu_in_regime + post T:fill_holes<64 / F:drop<256 | **0.5377** | 0.5405 | 0.5348 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['head', 'effb3_hp_glob_stack'] | 0.5253 | 0.5264 | 0.5243 |
| trustmark | fusion top3 ['head', 'effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.5278 | 0.5234 | 0.5322 |
| trustmark | fusion all ['head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.5293 | 0.5194 | 0.5393 |
| trustmark | fusion all + rule switch | 0.5293 | 0.5194 | 0.5393 |
| trustmark | fusion all + rule expected_area | 0.5474 | 0.5335 | 0.5612 |
| trustmark | fusion all + rule otsu_in_regime | 0.5359 | 0.5207 | 0.5512 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.5795 | 0.5619 | 0.5972 |
| trustmark | fusion all + CV-selected rule (whole-train choice: expected_area) | 0.5474 | 0.5335 | 0.5612 |
| trustmark | **v2 pipeline**: fusion all + expected_area + post T:fill_holes<256 / F:largest | **0.5557** | 0.5359 | 0.5755 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6786 | 0.7123 | 0.6450 |
| stegastamp | fusion all + rule switch | 0.6786 | 0.7123 | 0.6450 |
| stegastamp | fusion all + rule expected_area | 0.6822 | 0.7099 | 0.6546 |
| stegastamp | fusion all + rule otsu_in_regime | 0.6865 | 0.7178 | 0.6553 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7182 | 0.7440 | 0.6925 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: otsu_in_regime) | 0.6816 | 0.7111 | 0.6521 |
| stegastamp | **v2 pipeline**: fusion all + otsu_in_regime + post T:fill_holes<16 / F:largest | **0.6861** | 0.7174 | 0.6548 |

```json
{
 "pixelseal": {
  "map": "fusion top2",
  "sources": [
   "head",
   "effb3_hp_glob_stack"
  ],
  "rule": "otsu_in_regime",
  "post_T": "fill_holes<64",
  "post_F": "drop<256",
  "cv": 0.5377,
  "cv_T": 0.5405,
  "cv_F": 0.5348,
  "test_frac_pred_1": 0.464
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "expected_area",
  "post_T": "fill_holes<256",
  "post_F": "largest",
  "cv": 0.5557,
  "cv_T": 0.5359,
  "cv_F": 0.5755,
  "test_frac_pred_1": 0.495
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "otsu_in_regime",
  "post_T": "fill_holes<16",
  "post_F": "largest",
  "cv": 0.6861,
  "cv_T": 0.7174,
  "cv_F": 0.6548,
  "test_frac_pred_1": 0.489
 },
 "expected_cv_mIoU": 0.5932,
 "v1_cv": 0.5629,
 "file": "/p/project1/training2666/debbah2/wmloc_unet/submissions/submission_v2.pt",
 "size_MB": 15.96
}
```
