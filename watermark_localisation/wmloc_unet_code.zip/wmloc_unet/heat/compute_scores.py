"""Cache per-window scores: cache/scores_<split>_<method>.npz with names and s<w> = [N, ny, nx] for each size.
    python compute_scores.py <split> [methods...] [--sizes 96 128 192 256]"""
import argparse, sys, time
import numpy as np
sys.path.insert(0, "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/loc")
from common import load_split, load_watermark, KIT
from heatmap import score_windows, SIZES
from pathlib import Path
ap = argparse.ArgumentParser(); ap.add_argument("split"); ap.add_argument("methods", nargs="*", default=["pixelseal", "trustmark", "stegastamp"])
ap.add_argument("--sizes", type=int, nargs="+", default=list(SIZES)); a = ap.parse_args()
for meth in a.methods:
    ds = load_split(a.split, [meth]); wm = load_watermark(meth, KIT / "models", "cuda")
    S = {w: [] for w in a.sizes}; names = []; t = time.time()
    for i in range(len(ds)):
        it = ds[i]; sc = score_windows(wm, it["image"], it["message"], meth, a.sizes)
        for w in a.sizes: S[w].append(sc[w])
        names.append(it["image_name"])
        if i % 50 == 0: print(a.split, meth, i, f"{time.time()-t:.0f}s", flush=True)
    np.savez(Path(__file__).parent / "cache" / f"scores_{a.split}_{meth}.npz", names=np.array(names),
             **{f"s{w}": np.stack(S[w]) for w in a.sizes})
    print("wrote", a.split, meth, f"{time.time()-t:.0f}s", flush=True)
