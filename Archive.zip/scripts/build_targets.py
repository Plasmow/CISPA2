"""Build per-image soft targets that approximate what a model that never saw the image would predict.

Idea: the original model has memorised the exact forget images, but under strong perturbations the memorisation
breaks (diagnostic: ~50% accuracy at crop 0.25 / noise 0.2). Averaging the original's predictions over many strong
perturbations of an image gives
  - high confidence on "easy" images (still classified correctly when perturbed),
  - low confidence / a wrong class on "hard" images (and the wrong class it drifts to is a natural confusion).
The perturbation strength is a knob that sets how much is forgotten on average.

Saves output/targets/<name>.pt with {"probs": [N,100] float32, "labels": pseudo-labels, "strength": ..., "stats": ...}.
Usage (from unlearning/):  python scripts/build_targets.py [--k 16]
"""
import argparse
import json

import torch
import torch.nn.functional as F

import common as C

# perturbation strength levels: arguments for common.augment (+ cutout fraction)
LEVELS = {
    "s1": dict(scale=(0.35, 0.8), rot_deg=15, bright=0.3, contrast=0.3, noise=0.08, cutout=0.0),
    "s2": dict(scale=(0.2, 0.6), rot_deg=20, bright=0.35, contrast=0.4, noise=0.12, cutout=0.1),
    "s3": dict(scale=(0.12, 0.45), rot_deg=25, bright=0.4, contrast=0.5, noise=0.15, cutout=0.2),
    "s4": dict(scale=(0.08, 0.3), rot_deg=30, bright=0.45, contrast=0.6, noise=0.2, cutout=0.25),
}


def _interp(a, b, t):
    out = {}
    for k in a:
        if isinstance(a[k], tuple):
            out[k] = tuple(x + t * (y - x) for x, y in zip(a[k], b[k]))
        else:
            out[k] = a[k] + t * (b[k] - a[k])
    return out


# in-between levels (s1 gives ~99% target accuracy, s2 ~71%): s1.2 ... s1.8
for _t in (0.2, 0.4, 0.6, 0.8):
    LEVELS[f"s1.{int(_t * 10)}"] = _interp(LEVELS["s1"], LEVELS["s2"], _t)


def cutout(x, g, frac):
    if frac <= 0:
        return x
    B, _, H, W = x.shape
    s = int(H * frac ** 0.5)
    rows = torch.randint(0, H - s + 1, (B,), generator=g, device=x.device)
    cols = torch.randint(0, W - s + 1, (B,), generator=g, device=x.device)
    ar = torch.arange(H, device=x.device)
    mr = (ar[None] >= rows[:, None]) & (ar[None] < rows[:, None] + s)
    mc = (ar[None] >= cols[:, None]) & (ar[None] < cols[:, None] + s)
    m = (mr[:, :, None] & mc[:, None, :])[:, None]
    return torch.where(m, torch.full_like(x, 0.5), x)


@torch.no_grad()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=16, help="perturbations per image")
    ap.add_argument("--bs", type=int, default=250)
    ap.add_argument("--levels", default="", help="comma-separated subset of level names (default: all)")
    a = ap.parse_args()
    levels = {k: LEVELS[k] for k in a.levels.split(",")} if a.levels else LEVELS
    out = C.ROOT / "output" / "targets"
    out.mkdir(parents=True, exist_ok=True)

    teacher, imgs = C.load_all()
    N = len(imgs)
    clean = torch.cat([teacher(C.norm(C.u8_to01(imgs[i:i + a.bs]))).float() for i in range(0, N, a.bs)])
    labels = clean.argmax(1)
    summary = {}
    for name, lv in levels.items():
        g = torch.Generator(device=C.DEVICE).manual_seed(0)
        lv = dict(lv)
        cf = lv.pop("cutout")
        probs = torch.zeros(N, 100, device=C.DEVICE)
        logp_sum = torch.zeros(N, 100, device=C.DEVICE)
        for i in range(0, N, a.bs):
            x = C.u8_to01(imgs[i:i + a.bs])
            for _ in range(a.k):
                xa = C.norm(cutout(C.augment(x, g, **lv), g, cf))
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    lo = teacher(xa).float()
                probs[i:i + a.bs] += F.softmax(lo, -1) / a.k
                logp_sum[i:i + a.bs] += F.log_softmax(lo, -1) / a.k
        # two aggregations: arithmetic mean of probs (softer) and geometric mean (sharper)
        geo = F.softmax(logp_sum, -1)
        st = {}
        for agg, p in (("mean", probs), ("geo", geo)):
            loss = -p.clamp_min(1e-12).log().gather(1, labels[:, None])[:, 0]
            wrong = p.argmax(1) != labels
            st[agg] = {
                "acc": 1 - wrong.float().mean().item(),
                "loss_mean": loss.mean().item(), "loss_std": loss.std().item(),
                "maxp": p.max(1).values.mean().item(),
                "wrong_is_clean_top2": (p.argmax(1)[wrong] == clean.topk(2, 1).indices[wrong, 1]).float().mean().item()
                if wrong.any() else float("nan"),
            }
        summary[name] = st
        print(name, json.dumps(st), flush=True)
        torch.save({"probs_mean": probs.cpu(), "probs_geo": geo.cpu(), "labels": labels.cpu(),
                    "level": LEVELS[name], "k": a.k, "stats": st}, out / f"{name}.pt")
    sp = out / "summary.json"
    old = json.loads(sp.read_text()) if sp.exists() else {}
    old.update(summary)
    sp.write_text(json.dumps(old, indent=1))


if __name__ == "__main__":
    main()
