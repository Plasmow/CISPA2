"""Train the 128x128 U-Net with 5-fold CV on the train split (folds stratified by method x regime).
For each fold: trains on 4/5, saves out-of-fold probabilities on the held-out 1/5 and probabilities on the whole
test set (TTA: 4 flips), plus the weights and a log.

    python train_unet.py --variant rgb --folds 0 1 2 3 4
Outputs: runs/<variant>/fold<k>/{oof.npz, test.npz, model.pt, log.json}

Residual inputs (precompute_residual.py -> feats/residual_<split>.npz):
  res_aux  : 6 local correlation maps 128x128 (r = embed(x,m)-x and Delta = r(x,m)-r(x,1-m)) -> decoder aux input
  res_prod : 2 pixel-level normalised products hp(x).hp(r), hp(x).hp(Delta) 512x512 -> extra encoder input channels
Both are standardised per channel with train statistics and clipped to +-5.
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
TASK = Path(os.environ.get("WMLOC_TASK", "/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task"))   # data root (release/, starter_kit/, loc/)
sys.path.insert(0, str(TASK / "starter_kit")); sys.path.insert(0, str(HERE))
from wmloc.data import LocalisationDataset  # noqa: E402
from unet import UNet128, miou_loss  # noqa: E402

METHODS = ("pixelseal", "trustmark", "stegastamp")
EFF = "efficientnet_b3.ra2_in1k"
VARIANTS = {   # name -> model kwargs (+ res_aux / res_prod flags)
    "rgb": dict(highpass=False, glob_dim=0),
    "rgb_glob": dict(highpass=False, glob_dim=5),
    "rgb_hp_glob": dict(highpass=True, glob_dim=5),
    "effb3_hp_glob": dict(highpass=True, glob_dim=5, encoder=EFF),
    "rgb_glob_res": dict(highpass=False, glob_dim=5, res_aux=True, res_prod=True),
    "effb3_hp_glob_res": dict(highpass=True, glob_dim=5, encoder=EFF, res_aux=True, res_prod=True),
    "effb3_hp_glob_resaux": dict(highpass=True, glob_dim=5, encoder=EFF, res_aux=True),
    "effb3_hp_glob_resprod": dict(highpass=True, glob_dim=5, encoder=EFF, res_prod=True),
    # "everything connected": stacked maps (head logit, detector per-position conf, heatmap) as decoder aux input
    "rgb_glob_stack": dict(highpass=False, glob_dim=5, stack=True),
    "effb3_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder=EFF, stack=True),
    "effb3_hp_glob_stack_resaux": dict(highpass=True, glob_dim=5, encoder=EFF, stack=True, res_aux=True),
    "effb3_hp_glob_stack_res": dict(highpass=True, glob_dim=5, encoder=EFF, stack=True, res_aux=True, res_prod=True),
    # other encoder families for the fusion (diversity); all expose 5 feature levels (strides 2..32)
    "r50_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="resnet50.a1_in1k", stack=True),
    "effv2s_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="tf_efficientnetv2_s.in21k_ft_in1k", stack=True),
    "regy032_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="regnety_032.ra_in1k", stack=True),
    "r34_hp_glob_stack": dict(highpass=True, glob_dim=5, stack=True),   # ResNet34, can start from the synthetic r34_hp model
    # encoder zoo (22/11 11:30, weights already in hf/hub), same recipe, for fusion diversity
    "zeffb4_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="efficientnet_b4.ra2_in1k", stack=True),
    "zhrw18_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="hrnet_w18.ms_aug_in1k", stack=True),
    "zregy040_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="regnety_040.ra3_in1k", stack=True),
    "zrx50_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="resnext50_32x4d.a1h_in1k", stack=True),
    "zr2n50_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="res2net50_26w_4s.in1k", stack=True),
    "zserx50_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="seresnext50_32x4d.gluon_in1k", stack=True),
    "zeffv2m_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="tf_efficientnetv2_m.in21k_ft_in1k", stack=True),
    "zregz_hp_glob_stack": dict(highpass=True, glob_dim=5, encoder="regnetz_d8.ra3_in1k", stack=True),
}


def load(split, res=False, stack=False):
    ds = LocalisationDataset(TASK / "release", split)
    imgs = np.stack([np.asarray(ds[i]["image"]) for i in range(len(ds))])                 # N,512,512,3 uint8
    names = [m["image_name"] for m in ds.meta]; meth = np.array([METHODS.index(m["method"]) for m in ds.meta])
    msgs = [np.array([int(c) for c in m["message"]], np.float32) for m in ds.meta]
    gl = np.load(TASK / "loc" / "cache" / f"global_{split}.npy", allow_pickle=True).item()
    lut = {n: l for mm in METHODS for n, l in zip(gl[mm]["names"], gl[mm]["logits"])}
    conf = np.array([(lut[n] * (m * 2 - 1)).mean() for n, m in zip(names, msgs)])
    acc = np.array([((lut[n] > 0) == (m > 0)).mean() - 0.5 for n, m in zip(names, msgs)])
    glob = np.concatenate([np.eye(3)[meth], conf[:, None] / 5, acc[:, None] * 2], 1).astype(np.float32)
    out = dict(names=names, imgs=torch.from_numpy(imgs).permute(0, 3, 1, 2).contiguous(), meth=meth, glob=glob)
    if ds.train:
        out["mask"] = torch.from_numpy(np.stack([ds.m128[n] for n in names]).astype(np.float32))
        out["full"] = np.array([m["full_watermark"] for m in ds.meta])
    if res:
        z = np.load(HERE / "feats" / f"residual_{split}.npz")
        assert z["names"].tolist() == names, "residual feature order != metadata order"
        out["res_aux"] = torch.from_numpy(z["aux"]); out["prod"] = torch.from_numpy(z["prod"])
    if stack:
        z = np.load(HERE / "stack" / "maps" / f"stack_{split}.npz")
        assert z["names"].tolist() == names, "stack map order != metadata order"
        out["stack"] = torch.from_numpy(z["aux"])
    return out


def standardise(tr, te, key):
    """Per-channel mean/std on train (float64 accumulation), applied to both splits, clipped to +-5, stored fp16."""
    x = tr[key].float()
    mu = x.mean((0, 2, 3), keepdim=True); sd = x.std((0, 2, 3), keepdim=True) + 1e-6
    for d in (tr, te):
        d[key] = ((d[key].float() - mu) / sd).clamp(-5, 5).half()
    return mu.flatten().tolist(), sd.flatten().tolist()


def strat_folds(meth, full, k=5, seed=0):
    rng = np.random.RandomState(seed); fold = np.zeros(len(meth), int)
    for m in np.unique(meth):
        for f in (False, True):
            idx = rng.permutation(np.where((meth == m) & (full == f))[0])
            fold[idx] = np.arange(len(idx)) % k
    return fold


def dihedral(x, k):
    """k in 0..7: rot90 k%4 then hflip if k>=4. Works on [..., H, W]."""
    x = torch.rot90(x, k % 4, dims=(-2, -1))
    return torch.flip(x, dims=(-1,)) if k >= 4 else x


def miou_official(pred, gt):
    p, g = pred.bool().flatten(1), gt.bool().flatten(1); n = p.shape[1]
    i1 = (p & g).sum(1).float(); u1 = (p | g).sum(1).float(); i0 = n - u1; u0 = n - i1
    return ((torch.where(u1 == 0, 1.0, i1 / u1.clamp(min=1)) + torch.where(u0 == 0, 1.0, i0 / u0.clamp(min=1))) / 2)


def get_batch(d, ii, dev, use_aux, use_prod):
    x = d["imgs"][ii].to(dev, non_blocking=True).float() / 255
    g = torch.from_numpy(d["glob"][ii]).to(dev)
    aux = d["aux"][ii].to(dev).float() if use_aux else None
    ext = d["prod"][ii].to(dev).float() if use_prod else None
    return x, g, aux, ext


def tf(t, k):
    return None if t is None else dihedral(t, k)


@torch.no_grad()
def predict(model, d, idx, dev, use_aux, use_prod, bs=16, tta=(0, 2, 4, 6)):
    model.eval(); out = []
    for b in range(0, len(idx), bs):
        x, g, aux, ext = get_batch(d, idx[b:b + bs], dev, use_aux, use_prod)
        acc = 0
        for k in tta:
            with torch.autocast("cuda", dtype=torch.bfloat16):
                lg = model(dihedral(x, k), g, tf(aux, k), tf(ext, k)).float()
            if k >= 4:                                                   # invert the transform on the output
                lg = torch.flip(lg, dims=(-1,))
            acc = acc + torch.sigmoid(torch.rot90(lg, -(k % 4), dims=(-2, -1)))
        out.append((acc / len(tta)).cpu())
    return torch.cat(out)


def train_fold(args, tr, te, fold, dev):
    kw = dict(VARIANTS[args.variant]); enc = kw.pop("encoder", "resnet34.a1_in1k")
    kw.pop("res_aux", False); kw.pop("stack", False); use_prod = kw.pop("res_prod", False)
    use_aux = "aux" in tr; aux_ch = tr["aux"].shape[1] if use_aux else 0
    torch.manual_seed(fold + 1000 * len(args.tag))   # tag -> different init (zoo round 2)
    model = UNet128(encoder=enc, aux_ch=aux_ch, in_extra=2 if use_prod else 0, **kw)
    if args.init:                             # e.g. weights pre-trained on synthetic data; mismatched layers are skipped
        sd = torch.load(args.init, map_location="cpu"); own = model.state_dict()
        keep = {k: v.float() for k, v in sd.items() if k in own and own[k].shape == v.shape}
        model.load_state_dict(keep, strict=False)
        print(f"[init] loaded {len(keep)}/{len(own)} tensors from {args.init}", flush=True)
    model = model.to(dev).to(memory_format=torch.channels_last)
    enc_p = list(model.enc.parameters()); enc_ids = {id(p) for p in enc_p}
    dec_p = [p for p in model.parameters() if id(p) not in enc_ids]
    opt = torch.optim.AdamW([{"params": enc_p, "lr": args.lr_enc}, {"params": dec_p, "lr": args.lr}], weight_decay=1e-4)
    folds = strat_folds(tr["meth"], tr["full"])
    itr = np.where(folds != fold)[0]; iva = np.where(folds == fold)[0]
    steps_per_ep = int(np.ceil(len(itr) / args.bs)); total = steps_per_ep * args.epochs; warm = 2 * steps_per_ep
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / warm) * 0.5 * (1 + np.cos(np.pi * min(1, s / total))))
    log = []; t0 = time.time(); rng = np.random.RandomState(fold)
    for ep in range(args.epochs):
        model.train(); perm = rng.permutation(itr); tot = 0
        for b in range(0, len(perm), args.bs):
            ii = perm[b:b + args.bs]
            x, g, aux, ext = get_batch(tr, ii, dev, use_aux, use_prod); y = tr["mask"][ii].to(dev)
            k = rng.randint(8) if args.aug else 0                         # same transform on every spatial input
            x, y, aux, ext = dihedral(x, k), dihedral(y, k), tf(aux, k), tf(ext, k)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                lg = model(x.contiguous(memory_format=torch.channels_last), g, aux, ext)
            loss = F.binary_cross_entropy_with_logits(lg.float(), y) + miou_loss(lg, y)
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step(); sched.step(); tot += loss.item() * len(ii)
        rec = dict(ep=ep + 1, loss=tot / len(itr), t=round(time.time() - t0, 1))
        if (ep + 1) % args.eval_every == 0 or ep + 1 == args.epochs:
            p = predict(model, tr, iva, dev, use_aux, use_prod, tta=(0,))
            rec["val_miou@0.5"] = miou_official(p > 0.5, tr["mask"][iva]).mean().item()
        log.append(rec); print(f"[{args.variant} f{fold}] " + json.dumps(rec), flush=True)
    out = HERE / args.out_root / (args.variant + (f"_{args.tag}" if args.tag else "")) / f"fold{fold}"; out.mkdir(parents=True, exist_ok=True)
    p_va = predict(model, tr, iva, dev, use_aux, use_prod)
    s = miou_official(p_va > 0.5, tr["mask"][iva])
    print(f"[{args.variant} f{fold}] final val mIoU@0.5 TTA = {s.mean():.4f} | per method "
          + " ".join(f"{m}={s[torch.from_numpy(tr['meth'][iva] == j)].mean():.4f}" for j, m in enumerate(METHODS)), flush=True)
    np.savez(out / "oof.npz", names=np.array(tr["names"])[iva], prob=p_va.numpy().astype(np.float16))
    p_te = predict(model, te, np.arange(len(te["names"])), dev, use_aux, use_prod)
    np.savez(out / "test.npz", names=np.array(te["names"]), prob=p_te.numpy().astype(np.float16))
    torch.save({k: v.half() for k, v in model.state_dict().items()}, out / "model.pt")
    (out / "log.json").write_text(json.dumps(dict(args=vars(args), log=log, final_val=s.mean().item(),
                                                  norm=tr.get("norm"))))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", default="rgb", choices=list(VARIANTS))
    ap.add_argument("--folds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--epochs", type=int, default=80); ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--lr_enc", type=float, default=1e-4)
    ap.add_argument("--aug", type=int, default=1); ap.add_argument("--eval_every", type=int, default=10)
    ap.add_argument("--max_train", type=int, default=0, help="debug: subsample")
    ap.add_argument("--out_root", default="runs")
    ap.add_argument("--init", default="", help="state dict to start from (shape-matching tensors only)")
    ap.add_argument("--tag", default="", help="suffix of the run directory name")
    args = ap.parse_args()
    dev = "cuda"; torch.backends.cudnn.benchmark = True
    v = VARIANTS[args.variant]; res = v.get("res_aux", False) or v.get("res_prod", False); stack = v.get("stack", False)
    tr, te = load("train", res, stack), load("test", res, stack)
    for d in (tr, te):                       # decoder aux input = [stacked maps] + [residual local maps]
        parts = ([d.pop("stack")] if stack else []) + ([d.pop("res_aux")] if v.get("res_aux", False) else [])
        d.pop("res_aux", None)
        if parts:
            d["aux"] = torch.cat(parts, 1)
        if not v.get("res_prod", False):
            d.pop("prod", None)
    tr["norm"] = {k: standardise(tr, te, k) for k in ("aux", "prod") if k in tr}
    if args.max_train:
        for d in (tr, te):
            for k in ("imgs", "meth", "glob", "mask", "full", "aux", "prod"):
                if k in d: d[k] = d[k][:args.max_train]
            d["names"] = d["names"][:args.max_train]
    print(f"loaded train {tuple(tr['imgs'].shape)} test {tuple(te['imgs'].shape)} residual={res} stack={stack} "
          f"aux={tuple(tr['aux'].shape) if 'aux' in tr else None}", flush=True)
    for f in args.folds:
        train_fold(args, tr, te, f, dev)


if __name__ == "__main__":
    main()
