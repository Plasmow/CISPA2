The cispahack reservation is full (30/30 nodes) and several teams are holding multiple nodes, so other teams can't get in. Nodes here are exclusive: every job gets a whole node with 4 GPUs. Teams are allowed to use only node at a time. So two 1-GPU jobs = two nodes = a violation.

The rule: your whole team (everyone in /p/scratch/training2666/<lead>/<team>/) may run at most one job at a time, counting running and queued jobs.

Check your team before submitting (not squeue -u $USER — it can't see teammates):
T=$(pwd | grep -oE '/p/scratch/training2666/[^/]+/[^/]+')
squeue -r --reservation=cispahack -h -o "%u|%T|%Z" | grep "$T"
If anything shows up, your team already has its node — don't submit another.

Need more than 1 GPU? Use one job with #SBATCH --gres=gpu:4 and parallelise inside it — never two jobs.
More work to do? Chain it: sbatch --dependency=afterany:<jobid> next.sh. Don't stack a queue. Arrays: --array=0-N%1.
Always submit from inside your team folder.

If your team is on >1 node right now, please scancel down to one job immediately.
