| method | config | mIoU (CV) | type T | type F |
|---|---|---|---|---|
| pixelseal | source effb3_hp_glob | 0.4665 | 0.4635 | 0.4695 |
| pixelseal | source effb3_hp_glob_stack | 0.5078 | 0.5089 | 0.5067 |
| pixelseal | source rgb_hp_glob_synth8k | 0.4634 | 0.4690 | 0.4578 |
| pixelseal | source synth_zeroshot | 0.4466 | 0.4476 | 0.4457 |
| pixelseal | source headmulti | 0.5455 | 0.5530 | 0.5379 |
| pixelseal | source headsyn | 0.5616 | 0.5732 | 0.5499 |
| pixelseal | source headsyn2 | 0.5621 | 0.5756 | 0.5485 |
| pixelseal | source wmunet | 0.6079 | 0.6200 | 0.5957 |
| pixelseal | source wmunet0 | 0.5993 | 0.6058 | 0.5927 |
| pixelseal | source wmunetF | 0.5872 | 0.6068 | 0.5675 |
| pixelseal | source wmunetF0 | 0.5710 | 0.5799 | 0.5622 |
| pixelseal | source wmunet2 | 0.6114 | 0.6266 | 0.5962 |
| pixelseal | source wmunet20 | 0.6012 | 0.6080 | 0.5945 |
| pixelseal | source wmunetTi | 0.6159 | 0.6254 | 0.6063 |
| pixelseal | source wmunetTio | 0.5723 | 0.6133 | 0.5313 |
| pixelseal | source head | 0.5324 | 0.5304 | 0.5343 |
| pixelseal | fusion top2 ['wmunetTi', 'wmunet2'] | 0.6161 | 0.6288 | 0.6034 |
| pixelseal | fusion top3 ['wmunetTi', 'wmunet2', 'wmunet'] | 0.6157 | 0.6288 | 0.6026 |
| pixelseal | fusion all ['wmunetTi', 'wmunet2', 'wmunet', 'wmunet20', 'wmunet0', 'wmunetF', 'wmunetTio', 'wmunetF0', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6174 | 0.6284 | 0.6064 |
| pixelseal | fusion all + rule switch | 0.6174 | 0.6284 | 0.6064 |
| pixelseal | fusion all + rule expected_area | 0.6160 | 0.6343 | 0.5977 |
| pixelseal | fusion all + rule otsu_in_regime | 0.6186 | 0.6304 | 0.6068 |
| pixelseal | fusion all + rule regressed_area | 0.5953 | 0.6141 | 0.5764 |
| pixelseal | fusion all + rule emiou_none | 0.6233 | 0.6378 | 0.6088 |
| pixelseal | fusion all + rule emiouT|switch | 0.6219 | 0.6384 | 0.6055 |
| pixelseal | fusion all + rule emiouT|expected_area | 0.6181 | 0.6375 | 0.5987 |
| pixelseal | fusion all + rule emiouT|otsu_in_regime | 0.6220 | 0.6382 | 0.6058 |
| pixelseal | fusion all + rule emiouT|regressed_area | 0.6089 | 0.6360 | 0.5819 |
| pixelseal | fusion all + ORACLE per-image threshold (upper bound) | 0.6512 | 0.6661 | 0.6363 |
| pixelseal | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6217 | 0.6378 | 0.6057 |
| pixelseal | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<16 / F:largest | **0.6188** | 0.6366 | 0.6009 |
| pixelseal | + rect override none (boxes for 85 train images) | 0.6243 | 0.6359 | 0.6127 |
| pixelseal | + rect override rect>=0.7 (boxes for 85 train images) | 0.6411 | 0.6359 | 0.6463 |
| pixelseal | + rect override rect>=0.75 (boxes for 85 train images) | 0.6531 | 0.6359 | 0.6703 |
| pixelseal | + rect override rect>=0.8 (boxes for 85 train images) | 0.6548 | 0.6359 | 0.6738 |
| pixelseal | + rect override rect>=0.85 (boxes for 85 train images) | 0.6569 | 0.6359 | 0.6780 |
| pixelseal | + rect override rect>=0.9 (boxes for 85 train images) | 0.6459 | 0.6359 | 0.6559 |
| pixelseal | + rect override rect>=0.95 (boxes for 85 train images) | 0.6421 | 0.6359 | 0.6483 |
| pixelseal | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6569** | 0.6359 | 0.6780 |
| trustmark | source effb3_hp_glob | 0.4893 | 0.4656 | 0.5131 |
| trustmark | source effb3_hp_glob_stack | 0.5039 | 0.4897 | 0.5181 |
| trustmark | source rgb_hp_glob_synth8k | 0.4820 | 0.4744 | 0.4896 |
| trustmark | source synth_zeroshot | 0.4761 | 0.4577 | 0.4945 |
| trustmark | source headmulti | 0.5261 | 0.5380 | 0.5142 |
| trustmark | source headsyn | 0.5483 | 0.5672 | 0.5293 |
| trustmark | source headsyn2 | 0.5564 | 0.5758 | 0.5370 |
| trustmark | source wmunet | 0.6071 | 0.6136 | 0.6006 |
| trustmark | source wmunet0 | 0.5979 | 0.6005 | 0.5953 |
| trustmark | source wmunetF | 0.5850 | 0.5933 | 0.5767 |
| trustmark | source wmunetF0 | 0.5887 | 0.5964 | 0.5810 |
| trustmark | source wmunetTi | 0.6066 | 0.6245 | 0.5886 |
| trustmark | source wmunetTio | 0.5737 | 0.6192 | 0.5283 |
| trustmark | source head | 0.5167 | 0.5233 | 0.5102 |
| trustmark | fusion top2 ['wmunet', 'wmunetTi'] | 0.6115 | 0.6234 | 0.5996 |
| trustmark | fusion top3 ['wmunet', 'wmunetTi', 'wmunet0'] | 0.6151 | 0.6247 | 0.6055 |
| trustmark | fusion all ['wmunet', 'wmunetTi', 'wmunet0', 'wmunetF0', 'wmunetF', 'wmunetTio', 'headsyn2', 'headsyn', 'headmulti', 'head', 'effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'synth_zeroshot'] | 0.6152 | 0.6230 | 0.6075 |
| trustmark | fusion all + rule switch | 0.6152 | 0.6230 | 0.6075 |
| trustmark | fusion all + rule expected_area | 0.6201 | 0.6275 | 0.6127 |
| trustmark | fusion all + rule otsu_in_regime | 0.6194 | 0.6262 | 0.6125 |
| trustmark | fusion all + rule regressed_area | 0.6039 | 0.6179 | 0.5900 |
| trustmark | fusion all + rule emiou_none | 0.6255 | 0.6324 | 0.6186 |
| trustmark | fusion all + rule emiouT|switch | 0.6212 | 0.6323 | 0.6100 |
| trustmark | fusion all + rule emiouT|expected_area | 0.6226 | 0.6319 | 0.6133 |
| trustmark | fusion all + rule emiouT|otsu_in_regime | 0.6221 | 0.6322 | 0.6120 |
| trustmark | fusion all + rule emiouT|regressed_area | 0.6123 | 0.6311 | 0.5934 |
| trustmark | fusion all + ORACLE per-image threshold (upper bound) | 0.6538 | 0.6611 | 0.6465 |
| trustmark | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.6255 | 0.6324 | 0.6186 |
| trustmark | **v2 pipeline**: fusion all + emiou_none + post T:fill_holes<64 / F:largest | **0.6281** | 0.6322 | 0.6239 |
| trustmark | + rect override none (boxes for 86 train images) | 0.6281 | 0.6322 | 0.6239 |
| trustmark | + rect override rect>=0.7 (boxes for 86 train images) | 0.6548 | 0.6322 | 0.6774 |
| trustmark | + rect override rect>=0.75 (boxes for 86 train images) | 0.6813 | 0.6322 | 0.7304 |
| trustmark | + rect override rect>=0.8 (boxes for 86 train images) | 0.6888 | 0.6322 | 0.7453 |
| trustmark | + rect override rect>=0.85 (boxes for 86 train images) | 0.6918 | 0.6322 | 0.7514 |
| trustmark | + rect override rect>=0.9 (boxes for 86 train images) | 0.6918 | 0.6322 | 0.7514 |
| trustmark | + rect override rect>=0.95 (boxes for 86 train images) | 0.6918 | 0.6322 | 0.7514 |
| trustmark | **v3 + rect, CV-selected** (whole-train choice: rect>=0.85) | **0.6813** | 0.6322 | 0.7304 |
| stegastamp | source effb3_hp_glob | 0.6396 | 0.6735 | 0.6056 |
| stegastamp | source effb3_hp_glob_stack | 0.6535 | 0.6981 | 0.6089 |
| stegastamp | source rgb_hp_glob_synth8k | 0.6322 | 0.6632 | 0.6011 |
| stegastamp | source synth_zeroshot | 0.5781 | 0.5859 | 0.5702 |
| stegastamp | source headmulti | 0.5097 | 0.5210 | 0.4983 |
| stegastamp | source remark | 0.4636 | 0.4606 | 0.4666 |
| stegastamp | source headsyn2 | 0.5598 | 0.5928 | 0.5267 |
| stegastamp | source wmunet | 0.5922 | 0.6318 | 0.5526 |
| stegastamp | source wmunet0 | 0.5959 | 0.6264 | 0.5654 |
| stegastamp | source wmunetF | 0.5666 | 0.6006 | 0.5325 |
| stegastamp | source wmunetF0 | 0.5822 | 0.6136 | 0.5509 |
| stegastamp | source wmunetH | 0.5994 | 0.6289 | 0.5700 |
| stegastamp | source wmunetH0 | 0.6062 | 0.6322 | 0.5801 |
| stegastamp | source wmunetTi | 0.6040 | 0.6427 | 0.5654 |
| stegastamp | source wmunetTio | 0.5779 | 0.6451 | 0.5106 |
| stegastamp | fusion top2 ['effb3_hp_glob_stack', 'effb3_hp_glob'] | 0.6506 | 0.6891 | 0.6121 |
| stegastamp | fusion top3 ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k'] | 0.6675 | 0.7018 | 0.6332 |
| stegastamp | fusion all ['effb3_hp_glob_stack', 'effb3_hp_glob', 'rgb_hp_glob_synth8k', 'wmunetH0', 'wmunetTi', 'wmunetH', 'wmunet0', 'wmunet', 'wmunetF0', 'synth_zeroshot', 'wmunetTio', 'wmunetF', 'headsyn2', 'headmulti', 'remark'] | 0.6988 | 0.7435 | 0.6542 |
| stegastamp | fusion all + rule switch | 0.6988 | 0.7435 | 0.6542 |
| stegastamp | fusion all + rule expected_area | 0.7082 | 0.7433 | 0.6730 |
| stegastamp | fusion all + rule otsu_in_regime | 0.7060 | 0.7509 | 0.6611 |
| stegastamp | fusion all + rule regressed_area | 0.6879 | 0.7231 | 0.6528 |
| stegastamp | fusion all + rule emiou_none | 0.7193 | 0.7564 | 0.6822 |
| stegastamp | fusion all + rule emiouT|switch | 0.7037 | 0.7545 | 0.6528 |
| stegastamp | fusion all + rule emiouT|expected_area | 0.7147 | 0.7564 | 0.6731 |
| stegastamp | fusion all + rule emiouT|otsu_in_regime | 0.7083 | 0.7563 | 0.6603 |
| stegastamp | fusion all + rule emiouT|regressed_area | 0.7046 | 0.7564 | 0.6529 |
| stegastamp | fusion all + ORACLE per-image threshold (upper bound) | 0.7371 | 0.7683 | 0.7059 |
| stegastamp | fusion all + CV-selected rule (whole-train choice: emiou_none) | 0.7193 | 0.7564 | 0.6822 |
| stegastamp | **v2 pipeline**: fusion all + emiou_none + post T:close_holes3 / F:drop<64 | **0.7185** | 0.7576 | 0.6795 |
| stegastamp | + rect override none (boxes for 85 train images) | 0.7203 | 0.7576 | 0.6829 |
| stegastamp | + rect override rect>=0.7 (boxes for 85 train images) | 0.6829 | 0.7520 | 0.6139 |
| stegastamp | + rect override rect>=0.75 (boxes for 85 train images) | 0.7202 | 0.7520 | 0.6884 |
| stegastamp | + rect override rect>=0.8 (boxes for 85 train images) | 0.7282 | 0.7520 | 0.7044 |
| stegastamp | + rect override rect>=0.85 (boxes for 85 train images) | 0.7320 | 0.7520 | 0.7119 |
| stegastamp | + rect override rect>=0.9 (boxes for 85 train images) | 0.7348 | 0.7576 | 0.7119 |
| stegastamp | + rect override rect>=0.95 (boxes for 85 train images) | 0.7348 | 0.7576 | 0.7119 |
| stegastamp | **v3 + rect, CV-selected** (whole-train choice: rect>=0.9) | **0.7320** | 0.7520 | 0.7119 |

```json
{
 "pixelseal": {
  "map": "fusion all",
  "sources": [
   "wmunetTi",
   "wmunet2",
   "wmunet",
   "wmunet20",
   "wmunet0",
   "wmunetF",
   "wmunetTio",
   "wmunetF0",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<16",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6569,
  "cv_T": 0.6359,
  "cv_F": 0.678,
  "test_frac_pred_1": 0.49
 },
 "trustmark": {
  "map": "fusion all",
  "sources": [
   "wmunet",
   "wmunetTi",
   "wmunet0",
   "wmunetF0",
   "wmunetF",
   "wmunetTio",
   "headsyn2",
   "headsyn",
   "headmulti",
   "head",
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "synth_zeroshot"
  ],
  "rule": "emiou_none",
  "post_T": "fill_holes<64",
  "post_F": "largest",
  "rect": "rect>=0.85",
  "cv": 0.6813,
  "cv_T": 0.6322,
  "cv_F": 0.7304,
  "test_frac_pred_1": 0.494
 },
 "stegastamp": {
  "map": "fusion all",
  "sources": [
   "effb3_hp_glob_stack",
   "effb3_hp_glob",
   "rgb_hp_glob_synth8k",
   "wmunetH0",
   "wmunetTi",
   "wmunetH",
   "wmunet0",
   "wmunet",
   "wmunetF0",
   "synth_zeroshot",
   "wmunetTio",
   "wmunetF",
   "headsyn2",
   "headmulti",
   "remark"
  ],
  "rule": "emiou_none",
  "post_T": "close_holes3",
  "post_F": "drop<64",
  "rect": "rect>=0.9",
  "cv": 0.732,
  "cv_T": 0.752,
  "cv_F": 0.7119,
  "test_frac_pred_1": 0.494
 },
 "rules_plus": true,
 "rect3": false,
 "expected_cv_mIoU": 0.6901,
 "v1_cv": 0.5629,
 "file": "../submissions/submission_v11b.pt",
 "size_MB": 15.96
}
```
