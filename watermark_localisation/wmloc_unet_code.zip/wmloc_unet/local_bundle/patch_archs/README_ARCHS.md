# Patch : 3 architectures de plus pour la fusion

1. Copier `train_unet.py` et `unet.py` de ce patch dans le dossier `wmloc_local` (ils remplacent les anciens).
2. Copier `run_archs.sh` dans le même dossier et lancer : `bash run_archs.sh`
   - EfficientNetV2-S, puis ResNet50, puis RegNetY-032 (~1 h chacun sur RTX 4060, ~3 h au total).
   - Les poids ImageNet sont téléchargés par timm au premier lancement de chaque encodeur.
   - En cas de manque de mémoire GPU, le script relance automatiquement la variante en batch 4.
3. À renvoyer, au fur et à mesure (dès qu'une variante est finie, sans attendre les autres) :
   `runs/<variante>/oof_all.npz`, `runs/<variante>/test_mean.npz`, `train_<variante>.log`
   avec `<variante>` = `effv2s_hp_glob_stack`, `r50_hp_glob_stack`, `regy032_hp_glob_stack`.
