#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --reservation=cispahack
#SBATCH --time=02:00:00
#SBATCH --job-name=wm_unet_stack
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/unet_stack_%j.out
# Submit FROM THE TEAM FOLDER (scratch) so the team job check (%Z) sees it:
#   cd /p/scratch/training2666/ayadi1/automateam2 && sbatch /p/project1/training2666/debbah2/wmloc_unet/run_unet_stack.sh
# "Everything connected" U-Nets (stacked head / detector / heatmap maps) + residual variants, 2 variants per GPU.
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
cd /p/project1/training2666/debbah2/wmloc_unet
A=(effb3_hp_glob_stack effb3_hp_glob_stack_res effb3_hp_glob_stack_resaux effb3_hp_glob_resprod)
B=(rgb_glob_stack effb3_hp_glob_res effb3_hp_glob_resaux rgb_glob_res)
for k in 0 1 2 3; do
  ( CUDA_VISIBLE_DEVICES=$k $PY train_unet.py --variant ${A[$k]} --epochs 60 &&
    CUDA_VISIBLE_DEVICES=$k $PY train_unet.py --variant ${B[$k]} --epochs 60 ) 2>&1 \
    | grep --line-buffered -v -i -E "warn|Unexpected keys" | sed -u "s/^/[gpu$k] /" &
done
wait
$PY eval_unet.py 2>&1 | grep -v -i warn
echo done
