#!/bin/bash
# SCRUB-E sweep: SCRUB-C base (lr 3e-5, kd_T 4, msteps 8, 1 min/max) + three variants, 3 runs per GPU in sequence.
#   R = retain side   (more/stronger min steps, or freeze early blocks)
#   C = KL cap        (per-image cap on the max-step KL so the run settles instead of collapsing)
#   T = A1 target     (+ lam * CE(A1 soft target, student) in the max step: softer, better wrong class)
#SBATCH --job-name=scrubE
#SBATCH --account=training2666
#SBATCH --reservation=cispahack
#SBATCH --partition=dc-gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=32
#SBATCH --time=00:50:00
#SBATCH --output=output/%x-%j.out
#SBATCH --error=output/%x-%j.err

cd /p/scratch/training2666/ayadi1/automateam2/unlearning || exit 1
P=".venv/bin/python scripts/scrub.py --lr 3e-5 --kd_T 4 --epochs 10 --msteps 8 --min_per_max 1 --eval_every 30 --save_min 60 --save_max 420"
TG="--target output/targets/a1_m1.2_s2.4_T1.5_w0.5.pt"
run() { $P --run "$1" "${@:2}" > "output/$1.log" 2>&1; }
(export CUDA_VISIBLE_DEVICES=0
 run scrubE_R_mpm2 --min_per_max 2
 run scrubE_R_a3   --alpha 3
 run scrubE_R_fb6  --train_from_block 6) &
(export CUDA_VISIBLE_DEVICES=1
 run scrubE_C_cap10 --cap 10
 run scrubE_C_cap16 --cap 16
 run scrubE_C_cap24 --cap 24) &
(export CUDA_VISIBLE_DEVICES=2
 run scrubE_T_lam0.3 $TG --lam 0.3
 run scrubE_T_lam1   $TG --lam 1
 run scrubE_T_lam3   $TG --lam 3) &
(export CUDA_VISIBLE_DEVICES=3
 run scrubE_M_lam1_cap16  $TG --lam 1 --cap 16
 run scrubE_R_fb9         --train_from_block 9
 run scrubE_M_mpm2_lam1   $TG --lam 1 --min_per_max 2) &
wait
echo "done!"
