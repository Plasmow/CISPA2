"""SAM snapping, low-variance variants (CPU only). sam_rank.py's full listwise MLP over ~100 segments overfits on the 192
eligible train images (0.6786 vs 0.6887 for snap_sam). Here only low-variance alternatives, all strictly out-of-fold
(5 folds, seed 0, same folds as snap_sam's own CV; every parameter / model fitted on the 4 training folds only):

  ref     snap_sam: segment = argmax softIoU x contrast; snap if score >= s (s tuned in folds)
  dec     same segment, snap / no-snap decided by an L2 logistic regression on ~18 features of (segment, base, image),
          probability threshold tuned in folds
  emiou   segment = argmax expected mIoU under the map; snap if gain in expected mIoU over the base >= t (t tuned in folds)
  mix     segment = snap_sam's; snap if score >= s AND expected-mIoU gain >= t (s, t tuned in folds)
  lin     linear listwise ranker (no hidden layer, strong weight decay) over base + the 10 best segments by snap score

Report per method and per sub-type (F-rect / F-seg from the 512 ground truth) on the eligible images, + the effect on the
mean CV (sum of gains / 510). An option is worth integrating only if it gains >= +0.003 on the mean.

    python sam_rank2.py ../submissions/submission_v8.pt
"""
import sys
from pathlib import Path

import numpy as np
import torch

sys_argv = sys.argv; sys.argv = sys.argv[:2]                     # sam_rank reads an optional TOPK from argv[2]
import sam_rank as SR                                            # noqa: E402
sys.argv = sys_argv
from v3 import ROOT, METHODS, load_rect, folds, miou_batch, load_split  # noqa: E402

COL = dict(area=0, contrast=5, soft=6, sc=7, rank=9, mass=10, iou_base=11, iou_half=12, emiou=13, e1=14, e0=15, fill=16,
           ncomp=17, gacc=20, m0=21, base_area=24, pmean=25, pmax=26, pstd=27, phalf=28)


def logreg_fit(X, y, lam=1.0, iters=300):
    mu, sd = X.mean(0), X.std(0) + 1e-6; Z = np.c_[(X - mu) / sd, np.ones(len(X))]; w = np.zeros(Z.shape[1])
    for _ in range(iters):                                        # Newton steps (small problem)
        p = 1 / (1 + np.exp(-Z @ w)); g = Z.T @ (p - y) + lam * np.r_[w[:-1], 0]
        H = Z.T @ (Z * (p * (1 - p))[:, None]) + lam * np.diag(np.r_[np.ones(len(w) - 1), 0]) + 1e-6 * np.eye(len(w))
        w -= np.linalg.solve(H, g)
    return mu, sd, w


def logreg_pred(m, X):
    mu, sd, w = m; return 1 / (1 + np.exp(-(np.c_[(X - mu) / sd, np.ones(len(X))] @ w)))


def tune(vals_fn, grid, idx):
    """grid value maximising the mean score over idx; vals_fn(t) -> per-image scores."""
    return max(grid, key=lambda t: vals_fn(t)[idx].mean())


def main():
    sub = Path(sys.argv[1]).resolve(); stem = sub.stem; sd = ROOT / "sam" / stem
    import json
    cfg = json.loads(sub.with_suffix(".json").read_text())
    thr = {m: float(cfg[m]["rect"].split(">=")[1]) if cfg[m].get("rect", "none") != "none" else 9.0 for m in METHODS}
    rects = {n for m in METHODS for n, (_, acc) in load_rect(m, "train").items() if acc >= thr[m]}
    gacc, meth_of = SR.global_acc("train"); cands = SR.load_cands("train")
    d = torch.load(sd / "probs_train_oof.pt", weights_only=True); probs = {n: np.asarray(x, np.float32).ravel() for n, x in zip(d["image_names"], d["probs"].numpy())}
    d = torch.load(sd / "masks_train_oof.pt", weights_only=True); base = {n: np.asarray(x).ravel().astype(bool) for n, x in zip(d["image_names"], d["masks"].numpy())}
    tr = load_split("train"); gt = {n: tr.m128[n].astype(bool) for n in probs}
    names = [n for n in probs if gacc[n] < 0.8 and n not in rects and n in cands and len(cands[n])]
    sub_t = {}
    for i, m in enumerate(tr.meta):
        n = m["image_name"]
        if n in names:
            g5 = tr[i]["mask"].astype(bool); ys_, xs_ = np.where(g5)
            sub_t[n] = "F-rect" if g5.any() and g5.sum() == (np.ptp(ys_) + 1) * (np.ptp(xs_) + 1) else ("F-empty" if not g5.any() else "F-seg")
    data, ys = [], []
    for n in names:
        X, M = SR.feats(probs[n], base[n], cands[n], gacc[n], meth_of[n])
        data.append((X, M)); ys.append(miou_batch(M.reshape(-1, 128, 128), np.broadcast_to(gt[n], (len(M), 128, 128))))
    N_ = len(names); meths = np.array([meth_of[n] for n in names]); subs = np.array([sub_t[n] for n in names])
    sb = np.array([y[0] for y in ys])
    js = np.array([1 + int(np.argmax(X[1:, COL["sc"]])) for X, _ in data])            # snap_sam's segment
    ss = np.array([ys[i][js[i]] for i in range(N_)]); sc = np.array([data[i][0][js[i], COL["sc"]] for i in range(N_)])
    je = np.array([1 + int(np.argmax(X[1:, COL["emiou"]])) for X, _ in data])          # best expected mIoU segment
    se = np.array([ys[i][je[i]] for i in range(N_)])
    eg_s = np.array([data[i][0][js[i], COL["emiou"]] - data[i][0][0, COL["emiou"]] for i in range(N_)])
    eg_e = np.array([data[i][0][je[i], COL["emiou"]] - data[i][0][0, COL["emiou"]] for i in range(N_)])
    # decision features (segment row j vs base row 0)
    def dfeat(i):
        X = data[i][0]; j = js[i]; b = X[0]
        return np.r_[X[j, [COL[k] for k in ("sc", "contrast", "soft", "rank", "mass", "iou_base", "iou_half", "emiou", "e1", "e0", "fill", "ncomp", "area")]],
                     X[j, COL["emiou"]] - b[COL["emiou"]], np.log((X[j, COL["area"]] + 1e-4) / (b[COL["area"]] + 1e-4)),
                     b[[COL[k] for k in ("gacc", "m0", "m0")]] * np.r_[1, 1, 0] + np.r_[0, 0, X[j, COL["m0"] + 1]],
                     b[[COL["pmax"], COL["pstd"], COL["phalf"]]]]
    DX = np.stack([dfeat(i) for i in range(N_)]); Dy = (ss > sb).astype(float)
    S_GRID = np.r_[np.inf, np.quantile(sc, np.linspace(0, 1, 41))]; T_GRID = np.r_[np.inf, np.linspace(-0.1, 0.2, 31)]
    out = {k: np.zeros(N_) for k in ("ref", "dec", "emiou", "mix", "lin")}
    for f in folds(N_, 5, 0):
        trn = np.setdiff1d(np.arange(N_), f)
        s = tune(lambda t: np.where(sc >= t, ss, sb), S_GRID, trn); out["ref"][f] = np.where(sc[f] >= s, ss[f], sb[f])
        m = logreg_fit(DX[trn], Dy[trn], lam=3.0); p = logreg_pred(m, DX)
        tau = tune(lambda t: np.where(p >= t, ss, sb), np.r_[np.linspace(0.05, 0.95, 19), 2.0], trn); out["dec"][f] = np.where(p[f] >= tau, ss[f], sb[f])
        t = tune(lambda t: np.where(eg_e >= t, se, sb), T_GRID, trn); out["emiou"][f] = np.where(eg_e[f] >= t, se[f], sb[f])
        best = max(((s_, t_) for s_ in S_GRID[::4] for t_ in T_GRID[::3]),
                   key=lambda st: np.where((sc >= st[0]) & (eg_s >= st[1]), ss, sb)[trn].mean())
        out["mix"][f] = np.where((sc[f] >= best[0]) & (eg_s[f] >= best[1]), ss[f], sb[f])
        # linear listwise ranker over base + top-10 by snap score
        sel = [np.r_[0, 1 + np.argsort(-data[i][0][1:, COL["sc"]])[:10]] for i in range(N_)]
        dd = [(list(range(len(k))), None, data[i][0][k]) for i, k in enumerate(sel)]; yy = [ys[i][k] for i, k in enumerate(sel)]
        lin = SR.Sel.__new__(SR.Sel)
        X = np.concatenate([dd[i][2] for i in trn]); lin.mu = X.mean(0); lin.sd = X.std(0) + 1e-6
        K = 11; F_ = X.shape[1]; Xp = np.zeros((len(trn), K, F_), np.float32); Yp = np.full((len(trn), K), -1e9, np.float32); Mk = np.zeros((len(trn), K), bool)
        for r, i in enumerate(trn):
            k = len(dd[i][0]); Xp[r, :k] = (dd[i][2] - lin.mu) / lin.sd; Yp[r, :k] = yy[i]; Mk[r, :k] = True
        Xp, Yp, Mk = map(torch.from_numpy, (Xp, Yp, Mk)); tgt = torch.softmax(torch.where(Mk, Yp / 0.02, torch.tensor(-1e9)), 1)
        torch.manual_seed(0); lin.net = torch.nn.Linear(F_, 1); opt = torch.optim.Adam(lin.net.parameters(), 1e-2, weight_decay=1e-2)
        for _ in range(300):
            sco = lin.net(Xp).squeeze(-1).masked_fill(~Mk, -1e9); loss = -(tgt * torch.log_softmax(sco, 1)).sum(1).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        for i in f:
            j = int(np.argmax(lin.predict(dd[i][2]))); out["lin"][i] = yy[i][j]
    # per-method choice of the variant, nested: for each outer fold, the variant of each method is the best on the other folds
    pm = np.zeros(N_); picks = []
    for f in folds(N_, 5, 0):
        trn = np.setdiff1d(np.arange(N_), f)
        for m in METHODS:
            km = trn[meths[trn] == m]; best_v = max(out, key=lambda k: out[k][km].mean()); picks.append(f"{m[:2]}:{best_v}")
            fm = f[meths[f] == m]; pm[fm] = out[best_v][fm]
    out["per-method (nested)"] = pm
    lines = ["| variant | all (n=%d) | %s | F-rect | F-seg | effect on mean CV |" % (N_, " | ".join(METHODS)), "|---" * 6 + "|"]
    for k in ("ref", "dec", "emiou", "mix", "lin", "per-method (nested)"):
        v = out[k]; eff = (v.sum() - sb.sum()) / 510
        lines.append(f"| {k} | {v.mean():.4f} | " + " | ".join(f"{v[meths == m].mean():.4f}" for m in METHODS)
                     + f" | {v[subs == 'F-rect'].mean():.4f} | {v[subs == 'F-seg'].mean():.4f} | {eff:+.4f} |")
    v = sb; lines.append(f"| base (no SAM) | {v.mean():.4f} | " + " | ".join(f"{v[meths == m].mean():.4f}" for m in METHODS)
                         + f" | {v[subs == 'F-rect'].mean():.4f} | {v[subs == 'F-seg'].mean():.4f} | +0.0000 |")
    orc = np.maximum(ss, sb); lines.append(f"| oracle decision (snap_sam segment) | {orc.mean():.4f} | " + " | ".join(f"{orc[meths == m].mean():.4f}" for m in METHODS)
                                           + f" | {orc[subs == 'F-rect'].mean():.4f} | {orc[subs == 'F-seg'].mean():.4f} | {(orc.sum() - sb.sum()) / 510:+.4f} |")
    txt = f"eligible images: {N_} (F-rect {int((subs == 'F-rect').sum())}, F-seg {int((subs == 'F-seg').sum())}, F-empty {int((subs == 'F-empty').sum())})\n\n" + "\n".join(lines) + "\n"
    txt += "\nper-method picks per outer fold: " + " ".join(picks) + "\n"
    print(txt); (ROOT / f"results_{stem}_samrank2.md").write_text(txt)


if __name__ == "__main__":
    main()
