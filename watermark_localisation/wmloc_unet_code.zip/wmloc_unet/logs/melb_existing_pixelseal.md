| method | sources | switch CV of map | rule | all | T | F-rect | F-seg |
|---|---|---|---|---|---|---|---|
| pixelseal | wmunet_b4 alone | 0.6075 | switch | 0.6075 | 0.6207 | 0.4956 | 0.6953 |
| pixelseal | wmunet_b8 alone | 0.6078 | switch | 0.6078 | 0.6217 | 0.4959 | 0.6944 |
| pixelseal | wmunet2_b4 alone | 0.6111 | switch | 0.6111 | 0.6268 | 0.4967 | 0.6962 |
| pixelseal | wmunet2_b8 alone | 0.6112 | switch | 0.6112 | 0.6277 | 0.4971 | 0.6947 |
| pixelseal | base | 0.6151 | emiou_none | 0.6176 | 0.6341 | 0.4967 | 0.7080 |
| pixelseal | base | 0.6151 | emiou_none | 0.6176 | 0.6341 | 0.4967 | 0.7080 |
| pixelseal | base + wmunet_b8,wmunet2_b8 | 0.6148 | emiou_none | 0.6182 | 0.6354 | 0.4965 | 0.7078 |
| pixelseal | base + wmunet_b8,wmunet2_b8 | 0.6148 | emiou_none | 0.6182 | 0.6354 | 0.4965 | 0.7078 |
| pixelseal | base + wmunet_b4,wmunet2_b4,wmunet_b8,wmunet2_b8 | 0.6147 | emiou_none | 0.6171 | 0.6343 | 0.4965 | 0.7059 |
| pixelseal | base + wmunet_b4,wmunet2_b4,wmunet_b8,wmunet2_b8 | 0.6147 | emiou_none | 0.6171 | 0.6343 | 0.4965 | 0.7059 |
