#!/bin/bash
# SCRUB+R sweep, 4 configs in parallel (one per GPU): more max-steps, 1 min-step per max-step, kd_T 4 vs 8, lr 1e-5 vs 3e-5
P=".venv/bin/python scripts/scrub.py --epochs 10 --msteps 8 --min_per_max 1 --eval_every 30"
CUDA_VISIBLE_DEVICES=0 $P --run scrubB_A_lr1e-5_T4 --lr 1e-5 --kd_T 4 > output/scrubB_A.log 2>&1 &
CUDA_VISIBLE_DEVICES=1 $P --run scrubB_B_lr1e-5_T8 --lr 1e-5 --kd_T 8 > output/scrubB_B.log 2>&1 &
CUDA_VISIBLE_DEVICES=2 $P --run scrubB_C_lr3e-5_T4 --lr 3e-5 --kd_T 4 > output/scrubB_C.log 2>&1 &
CUDA_VISIBLE_DEVICES=3 $P --run scrubB_D_lr3e-5_T8 --lr 3e-5 --kd_T 8 > output/scrubB_D.log 2>&1 &
wait
