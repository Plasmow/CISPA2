"""Heat map (128x128 float) -> binary mask, thresholds learned by 5-fold CV, vectorised official mIoU.

Decision rules (all per method):
  - "single": mask = heat > t
  - "switch": regime decided by the whole-image score g (g > tg -> mostly watermarked):
        mostly-wm regime : mask = heat > t_hi   (finds the hole)
        mostly-clean     : mask = heat > t_lo   (finds the small watermarked part)
    tg, t_hi, t_lo all learned on the training folds.
"""
import numpy as np
import torch
import torch.nn.functional as F
from common import folds


def miou_batch(pred, gt):
    """pred, gt: [N,128,128] bool -> [N] official per-image mIoU."""
    p = np.asarray(pred, bool); g = np.asarray(gt, bool)
    out = np.zeros(len(p))
    for c in (False, True):
        pc, gc = p == c, g == c
        inter = (pc & gc).sum((1, 2)); union = (pc | gc).sum((1, 2))
        out += np.where(union == 0, 1.0, inter / np.maximum(union, 1))
    return out / 2


def miou_grid(heat, gt, thrs):
    """heat [N,H,W], gt [N,H,W] -> [len(thrs), N] mIoU for mask = heat > t (torch on GPU if available)."""
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    h = torch.as_tensor(heat, dtype=torch.float32, device=dev).flatten(1)
    g = torch.as_tensor(np.asarray(gt, bool), device=dev).flatten(1)
    g1 = g.sum(1).float(); n = h.shape[1]
    out = []
    for t in thrs:
        p = h > float(t)
        p1 = p.sum(1).float(); i1 = (p & g).sum(1).float()
        u1 = p1 + g1 - i1; i0 = n - u1; u0 = n - i1
        s = torch.where(u1 == 0, 1.0, i1 / u1.clamp(min=1)) + torch.where(u0 == 0, 1.0, i0 / u0.clamp(min=1))
        out.append(s / 2)
    return torch.stack(out).cpu().numpy()


def to128(m):
    """[N,h,w] map -> [N,128,128] by bilinear upsampling (align_corners=False) or 4x4 mean pooling if 512."""
    x = torch.as_tensor(np.asarray(m, np.float32))[:, None]
    if x.shape[-1] == 512:
        return F.avg_pool2d(x, 4)[:, 0].numpy()
    return F.interpolate(x, size=(128, 128), mode="bilinear", align_corners=False)[:, 0].numpy()


def thr_grid(heat, n=64):
    return np.unique(np.quantile(np.asarray(heat).ravel(), np.linspace(0, 1, n)))


def fit_single(heat, gt, idx):
    th = thr_grid(heat[idx]); s = miou_grid(heat[idx], gt[idx], th).mean(1)
    return dict(t=th[s.argmax()])


def apply_single(heat, p):
    return heat > p["t"]


def fit_switch(heat, gt, g, idx):
    """Learn tg on g (regime), then t_hi / t_lo separately on each regime's training images."""
    idx = np.asarray(idx)
    # regime threshold: maximise the all-1/all-0 baseline
    s1 = miou_batch(np.ones_like(gt[idx]), gt[idx]); s0 = miou_batch(np.zeros_like(gt[idx]), gt[idx])
    cands = np.unique(g[idx]); tg = max(cands, key=lambda t: np.where(g[idx] > t, s1, s0).mean())
    p = dict(tg=tg)
    for key, sel in (("t_hi", g[idx] > tg), ("t_lo", g[idx] <= tg)):
        ii = idx[sel]
        if len(ii) == 0:
            p[key] = np.inf if key == "t_lo" else -np.inf; continue
        th = np.concatenate([[-np.inf, np.inf], thr_grid(heat[ii])])
        s = miou_grid(heat[ii], gt[ii], th).mean(1)
        p[key] = th[s.argmax()]
    return p


def apply_switch(heat, g, p):
    t = np.where(g > p["tg"], p["t_hi"], p["t_lo"])[:, None, None]
    return heat > t


def cv_eval(heat, gt, g=None, rule="switch", k=5, seed=0, return_pred=False):
    """5-fold CV: fit on 4 folds, predict on the held-out fold. Returns per-image mIoU (and predictions)."""
    heat = np.asarray(heat, np.float32); gt = np.asarray(gt, bool)
    pred = np.zeros(gt.shape, bool)
    for f in folds(len(heat), k, seed):
        tr = np.setdiff1d(np.arange(len(heat)), f)
        if rule == "single":
            pred[f] = apply_single(heat[f], fit_single(heat, gt, tr))
        else:
            pred[f] = apply_switch(heat[f], g[f], fit_switch(heat, gt, g, tr))
    s = miou_batch(pred, gt)
    return (s, pred) if return_pred else s
