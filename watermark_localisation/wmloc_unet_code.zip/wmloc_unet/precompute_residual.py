"""Precompute residual-based inputs for every train/test image (metadata order):
  aux  [N,6,128,128] : local maps  raw_ncc8, raw_ncc16, raw_beta16 (r = embed(x,m)-x)
                                   comp_ncc16, comp_ncc32, comp_beta32 (Delta = r(x,m) - r(x,1-m), content term cancels)
  prod [N,2,512,512] : pixel-level normalised products  hp(x).hp(r) and hp(x).hp(Delta)
                       (sum over channels / sqrt(local energy of each, gaussian sigma 4))
Saved to feats/residual_<split>.npz (float16)."""
import sys
import time
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "starter_kit"))
from wmloc.data import LocalisationDataset  # noqa: E402
from wmloc.watermarks import load_watermark  # noqa: E402
from residual import residual_float, hp, local_maps  # noqa: E402
from unet import gaussian_blur  # noqa: E402

AUX = ["raw_ncc8", "raw_ncc16", "raw_beta16", "comp_ncc16", "comp_ncc32", "comp_beta32"]


def pix_ncc(a, b, s=4.0, eps=1e-3):
    num = (a * b).sum(0)[None, None]
    ea = gaussian_blur((a * a).sum(0)[None, None], s); eb = gaussian_blur((b * b).sum(0)[None, None], s)
    return (num / (ea * eb + eps ** 2).sqrt())[0, 0]


@torch.no_grad()
def feats(wm, img, msg):
    X = torch.from_numpy(np.asarray(img)).permute(2, 0, 1).float().cuda()
    r = residual_float(wm, img, msg); d = r - residual_float(wm, img, 1 - np.asarray(msg))
    hx, hr, hd = hp(X), hp(r), hp(d)
    a = local_maps(hx, hr, (8, 16)); b = local_maps(hx, hd, (16, 32))
    aux = torch.stack([a["ncc8"], a["ncc16"], a["beta16"], b["ncc16"], b["ncc32"], b["beta32"]])
    prod = torch.stack([pix_ncc(hx, hr), pix_ncc(hx, hd)])
    return aux.half().cpu().numpy(), prod.half().cpu().numpy()


def main():
    (HERE / "feats").mkdir(exist_ok=True)
    wms = {m: load_watermark(m, TASK / "starter_kit" / "models", "cuda") for m in ("pixelseal", "trustmark", "stegastamp")}
    for split in (sys.argv[1:] or ["train", "test"]):
        ds = LocalisationDataset(TASK / "release", split); N = len(ds)
        aux = np.zeros((N, len(AUX), 128, 128), np.float16); prod = np.zeros((N, 2, 512, 512), np.float16); t = time.time()
        for i in range(N):
            it = ds[i]; aux[i], prod[i] = feats(wms[it["method"]], it["image"], it["message"])
            if i % 200 == 0:
                print(split, i, f"{time.time() - t:.0f}s", flush=True)
        np.savez(HERE / "feats" / f"residual_{split}.npz", names=np.array([m["image_name"] for m in ds.meta]),
                 aux=aux, prod=prod, aux_names=np.array(AUX))
        print("wrote", split, aux.shape, prod.shape, f"{time.time() - t:.0f}s", flush=True)


if __name__ == "__main__":
    main()
