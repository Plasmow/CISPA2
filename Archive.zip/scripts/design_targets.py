"""Design per-image forget targets that maximise the (leaderboard-fitted) score model.

Gold model (fitted on 31 leaderboard scores, see lbfit.py / lbfit_land.py):
  p_gold(x) at T=2  ~ g(x)  (hypothesis: twins s0.625 average and/or orig tail with p_true 0.3)
  gold loss stats   mu + sigma ~ 12 (split unidentified, mu >= 2)
Target family: q_i = [t_i on the true class, (1 - t_i) * g_i(-y) / (1 - g_iy) elsewhere]  (T=2 distribution)
  -> KL(g_i || q_i) = binary KL(g_iy || t_i)  (cheap to make t tiny where gold's p_true is small)
  -> T=1 logits z_i = 2 log q_i, T=1 loss l_i = -2 log t_i + log sum_j q_ij^2
Maximise LDS(mean l, std l; mu, sigma) * PS over t (gradient ascent on logit t).
Writes output/targets/dz_<name>.pt with 'logits' [N,100] (T=1 target logits), 'q2' (T=2 probs), 'labels', 'stats'.
"""
import argparse, sys
import numpy as np, torch, torch.nn.functional as F
sys.path.insert(0, "scripts")
from lbfit_lib import *

ap = argparse.ArgumentParser()
ap.add_argument("--hyp", default="blend", choices=["tw", "tail", "blend", "blend12", "blend12w7", "tw12"])
ap.add_argument("--mu", type=float, default=4.0)
ap.add_argument("--sd", type=float, default=8.0)
ap.add_argument("--shrink", type=float, default=0.0, help="g_y <- (1-shrink) g_y + shrink * mean(g_y)  (robustness)")
ap.add_argument("--tmin", type=float, default=1e-9)
ap.add_argument("--name", default="")
ap.add_argument("--eval_only", action="store_true")
ap.add_argument("--iters", type=int, default=3000)
ap.add_argument("--tailP", type=float, default=0.3, help="gold p_true assumed by the 'tail' hypothesis")
ap.add_argument("--tail_tau", type=float, default=1.0, help="extra temperature of the orig tail shape (>1 broader)")
ap.add_argument("--init_noise", type=float, default=0.0, help="std of seeded noise on the initial logit(t) (symmetry breaking)")
ap.add_argument("--cap_gy_mult", type=float, default=1.0, help="multiply assumed gold p_true on the 130-cap classes")
ap.add_argument("--rest_w", type=float, default=-1, help="custom g: weight of tw12 in the wrong-class shape (rest is orig tail)")
ap.add_argument("--cap_gy", type=float, default=-1, help=">=0: gold p_true on the 9 130-cap classes set to this (class-removal hypothesis)")
ap.add_argument("--gy_w", type=float, default=0.5, help="custom g: g_y = gy_w * tw12_y + (1-gy_w) * 0.3")
a = ap.parse_args()
dev = "cuda" if torch.cuda.is_available() else "cpu"

orig = torch.load(LB / "orig.pt"); zo = orig["clean"].float().to(dev); y = zo.argmax(1); N = len(y)
oh = F.one_hot(y, 100).float()
tw = load_twins("0.625").to(dev)
g_tw = F.softmax(tw / T, -1).mean(1)
z = zo.clone(); z[torch.arange(N), y] = -1e4
g_tail = F.softmax(z / (T * a.tail_tau), -1) * (1 - a.tailP) + oh * a.tailP
G = {"tw": g_tw, "tail": g_tail, "blend": 0.5 * g_tw + 0.5 * g_tail}
if a.hyp == "tw12":
    G["tw12"] = F.softmax(torch.cat([tw, load_twins("0.625b").to(dev)], 1) / T, -1).mean(1)
if a.hyp.startswith("blend12"):
    g12 = F.softmax(torch.cat([tw, load_twins("0.625b").to(dev)], 1) / T, -1).mean(1)
    w = 0.7 if a.hyp == "blend12w7" else 0.5
    G[a.hyp] = w * g12 + (1 - w) * g_tail
g = G[a.hyp]
if a.rest_w >= 0:  # custom: wrong-class shape and true-class mass mixed separately
    g12c = F.softmax(torch.cat([tw, load_twins("0.625b").to(dev)], 1) / T, -1).mean(1)
    zt2 = zo.clone(); zt2[torch.arange(N, device=dev), zo.argmax(1)] = -1e4
    tail_rest = F.softmax(zt2 / T, -1)
    ohc = F.one_hot(zo.argmax(1), 100).float()
    tw_rest = g12c * (1 - ohc); tw_rest = tw_rest / tw_rest.sum(1, keepdim=True)
    rest_mix = a.rest_w * tw_rest + (1 - a.rest_w) * tail_rest
    gy_c = a.gy_w * (g12c * ohc).sum(1) + (1 - a.gy_w) * 0.3
    g = rest_mix * (1 - gy_c[:, None]) + ohc * gy_c[:, None]
if a.cap_gy >= 0:
    capm = torch.isin(y, CAP.to(dev))
    g = g.clone()
    rest_ = g * (1 - oh); rest_ = rest_ / rest_.sum(1, keepdim=True)
    gyc = (g * oh).sum(1); gyc[capm] = a.cap_gy
    g = rest_ * (1 - gyc[:, None]) + oh * gyc[:, None]
    print(f"cap-class hypothesis: {int(capm.sum())} images get gold p_true {a.cap_gy}")
gy = (g * oh).sum(1)
if a.shrink > 0:
    gy_s = (1 - a.shrink) * gy + a.shrink * gy.mean()
else:
    gy_s = gy
if a.cap_gy_mult != 1.0:
    capm = torch.isin(y, CAP.to(y.device))
    gy_s = gy_s.clone(); gy_s[capm] = (gy_s[capm] * a.cap_gy_mult).clamp(1e-3, 0.95)
    g = g * (1 - oh) / (1 - gy).clamp_min(1e-6)[:, None] * (1 - gy_s)[:, None] + oh * gy_s[:, None]
    gy = gy_s
    rest = g * (1 - oh); rest = rest / rest.sum(1, keepdim=True)
rest = g * (1 - oh); rest = rest / rest.sum(1, keepdim=True)          # wrong-class shape
lq_o = F.log_softmax(zo / T, -1)
D = kl_mean(g, lq_o)                                                     # PS denominator (clean)


def build(t):
    q = rest * (1 - t[:, None]) + oh * t[:, None]
    return q


def t1_loss(q):
    lq = q.clamp_min(1e-30).log()
    z1 = 2 * lq
    return -(F.log_softmax(z1, -1) * oh).sum(1)


def objective(t, mu, sd, gyv=gy_s):
    q = build(t)
    l = t1_loss(q)
    m, s = l.mean(), l.std()
    lds_ = 1 - ((m - mu).abs() + (s - sd).abs()) / (mu + sd)
    klb = gyv * (gyv / t).log() + (1 - gyv) * ((1 - gyv) / (1 - t)).log()
    ps = 1 - klb.mean() / D
    return lds_ * ps, lds_, ps, m, s


# init: t = g_y (PS-optimal), then optimise
u = torch.logit(gy_s.clamp(1e-4, 1 - 1e-4)).clone()
if a.init_noise > 0:
    u = u + a.init_noise * torch.randn(len(u), generator=torch.Generator().manual_seed(0)).to(u.device)
u = u.requires_grad_(True)
opt = torch.optim.Adam([u], lr=0.05)
for it in range(a.iters):
    t = torch.sigmoid(u).clamp(a.tmin, 1 - 1e-6)
    f, l_, p_, m, s = objective(t, a.mu, a.sd)
    opt.zero_grad(); (-f).backward(); opt.step()
t = torch.sigmoid(u).detach().clamp(a.tmin, 1 - 1e-6)
f, l_, p_, m, s = objective(t, a.mu, a.sd)
m, s = m.item(), s.item()
q = build(t)
l = t1_loss(q)
print(f"hyp {a.hyp} mu {a.mu} sd {a.sd} shrink {a.shrink}: score_model {f:.3f} = LDS {l_:.3f} x PS {p_:.3f}  "
      f"(loss {m:.2f}±{s:.2f}, D {D:.2f}); t quantiles {[round(v, 4) for v in t.quantile(torch.tensor([.05, .25, .5, .75, .95], device=dev)).tolist()]}")
print(f"  loss quantiles {[round(v, 2) for v in l.quantile(torch.tensor([.1, .5, .75, .9, .95, .99], device=dev)).tolist()]}, "
      f"frac loss>10: {(l > 10).float().mean():.3f}, acc(T2 argmax) {(q.argmax(1) == y).float().mean():.3f}")
# robustness: evaluate the designed q under the OTHER hypotheses and other ridge points
for hn, gh in (("tw", g_tw), ("tail", g_tail), ("blend", 0.5 * g_tw + 0.5 * g_tail)):
    Dh = kl_mean(gh, lq_o)
    ps_h = 1 - kl_mean(gh, q.clamp_min(1e-30).log()) / Dh
    out = []
    for mu in (2.5, 4, 6):
        sd = 12 - mu
        out.append(f"mu{mu}:{(1 - (abs(m - mu) + abs(s - sd)) / (mu + sd)) * ps_h:.3f}")
    print(f"  under gold={hn:5s}: PS {ps_h:.3f}  LDSxPS " + " ".join(out))
if a.name and not a.eval_only:
    z1 = 2 * q.clamp_min(1e-30).log()
    z1 = z1 - z1.mean(1, keepdim=True)
    torch.save({"logits": z1.cpu(), "q2": q.cpu(), "labels": y.cpu(), "t": t.cpu(),
                "stats": dict(hyp=a.hyp, mu=a.mu, sd=a.sd, shrink=a.shrink, loss_mean=m, loss_std=s)},
               ROOT / "output" / "targets" / f"dz_{a.name}.pt")
    print("  wrote", ROOT / "output" / "targets" / f"dz_{a.name}.pt")
