"""Submission v3 (CPU only) = v2 + extra sources (multi-layer heads, StegaStamp occlusion head, re-marking,
more U-Net architectures) + a regressed per-image area rule.

v2 description: Per method, everything validated by 5-fold CV on out-of-fold (OOF) train maps:
  1. single sources                      (head, U-Nets, synthetic zero-shot U-Net)
  2. fusion: logistic regression per cell on [source logits, g, g x logits]   (trained in CV -> OOF fused map)
  3. thresholding rule: 'switch' (regime from g + one threshold per regime), expected-area top-k per image, Otsu
     (+ the per-image oracle threshold, as an upper bound only)
  4. post-processing per predicted type (T: fill small holes / opening; F: drop small blobs, keep largest,
     closing, fill holes, box replacement for near-rectangular regions)
Choices at every step are made on training folds only (nested where it matters); the final pipeline is refitted on
the whole train split and applied to test.

    python v2.py                 # report + writes ../submissions/submission_v2.pt (no upload)
    python v2.py --submit        # same, then uploads if the expected CV beats v1 (0.5629)
"""
import argparse
import glob
import json
import os
import sys
from itertools import product
from pathlib import Path

import numpy as np
import torch
from scipy import ndimage as ndi

TASK = Path("/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task")
sys.path.insert(0, str(TASK / "loc")); sys.path.insert(0, str(TASK / "starter_kit"))
from common import load_split, CACHE, folds  # noqa: E402
from evalkit import cv_eval, fit_switch, apply_switch, miou_batch  # noqa: E402
from heads import fit_logreg, predict_logreg  # noqa: E402

HERE = Path(__file__).resolve().parent; ROOT = HERE.parent
METHODS = ("pixelseal", "trustmark", "stegastamp")
V1_CV = 0.5629
UNET_RUNS = ("effb3_hp_glob", "effb3_hp_glob_stack", "rgb_hp_glob_synth8k")
torch.set_num_threads(16)


def load_rect(meth, split):
    """Boxes found by the teammate's blind rectangle search (loc/rect_search.py, read-only): name -> (mask128, bit acc)."""
    import glob
    from common import downsample_mask
    out = {}
    files = glob.glob(str(CACHE / f"rect_{meth}_{split}_*.npz"))
    if not os.environ.get("WMLOC_NO_RECT2"):                           # WMLOC_NO_RECT2=1 replays versions made before rect2 (<= v4b)
        files += glob.glob(str(HERE / "maps" / f"rect2_{meth}_{split}_*.npz"))
    if not os.environ.get("WMLOC_NO_RECT3"):                           # pairs-of-edges search (rect_pairs.py); off to replay <= v9
        files += glob.glob(str(HERE / "maps" / f"rect3_{meth}_{split}_*.npz"))
    for f in files:                                                    # + map-seeded search (rect_seeded.py); keep the best acc
        d = np.load(f)
        for n, (y0, y1, x0, x1), acc in zip(d["names"], d["boxes"], d["acc"]):
            if str(n) in out and out[str(n)][1] >= float(acc):
                continue
            m = np.zeros((512, 512), np.uint8); m[int(y0):int(y1), int(x0):int(x1)] = 1
            out[str(n)] = (downsample_mask(m).astype(bool), float(acc))
    return out


def logit(p):
    p = np.clip(p.astype(np.float32), 1e-4, 1 - 1e-4); return np.log(p / (1 - p))


def g_of(split, names, meta):
    gl = np.load(CACHE / f"global_{split}.npy", allow_pickle=True).item()
    lut = {n: l for m in METHODS for n, l in zip(gl[m]["names"], gl[m]["logits"])}
    return np.array([(lut[n] * (np.array([int(c) for c in meta[n]["message"]]) * 2. - 1)).mean() for n in names])


def load_sources(meth, n_tr, n_te, unet_runs=UNET_RUNS, extras=("headmulti", "remark", "headsyn")):
    """-> {source: (train logits [N,128,128], test logits [M,128,128])}"""
    S = {}
    def by_name(path, names):
        z = np.load(path); d = dict(zip(z["names"].tolist(), z["prob"])); return np.stack([d[n] for n in names])
    for v in unet_runs:
        S[v] = (logit(by_name(ROOT / "runs" / v / "oof_all.npz", n_tr)), logit(by_name(ROOT / "runs" / v / "test_mean.npz", n_te)))
    sp = ROOT / "synth" / "runs_synth" / "r34_hp_40k"
    S["synth_zeroshot"] = (logit(by_name(sp / "real_train_probs.npz", n_tr)), logit(by_name(sp / "real_test_probs.npz", n_te)))
    for extra in extras:                                                   # optional CPU-built sources
        pa, pb = HERE / "maps" / f"{extra}_train_{meth}.npz", HERE / "maps" / f"{extra}_test_{meth}.npz"
        if pa.exists() and pb.exists():
            za, zb = np.load(pa), np.load(pb); assert za["names"].tolist() == n_tr and zb["names"].tolist() == n_te
            S[extra] = (za["logit128"].astype(np.float32), zb["logit128"].astype(np.float32))
    if meth != "stegastamp":
        a = np.load(HERE / "maps" / f"head_train_{meth}.npz"); b = np.load(HERE / "maps" / f"head_test_{meth}.npz")
        assert a["names"].tolist() == n_tr and b["names"].tolist() == n_te
        S["head"] = (a["logit128"].astype(np.float32), b["logit128"].astype(np.float32))
    return S


# ---------------------------------------------------------------- fusion
def fuse_feats(maps, g):
    X = [np.clip(m, -8, 8) for m in maps]; G = np.broadcast_to((g / 5)[:, None, None], maps[0].shape)
    return np.stack(X + [G] + [x * G for x in X], -1)                     # [N,128,128,F]


def fit_fusion(F_, gt, idx):
    sub = F_[idx][:, ::2, ::2].reshape(-1, F_.shape[-1]); y = gt[idx][:, ::2, ::2].reshape(-1).astype(np.float32)
    return fit_logreg(sub, y, wd=1e-4, iters=200, dev="cpu")


def apply_fusion(model, F_):
    return predict_logreg(model, F_.reshape(-1, F_.shape[-1]), dev="cpu").reshape(F_.shape[:3])


def oof_fusion(F_, gt):
    out = np.zeros(F_.shape[:3], np.float32)
    for f in folds(len(F_), 5, 2):
        out[f] = apply_fusion(fit_fusion(F_, gt, np.setdiff1d(np.arange(len(F_)), f)), F_[f])
    return out


# ---------------------------------------------------------------- thresholding rules (per image scores)
def otsu(v):
    h, e = np.histogram(v, 64); c = (e[:-1] + e[1:]) / 2; w = np.cumsum(h); w2 = w[-1] - w
    m1 = np.cumsum(h * c) / np.maximum(w, 1); m2 = (np.sum(h * c) - np.cumsum(h * c)) / np.maximum(w2, 1)
    return c[np.argmax(w * w2 * (m1 - m2) ** 2)]


def rule_preds(L, g, gt, tr_idx):
    """Binary predictions for every rule, thresholds fitted on tr_idx only."""
    p = fit_switch(L, gt, g, tr_idx); out = {"switch": apply_switch(L, g, p)}
    P = 1 / (1 + np.exp(-L)); k = P.reshape(len(L), -1).sum(1)            # expected number of watermarked cells
    flat = L.reshape(len(L), -1); order = np.argsort(-flat, 1); topk = np.zeros_like(flat, bool)
    for i in range(len(L)):
        topk[i, order[i, :int(round(k[i]))]] = True
    out["expected_area"] = topk.reshape(L.shape)
    regT = g > p["tg"]
    ot = np.stack([L[i] > otsu(L[i]) for i in range(len(L))])
    out["otsu_in_regime"] = np.where(regT[:, None, None], ot | (L > p["t_hi"]), ot & (L > p["t_lo"]))
    # regressed area: ridge regression (fitted on tr_idx) of the oracle-best fraction of watermarked cells
    Fx = area_feats(L, g); fstar = oracle_fraction(L[tr_idx], gt[tr_idx])
    mu, sd = Fx[tr_idx].mean(0), Fx[tr_idx].std(0) + 1e-6; Z = (Fx - mu) / sd
    A = np.c_[Z[tr_idx], np.ones(len(tr_idx))]; yv = np.log(np.clip(fstar, 1e-3, 1 - 1e-3) / (1 - np.clip(fstar, 1e-3, 1 - 1e-3)))
    w = np.linalg.solve(A.T @ A + 1.0 * np.eye(A.shape[1]), A.T @ yv)
    fhat = 1 / (1 + np.exp(-(np.c_[Z, np.ones(len(Z))] @ w))); reg = np.zeros_like(flat)
    for i in range(len(L)):
        reg[i, order[i, :int(round(fhat[i] * flat.shape[1]))]] = True
    out["regressed_area"] = reg.reshape(L.shape)
    return out, p



def rule_preds_any(L, g, gt, tr_idx):
    """rule_preds + Agent B's 'maximum expected mIoU' rules (stack/rule_emiou.py: emiou_none and hybrids emiouT|<rule>)
    when WMLOC_RULES_PLUS=1 (set by --rules_plus; versions >= v9). Without it: exactly rule_preds."""
    if os.environ.get("WMLOC_RULES_PLUS"):
        from rule_emiou import rule_preds_plus
        return rule_preds_plus(L, g, gt, tr_idx)
    return rule_preds(L, g, gt, tr_idx)

def area_feats(L, g):
    P = 1 / (1 + np.exp(-L.reshape(len(L), -1)))
    q = np.quantile(P, [0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95], axis=1).T
    return np.c_[g / 5, P.mean(1), (P > 0.5).mean(1), q, P.std(1)]


def oracle_fraction(L, gt, grid=np.linspace(0, 1, 51)):
    flat = L.reshape(len(L), -1); srt = -np.sort(-flat, 1); best = np.zeros(len(L)); fbest = np.zeros(len(L))
    for f in grid:
        k = int(round(f * flat.shape[1])); th = srt[:, k - 1][:, None, None] if k > 0 else np.full((len(L), 1, 1), np.inf)
        s = miou_batch(L >= th, gt); upd = s > best; best[upd] = s[upd]; fbest[upd] = f
    return fbest


def cv_rules(L, g, gt):
    """Per-image scores of every rule under 5-fold CV; also the CV-selected rule."""
    S = {}
    for f in folds(len(L), 5, 0):
        tr = np.setdiff1d(np.arange(len(L)), f); preds, _ = rule_preds_any(L, g, gt, tr)
        for r, pr in preds.items():
            S.setdefault(r, np.zeros(len(L)))[f] = miou_batch(pr[f], gt[f])
    return S


def oracle(L, gt):
    th = np.quantile(L.reshape(len(L), -1), np.linspace(0.0, 1.0, 41), axis=1).T     # 41 candidate thresholds per image
    best = np.zeros(len(L))
    for j in range(th.shape[1]):
        best = np.maximum(best, miou_batch(L > th[:, j, None, None], gt))
    return best


# ---------------------------------------------------------------- post-processing
def comps_filter(m, min_size):
    lab, n = ndi.label(m)
    if n == 0:
        return m
    sizes = ndi.sum(m, lab, range(1, n + 1)); keep = np.zeros(n + 1, bool); keep[1:] = sizes >= min_size
    return keep[lab]


def keep_largest(m):
    lab, n = ndi.label(m)
    if n <= 1:
        return m
    sizes = ndi.sum(m, lab, range(1, n + 1)); return lab == (1 + int(np.argmax(sizes)))


def box_if_rect(m, r):
    ys, xs = np.nonzero(m)
    if len(ys) == 0:
        return m
    box = np.zeros_like(m); box[ys.min():ys.max() + 1, xs.min():xs.max() + 1] = True
    return box if m.sum() / box.sum() >= r else m


POST_T = {"none": lambda m: m,                                            # m = predicted watermark mask, type T
          **{f"fill_holes<{s}": (lambda s: lambda m: ~comps_filter(~m, s))(s) for s in (4, 16, 64, 256)},
          "close_holes3": lambda m: ~ndi.binary_opening(~m, np.ones((3, 3))),
          "close_holes5": lambda m: ~ndi.binary_opening(~m, np.ones((5, 5)))}
POST_F = {"none": lambda m: m,
          **{f"drop<{s}": (lambda s: lambda m: comps_filter(m, s))(s) for s in (4, 16, 64, 256)},
          "largest": keep_largest,
          "close3+fill": lambda m: ndi.binary_fill_holes(ndi.binary_closing(m, np.ones((3, 3)))),
          "drop<16+close5+fill": lambda m: ndi.binary_fill_holes(ndi.binary_closing(comps_filter(m, 16), np.ones((5, 5)))),
          **{f"drop<16+box>={r}": (lambda r: lambda m: box_if_rect(comps_filter(m, 16), r))(r) for r in (0.7, 0.85)}}


def post_scores(pred, gt, typ_T):
    """Per-image scores for each post-processing of its predicted type (other images keep 'none')."""
    out = {}
    for name, fn in POST_T.items():
        out[("T", name)] = np.array([miou_batch(fn(pred[i])[None], gt[i][None])[0] if typ_T[i] else np.nan for i in range(len(pred))])
    for name, fn in POST_F.items():
        out[("F", name)] = np.array([miou_batch(fn(pred[i])[None], gt[i][None])[0] if not typ_T[i] else np.nan for i in range(len(pred))])
    return out


def cv_select(scores, mask):
    """CV selection of one option among `scores` {name: per-image score}, restricted to images in mask."""
    idx = np.where(mask)[0]; chosen = np.zeros(len(mask))
    for f in folds(len(mask), 5, 3):
        tr = np.intersect1d(np.setdiff1d(np.arange(len(mask)), f), idx); te = np.intersect1d(f, idx)
        best = max(scores, key=lambda k: np.nanmean(scores[k][tr]))
        chosen[te] = scores[best][te]
    return chosen[idx], max(scores, key=lambda k: np.nanmean(scores[k][idx]))


def cv_choice(scores, mask):
    """Same folds/selection as cv_select, but returns the option chosen for each image (None outside mask)."""
    idx = np.where(mask)[0]; choice = np.full(len(mask), None, object)
    for f in folds(len(mask), 5, 3):
        tr = np.intersect1d(np.setdiff1d(np.arange(len(mask)), f), idx); te = np.intersect1d(f, idx)
        choice[te] = max(scores, key=lambda k: np.nanmean(scores[k][tr]))
    return choice


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--submit", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "submissions" / "submission_v3.pt"))
    ap.add_argument("--runs", nargs="+", default=list(UNET_RUNS), help="U-Net runs used as sources")
    ap.add_argument("--select", action="store_true", help="per method, only the sources kept by ablate.py (maps/select_<method>.json), one fusion")
    ap.add_argument("--dump", action="store_true", help="save the fused maps (train OOF, test) to maps/fused_<split>_<method>.npz")
    ap.add_argument("--rect", action="store_true", help="final step: replace type-F masks by the searched box when its bit acc >= thr (thr by CV)")
    ap.add_argument("--baseline_cv", type=float, default=0.5932, help="submit only above this expected CV")
    ap.add_argument("--rules_plus", action="store_true", help="also offer Agent B's expected-mIoU rules (rule_emiou.py) to the CV rule choice")
    ap.add_argument("--extras", nargs="*", default=["headmulti", "remark", "headsyn"],
                    help="optional sources from stack/maps (v3a = headmulti remark)")
    ap.add_argument("--oof_out", default=None,
                    help="also save the out-of-fold (validation) binary masks of the final pipeline on the train split")
    a = ap.parse_args()
    if a.rules_plus:
        os.environ["WMLOC_RULES_PLUS"] = "1"                           # read by rule_preds_any (and by sam_stage via the json)
    if a.oof_out and a.rect:
        sys.exit("--oof_out is not implemented together with --rect")
    tr_all, te_all = load_split("train"), load_split("test")
    meta_tr = {m["image_name"]: m for m in tr_all.meta}; meta_te = {m["image_name"]: m for m in te_all.meta}
    final_masks, report, lines = {}, {}, []
    oof_masks, oof_typT = {}, {}
    for meth in METHODS:
        n_tr = [m["image_name"] for m in tr_all.meta if m["method"] == meth]; n_te = [m["image_name"] for m in te_all.meta if m["method"] == meth]
        g_tr, g_te = g_of("train", n_tr, meta_tr), g_of("test", n_te, meta_te)
        gt = np.stack([tr_all.m128[n] for n in n_tr]).astype(bool); full = np.array([meta_tr[n]["full_watermark"] for n in n_tr])
        S = load_sources(meth, n_tr, n_te, a.runs, a.extras)
        if a.select:                                                   # simplified pipeline: sources kept by ablate.py
            sel = json.loads((HERE / "maps" / f"select_{meth}.json").read_text())["selected"]
            S = {k: S[k] for k in sel}
        # 1. single sources
        cands = {}
        for k, (L, _) in S.items():
            s = cv_eval(L, gt, g_tr, "switch"); cands[k] = (s.mean(), L, S[k][1], None)
            lines.append(f"| {meth} | source {k} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
        # 2. fusions
        ranked = sorted(S, key=lambda k: -cands[k][0])
        combos = ((("fusion selected", ranked),) if len(ranked) > 1 else ()) if a.select else \
            (("fusion top2", ranked[:2]), ("fusion top3", ranked[:3]), ("fusion all", ranked))
        for name, srcs in combos:
            Ftr = fuse_feats([S[k][0] for k in srcs], g_tr); L = oof_fusion(Ftr, gt)
            s = cv_eval(L, gt, g_tr, "switch"); cands[name] = (s.mean(), L, None, srcs)
            lines.append(f"| {meth} | {name} {srcs} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
            print(lines[-1], flush=True)
        best = max(cands, key=lambda k: cands[k][0]); _, Lb, _, srcs = cands[best]
        # 3. thresholding rules on the best map
        R = cv_rules(Lb, g_tr, gt); orc = oracle(Lb, gt)
        for r, s in R.items():
            lines.append(f"| {meth} | {best} + rule {r} | {s.mean():.4f} | {s[full].mean():.4f} | {s[~full].mean():.4f} |")
        lines.append(f"| {meth} | {best} + ORACLE per-image threshold (upper bound) | {orc.mean():.4f} | {orc[full].mean():.4f} | {orc[~full].mean():.4f} |")
        s_rule, rule = cv_select(R, np.ones(len(Lb), bool)); s_rule_full = np.zeros(len(Lb)); s_rule_full[:] = s_rule
        lines.append(f"| {meth} | {best} + CV-selected rule (whole-train choice: {rule}) | {s_rule.mean():.4f} | {s_rule[full].mean():.4f} | {s_rule[~full].mean():.4f} |")
        # 4. post-processing on the CV binary predictions of the chosen rule
        pred = np.zeros(gt.shape, bool); typT = np.zeros(len(Lb), bool)
        for f in folds(len(Lb), 5, 0):
            trn = np.setdiff1d(np.arange(len(Lb)), f); pr, p = rule_preds_any(Lb, g_tr, gt, trn)
            pred[f] = pr[rule][f]; typT[f] = g_tr[f] > p["tg"]
        P = post_scores(pred, gt, typT)
        sT, postT = cv_select({k[1]: v for k, v in P.items() if k[0] == "T"}, typT)
        sF, postF = cv_select({k[1]: v for k, v in P.items() if k[0] == "F"}, ~typT)
        s_post = np.zeros(len(Lb)); s_post[typT] = sT; s_post[~typT] = sF
        if a.oof_out:                                                  # OOF masks behind s_post (post chosen per fold)
            cT = cv_choice({k[1]: v for k, v in P.items() if k[0] == "T"}, typT)
            cF = cv_choice({k[1]: v for k, v in P.items() if k[0] == "F"}, ~typT)
            oof = np.stack([POST_T[cT[i]](pred[i]) if typT[i] else POST_F[cF[i]](pred[i]) for i in range(len(pred))])
            assert np.allclose(miou_batch(oof, gt), s_post), "OOF masks do not reproduce the CV scores"
            oof_masks.update(zip(n_tr, oof)); oof_typT.update(zip(n_tr, typT))
        lines.append(f"| {meth} | **v2 pipeline**: {best} + {rule} + post T:{postT} / F:{postF} | **{s_post.mean():.4f}** | {s_post[full].mean():.4f} | {s_post[~full].mean():.4f} |")
        rect_choice = "none"
        if a.rect and load_rect(meth, "test"):                         # only where test boxes exist (not StegaStamp yet)
            B = load_rect(meth, "train")
            final = np.stack([POST_T[postT](pred[i]) if typT[i] else POST_F[postF](pred[i]) for i in range(len(pred))])
            opts = {"none": miou_batch(final, gt)}
            for thr in (0.7, 0.75, 0.8, 0.85, 0.9, 0.95):
                alt = final.copy()
                for i, n in enumerate(n_tr):
                    if not typT[i] and n in B and B[n][1] >= thr:
                        alt[i] = B[n][0]
                opts[f"rect>={thr}"] = miou_batch(alt, gt)
            for k, v in opts.items():
                lines.append(f"| {meth} | + rect override {k} (boxes for {len(B)} train images) | {v.mean():.4f} | {v[full].mean():.4f} | {v[~full].mean():.4f} |")
            s_rect, rect_choice = cv_select(opts, np.ones(len(n_tr), bool))
            lines.append(f"| {meth} | **v3 + rect, CV-selected** (whole-train choice: {rect_choice}) | **{s_rect.mean():.4f}** | {s_rect[full].mean():.4f} | {s_rect[~full].mean():.4f} |")
            s_post = s_rect
        print("\n".join(lines[-10:]), flush=True)
        # 5. refit on the whole train split, apply to test
        if srcs is None:
            L_te = cands[best][2]
        else:
            model = fit_fusion(fuse_feats([S[k][0] for k in srcs], g_tr), gt, np.arange(len(n_tr)))
            L_te = apply_fusion(model, fuse_feats([S[k][1] for k in srcs], g_te))
        if a.dump:
            np.savez(HERE / "maps" / f"fused_train_{meth}.npz", names=np.array(n_tr), logit128=Lb.astype(np.float16), g=g_tr)
            np.savez(HERE / "maps" / f"fused_test_{meth}.npz", names=np.array(n_te), logit128=np.asarray(L_te).astype(np.float16), g=g_te)
        preds_te, p = rule_preds_any(np.concatenate([Lb, L_te]), np.concatenate([g_tr, g_te]),
                                 np.concatenate([gt, np.zeros((len(n_te),) + gt.shape[1:], bool)]), np.arange(len(n_tr)))
        m_te = preds_te[rule][len(n_tr):]; tT = g_te > p["tg"]
        m_te = np.stack([POST_T[postT](m_te[i]) if tT[i] else POST_F[postF](m_te[i]) for i in range(len(n_te))])
        if rect_choice != "none":
            thr = float(rect_choice.split(">=")[1]); Bt = load_rect(meth, "test"); n_used = 0
            for i, n in enumerate(n_te):
                if not tT[i] and n in Bt and Bt[n][1] >= thr:
                    m_te[i] = Bt[n][0]; n_used += 1
            print(f"{meth}: rect override on {n_used} test images (boxes available for {len(Bt)})", flush=True)
        final_masks.update(zip(n_te, m_te))
        report[meth] = dict(map=best, sources=srcs, rule=rule, post_T=postT, post_F=postF, rect=rect_choice, cv=round(float(s_post.mean()), 4),
                            cv_T=round(float(s_post[full].mean()), 4), cv_F=round(float(s_post[~full].mean()), 4),
                            test_frac_pred_1=round(float(m_te.mean()), 3))
    names = [m["image_name"] for m in te_all.meta]; masks = np.stack([final_masks[n] for n in names])
    assert len(names) == len(set(names)) == 1020 and masks.shape == (1020, 128, 128)
    out = Path(a.out); torch.save({"image_names": names, "masks": torch.from_numpy(masks).bool()}, out)
    re = torch.load(out, weights_only=True); assert re["image_names"] == names and re["masks"].dtype == torch.bool
    size = os.path.getsize(out) / 2 ** 20; assert size < 20
    report["rules_plus"] = bool(a.rules_plus)
    report["rect3"] = bool(not os.environ.get("WMLOC_NO_RECT3") and glob.glob(str(HERE / "maps" / "rect3_*.npz")))  # sam_stage replays with the same boxes
    report["expected_cv_mIoU"] = round(float(np.mean([report[m]["cv"] for m in METHODS])), 4); report["v1_cv"] = V1_CV
    report["file"] = str(out); report["size_MB"] = round(size, 2)
    hdr = ["| method | config | mIoU (CV) | type T | type F |", "|---|---|---|---|---|"]
    (ROOT / f"results_{out.stem}.md").write_text("\n".join(hdr + lines) + "\n\n```json\n" + json.dumps(report, indent=1) + "\n```\n")
    out.with_suffix(".json").write_text(json.dumps(report, indent=1)); print(json.dumps(report, indent=1))
    if a.oof_out:
        n_tr_all = [m["image_name"] for m in tr_all.meta]
        oof = torch.from_numpy(np.stack([oof_masks[n] for n in n_tr_all])).bool()
        torch.save({"image_names": n_tr_all, "masks": oof,
                    "method": [meta_tr[n]["method"] for n in n_tr_all],
                    "pred_type_T": [bool(oof_typT[n]) for n in n_tr_all]}, a.oof_out)
        print(f"OOF validation masks: {tuple(oof.shape)} -> {a.oof_out}")
    if a.submit:
        if report["expected_cv_mIoU"] > a.baseline_cv:
            sys.path.insert(0, str(TASK / "starter_kit")); from submission_template import submit; submit(str(out))
        else:
            print(f"NOT submitted: expected CV {report['expected_cv_mIoU']} <= baseline {a.baseline_cv}")


if __name__ == "__main__":
    main()
