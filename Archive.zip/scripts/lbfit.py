"""Test gold hypotheses against the leaderboard: for each hypothesis H of the per-image gold distribution (T=2),
predict every scored checkpoint's public score with the official formula and compare to the actual score.

pred = LDS(mu, sigma) * PS(H) * retain(c),  LDS/PS averaged over the clean and mild views (mild = proxy for altered).
mu, sigma (gold loss mean/std) and c (control KL = c * proxy_kl) are fitted per hypothesis by grid search.
"""
import csv, glob, itertools, json, sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parent.parent
LB = ROOT / "output" / "lbfit"
T = 2.0

rows = list(csv.DictReader(open(ROOT / "output" / "results.csv")))
pkl = {(r["run"], r["step"]): float(r["proxy_kl"]) if r["proxy_kl"] else np.nan for r in rows}
subs = []
for r in csv.DictReader(open(ROOT / "output" / "submissions.csv")):
    if not r["score"]:
        continue
    key = r["file"].replace("output/", "").replace("/", "__").replace(".pt", "")
    if not (LB / f"{key}.pt").exists():
        continue
    run = r["file"].split("/")[1]
    step = r["file"].split("ckpt_")[-1].replace(".pt", "").lstrip("0") if "ckpt_" in r["file"] else ""
    subs.append(dict(key=key, score=float(r["score"]), pkl=pkl.get((run, step), np.nan)))
# dedupe keys (same ckpt submitted twice)
seen = {}
for s in subs:
    seen[s["key"]] = s
subs = list(seen.values())
orig = torch.load(LB / "orig.pt")
Z = {s["key"]: torch.load(LB / f"{s['key']}.pt") for s in subs}
y = orig["clean"].float().argmax(1)
N = len(y)
for s in subs:
    if np.isnan(s["pkl"]):
        s["pkl"] = 0.3  # headbias: unknown, rough
score = np.array([s["score"] for s in subs])


def logp(z, t=T):
    return F.log_softmax(z.float() / t, -1)


def loss_stats(z):
    l = F.cross_entropy(z.float(), y, reduction="none")
    return l.mean().item(), l.std().item()


def kl(pg, lq):  # pg probs, lq log probs -> mean KL
    return (pg * (pg.clamp_min(1e-12).log() - lq)).sum(1).mean().item()


LS = {k: {v: loss_stats(Z[k][v]) for v in ("clean", "mild")} for k in Z}
LS_o = {v: loss_stats(orig[v]) for v in ("clean", "mild")}
LQ = {k: {v: logp(Z[k][v]) for v in ("clean", "mild")} for k in Z}
LQ_o = {v: logp(orig[v]) for v in ("clean", "mild")}


def ps_vec(H):
    """H: dict view -> gold probs [N,100] at T=2. returns PS per checkpoint (avg over views)."""
    out = []
    for s in subs:
        v_ps = []
        for v in ("clean", "mild"):
            d = kl(H[v], LQ_o[v])
            v_ps.append(1 - np.clip(kl(H[v], LQ[s["key"]][v]) / d, 0, 1))
        out.append(np.mean(v_ps))
    return np.array(out)


def lds_vec(mu, sd):
    out = []
    for s in subs:
        v = []
        for vw in ("clean", "mild"):
            m, st = LS[s["key"]][vw]
            mo, so = LS_o[vw]
            d = abs(m - mu) + abs(st - sd)
            do = abs(mo - mu) + abs(so - sd)
            v.append(1 - np.clip(d / do, 0, 1))
        out.append(np.mean(v))
    return np.array(out)


MUS = np.arange(1, 12.01, 0.5)
SDS = np.arange(1, 14.01, 0.5)
LDS = {(mu, sd): lds_vec(mu, sd) for mu in MUS for sd in SDS}
PK = np.array([s["pkl"] for s in subs])
CS = [0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5]


def fit(ps):
    best = None
    for (mu, sd), l in LDS.items():
        for c in CS:
            pred = l * ps / (1 + c * PK)
            sse = ((pred - score) ** 2).sum()
            if best is None or sse < best[0]:
                best = (sse, mu, sd, c, pred)
    sse, mu, sd, c, pred = best
    ra = np.argsort(np.argsort(pred)); rb = np.argsort(np.argsort(score))
    rho = np.corrcoef(ra, rb)[0, 1]
    return dict(rmse=float(np.sqrt(sse / len(score))), mu=mu, sd=sd, c=c, rho=float(rho), pred=pred)


# ------------------------------------------------------------------ hypotheses
H = {}
tw = {}
for f in sorted(glob.glob(str(ROOT / "output/twins/s*_sh0.npz"))):
    s = Path(f).name.split("_sh")[0][1:]
    idx, lg = [], []
    for g in sorted(glob.glob(str(ROOT / f"output/twins/s{s}_sh*.npz"))):
        if ".tmp" in g:
            continue
        with np.load(g) as d:
            idx.append(d["idx"]); lg.append(d["logits"])
    idx = np.concatenate(idx); lg = torch.from_numpy(np.concatenate(lg))
    o = np.argsort(idx)
    if len(idx) == N:
        tw[s] = lg[o]
for s, lg in tw.items():
    p = F.softmax(lg / T, -1).mean(1)
    H[f"tw{s}"] = {"clean": p, "mild": p}
# all 12 s0.625 twins (seed 0 k=4 + seed 1 k=8) and blends with the orig tail
if "0.625" in tw and "0.625b" in tw:
    p12 = F.softmax(torch.cat([tw["0.625"], tw["0.625b"]], 1) / T, -1).mean(1)
    H["tw12"] = {"clean": p12, "mild": p12}
    zt_ = orig["clean"].float().clone(); zt_[torch.arange(N), y] = -1e4
    tail_ = F.softmax(zt_ / T, -1)
    for P in (0.2, 0.3):
        for w in (0.5, 0.7):
            pb = w * p12 + (1 - w) * (tail_ * (1 - P) + F.one_hot(y, 100).float() * P)
            H[f"blend12_w{w}_P{P}"] = {"clean": pb, "mild": pb}
# mixtures of twin strengths
if "0.625" in tw and "0.875" in tw:
    for w in (0.25, 0.5):
        p = (1 - w) * H["tw0.625"]["clean"] + w * H["tw0.875"]["clean"]
        H[f"tw.625+.875_w{w}"] = {"clean": p, "mild": p}
# class-removal variants: for the 130-cap classes, gold has (almost) no mass on the true class
CAP = torch.tensor([0, 6, 7, 8, 29, 30, 31, 33, 38])
capm = torch.isin(y, CAP)
for base in [k for k in list(H) if k.startswith("tw")]:
    for keep in (0.0, 0.05):
        Hv = {}
        for v in ("clean", "mild"):
            p = H[base][v].clone()
            p[capm, y[capm]] *= keep
            Hv[v] = p / p.sum(1, keepdim=True)
        H[f"{base}_cap{keep}"] = Hv
# tempered orig
for tau in (1.5, 2, 3, 4, 6, 8):
    H[f"orig_tau{tau}"] = {v: F.softmax(orig[v].float() / (T * tau), -1) for v in ("clean", "mild")}
# orig tail, true-class mass fixed at P (T=2)
for P in (0.3, 0.5, 0.7, 0.85):
    for tt in (1, 2):
        Hv = {}
        for v in ("clean", "mild"):
            z = orig[v].float().clone()
            z[torch.arange(N), y] = -1e4
            tail = F.softmax(z / (T * tt), -1)
            Hv[v] = tail * (1 - P) + F.one_hot(y, 100).float() * P
        H[f"origtail_P{P}_t{tt}"] = Hv
# uniform mixtures
for P in (0.3, 0.5, 0.7):
    p = F.one_hot(y, 100).float() * P + (1 - P) / 100
    H[f"unif_P{P}"] = {"clean": p, "mild": p}
# best-scoring submissions as hypotheses (sanity)
for k in ("scrubF_cap32__ckpt_00660", "scrubB_C_lr3e-5_T4__ckpt_00240", "an_tail1_e20_lr2e-4__ckpt_00810"):
    H[f"sub:{k}"] = {v: F.softmax(Z[k][v].float() / T, -1) for v in ("clean", "mild")}

res = []
for name, Hv in H.items():
    ps = ps_vec(Hv)
    r = fit(ps)
    ent = -(Hv["clean"] * Hv["clean"].clamp_min(1e-12).log()).sum(1).mean().item()
    pt = Hv["clean"][torch.arange(N), y].mean().item()
    res.append((r["rmse"], name, r, ent, pt, ps))
res.sort(key=lambda t: t[0])
print(f"{'hypothesis':34s} rmse   rho   mu   sd   c   | H_ent  p_true | PS(best sub)")
for rmse, name, r, ent, pt, ps in res:
    i = int(np.argmax(score))
    print(f"{name:34s} {rmse:.4f} {r['rho']:.2f} {r['mu']:.2f} {r['sd']:.2f} {r['c']:.2f} | {ent:.2f} {pt:.2f} | {ps[i]:.3f} max {ps.max():.3f}")
best = res[0]
print("\nbest:", best[1])
for s, p, ps in sorted(zip(subs, best[2]["pred"], best[5]), key=lambda t: -t[0]["score"]):
    print(f"  {s['key'][:48]:48s} actual {s['score']:.4f} pred {p:.4f}  PS {ps:.3f}  "
          f"L {LS[s['key']]['clean'][0]:.2f}±{LS[s['key']]['clean'][1]:.2f}")
