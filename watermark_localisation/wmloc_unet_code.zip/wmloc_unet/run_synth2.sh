#!/bin/bash
#SBATCH --account=training2666
#SBATCH --nodes=1
#SBATCH --gres=gpu:4
#SBATCH --cpus-per-task=64
#SBATCH --partition=dc-gpu
#SBATCH --reservation=cispahack
#SBATCH --time=01:50:00
#SBATCH --job-name=wm_synth2
#SBATCH --output=/p/project1/training2666/debbah2/wmloc_unet/logs/synth2_%j.out
# The team's ONE node (cispahack is MAGNETIC: every training2666 dc-gpu job lands in it anyway).
# Submit only when no other team job exists (CLAUDE.md check), from the team folder:
#   cd /p/scratch/training2666/ayadi1/automateam2 && sbatch /p/project1/training2666/debbah2/wmloc_unet/run_synth2.sh
#
# GPU0: synthetic pre-training EfficientNet-B3, REALISTIC edits (30k steps) -> "everything connected" U-Net from it
# GPU1: synthetic pre-training EfficientNet-B3, original edits (30k; the run lost earlier) -> same fine-tune
# GPU2: "everything connected" ResNet34 from the existing synthetic r34_hp_40k model, then rgb_hp_glob from r34 40k
# GPU3: "everything connected" EfficientNet-B3, second seed-free variant with residual maps (diversity for the fusion)
# Then: CV evaluation of every run and the v3 fusion (candidate file, NOT uploaded).
export PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 OMP_NUM_THREADS=4
export HF_HOME=/p/project1/training2666/debbah2/wmloc_unet/hf HUGGINGFACE_HUB_CACHE=/p/project1/training2666/debbah2/wmloc_unet/hf/hub
PY=/p/scratch/training2666/ayadi1/automateam2/Hackathon_Watermark_Localisation_Task/.venv/bin/python
R=/p/project1/training2666/debbah2/wmloc_unet; cd $R
EFF=efficientnet_b3.ra2_in1k
tagged() { grep --line-buffered -v -i -E "warn|Unexpected keys|ffmpeg" | sed -u "s/^/[$1] /"; }

( CUDA_VISIBLE_DEVICES=0 $PY synth/train_synth.py --name effb3_hp_30k_real --encoder $EFF --realistic --steps 30000 --eval_every 10000 --workers 15 &&
  CUDA_VISIBLE_DEVICES=0 $PY train_unet.py --variant effb3_hp_glob_stack --epochs 60 --init synth/runs_synth/effb3_hp_30k_real/model.pt --tag synthR ) 2>&1 | tagged gpu0 &
( CUDA_VISIBLE_DEVICES=1 $PY synth/train_synth.py --name effb3_hp_30k --encoder $EFF --steps 30000 --eval_every 10000 --workers 15 &&
  CUDA_VISIBLE_DEVICES=1 $PY train_unet.py --variant effb3_hp_glob_stack --epochs 60 --init synth/runs_synth/effb3_hp_30k/model.pt --tag synth ) 2>&1 | tagged gpu1 &
( CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant r34_hp_glob_stack --epochs 60 --init synth/runs_synth/r34_hp_40k/model.pt --tag synth40k &&
  CUDA_VISIBLE_DEVICES=2 $PY train_unet.py --variant rgb_hp_glob --epochs 60 --init synth/runs_synth/r34_hp_40k/model.pt --tag synth40k ) 2>&1 | tagged gpu2 &
( CUDA_VISIBLE_DEVICES=3 $PY train_unet.py --variant effb3_hp_glob_stack_resaux --epochs 60 ) 2>&1 | tagged gpu3 &
wait

$PY eval_unet.py 2>&1 | grep -v -i warn
cd stack && CUDA_VISIBLE_DEVICES="" $PY v3.py --out ../submissions/submission_v3_job.pt --runs effb3_hp_glob effb3_hp_glob_stack rgb_hp_glob_synth8k \
  effb3_hp_glob_stack_synthR effb3_hp_glob_stack_synth r34_hp_glob_stack_synth40k rgb_hp_glob_synth40k effb3_hp_glob_stack_resaux 2>&1 | grep -v -i warn
echo done
