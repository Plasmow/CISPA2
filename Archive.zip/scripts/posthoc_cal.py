"""Post-hoc head calibration test (2026-11-22 10:20): does a global logit scale or a per-class bias correction
(fitted on t2i TRAIN anchors) reduce drift on held-out sets without hurting forget metrics?
Usage: python scripts/posthoc_cal.py CKPT [--write OUT.pt --scale s --bias 1]"""
import argparse, glob, sys
import numpy as np
import torch
import torch.nn.functional as F
import common as C

ap = argparse.ArgumentParser()
ap.add_argument("ckpt")
ap.add_argument("--write", default="")
ap.add_argument("--scale", type=float, default=1.0)
ap.add_argument("--bias", type=int, default=0)
a = ap.parse_args()

teacher, imgs = C.load_all()
ev = C.Evaluator(teacher, imgs)
y = ev.labels
m = C.tt.build_model(); m.load_state_dict(torch.load(a.ckpt, map_location="cpu", weights_only=True)); m = m.to(C.DEVICE).eval()


def load(pat, n=None, last=True):
    fs = sorted(f for pp in pat.split(",") for f in glob.glob(str(C.ROOT / pp)) if ".tmp" not in f)
    x = np.concatenate([np.load(f)["images"].reshape(-1, 224, 224, 3) for f in fs])
    if n:
        x = x[-n:] if last else x[:n]
    return torch.from_numpy(x).to(C.DEVICE)


def lg(model, u8):
    out = []
    with torch.no_grad():
        for i in range(0, len(u8), 200):
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                out.append(model(C.norm(C.u8_to01(u8[i:i + 200]))).float())
    return torch.cat(out)


sets = {"t2i_ho": load("output/t2i/t2i_sh*.npz", 2000), "mem_ho": load("output/mem_anchors.npz", 600),
        "tw625b_ho": load("output/twins/s0.625b_sh*.npz", 1000), "tw875_ho": load("output/twins/s0.875_sh*.npz", 1000)}
fit = load("output/t2i/t2iA_sh*.npz", 4000, last=False)
Z = {k: (lg(teacher, v), lg(m, v)) for k, v in sets.items()}
Z["proxy"] = (ev.t_proxy, ev.sets.logits(m, "proxy"))
zf_o, zf_s = lg(teacher, fit), lg(m, fit)
zc, zm = ev.sets.logits(m, "clean"), ev.sets.logits(m, "mild")


def kl(zo, zs):
    lo, ls = F.log_softmax(zo / 2, -1), F.log_softmax(zs / 2, -1)
    return (lo.exp() * (lo - ls)).sum(1).mean().item()


# per-class bias: mean centred logit difference on the fit set, weighted by orig's predicted class
d = (zf_s - zf_s.mean(1, keepdim=True)) - (zf_o - zf_o.mean(1, keepdim=True))
b = d.mean(0)
print("per-class bias shift: std %.3f  max|.| %.3f" % (b.std().item(), b.abs().max().item()))
# fitted scale on the fit set
best = None
for s in [0.8, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.2, 1.3]:
    v = kl(zf_o, zf_s * s)
    best = (v, s) if best is None or v < best[0] else best
print("fit-set KL by scale -> best s=%.2f" % best[1])
for name, (sc, bb) in {"none": (1.0, 0), "scale*": (best[1], 0), "bias": (1.0, 1), "bias+scale*": (best[1], 1)}.items():
    f = lambda z: (z - bb * b) * sc  # noqa: E731
    row = " ".join(f"{k} {kl(zo, f(zs)):.4f}" for k, (zo, zs) in Z.items())
    lc = F.cross_entropy(f(zc), y, reduction="none"); lm = F.cross_entropy(f(zm), y, reduction="none")
    print(f"{name:12s} {row} | clean {lc.mean():.2f}±{lc.std():.2f} mild {lm.mean():.2f}±{lm.std():.2f}", flush=True)
if a.write:
    sd = {k: v.detach().cpu().float() for k, v in m.state_dict().items()}
    if a.bias:
        sd["head.bias"] = sd["head.bias"] - b.cpu()
    sd["head.weight"] = sd["head.weight"] * a.scale
    sd["head.bias"] = sd["head.bias"] * a.scale
    torch.save(sd, a.write)
    print("wrote", a.write)
