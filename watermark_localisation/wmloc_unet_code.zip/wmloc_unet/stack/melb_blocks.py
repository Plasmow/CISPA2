"""MELB-style block statistics (Bulychev et al., "Where is the Watermark?", 2025): the per-cell message-agreement map
of wam_ft.py is aggregated over k x k blocks of cells (box mean = soft version of MELB's per-block agreement count),
because the v3 fusion is a PER-CELL logistic regression and cannot pool a neighbourhood by itself.
Writes stack/maps/<tag>_b<k>_{train,test}_<method>.npz (same format).    python melb_blocks.py wamna wamda --k 4 8"""
import argparse
from pathlib import Path

import numpy as np
from scipy.ndimage import uniform_filter

HERE = Path(__file__).resolve().parent
ap = argparse.ArgumentParser(); ap.add_argument("tags", nargs="+"); ap.add_argument("--k", nargs="+", type=int, default=[4, 8])
a = ap.parse_args()
for t in a.tags:
    for m in ("pixelseal", "trustmark", "stegastamp"):
        for split in ("train", "test"):
            f = HERE / "maps" / f"{t}_{split}_{m}.npz"
            if not f.exists():
                continue
            d = np.load(f); L = d["logit128"].astype(np.float32)
            for k in a.k:
                B = uniform_filter(L, size=(1, k, k), mode="reflect")
                np.savez(HERE / "maps" / f"{t}_b{k}_{split}_{m}.npz", names=d["names"], logit128=B.astype(np.float16))
                print(f"{t}_b{k} {split} {m} {B.shape}", flush=True)
